# Charts: grid data + chart config (guide)

How every chart on a dashboard is drawn, using only the three existing responses:

| Response | Used by grids | Used by charts |
|---|---|---|
| **Grid config** | ✓ structure, heatmap, totals | ✗ not needed |
| **Grid data** | ✓ one row per desk / item | ✓ one row per date (trend mode) |
| **Chart config** | – | ✓ how to draw (type, series, colours, tooltip) |

> A chart = **its grid's data called in trend mode** + **one chart config entry**. No new API, no grid config for charts.

Sample files in this folder:

```
chart-samples/
  chart-config.json                          ← all charts of the VaR Summary dashboard (new format)
  chart-data/
    standalone-trend.all.json                ← Standalone trend, no desk selected
    standalone-trend.row_1.json              ← Standalone trend, desk row_1 selected
    component-trend.all.json                 ← Component VaR/SVaR trend (stacked)
    fs-type-trend.all.json                   ← FS type trend (stacked)
    limit-history.lim_1493.json              ← Limit history for limit lim_1493
```

---

## 1. What changes

| Response | Change |
|---|---|
| Grid config | **None.** |
| Grid data | **New trend mode.** When called with `view: trend` + `days` + `rowId`, return **one row per date** instead of one row per desk. Same `{ rowData }` format. |
| Chart config | Each chart gets `source`, `params` and one `series[]` list. Shared settings move into `templates`. |

What is removed: the separate trend grid config, and the per-chart keys `valueFields`, `seriesLabels`, `seriesTones`, `seriesStyle` (all merged into `series[]`).

---

## 2. Grid data in trend mode

### Request parameters
The chart sends **all dashboard filters** (cob, pcob, compare, region, variant, attribute, display) **plus**:

| Param | Values | Meaning |
|---|---|---|
| `view` | `trend` | Return rows by date (the grid itself never sends this) |
| `days` | `30` / `60` / `90` | Number of business days, ending at COB |
| `rowId` | `row_3`, `lim_1493`, or `all` | The selected grid row; `all` = total when nothing is selected |

### Response
```json
{ "rowData": [
  { "id": "2026-07-31", "cobDate": "2026-07-31", "mcVar": 144.21, "histVar": 139.80, "mcSvar": 191.55, "histSvar": 187.02 },
  { "id": "2026-08-03", "cobDate": "2026-08-03", "mcVar": 144.97, "histVar": 140.12, "mcSvar": 192.40, "histSvar": 186.71 }
] }
```

### Row rules
| Rule | Detail |
|---|---|
| One row per date | exactly `days` rows, oldest first, last row = COB |
| `id` | the date (unique) |
| `cobDate` | ISO `yyyy-mm-dd`; the UI formats it (Aug 14 / Mon, Aug 31, 2026) |
| Values | raw numbers in the grid's unit ($MM), `-1.23` for negatives, `null` if missing |
| Field names | must match `series[].field` in the chart config |
| Display filter | drop the hidden measure fields (e.g. Display = MC VaR → no `histVar`, `histSvar`, `chvar_*`) |
| Nothing else | no rowType, styling, path, node, ntr, groups or children |

### Fields per chart
| Chart | Fields per row |
|---|---|
| Standalone VaR/SVaR trend | `cobDate, mcVar, histVar, mcSvar, histSvar` |
| Component VaR/SVaR trend | `cobDate, cvar_eqdl … cvar_other, chvar_eqdl … chvar_other` |
| FS type trend | same as Component |
| Limit history | `cobDate, exposure, threshold` |

---

## 3. Chart config

### File shape
```json
{
  "schemaVersion": "2.0",
  "dashboardId": "var-summary",
  "templates": { "trend-line": { … }, "trend-stacked": { … } },
  "charts":    { "standalone-trend-line": { … }, … }
}
```
Loaded **once per dashboard** and cached. The dashboard definition points each chart widget to an entry via `chartConfigId`.

### Keys of one chart
| Key | Required | Meaning |
|---|---|---|
| `template` | – | Name in `templates`; its keys are copied in, the chart's own keys win |
| `source` | ✓ | Which grid's data to call (the grid id, e.g. `standalone-var-svar`) |
| `params` | ✓ | Extra parameters for the call. Bindings: `$filter.days`, `$selection.widget-1.rowId|all` (`|all` = fallback when nothing is selected) |
| `type` | ✓ | `line` · `area` · `column` · `bar` |
| `stacking` | – | `normal` · `percent` |
| `orientation` | ✓ | `timeSeries` (x = date rows) · `rowsAsCategories` (x = name rows) · `fieldsAsCategories` (x = fields) |
| `categoryField` | ✓ | Field for the x-axis (`cobDate` for trends) |
| `series` | ✓ | What to plot, see below. `"*"` = every numeric field in the rows |
| `areaFirstSeries` | – | First series drawn as a soft area |
| `legend` | – | `{ "position": "top" | "bottom" }` |
| `height` | – | Minimum chart height (px) |
| `valueFormat` | – | `{ "decimals": 2 }` |
| `chartTooltip` | – | Black table tooltip (section 4) |
| `colorByRatio`, `referenceLines`, `derivedSeries`, `secondaryAxis` | – | Limit-style charts (section 5) |

### `series[]`: one entry per plotted field
```json
"series": [
  { "field": "mcVar",   "label": "MC VaR",   "tone": "series1" },
  { "field": "histVar", "label": "Hist VaR", "tone": "series2", "dash": "Dash" }
]
```
| Key | Meaning |
|---|---|
| `field` | Key in each grid data row |
| `label` | Legend and tooltip name (always write **VaR**, never VAR) |
| `tone` | Colour token (`series1…4`, `stack1…7`, `warning`, `negative` …). The UI maps tokens to hex. A raw `#hex` is allowed only as an override |
| `dash` | `Dash`, `Dot` … (solid if absent) |
| `stack` | Stacked charts: which stack the series belongs to (e.g. `CVaR` / `CHVaR` side by side) |

Rules:
- **Order** of `series[]` = draw and legend order.
- A series whose field is **missing in the rows is skipped** (Display filter works automatically).
- `"series": "*"` plots every numeric field; labels then fall back to the field name, so prefer an explicit list.

---

## 4. Tooltip (`chartTooltip`)

Shared tooltip: hovering a date shows every series. With `groupingEnabled`, each **label** is split into a row and a column.

| Key | Meaning |
|---|---|
| `separators` | Where to split the label (first match wins) |
| `namePattern` | `column·row`: part before the separator = column. `row·column`: part before = row |
| `groupedRowHeader` | Header of the first column when grouped |
| `rowHeader` | Header when not grouped (fallback if a label can't be split) |
| `columnLabels` | Display text for column keys |
| `footerWhenGrouped` | Adds a totals row per column (stacked charts) |
| `footerLabelSuffix` | Text after the column name in the footer ("CVaR Trend") |

Standalone example: labels `MC VaR`, `Hist VaR`, `MC SVaR`, `Hist SVaR`, separator `" "`, pattern `column·row`:

```
Mon, Aug 31, 2026
Measure   MC ($MM)   Hist ($MM)
VaR       144.35     140.29
SVaR      191.77     187.38
```

Component example: labels `EQDL · CVaR`, separator `" · "`, pattern `row·column` → rows EQDL, ISDL…; columns CVaR, CHVaR; footer = totals per column.

---

## 5. Limit-style chart keys

| Key | Meaning |
|---|---|
| `colorByRatio` | Colours each column by `numerator / denominator` (exposure / threshold) using `thresholds` (≥ 0.8 warning, ≥ 1 negative) |
| `referenceLines` | Draws a field as a line (`threshold` → "Limit") |
| `derivedSeries` | A computed line (`exposure / threshold` → "Utilization %") |
| `secondaryAxis` | Right axis for derived series (`format: percent`, `max`) |

The grid data only sends `exposure` and `threshold`; the UI derives the rest.

---

## 6. When charts load

| Action | Grid | Its chart(s) |
|---|---|---|
| Page load | grid config + grid data | grid data (trend mode) |
| Click / clear a row | – | grid data (trend mode, new `rowId`) |
| Days 30 / 60 / 90 | – | grid data (trend mode, new `days`) |
| Region / COB / Variant / Attribute / Display | grid config + grid data | grid data (trend mode) |

Chart and grid calls run in parallel. Each result is cached by its parameters, so revisiting a selection is instant.

---

## 7. Old → new chart config keys

| Old (v1) | New (v2) |
|---|---|
| `valueFields: ["mcVar", …]` | `series[].field` |
| `seriesLabels: { mcVar: "MC VaR" }` | `series[].label` |
| `seriesTones: { mcVar: "series1" }` / array | `series[].tone` |
| `seriesStyle: { histVar: { dash } }` | `series[].dash` |
| stack read from tooltip label | `series[].stack` |
| repeated settings per chart | `templates` + `template` |
| separate trend grid config | removed |
| (none) | `source`, `params` |

The UI keeps reading v1 keys during migration, so old entries keep working.

---

## 8. Checklists

**Services**
- [ ] Grid data: support `view: trend` with `days` and `rowId` for every grid that has a chart.
- [ ] Return exactly `days` business-day rows ending at COB, fields as in section 2.
- [ ] Apply the Display filter by dropping fields.
- [ ] Stop sending a grid config for trend charts.
- [ ] Chart config (if served by services): move to v2 (`templates`, `source`, `params`, `series[]`).

**UI**
- [ ] Chart widget: call grid data of `source` with filters + resolved `params`; skip grid config.
- [ ] Resolve `template` → merge → build Highcharts options from `series[]`.
- [ ] Keep v1 keys as fallback.
- [ ] Skip series whose field is missing in the rows.

**Adding a new chart**
1. Services: make the grid's data answer `view: trend` with the new fields.
2. Chart config: add one entry (`template`, `source`, `params`, `series`).
3. Definition: add a chart widget with `chartConfigId`.
No UI code change.
