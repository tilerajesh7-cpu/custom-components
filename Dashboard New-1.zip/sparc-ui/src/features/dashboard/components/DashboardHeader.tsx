import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import type { GridResponse } from '@shared/lib/contract/gridResponse';
import { downloadText, gridResponseToRows, rowsToCsv, safeFileName } from '@shared/lib/export/csv';
import { fmtDisplayDate } from '@shared/lib/format/date';
import { DatePill, IconButton, MenuList, PageHeader, Popover, SegmentedControl, SettingsPanel, type MenuItem } from '@shared/ui';
import { useDashboardContext } from '../context';
import { toSearch } from '../lib/filters';
import { dashboardActions, selectDensity } from '../model/dashboardSlice';
import type { FilterValue } from '../model/types';
import styles from './DashboardView.module.css';

interface Props {
  settingsOpen: boolean;
  setSettingsOpen: (v: boolean) => void;
  openHelp: () => void;
}

export function DashboardHeader({ settingsOpen, setSettingsOpen, openHelp }: Props) {
  const { dashboardId, definition, filterDefs, filters } = useDashboardContext();
  const dispatch = useDispatch();
  const density = useSelector(selectDensity);
  const location = useLocation();
  const queryClient = useQueryClient();
  const [copied, setCopied] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const actions = definition.header.actions;
  const setFilter = (id: string, value: FilterValue) => dispatch(dashboardActions.setFilter({ dashboardId, id, value }));

  const copyLink = () => {
    const url = `${window.location.origin}${window.location.pathname}#${location.pathname}?${toSearch(filterDefs, filters)}`;
    const done = () => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    };
    if (navigator.clipboard) navigator.clipboard.writeText(url).then(done, done);
    else done();
  };

  const exportAllCsv = () => {
    const parts: string[] = [];
    definition.widgets.forEach((w) => {
      const hits = queryClient.getQueriesData<GridResponse>({ queryKey: ['widget-data', w.endpoint] }).filter(([, d]) => d);
      const data = hits[hits.length - 1]?.[1];
      if (data) parts.push(`${w.title}\n${rowsToCsv(gridResponseToRows(data))}`);
    });
    downloadText(`${safeFileName(definition.title)}_${filters.cob ?? ''}.csv`, parts.join('\n\n'));
  };

  const settingsItems: MenuItem[] = [
    { id: 'help', label: 'Keyboard shortcuts', icon: 'keyboard', shortcut: '?', onClick: () => { setSettingsOpen(false); openHelp(); } },
    { id: 'reset', label: 'Reset grid layout', icon: 'columns', onClick: () => { dispatch(dashboardActions.resetLayout({ dashboardId })); setSettingsOpen(false); } },
  ];

  const headerFields = filterDefs.filter((f) => f.placement === 'header');

  return (
    <PageHeader
      breadcrumb={definition.breadcrumb}
      title={definition.title}
      actions={
        <>
          {headerFields.map((f) => {
            const v = filters[f.id];
            if (f.type === 'date' || f.display === 'date') {
              return (
                <DatePill
                  key={f.id}
                  label={f.label}
                  icon={f.type === 'derived' ? 'swap' : 'calendar'}
                  value={f.editable ? String(v ?? '') : v ? fmtDisplayDate(String(v)) : '—'}
                  onChange={f.editable ? (iso) => setFilter(f.id, iso) : undefined}
                />
              );
            }
            if (f.type === 'segmented' && f.options) {
              return <SegmentedControl key={f.id} tone="light" ariaLabel={f.label} options={f.options.map((o) => ({ value: o.value, label: o.label }))} value={v} onChange={(nv) => setFilter(f.id, nv)} />;
            }
            return null;
          })}
          {actions.includes('settings') ? (
            <Popover
              open={settingsOpen}
              onClose={() => setSettingsOpen(false)}
              label="Display settings"
              trigger={<IconButton icon="settings" label="Settings" size="lg" active={settingsOpen} onClick={() => setSettingsOpen(!settingsOpen)} />}
            >
              <SettingsPanel density={density} onDensity={(d) => dispatch(dashboardActions.setDensity(d))} items={settingsItems} />
            </Popover>
          ) : null}
          {actions.includes('copyLink') ? (
            <div className={styles.copyWrap} data-noprint="">
              <IconButton icon="link" label="Copy link to this view" size="lg" onClick={copyLink} />
              {copied ? <span className={styles.toast}>Link copied</span> : null}
            </div>
          ) : null}
          {actions.includes('exportPdf') ? <IconButton icon="download" label="Export page (PDF)" size="lg" variant="primary" data-noprint="" onClick={() => window.print()} /> : null}
          {actions.includes('exportMenu') ? (
            <Popover
              open={exportOpen}
              onClose={() => setExportOpen(false)}
              label="Export"
              width="sm"
              trigger={
                <button type="button" className={styles.exportBtn} onClick={() => setExportOpen(!exportOpen)}>
                  Export
                </button>
              }
            >
              <MenuList
                items={[
                  { id: 'pdf', tag: 'PDF', icon: 'download', label: 'Full page PDF', sub: 'Print-ready, all sections', onClick: () => { setExportOpen(false); window.setTimeout(() => window.print(), 120); } },
                  { id: 'csv', tag: 'CSV', icon: 'download', label: 'All panels (CSV)', sub: 'Every grid in one file', onClick: () => { setExportOpen(false); exportAllCsv(); } },
                ]}
              />
            </Popover>
          ) : null}
        </>
      }
    />
  );
}
