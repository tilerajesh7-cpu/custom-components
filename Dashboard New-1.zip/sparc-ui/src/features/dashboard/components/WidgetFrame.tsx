import type { ReactNode } from 'react';
import { useDispatch } from 'react-redux';
import type { UseQueryResult } from '@tanstack/react-query';
import type { GridResponse } from '@shared/lib/contract/gridResponse';
import { downloadText, gridResponseToRows, rowsToCsv, safeFileName } from '@shared/lib/export/csv';
import { ErrorState, Spinner, WidgetCard } from '@shared/ui';
import { useDashboardContext } from '../context';
import { dashboardActions } from '../model/dashboardSlice';
import type { WidgetDef } from '../model/types';

interface Props {
  widget: WidgetDef;
  title: string;
  subtitle?: string;
  query: UseQueryResult<GridResponse>;
  ready: boolean;
  toolbar?: ReactNode;
  children: (data: GridResponse) => ReactNode;
}

/** Card chrome + loading / error / empty handling shared by every widget kind. */
export function WidgetFrame({ widget, title, subtitle, query, ready, toolbar, children }: Props) {
  const { dashboardId, expanded } = useDashboardContext();
  const dispatch = useDispatch();
  const p = widget.presentation ?? {};
  const data = query.data;
  const onExport = p.exportCsv && data ? () => downloadText(`${safeFileName(title)}.csv`, rowsToCsv(gridResponseToRows(data))) : undefined;

  let body: ReactNode;
  if (query.isError && !data) body = <ErrorState message={query.error instanceof Error ? query.error.message : undefined} onRetry={() => void query.refetch()} />;
  else if (!data) body = <Spinner label={ready ? 'Loading' : 'Waiting for selection'} />;
  else body = children(data);

  return (
    <WidgetCard
      id={widget.id}
      title={title}
      subtitle={subtitle}
      icon={widget.icon}
      variant={p.variant}
      toolbar={toolbar}
      loading={!!data && query.isFetching}
      expanded={expanded === widget.id}
      onToggleExpand={p.expandable ? () => dispatch(dashboardActions.toggleExpanded({ dashboardId, widgetId: widget.id })) : undefined}
      onExport={onExport}
      fullscreen={p.fullscreen}
      fill
    >
      {body}
    </WidgetCard>
  );
}
