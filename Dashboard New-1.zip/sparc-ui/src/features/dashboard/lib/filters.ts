import { addDaysIso, fmtDisplayDate } from '@shared/lib/format/date';
import type { FilterDef, FilterValue, FilterValues } from '../model/types';

export function defaultFilterValues(defs: FilterDef[]): FilterValues {
  const out: FilterValues = {};
  defs.forEach((d) => {
    if (d.type !== 'derived' && d.default !== undefined) out[d.id] = d.default;
  });
  return out;
}

/** Adds derived fields (e.g. PCOB from the Custom/DoD/WoW/MoM option, or COB − 7 days). */
export function withDerived(defs: FilterDef[], values: FilterValues): FilterValues {
  const out = { ...values };
  defs.forEach((d) => {
    if (d.type !== 'derived' || !d.derive) return;
    const src = out[d.derive.from];
    if (d.derive.via === 'addDays') {
      if (typeof src === 'string') out[d.id] = addDaysIso(src, d.derive.days);
    } else {
      const field = d.derive.optionField;
      const opt = defs.find((x) => x.id === d.derive!.from)?.options?.find((o) => o.value === src);
      const v = opt?.[field];
      if (typeof v === 'string' || typeof v === 'number') out[d.id] = v;
    }
  });
  return out;
}

/** Display labels for templates: {filterLabel.variant} → "1DAY", dates → "11-Sep-2026". */
export function filterLabels(defs: FilterDef[], values: FilterValues): Record<string, string> {
  const out: Record<string, string> = {};
  defs.forEach((d) => {
    const v = values[d.id];
    if (v == null) return;
    const opt = d.options?.find((o) => o.value === v);
    out[d.id] = opt?.label ?? (d.type === 'date' || d.display === 'date' ? fmtDisplayDate(String(v)) : String(v));
  });
  return out;
}

const editable = (d: FilterDef) => d.type !== 'derived' && (d.placement === 'bar' || d.placement === 'header');

export function toSearch(defs: FilterDef[], values: FilterValues): string {
  const q = new URLSearchParams();
  defs.filter(editable).forEach((d) => values[d.id] != null && q.set(d.id, String(values[d.id])));
  return q.toString();
}

export function fromSearch(defs: FilterDef[], search: string): FilterValues {
  const q = new URLSearchParams(search);
  const out: FilterValues = {};
  defs.filter(editable).forEach((d) => {
    const raw = q.get(d.id);
    if (raw == null) return;
    const opt = d.options?.find((o) => String(o.value) === raw);
    if (opt) out[d.id] = opt.value;
    else if (!d.options && /^\d{4}-\d{2}-\d{2}$/.test(raw)) out[d.id] = raw;
  });
  return out;
}

export function cycleValue(def: FilterDef, current: FilterValue | undefined): FilterValue | undefined {
  const opts = def.options ?? [];
  if (!opts.length) return current;
  const i = opts.findIndex((o) => o.value === current);
  return opts[(i + 1) % opts.length].value;
}
