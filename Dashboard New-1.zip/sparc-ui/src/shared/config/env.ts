export const env = {
  apiBase: import.meta.env.VITE_API_BASE ?? './api',
  useMocks: import.meta.env.VITE_USE_MOCKS === 'true',
  mockLatencyMs: Number(import.meta.env.VITE_MOCK_LATENCY_MS ?? 350),
  agGridLicense: import.meta.env.VITE_AG_GRID_LICENSE ?? '',
} as const;
