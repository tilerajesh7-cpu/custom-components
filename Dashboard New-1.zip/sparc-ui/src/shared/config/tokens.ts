/**
 * UI-owned design tokens. Services send tone names (never hex) unless they deliberately
 * override a colour; tone → hex resolution lives here only.
 * Keep in sync with the CSS custom properties in app/global.css (:root).
 */
export type Tone = string;

export const TONES: Readonly<Record<string, string>> = {
  series1: '#2f62c9',
  series2: '#6a4bd6',
  series3: '#12918a',
  series4: '#b7780a',
  stack1: '#2f62c9',
  stack2: '#6f93ea',
  stack3: '#14224a',
  stack4: '#c2622f',
  stack5: '#d08a0e',
  stack6: '#2f9e8f',
  stack7: '#c5ccd8',
  positive: '#16895a',
  negative: '#c2392f',
  warning: '#d08a0e',
  neutral: '#98a2b3',
  info: '#5b86f5',
  ink: '#0f1a3a',
  muted: '#667085',
  utilization: '#e0685e',
  regionAmer: '#1e3a72',
  regionEmea: '#2f7fd0',
  regionApac: '#5fb6e0',
  regionX: '#e8892b',
  accent: '#e8892b',
};

export const DEFAULT_SERIES_TONES: readonly Tone[] = ['series1', 'series2', 'series3', 'series4', 'stack4', 'stack5', 'stack6'];

export function toneHex(tone: Tone | undefined, fallback = TONES.neutral): string {
  if (!tone) return fallback;
  if (tone.startsWith('#')) return tone;
  return TONES[tone] ?? fallback;
}

export const DENSITY = {
  compact: { rowHeight: 28, headerHeight: 30, gap: 10 },
  comfortable: { rowHeight: 34, headerHeight: 34, gap: 16 },
  spacious: { rowHeight: 42, headerHeight: 38, gap: 22 },
} as const;

export type Density = keyof typeof DENSITY;
export const DENSITIES = Object.keys(DENSITY) as Density[];

/** Single hover delay used by every tooltip (grid cells, charts, chips). */
export const TOOLTIP_DELAY_MS = 250;
