import { describe, expect, it } from 'vitest';
import { buildChartOptions, type ChartConfig } from './buildChartOptions';
import type { GridResponse } from '../contract/gridResponse';

const base = (over: Partial<GridResponse>): GridResponse => ({
  schemaVersion: '2.0',
  gridId: 't',
  gridMetaData: {},
  columnDefs: [],
  columnMetadata: {},
  rowData: [],
  rowMetadata: {},
  cellMetadata: {},
  pinnedTopRows: [],
  pinnedBottomRows: [],
  ...over,
});

describe('buildChartOptions', () => {
  it('builds a time series with one series per value field', () => {
    const res = base({
      columnDefs: [{ field: 'cobDate', colType: 'StringType' }, { field: 'a', headerName: 'A', colType: 'DoubleType' }, { field: 'b', headerName: 'B', colType: 'DoubleType' }],
      rowData: [{ id: '1', cobDate: '2026-09-10', a: 1, b: 2 }, { id: '2', cobDate: '2026-09-11', a: 3, b: 4 }],
    });
    const cfg: ChartConfig = { type: 'line', orientation: 'timeSeries', categoryField: 'cobDate', valueFields: '*' };
    const o = buildChartOptions(res, cfg);
    expect((o.xAxis as { categories: string[] }).categories).toEqual(['Sep 10', 'Sep 11']);
    expect(o.series).toHaveLength(2);
    expect((o.series![0] as { name: string }).name).toBe('A');
  });

  it('stacks rows as series and excludes grand totals / total columns', () => {
    const res = base({
      columnDefs: [{ field: 'region', colType: 'StringType' }, { field: 'delta', headerName: 'Delta', colType: 'DoubleType' }, { field: 'grand_total', headerName: 'Total', colType: 'DoubleType' }],
      rowData: [{ id: 'amer', region: 'AMER', delta: 5, grand_total: 5 }, { id: 'gt', region: 'Grand Total', delta: 5, grand_total: 5 }],
      rowMetadata: { gt: { rowType: 'GRAND_TOTAL' } },
    });
    const cfg: ChartConfig = { type: 'column', stacking: 'normal', orientation: 'fieldsAsCategories', seriesField: 'region', excludeFields: ['grand_total'], excludeRowTypes: ['GRAND_TOTAL'] };
    const o = buildChartOptions(res, cfg);
    expect(o.series).toHaveLength(1);
    expect((o.xAxis as { categories: string[] }).categories).toEqual(['Delta']);
  });

  it('adds reference + derived ratio series on a secondary axis', () => {
    const res = base({
      columnDefs: [{ field: 'cobDate' }, { field: 'exposure', colType: 'DoubleType' }, { field: 'threshold', colType: 'DoubleType' }],
      rowData: [{ id: '1', cobDate: '2026-09-11', exposure: 18, threshold: 15 }],
    });
    const cfg: ChartConfig = {
      type: 'column', orientation: 'timeSeries', categoryField: 'cobDate', valueFields: ['exposure'],
      referenceLines: [{ field: 'threshold', label: 'Limit', tone: 'ink' }],
      derivedSeries: [{ id: 'u', label: 'Utilization', numerator: 'exposure', denominator: 'threshold', tone: 'utilization', axis: 'secondary' }],
      secondaryAxis: { max: 1.5, format: 'percent' },
    };
    const o = buildChartOptions(res, cfg);
    expect(o.series).toHaveLength(3);
    expect(Array.isArray(o.yAxis) && o.yAxis.length).toBe(2);
    expect((o.series![2] as { data: number[] }).data[0]).toBeCloseTo(1.2);
  });
});
