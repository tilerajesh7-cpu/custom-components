const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const parts = (iso: string) => {
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return { y, m, d };
};

export const isIsoDate = (v: unknown): v is string => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}/.test(v);

/** "2026-09-11" → "Sep 11" */
export const fmtShortDate = (iso: string) => {
  const { m, d } = parts(iso);
  return `${MON[m - 1]} ${d}`;
};

/** "2026-09-11" → "Sep 11, 2026" */
export const fmtLongDate = (iso: string) => {
  const { y, m, d } = parts(iso);
  return `${MON[m - 1]} ${d}, ${y}`;
};

/** "2026-09-11" → "11-Sep-2026" */
export const fmtDisplayDate = (iso: string) => {
  const { y, m, d } = parts(iso);
  return `${String(d).padStart(2, '0')}-${MON[m - 1]}-${y}`;
};

export const addDaysIso = (iso: string, days: number) => {
  const { y, m, d } = parts(iso);
  const t = new Date(Date.UTC(y, m - 1, d + days));
  return t.toISOString().slice(0, 10);
};
