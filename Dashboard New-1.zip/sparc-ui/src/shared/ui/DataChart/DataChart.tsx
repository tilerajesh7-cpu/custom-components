import { useEffect, useRef } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import '../Tooltip/tooltip.css';
import styles from './DataChart.module.css';

let configured = false;
function ensureHighchartsSetup() {
  if (configured) return;
  Highcharts.setOptions({ lang: { thousandsSep: ',' }, chart: { style: { fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" } } });
  configured = true;
}
ensureHighchartsSetup();

export interface DataChartProps {
  options: Highcharts.Options;
  ariaLabel?: string;
}

/** Thin Highcharts wrapper: reflows on container resize (expand / collapse / sidebar). */
export function DataChart({ options, ariaLabel }: DataChartProps) {
  const wrap = useRef<HTMLDivElement>(null);
  const chartRef = useRef<HighchartsReact.RefObject>(null);
  useEffect(() => {
    const el = wrap.current;
    if (!el || typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(() => chartRef.current?.chart?.reflow());
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div ref={wrap} className={styles.root} role="img" aria-label={ariaLabel}>
      <HighchartsReact ref={chartRef} highcharts={Highcharts} options={options} immutable containerProps={{ className: styles.container }} />
    </div>
  );
}
