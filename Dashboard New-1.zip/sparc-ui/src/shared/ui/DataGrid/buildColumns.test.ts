import { describe, expect, it } from 'vitest';
import { buildColumnDefs, computeStats, heatClass } from './buildColumns';
import type { GridResponse } from '@shared/lib/contract/gridResponse';

const res: GridResponse = {
  schemaVersion: '2.0',
  gridId: 'g',
  gridMetaData: { heatmap: { scope: 'grid', excludeRowTypes: ['GRAND_TOTAL'] } },
  columnDefs: [
    { field: 'name', headerName: 'Name', colType: 'StringType', pinned: 'left' },
    { headerName: 'Monte Carlo', children: [{ field: 'cob', headerName: 'COB', colType: 'DoubleType' }, { field: 'diff', headerName: 'Diff', colType: 'DoubleType' }] },
  ],
  columnMetadata: { cob: { type: 'heatmap' }, diff: { type: 'bar', bar: { mode: 'diverging' } } },
  rowData: [{ id: 'a', name: 'A', cob: 10, diff: -2 }, { id: 'b', name: 'B', cob: -40, diff: 4 }],
  rowMetadata: {},
  cellMetadata: {},
  pinnedTopRows: [],
  pinnedBottomRows: [{ id: 'grand_total', name: 'Total', cob: -30, diff: 2 }],
};

describe('DataGrid adapter', () => {
  it('maps nested columnDefs into groups with tone classes', () => {
    const defs = buildColumnDefs(res, { groupTones: ['series1'] });
    expect(defs).toHaveLength(2);
    const group = defs[1] as { children: { field: string; cellRenderer?: string }[]; headerClass: string[] };
    expect(group.headerClass).toContain('dg-tone-series1');
    expect(group.children[1].cellRenderer).toBe('barCell');
  });

  it('computes bar maxima, heat max and grand totals', () => {
    const s = computeStats(res);
    expect(s.maxAbs.cob).toBe(40);
    expect(s.heatMax).toBe(40);
    expect(s.totals.cob).toBe(-30);
  });

  it('buckets heat values', () => {
    expect(heatClass(40, 40)).toBe('dg-heat-pos-5');
    expect(heatClass(-9, 40)).toBe('dg-heat-neg-2');
    expect(heatClass(0.1, 40)).toBe('');
  });
});
