import type { CellClassParams, ColDef, ColGroupDef, ITooltipParams, ValueFormatterParams } from 'ag-grid-community';
import { leafColumns, type GridResponse, type GridRow, type RowType, type WireColDef } from '@shared/lib/contract/gridResponse';
import { formatNumber, signTone } from '@shared/lib/format/number';

export interface GridStats {
  /** max |value| per numeric field over body rows (bars) */
  maxAbs: Record<string, number>;
  /** max |value| across all heatmap cells (grid scope) */
  heatMax: number;
  /** grand-total row values (share-of-total in tooltips) */
  totals: Record<string, number | null>;
}

export interface GridContext {
  stats: GridStats;
  selectedRowId: string | null;
  templateContext: Record<string, unknown>;
  response: GridResponse;
}

export type AnyColDef = ColDef<GridRow> | ColGroupDef<GridRow>;

const abs = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? Math.abs(v) : 0);

function heatExcluded(res: GridResponse, rowId: string | undefined, excl: RowType[]) {
  if (!rowId) return true;
  const m = res.rowMetadata[rowId];
  return !!m?.excludeHeatMap || (!!m?.rowType && excl.includes(m.rowType));
}

export function computeStats(res: GridResponse): GridStats {
  const leaves = leafColumns(res.columnDefs).filter((c) => c.field && c.colType === 'DoubleType');
  const body = res.rowData.filter((r) => !res.rowMetadata[r.id]?.rowType);
  const maxAbs: Record<string, number> = {};
  leaves.forEach((c) => {
    maxAbs[c.field!] = Math.max(1e-9, ...body.map((r) => abs(r[c.field!])));
  });

  let heatMax = 0;
  const hm = res.gridMetaData.heatmap;
  if (hm) {
    const excl = hm.excludeRowTypes ?? ['GRAND_TOTAL'];
    const fields = leaves.filter((c) => res.columnMetadata[c.field!]?.type === 'heatmap').map((c) => c.field!);
    const rows = res.rowData.filter((r) => !heatExcluded(res, r.id, excl));
    heatMax = hm.max ?? Math.max(1e-9, ...rows.flatMap((r) => fields.map((f) => abs(r[f]))));
  }

  const totalRow =
    res.pinnedBottomRows.find((r) => res.rowMetadata[r.id]?.rowType === 'GRAND_TOTAL' || r.id === 'grand_total') ??
    res.rowData.find((r) => res.rowMetadata[r.id]?.rowType === 'GRAND_TOTAL');
  const totals: Record<string, number | null> = {};
  leaves.forEach((c) => {
    const v = totalRow?.[c.field!];
    totals[c.field!] = typeof v === 'number' ? v : null;
  });
  return { maxAbs, heatMax, totals };
}

/** 5 positive / 5 negative buckets, coloured by CSS (palette is UI-owned). */
export function heatClass(v: unknown, max: number): string {
  if (typeof v !== 'number' || !Number.isFinite(v) || max <= 0) return '';
  const r = Math.abs(v) / max;
  if (r < 0.02) return '';
  const n = Math.min(5, Math.max(1, Math.ceil(r * 5)));
  return `dg-heat-${v < 0 ? 'neg' : 'pos'}-${n}`;
}

export interface BuildColumnsOptions {
  groupTones?: string[];
}

export function buildColumnDefs(res: GridResponse, opts: BuildColumnsOptions = {}): AnyColDef[] {
  const sortable = res.gridMetaData.defaultColDef?.sortable ?? true;
  const resizable = res.gridMetaData.defaultColDef?.resizable ?? true;
  const heatExcl = res.gridMetaData.heatmap?.excludeRowTypes ?? ['GRAND_TOTAL'];
  let groupIdx = 0;

  const leaf = (wire: WireColDef, tone?: string, groupStart = false): ColDef<GridRow> => {
    const field = wire.field ?? '';
    const meta = res.columnMetadata[field] ?? {};
    const numeric = wire.colType === 'DoubleType';
    const def: ColDef<GridRow> = {
      colId: field,
      field,
      headerName: wire.headerName ?? field,
      headerTooltip: wire.headerTooltip ?? wire.headerName,
      hide: wire.hide,
      pinned: wire.pinned ?? undefined,
      width: wire.width,
      minWidth: numeric ? 56 : 84,
      sortable,
      resizable,
      sort: meta.sort ?? null,
      sortIndex: meta.sortIndex,
      type: numeric ? 'rightAligned' : undefined,
      headerClass: [groupStart ? 'dg-group-start' : '', tone ? `dg-tone-${tone}` : ''].filter(Boolean),
      cellClass: (p: CellClassParams<GridRow>) => {
        const cls: string[] = [];
        if (numeric) cls.push('dg-num');
        if (groupStart) cls.push('dg-group-start');
        if (tone) cls.push(`dg-tone-${tone}`);
        if (meta.tone === 'muted') cls.push('dg-muted');
        if (meta.tone === 'sign') cls.push(`dg-sign-${signTone(p.value)}`);
        if (meta.type === 'heatmap' && !p.node.rowPinned && !heatExcluded(res, p.data?.id, heatExcl)) {
          const h = heatClass(p.value, (p.context as GridContext).stats.heatMax);
          if (h) cls.push(h);
        }
        if (p.data && res.cellMetadata[p.data.id]?.[field]) cls.push('dg-cell-flag');
        return cls;
      },
    };
    if (numeric || meta.format) def.valueFormatter = (p: ValueFormatterParams<GridRow>) => formatNumber(p.value, meta.format);
    if (meta.type === 'bar' && meta.bar) {
      def.cellRenderer = 'barCell';
      def.cellRendererParams = { mode: meta.bar.mode, max: meta.bar.max, thresholds: meta.bar.thresholds };
    }
    if (meta.type === 'badge') def.cellRenderer = 'badgeCell';
    def.tooltipValueGetter = (p: ITooltipParams<GridRow>) => (p.value == null || p.value === '' ? null : String(p.value));
    if (meta.tooltip) {
      def.tooltipComponent = 'cellTooltip';
      def.tooltipComponentParams = { config: meta.tooltip, format: meta.format };
    }
    return def;
  };

  const map = (wire: WireColDef): AnyColDef => {
    if (!wire.children?.length) return leaf(wire);
    const tone = opts.groupTones?.[groupIdx++ % (opts.groupTones.length || 1)];
    return {
      groupId: wire.headerName,
      headerName: wire.headerName,
      marryChildren: true,
      headerClass: ['dg-group', 'dg-group-start', tone ? `dg-tone-${tone}` : ''].filter(Boolean),
      children: wire.children.map((c, i) => leaf(c, tone, i === 0)),
    } satisfies ColGroupDef<GridRow>;
  };

  return res.columnDefs.map(map);
}
