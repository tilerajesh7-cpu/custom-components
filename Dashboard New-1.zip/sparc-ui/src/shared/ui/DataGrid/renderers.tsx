import type { CustomCellRendererProps } from 'ag-grid-react';
import type { GridRow } from '@shared/lib/contract/gridResponse';
import { cssVars } from '@shared/lib/cssVars';
import type { GridContext } from './buildColumns';

interface BarParams {
  mode: 'magnitude' | 'diverging' | 'progress';
  max?: number;
  thresholds?: { gte: number; tone: string }[];
}

const HALF = 15;

export function BarCell(props: CustomCellRendererProps<GridRow> & BarParams) {
  const v = typeof props.value === 'number' ? props.value : null;
  const text = props.valueFormatted ?? String(props.value ?? '');
  const field = props.colDef?.field ?? '';
  const max = (props.context as GridContext).stats.maxAbs[field] || 1;
  if (v == null || props.node.rowPinned) return <span className="dg-bar-text">{text}</span>;

  if (props.mode === 'magnitude') {
    const pct = Math.max(2, Math.min(100, (Math.abs(v) / max) * 100));
    return (
      <div className="dg-bar dg-bar-magnitude" style={cssVars({ '--pct': `${pct}%` })}>
        <span className="dg-bar-text">{text}</span>
      </div>
    );
  }

  if (props.mode === 'diverging') {
    const w = Math.max(v ? 1.5 : 0, (Math.abs(v) / max) * HALF);
    return (
      <div className="dg-bar dg-bar-diverging">
        <span className="dg-mini" aria-hidden="true">
          <span className={v >= 0 ? 'dg-mini-fill is-pos' : 'dg-mini-fill is-neg'} style={cssVars({ '--l': `${v >= 0 ? HALF : HALF - w}px`, '--w': `${w}px` })} />
        </span>
        <span className="dg-bar-text">{text}</span>
      </div>
    );
  }

  const cap = props.max ?? 1;
  const tone = [...(props.thresholds ?? [])].sort((a, b) => b.gte - a.gte).find((t) => v >= t.gte)?.tone ?? 'neutral';
  return (
    <div className="dg-progress" data-tone={tone}>
      <span className="dg-progress-track">
        <span className="dg-progress-fill" style={cssVars({ '--pct': `${Math.min(100, (v / cap) * 100)}%` })} />
      </span>
      <span className="dg-progress-text">{text}</span>
    </div>
  );
}

export function BadgeCell(props: CustomCellRendererProps<GridRow>) {
  if (props.value == null || props.node.rowPinned) return null;
  return <span className="dg-badge">{String(props.value)}</span>;
}
