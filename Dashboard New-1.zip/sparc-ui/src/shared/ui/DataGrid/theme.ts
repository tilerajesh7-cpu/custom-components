import { themeQuartz } from 'ag-grid-community';

const base = {
  browserColorScheme: 'light',
  fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif",
  fontSize: 13,
  foregroundColor: '#101828',
  backgroundColor: '#ffffff',
  accentColor: '#2f62c9',
  borderColor: '#eef1f6',
  wrapperBorder: false,
  wrapperBorderRadius: 0,
  rowBorder: { color: '#f1f3f7' },
  columnBorder: false,
  headerRowBorder: { color: '#e6ebf3' },
  headerFontSize: 11.5,
  headerFontWeight: 600,
  headerTextColor: '#667085',
  headerBackgroundColor: '#f8fafd',
  rowHoverColor: '#f5f8fd',
  selectedRowBackgroundColor: '#edf2fd',
  oddRowBackgroundColor: '#ffffff',
  cellHorizontalPadding: 10,
  spacing: 6,
} as const;

/** VaR-style grids. */
export const standardGridTheme = themeQuartz.withParams(base);

/** Compact Greek heatmap grids. */
export const heatmapGridTheme = themeQuartz.withParams({
  ...base,
  fontSize: 12,
  headerFontSize: 10.5,
  headerTextColor: '#475467',
  headerBackgroundColor: '#f3f6fb',
  cellHorizontalPadding: 8,
});
