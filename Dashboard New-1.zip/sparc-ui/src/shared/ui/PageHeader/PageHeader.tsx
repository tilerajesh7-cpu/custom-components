import type { ReactNode } from 'react';
import { Icon, type IconName } from '../Icon/Icon';
import styles from './PageHeader.module.css';

export interface PageHeaderProps {
  breadcrumb: string[];
  title: string;
  actions?: ReactNode;
}

export function PageHeader({ breadcrumb, title, actions }: PageHeaderProps) {
  return (
    <header className={styles.header}>
      <div className={styles.titles}>
        <nav aria-label="Breadcrumb" className={styles.crumbs}>
          {breadcrumb.map((c, i) => (
            <span key={c} className={styles.crumb}>
              {i ? <span className={styles.sep}>/</span> : null}
              {c}
            </span>
          ))}
        </nav>
        <h1 className={styles.title}>{title}</h1>
      </div>
      <div className={styles.actions}>{actions}</div>
    </header>
  );
}

export interface DatePillProps {
  label: string;
  value: string;
  icon?: IconName;
  /** When set, renders a native date input (ISO yyyy-mm-dd). */
  onChange?: (iso: string) => void;
  max?: string;
}

export function DatePill({ label, value, icon = 'calendar', onChange, max }: DatePillProps) {
  const body = (
    <>
      <Icon name={icon} />
      <span className={styles.pillText}>
        <span className={styles.pillLabel}>{label}</span>
        {onChange ? (
          <input type="date" className={styles.input} value={value} max={max} aria-label={label} onChange={(e) => e.target.value && onChange(e.target.value)} />
        ) : (
          <span className={styles.pillValue}>{value}</span>
        )}
      </span>
    </>
  );
  return onChange ? <label className={styles.pill}>{body}</label> : <div className={styles.pill}>{body}</div>;
}
