import clsx from 'clsx';
import styles from './Spinner.module.css';

export function Spinner({ label = 'Loading', overlay = false }: { label?: string; overlay?: boolean }) {
  return (
    <div role="status" aria-live="polite" className={clsx(styles.wrap, overlay && styles.overlay)}>
      <span className={styles.ring} />
      <span className={styles.sr}>{label}</span>
    </div>
  );
}

export function PageLoader() {
  return (
    <div className={styles.page}>
      <Spinner label="Loading page" />
    </div>
  );
}
