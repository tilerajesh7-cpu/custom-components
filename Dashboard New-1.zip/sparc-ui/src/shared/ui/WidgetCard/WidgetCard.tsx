import clsx from 'clsx';
import { useRef, type ReactNode } from 'react';
import { toggleFullscreen } from '../../hooks/dom';
import { Icon, type IconName } from '../Icon/Icon';
import { IconButton } from '../IconButton/IconButton';
import { Spinner } from '../Spinner/Spinner';
import styles from './WidgetCard.module.css';

export interface WidgetCardProps {
  id?: string;
  title: ReactNode;
  subtitle?: ReactNode;
  icon?: IconName;
  /** accent = VaR cards (blue top rule) · compact = Greek cards (icon + tinted header) */
  variant?: 'accent' | 'compact';
  toolbar?: ReactNode;
  loading?: boolean;
  expanded?: boolean;
  onToggleExpand?: () => void;
  onExport?: () => void;
  fullscreen?: boolean;
  fill?: boolean;
  className?: string;
  children: ReactNode;
}

export function WidgetCard({ id, title, subtitle, icon, variant = 'accent', toolbar, loading, expanded, onToggleExpand, onExport, fullscreen, fill, className, children }: WidgetCardProps) {
  const ref = useRef<HTMLElement>(null);
  return (
    <section ref={ref} data-widget={id} aria-busy={loading || undefined} className={clsx(styles.card, styles[variant], fill && styles.fill, className)}>
      <header className={styles.head}>
        {icon ? (
          <span className={styles.ico} data-icon={icon}>
            <Icon name={icon} />
          </span>
        ) : null}
        <div className={styles.titles}>
          <h2 className={styles.title}>{title}</h2>
          {subtitle ? <span className={styles.sub}>{subtitle}</span> : null}
        </div>
        <div className={styles.actions} data-noprint="">
          {toolbar}
          {onExport ? <IconButton icon="download" label="Export data (CSV)" size={variant === 'compact' ? 'sm' : 'md'} onClick={onExport} /> : null}
          {onToggleExpand ? <IconButton icon={expanded ? 'collapse' : 'expand'} label={expanded ? 'Restore (Esc)' : 'Expand to full width'} size={variant === 'compact' ? 'sm' : 'md'} onClick={onToggleExpand} /> : null}
          {fullscreen ? <IconButton icon="fullscreen" label="Full screen" size={variant === 'compact' ? 'sm' : 'md'} onClick={() => toggleFullscreen(ref.current)} /> : null}
        </div>
      </header>
      <div className={styles.body}>
        {children}
        {loading ? <Spinner overlay label="Refreshing" /> : null}
      </div>
    </section>
  );
}
