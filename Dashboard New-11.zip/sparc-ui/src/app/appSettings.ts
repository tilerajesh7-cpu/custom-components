import type { NumberDisplayOptions } from '@shared/lib/format/numberDisplay';

/** SPARC-specific display choices. Other apps using shared/ui pass their own. */
export const NUMBER_DISPLAY: NumberDisplayOptions = {
  negative: 'minus', // -123 (not (123))
  colorNegative: true, // red
};
