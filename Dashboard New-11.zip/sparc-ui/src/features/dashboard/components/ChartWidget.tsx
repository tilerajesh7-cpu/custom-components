import { useMemo } from 'react';
import { buildChartOptions } from '@shared/lib/chart/buildChartOptions';
import { DataChart, EmptyState, StatTiles, useNumberDisplay } from '@shared/ui';
import { useDashboardContext } from '../context';
import { useWidgetData, useWidgetText } from '../hooks/useWidgetData';
import { computeStatTiles } from '../lib/statTiles';
import type { WidgetDef } from '../model/types';
import { WidgetFrame } from './WidgetFrame';
import styles from './widgets.module.css';

export function ChartWidget({ widget }: { widget: WidgetDef }) {
  const { chartConfigs } = useDashboardContext();
  const { query, selections, ready } = useWidgetData(widget);
  const { title, subtitle } = useWidgetText(widget, selections, query.data?.gridMetaData);
  const cfg = widget.chartConfigId ? chartConfigs[widget.chartConfigId] : undefined;
  const { negative } = useNumberDisplay();
  const options = useMemo(() => (query.data && cfg ? buildChartOptions(query.data, cfg, { negative }) : null), [query.data, cfg, negative]);
  const tileDefs = widget.presentation?.statTiles;
  const tiles = useMemo(() => (query.data && tileDefs ? computeStatTiles(query.data, tileDefs) : null), [query.data, tileDefs]);

  return (
    <WidgetFrame widget={widget} title={title} subtitle={subtitle} query={query} ready={ready}>
      {(data) =>
        !options ? (
          <EmptyState message="Chart configuration is not available" />
        ) : !data.rowData.length ? (
          <EmptyState />
        ) : (
          <div className={styles.chartBody}>
            {tiles ? <StatTiles tiles={tiles} /> : null}
            <DataChart key={query.dataUpdatedAt} options={options} ariaLabel={title} minHeight={cfg?.height} />
          </div>
        )
      }
    </WidgetFrame>
  );
}
