import { useCallback, useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { buildChartOptions } from '@shared/lib/chart/buildChartOptions';
import { DataChart, DataGrid, EmptyState, SegmentedControl, useNumberDisplay, type GridEvent } from '@shared/ui';
import { useDashboardContext } from '../context';
import { useWidgetData, useWidgetText } from '../hooks/useWidgetData';
import { dashboardActions, selectInstance, type DashboardRootState } from '../model/dashboardSlice';
import type { ViewMode, WidgetDef } from '../model/types';
import { WidgetFrame } from './WidgetFrame';
import styles from './widgets.module.css';

export const VIEW_LABEL: Record<ViewMode, { label: string; icon: 'chart' | 'grid' }> = {
  chart: { label: 'Chart', icon: 'chart' },
  grid: { label: 'Grid', icon: 'grid' },
  list: { label: 'Table', icon: 'grid' },
};

export function GridWidget({ widget }: { widget: WidgetDef }) {
  const { dashboardId, density, resetToken, chartConfigs } = useDashboardContext();
  const dispatch = useDispatch();
  const { query, selections, ready } = useWidgetData(widget);
  const { title, subtitle, templateContext } = useWidgetText(widget, selections, query.data?.gridMetaData);
  const explicit = useSelector((s: DashboardRootState) => selectInstance(s, dashboardId).selections[widget.id]);
  const stored = useSelector((s: DashboardRootState) => selectInstance(s, dashboardId).views[widget.id]);

  const { negative } = useNumberDisplay();
  const p = widget.presentation ?? {};
  const views = p.views ?? ['grid'];
  const view: ViewMode = stored ?? p.defaultView ?? views[0];
  const selectedRowId = widget.selection ? (selections[widget.id]?.rowId ?? null) : null;
  const chartConfig = widget.chartConfigId ? chartConfigs[widget.chartConfigId] : undefined;

  const onEvent = useCallback(
    (e: GridEvent) => {
      if (!widget.selection) return;
      const clear = widget.selection.toggle && explicit?.rowId === e.rowId;
      dispatch(dashboardActions.selectRow({ dashboardId, widgetId: widget.id, selection: clear ? null : { rowId: e.rowId, row: e.row } }));
    },
    [dispatch, dashboardId, widget, explicit],
  );

  useEffect(() => {
    const d = query.data;
    if (explicit && d && !query.isPlaceholderData && !query.isFetching && !d.rowData.some((r) => r.id === explicit.rowId)) {
      dispatch(dashboardActions.selectRow({ dashboardId, widgetId: widget.id, selection: null }));
    }
  }, [explicit, query.data, query.isPlaceholderData, query.isFetching, dispatch, dashboardId, widget.id]);

  const chartOptions = useMemo(() => (view === 'chart' && query.data && chartConfig ? buildChartOptions(query.data, chartConfig, { negative }) : null), [view, query.data, chartConfig, negative]);

  const toolbar =
    views.length > 1 ? (
      <SegmentedControl
        tone="subtle"
        iconOnly
        ariaLabel={`${title} view`}
        options={views.map((v) => ({ value: v, ...VIEW_LABEL[v] }))}
        value={view}
        onChange={(v) => dispatch(dashboardActions.setView({ dashboardId, widgetId: widget.id, view: v }))}
      />
    ) : null;

  return (
    <WidgetFrame widget={widget} title={title} subtitle={subtitle} query={query} ready={ready} toolbar={toolbar}>
      {(data) =>
        view === 'chart' ? (
          chartOptions ? (
            <div key="chart" className={styles.chartBody}>
              <DataChart key={query.dataUpdatedAt} options={chartOptions} ariaLabel={title} minHeight={chartConfig?.height} />
            </div>
          ) : (
            <EmptyState message="Chart configuration is not available" />
          )
        ) : (
          <div key="grid" className={styles.gridBody}>
            <DataGrid
              response={data}
              density={density}
              selectedRowId={selectedRowId}
              interactive={!!widget.selection}
              groupTones={p.groupTones}
              height={p.height}
              variant={p.gridVariant}
              templateContext={templateContext}
              resetToken={resetToken}
              ariaLabel={title}
              onEvent={onEvent}
            />
          </div>
        )
      }
    </WidgetFrame>
  );
}
