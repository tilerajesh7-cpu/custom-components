import { describe, expect, it } from 'vitest';
import type { GridResponse } from '@shared/lib/contract/gridResponse';
import { toRankedList } from './ListWidget';

const res: GridResponse = {
  schemaVersion: '2.0',
  gridId: 'concentration-index-delta',
  gridMetaData: {},
  columnDefs: [
    { field: 'name', headerName: 'Name', colType: 'StringType' },
    { field: 'exposure', headerName: 'Exposure', colType: 'DoubleType' },
    { field: 'diff', headerName: 'Diff', colType: 'DoubleType' },
  ],
  columnMetadata: { diff: { type: 'bar', bar: { mode: 'diverging' } } },
  rowData: [
    { id: 'a', name: 'A', exposure: 90, diff: 3 },
    { id: 'b', name: 'B', exposure: -60, diff: -2 },
    { id: 'c', name: 'C', exposure: 30, diff: 1 },
    { id: 'd', name: 'D', exposure: 20, diff: 0 },
  ],
  rowMetadata: { total: { rowType: 'GRAND_TOTAL' } },
  cellMetadata: {},
  pinnedTopRows: [{ id: 'total', name: 'Total Index', exposure: -54, diff: 41 }],
  pinnedBottomRows: [],
};

describe('toRankedList', () => {
  it('takes top N, bar columns and the pinned total with share of gross', () => {
    const m = toRankedList(res, 3, true);
    expect(m.rows.map((r) => r.label)).toEqual(['A', 'B', 'C']);
    expect(m.columns[1].bar?.mode).toBe('diverging');
    expect(m.summary?.label).toBe('Total Index');
    expect(m.summary?.share?.text).toBe('Top 3 = 90% of gross');
  });

  it('applies the app negative style', () => {
    const m = toRankedList(res, 3, false, { negative: 'minus', colorNegative: true });
    expect(m.rows[1].cells[0].text.startsWith('-')).toBe(true);
  });
});
