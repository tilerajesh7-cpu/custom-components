import { useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { buildChartOptions } from '@shared/lib/chart/buildChartOptions';
import { leafColumns, type GridResponse } from '@shared/lib/contract/gridResponse';
import { formatNumber, toNumber, type NumberFormat } from '@shared/lib/format/number';
import { withDisplay, type NumberDisplayOptions } from '@shared/lib/format/numberDisplay';
import { DataChart, EmptyState, RankedList, SegmentedControl, useNumberDisplay, type RankedListColumn, type RankedListRow, type RankedListSummary } from '@shared/ui';
import { useDashboardContext } from '../context';
import { useWidgetData, useWidgetText } from '../hooks/useWidgetData';
import { dashboardActions, selectInstance, type DashboardRootState } from '../model/dashboardSlice';
import type { ViewMode, WidgetDef } from '../model/types';
import { VIEW_LABEL } from './GridWidget';
import { WidgetFrame } from './WidgetFrame';
import styles from './widgets.module.css';

let ND: NumberDisplayOptions = { negative: 'source', colorNegative: false };
const cell = (v: unknown, fmt?: NumberFormat) => ({ value: toNumber(v), text: formatNumber(v, withDisplay(fmt, ND)) });

const bodyRows = (res: GridResponse) => res.rowData.filter((r) => !res.rowMetadata[r.id]?.rowType);

/** Same response, body rows limited to the top N (chart view). */
export const topRows = (res: GridResponse, topN: number): GridResponse => ({ ...res, rowData: bodyRows(res).slice(0, topN) });

/** Maps a Grid Response v2 onto RankedList: first text column = label, numeric columns = values, type 'bar' columns get a bar. */
export function toRankedList(res: GridResponse, topN: number, shareOfGross: boolean, nd?: NumberDisplayOptions) {
  if (nd) ND = nd;
  const leaves = leafColumns(res.columnDefs).filter((c) => c.field && !c.hide);
  const labelCol = leaves.find((c) => c.colType !== 'DoubleType');
  const numCols = leaves.filter((c) => c.colType === 'DoubleType');
  const meta = (f: string) => res.columnMetadata[f] ?? {};

  const columns: RankedListColumn[] = numCols.map((c) => {
    const m = meta(c.field!);
    return { key: c.field!, header: c.headerName ?? c.field!, bar: m.type === 'bar' ? { mode: m.bar?.mode === 'diverging' ? 'diverging' : 'magnitude', tone: m.bar?.tone } : undefined };
  });
  const body = bodyRows(res);
  const shown = body.slice(0, topN);
  const rows: RankedListRow[] = shown.map((r) => ({
    id: r.id,
    label: String(labelCol ? (r[labelCol.field!] ?? '') : r.id),
    cells: numCols.map((c) => cell(r[c.field!], meta(c.field!).format)),
  }));

  let summary: RankedListSummary | undefined;
  const total = res.pinnedTopRows[0];
  if (total && numCols[0]) {
    const f0 = numCols[0].field!;
    const gross = body.reduce((s, r) => s + Math.abs(toNumber(r[f0]) ?? 0), 0);
    const top = shown.reduce((s, r) => s + Math.abs(toNumber(r[f0]) ?? 0), 0);
    const ratio = gross ? top / gross : 0;
    summary = {
      label: String(labelCol ? total[labelCol.field!] : 'Total'),
      primary: cell(total[f0], meta(f0).format),
      secondary: numCols[1] ? { label: numCols[1].headerName ?? '', cell: cell(total[numCols[1].field!], meta(numCols[1].field!).format) } : undefined,
      share: shareOfGross ? { ratio, text: `${Number.isFinite(topN) ? `Top ${topN}` : 'All names'} = ${Math.round(ratio * 100)}% of gross` } : undefined,
    };
  }
  return { columns, rows, summary, labelHeader: labelCol?.headerName };
}

export function ListWidget({ widget }: { widget: WidgetDef }) {
  const { dashboardId, filters, chartConfigs } = useDashboardContext();
  const dispatch = useDispatch();
  const stored = useSelector((s: DashboardRootState) => selectInstance(s, dashboardId).views[widget.id]);
  const { query, selections, ready } = useWidgetData(widget);
  const { title, subtitle } = useWidgetText(widget, selections, query.data?.gridMetaData);

  const nd = useNumberDisplay();
  const p = widget.presentation ?? {};
  const cfg = p.list;
  // section-level Top 3 / 5 / 10 / All (a client-only filter) overrides the widget default
  const fromFilter = cfg?.topNFilter ? filters[cfg.topNFilter] : undefined;
  const topN = fromFilter === 'All' ? Infinity : typeof fromFilter === 'number' ? fromFilter : (cfg?.topN ?? 5);
  const views: ViewMode[] = p.views ?? ['list'];
  const view: ViewMode = stored ?? p.defaultView ?? views[0];
  const chartCfg = widget.chartConfigId ? chartConfigs[widget.chartConfigId] : undefined;

  const model = useMemo(() => (query.data ? toRankedList(query.data, topN, !!cfg?.shareOfGross, nd) : null), [query.data, topN, cfg?.shareOfGross, nd]);
  const options = useMemo(() => (view === 'chart' && query.data && chartCfg ? buildChartOptions(topRows(query.data, topN), chartCfg, { negative: nd.negative }) : null), [view, query.data, chartCfg, topN, nd.negative]);

  const toolbar =
    views.length > 1 ? (
      <SegmentedControl
        tone="subtle"
        iconOnly
        ariaLabel={`${title} view`}
        options={views.map((v) => ({ value: v, ...VIEW_LABEL[v] }))}
        value={view}
        onChange={(v) => dispatch(dashboardActions.setView({ dashboardId, widgetId: widget.id, view: v }))}
      />
    ) : null;

  return (
    <WidgetFrame widget={widget} title={title} subtitle={subtitle} query={query} ready={ready} toolbar={toolbar}>
      {() =>
        !model || !model.rows.length ? (
          <EmptyState />
        ) : view === 'chart' && options ? (
          <div key="chart" className={styles.chartBody}>
            <DataChart key={`${query.dataUpdatedAt}-${topN}`} options={options} ariaLabel={title} minHeight={chartCfg?.height} />
          </div>
        ) : (
          <div key="list" className={styles.swap}>
            <RankedList {...model} />
          </div>
        )
      }
    </WidgetFrame>
  );
}
