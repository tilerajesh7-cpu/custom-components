import type { ChartConfig } from '@shared/lib/chart/buildChartOptions';
import type { Tone } from '@shared/config/tokens';
import type { IconName } from '@shared/ui';

export type ParamValue = string | number | boolean;
export type ViewMode = 'grid' | 'chart' | 'list';
export type FilterValue = string | number;
export type FilterValues = Record<string, FilterValue>;

export interface StatTileDef {
  label: string;
  field: string;
  agg: 'last' | 'max' | 'min';
  ratioTo?: string;
  noteSuffix?: string;
  thresholds?: { gte: number; tone: 'warning' | 'negative' }[];
}

export interface SelectionDef {
  mode: 'single';
  /** Clicking the selected row again clears it. */
  toggle?: boolean;
  /** UI picks the first row when nothing is selected (and re-picks after reloads). */
  default?: 'firstRow';
  chip?: { kind: string; labelTemplate: string; tone: Tone };
  affects?: string[];
}

export interface WidgetPresentation {
  views?: ViewMode[];
  defaultView?: ViewMode;
  height?: number | 'auto';
  groupTones?: Tone[];
  expandable?: boolean;
  fullscreen?: boolean;
  exportCsv?: boolean;
  statTiles?: StatTileDef[];
  variant?: 'accent' | 'compact';
  gridVariant?: 'standard' | 'heatmap';
  /** kind 'list': ranked top-N names; total comes from pinnedTopRows[0] */
  /** topNFilter: id of a section-level filter (Top 3/5/10/All) that overrides topN */
  list?: { topN?: number; topNFilter?: string; shareOfGross?: boolean };
  /** kind 'alerts': clicking an alert selects that row in targetWidget */
  alerts?: { targetWidget: string; dismissible?: boolean };
  flex?: string;
}

export interface WidgetDef {
  id: string;
  kind: 'grid' | 'chart' | 'list' | 'alerts';
  title: string;
  /** Template used when the context selection exists, e.g. "{sel.limitId} · {sel.name}" */
  titleTemplate?: string;
  subtitle?: string;
  subtitleTemplate?: string;
  /** Widget whose (effective) selection feeds {sel.*} in templates. */
  contextFrom?: string;
  icon?: IconName;
  endpoint: string;
  /** Bindings: "$filter.x", "$selection.widget-1.rowId|fallback", or literals. */
  params: Record<string, ParamValue>;
  chartConfigId?: string;
  selection?: SelectionDef;
  presentation?: WidgetPresentation;
}

export interface LayoutSection {
  id: string;
  title?: string;
  subtitleTemplate?: string;
  /** heading = bar + title · kicker = small uppercase label */
  style?: 'heading' | 'kicker';
  /** filter ids rendered as controls on the right of the section header */
  controls?: string[];
  rows: string[][];
}

export type HeaderAction = 'settings' | 'copyLink' | 'exportPdf' | 'exportMenu';

export interface DashboardDefinition {
  schemaVersion: string;
  dashboardId: string;
  title: string;
  breadcrumb: string[];
  header: { actions: HeaderAction[] };
  features: { filterBar?: boolean; crossFilterStrip?: boolean };
  tooltip?: { hoverDelayMs?: number };
  footnote?: string;
  widgets: WidgetDef[];
  layout: { sections: LayoutSection[] };
}

export interface FilterOption {
  value: FilterValue;
  label: string;
  [extra: string]: unknown;
}

export interface DateOffset {
  days?: number;
  businessDays?: number;
  months?: number;
}

export type FilterDerive =
  | { from: string; via: 'optionField'; optionField: string }
  | { from: string; via: 'addDays'; days: number }
  /** e.g. PCOB = COB − offset[compare]; user-entered while compare === manualWhen */
  | { from: string; via: 'compareOffset'; compareField: string; manualWhen: string; offsets: Record<string, DateOffset> };

export interface FilterDef {
  id: string;
  label: string;
  type: 'date' | 'segmented' | 'select' | 'derived';
  /** section = rendered in a layout section header (layout.sections[].controls) */
  placement: 'header' | 'bar' | 'section' | 'hidden';
  default?: FilterValue;
  editable?: boolean;
  /** Caption shown once before the options, e.g. "Top" → Top: 3 · 5 · 10 · All */
  prefix?: string;
  /** editable only while these filters have these values, e.g. { compare: 'Custom' } */
  editableWhen?: Record<string, FilterValue>;
  display?: 'date';
  options?: FilterOption[];
  derive?: FilterDerive;
}

export interface FilterSection {
  id: string;
  label: string;
  fields: string[];
}

export interface HotkeyDef {
  keys: string[];
  label: string;
  action: 'cycleFilter' | 'setFilter';
  filterId: string;
  values?: FilterValue[];
}

export interface DashboardFilters {
  schemaVersion: string;
  dashboardId: string;
  fields: FilterDef[];
  sections: FilterSection[];
  hotkeys: HotkeyDef[];
}

export interface ChartConfigResponse {
  schemaVersion: string;
  dashboardId: string;
  charts: Record<string, ChartConfig>;
}

export interface WidgetSelection {
  rowId: string;
  row: Record<string, unknown>;
  /** true when chosen by the UI (selection.default), not by the user */
  isDefault?: boolean;
}
