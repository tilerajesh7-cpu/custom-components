export type PrintMode = 'page' | 'a4';

const STYLE_ID = 'sparc-print-page';
const A4_CONTENT_WIDTH_PX = 718; // 210mm − 2 × 10mm margins at 96dpi

/**
 * Print-to-PDF with a mode-specific @page box (the browser's print dialog saves the PDF).
 *  - page: one continuous page sized to the whole dashboard (no page breaks).
 *  - a4:   A4 portrait, content scaled to the page width; cards never split across pages.
 * @page size cannot read CSS variables, so a print-only <style> is injected for the job and removed after.
 */
export function printDashboard(mode: PrintMode, root: HTMLElement | null = document.body) {
  const el = root ?? document.body;
  const width = Math.ceil(el.scrollWidth);
  const height = Math.ceil(el.scrollHeight);
  const scale = Math.min(1, A4_CONTENT_WIDTH_PX / width);

  const css =
    mode === 'page'
      ? `@page { size: ${width + 32}px ${height + 32}px; margin: 16px; }
         html.print-page, html.print-page body { width: ${width}px; }`
      : `@page { size: A4 portrait; margin: 10mm; }
         html.print-a4 body { zoom: ${scale.toFixed(3)}; }
         html.print-a4 [data-widget], html.print-a4 [data-print-avoid] { break-inside: avoid; page-break-inside: avoid; }`;

  document.getElementById(STYLE_ID)?.remove();
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.media = 'print';
  style.textContent = css;
  document.head.appendChild(style);
  const cls = `print-${mode}`;
  document.documentElement.classList.add(cls);

  const cleanup = () => {
    style.remove();
    document.documentElement.classList.remove(cls);
    window.removeEventListener('afterprint', cleanup);
  };
  window.addEventListener('afterprint', cleanup);
  // let menus close and charts reflow before the print snapshot
  window.setTimeout(() => {
    window.dispatchEvent(new Event('resize'));
    window.setTimeout(() => window.print(), 150);
  }, 120);
}
