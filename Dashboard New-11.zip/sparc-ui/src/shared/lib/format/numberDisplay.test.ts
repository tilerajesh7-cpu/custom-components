import { describe, expect, it } from 'vitest';
import { cellNumber, formatActual, formatCell, withDisplay } from './numberDisplay';

describe('numberDisplay', () => {
  it('app option overrides the service negative style', () => {
    expect(withDisplay({ negative: 'parentheses', decimals: 1 }, { negative: 'minus', colorNegative: true })).toEqual({ negative: 'minus', decimals: 1 });
    expect(withDisplay({ negative: 'parentheses' }, { negative: 'source', colorNegative: false }).negative).toBe('parentheses');
  });
  it('formats limit strings', () => {
    expect(formatCell('-1500|1500', { negative: 'minus' })).toBe('-1,500 | 1,500');
    expect(formatCell('-150', { negative: 'minus' })).toBe('-150');
    expect(cellNumber('-150')).toBe(-150);
    expect(cellNumber('-9|60')).toBeNull();
  });
  it('shows the actual value in tooltips', () => {
    expect(formatActual(-223.8, { label: '$MM', multiplier: 1_000_000 }, { negative: 'minus' })).toBe('-223,800,000.00');
    expect(formatActual(1.2345, undefined)).toBe('1.2345');
  });
});
