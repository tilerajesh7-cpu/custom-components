import { formatNumber, type NumberFormat } from './number';

/**
 * Application-level number display (one per app, set in app/providers via NumberDisplayProvider).
 * Lets each consuming application decide how negatives look without touching service contracts.
 */
export interface NumberDisplayOptions {
  /** 'source' keeps whatever columnMetadata.format says; otherwise overrides it. */
  negative: 'minus' | 'parentheses' | 'source';
  /** Colour negative numbers (grid cells, lists, tooltips). */
  colorNegative: boolean;
}

export const DEFAULT_NUMBER_DISPLAY: NumberDisplayOptions = { negative: 'source', colorNegative: false };

export const withDisplay = (fmt: NumberFormat | undefined, d: NumberDisplayOptions): NumberFormat =>
  d.negative === 'source' ? (fmt ?? {}) : { ...(fmt ?? {}), negative: d.negative };

const RANGE = /^\s*(-?\d+(?:\.\d+)?)\s*\|\s*(-?\d+(?:\.\d+)?)\s*$/;
const NUM_STR = /^\s*-?\d+(?:\.\d+)?\s*$/;

/** Numeric value of a cell: numbers, numeric strings ("-150"); ranges ("min|max") return null. */
export const cellNumber = (v: unknown): number | null =>
  typeof v === 'number' && Number.isFinite(v) ? v : typeof v === 'string' && NUM_STR.test(v) ? Number(v) : null;

/**
 * Formats any grid cell value. Supports limit strings sent by services:
 *   "-1500|1500" → "-1,500 | 1,500" · "-150" → "-150" · "" → "".
 */
export function formatCell(v: unknown, fmt: NumberFormat = {}): string {
  if (typeof v === 'string') {
    const m = RANGE.exec(v);
    if (m) return `${formatNumber(Number(m[1]), { ...fmt, style: 'compact' })} | ${formatNumber(Number(m[2]), { ...fmt, style: 'compact' })}`;
    if (NUM_STR.test(v)) return formatNumber(Number(v), { ...fmt, style: 'compact' });
    return v;
  }
  return formatNumber(v, fmt);
}

export interface ValueUnit {
  /** e.g. "$MM" */
  label: string;
  /** displayed value × multiplier = actual value (1,000,000 for $MM) */
  multiplier: number;
}

/** Full-precision "actual" value for plain tooltips: 223.8 ($MM) → "223,800,000.00". */
export function formatActual(v: unknown, unit: ValueUnit | undefined, fmt: NumberFormat = {}): string | null {
  const n = cellNumber(v);
  if (n == null) return typeof v === 'string' && v ? formatCell(v, fmt) : null;
  const actual = unit ? n * unit.multiplier : n;
  return formatNumber(actual, { negative: fmt.negative, style: 'fixed', decimals: unit ? 2 : Math.min(6, Math.max(2, (String(n).split('.')[1] ?? '').length)) });
}
