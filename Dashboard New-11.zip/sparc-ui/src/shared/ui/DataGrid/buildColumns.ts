import type { CellClassParams, ColDef, ColGroupDef, ITooltipParams, ValueFormatterParams } from 'ag-grid-community';
import { leafColumns, type GridResponse, type GridRow, type WireColDef } from '@shared/lib/contract/gridResponse';
import { signTone } from '@shared/lib/format/number';
import { cellNumber, DEFAULT_NUMBER_DISPLAY, formatActual, formatCell, withDisplay, type NumberDisplayOptions } from '@shared/lib/format/numberDisplay';
import { mix, rgba, shade } from '@shared/lib/color';
import { toneHex } from '@shared/config/tokens';

export interface GridStats {
  /** max |value| per numeric field over body rows (bars) */
  maxAbs: Record<string, number>;
  /** max |value − centerline| across all heatmap cells (grid scope) — one scale for the whole grid */
  heatMax: number;
  heat: HeatScale | null;
  /** grand-total row values (share-of-total in tooltips) */
  totals: Record<string, number | null>;
}

export interface HeatScale {
  center: number;
  max: number;
  pos: string;
  neg: string;
  /** services overrode colours with hex → continuous alpha tint of that hex */
  custom: boolean;
}

/** UI-owned palette endpoints (frozen design hues). Tint is interpolated from white → strong on ONE grid-wide scale. */
const HEAT_POS_STRONG = '#5cbf85';
const HEAT_NEG_STRONG = '#e8796d';
/** Cells below this share of the grid max stay unshaded (|v| / max < 1%). */
const HEAT_DEAD_ZONE = 0.01;
export const HEAT_INK = { pos: '#0f5132', neg: '#b42318', zero: '#98a2b3' };

export interface GridContext {
  stats: GridStats;
  numberDisplay: NumberDisplayOptions;
  selectedRowId: string | null;
  templateContext: Record<string, unknown>;
  response: GridResponse;
}

export type AnyColDef = ColDef<GridRow> | ColGroupDef<GridRow>;

const abs = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? Math.abs(v) : 0);

/** Row-level opt-out only: rowMetadata[id].excludeHeatMap (e.g. Grand Total / sub-total rows). */
export function heatExcluded(res: GridResponse, rowId: string | undefined) {
  if (!rowId) return true;
  return !!res.rowMetadata[rowId]?.excludeHeatMap;
}

/** Grid-level heatmap = every numeric column of the grid. */
export const isHeatField = (res: GridResponse, colType: string | undefined) => !!res.gridMetaData.heatmap && colType === 'DoubleType';

export function computeStats(res: GridResponse): GridStats {
  const leaves = leafColumns(res.columnDefs).filter((c) => c.field && c.colType === 'DoubleType');
  const body = res.rowData.filter((r) => !res.rowMetadata[r.id]?.rowType);
  const maxAbs: Record<string, number> = {};
  leaves.forEach((c) => {
    maxAbs[c.field!] = Math.max(1e-9, ...body.map((r) => abs(r[c.field!])));
  });

  let heatMax = 0;
  let heat: HeatScale | null = null;
  const hm = res.gridMetaData.heatmap;
  if (hm) {
    const center = hm.centerline ?? 0;
    if (typeof hm.min === 'number' && typeof hm.max === 'number') {
      // services computed the grid-level range
      heatMax = Math.max(Math.abs(hm.max - center), Math.abs(hm.min - center));
    } else {
      const fields = leaves.filter((c) => !c.hide).map((c) => c.field!);
      const rows = [...res.pinnedTopRows, ...res.rowData, ...res.pinnedBottomRows].filter((r) => !heatExcluded(res, r.id));
      heatMax = Math.max(0, ...rows.flatMap((r) => fields.map((f) => (typeof r[f] === 'number' ? Math.abs((r[f] as number) - center) : 0))));
    }
    heat = { center, max: heatMax, pos: toneHex(hm.positiveColor ?? 'heatPositive'), neg: toneHex(hm.negativeColor ?? 'heatNegative'), custom: !!(hm.positiveColor || hm.negativeColor) };
  }

  const totalRow =
    res.pinnedBottomRows.find((r) => res.rowMetadata[r.id]?.rowType === 'GRAND_TOTAL' || r.id === 'grand_total') ??
    res.rowData.find((r) => res.rowMetadata[r.id]?.rowType === 'GRAND_TOTAL');
  const totals: Record<string, number | null> = {};
  leaves.forEach((c) => {
    const v = totalRow?.[c.field!];
    totals[c.field!] = typeof v === 'number' ? v : null;
  });
  return { maxAbs, heatMax, heat, totals };
}

/** Continuous grid-level heat colour: tint strength ∝ |v − centerline| / grid max (perceptual curve). */
/**
 * Grid-level heat colour. Intensity = sqrt(|v − centerline| / gridMax) — the SAME max for every column,
 * so a column of small values (e.g. A/A Correl ≈ 1) stays near-white next to Skew ≈ 1,600.
 * Zero and near-zero (< 1% of grid max) are not coloured.
 */
export function heatColor(v: unknown, s: HeatScale): { bg: string; ink: string } | null {
  if (typeof v !== 'number' || !Number.isFinite(v) || s.max <= 0) return null;
  const d = v - s.center;
  const t = Math.min(1, Math.abs(d) / s.max);
  if (t < HEAT_DEAD_ZONE) return null;
  const k = Math.sqrt(t);
  if (s.custom) {
    const hex = d > 0 ? s.pos : s.neg;
    return { bg: rgba(hex, 0.08 + 0.6 * k), ink: shade(hex, 0.5) };
  }
  return { bg: mix('#ffffff', d > 0 ? HEAT_POS_STRONG : HEAT_NEG_STRONG, 0.12 + 0.88 * k), ink: d > 0 ? HEAT_INK.pos : HEAT_INK.neg };
}

export interface BuildColumnsOptions {
  groupTones?: string[];
  numberDisplay?: NumberDisplayOptions;
}

export function buildColumnDefs(res: GridResponse, opts: BuildColumnsOptions = {}): AnyColDef[] {
  const sortable = res.gridMetaData.defaultColDef?.sortable ?? true;
  const resizable = res.gridMetaData.defaultColDef?.resizable ?? true;
  let groupIdx = 0;
  const nd = opts.numberDisplay ?? DEFAULT_NUMBER_DISPLAY;
  const allRows = [...res.pinnedTopRows, ...res.rowData, ...res.pinnedBottomRows];

  const leaf = (wire: WireColDef, tone?: string, groupStart = false): ColDef<GridRow> => {
    const field = wire.field ?? '';
    const meta = res.columnMetadata[field] ?? {};
    const fmt = withDisplay(meta.format, nd);
    const unit = meta.valueUnit ?? res.gridMetaData.valueUnit;
    const numeric = wire.colType === 'DoubleType';
    const heatCol = isHeatField(res, wire.colType);
    const pinned = wire.pinned ?? undefined;
    // UI owns widths: every unpinned column flexes to fill the grid (no right-side whitespace,
    // also after Display / expand); services' width is only the floor. Narrower than the sum
    // of floors → horizontal scroll instead of squeezing.
    // floor never cuts the longest formatted value (or a heat column's header)
    const longest = numeric ? Math.max(0, ...allRows.map((r) => formatCell(r[field], fmt).length)) : 0;
    const extra = heatCol ? 30 : meta.type === 'bar' && meta.bar?.mode === 'diverging' ? 60 : 24;
    const textFloor = numeric ? Math.ceil(longest * 7.6 + extra) : 0;
    const headFloor = heatCol ? Math.min(130, Math.ceil((wire.headerName ?? field).length * 6.6 + 26)) : 0;
    const floor = Math.max(heatCol ? 78 : wire.width ?? (numeric ? 72 : 120), textFloor, headFloor);
    const def: ColDef<GridRow> = {
      colId: field,
      field,
      headerName: wire.headerName ?? field,
      headerTooltip: wire.headerTooltip ?? wire.headerName,
      hide: wire.hide,
      pinned,
      width: pinned ? wire.width : undefined,
      flex: pinned ? undefined : heatCol ? 1 : Math.max(1, Math.round(floor / 40)),
      minWidth: pinned ? wire.width ?? floor : floor,
      sortable,
      resizable,
      sort: meta.sort ?? null,
      sortIndex: meta.sortIndex,
      type: numeric ? 'rightAligned' : undefined,
      // numbers right-aligned, text left-aligned — header and cell alike
      headerClass: [numeric ? 'dg-align-right' : 'dg-align-left', groupStart ? 'dg-group-start' : '', tone ? `dg-tone-${tone}` : ''].filter(Boolean),
      cellClass: (p: CellClassParams<GridRow>) => {
        const cls: string[] = [numeric ? 'dg-align-right' : 'dg-align-left'];
        if (numeric) cls.push('dg-num');
        if (groupStart) cls.push('dg-group-start');
        if (tone) cls.push(`dg-tone-${tone}`);
        if (meta.tone === 'muted') cls.push('dg-muted');
        if (meta.tone === 'sign') cls.push(`dg-sign-${signTone(p.value)}`);
        const isLimit = !!p.data && res.rowMetadata[p.data.id]?.rowType === 'LIMIT';
        if (nd.colorNegative && numeric && !isLimit && (cellNumber(p.value) ?? 0) < 0) cls.push('dg-neg');
        if (heatCol) cls.push('dg-heat-cell');
        if (p.data && res.cellMetadata[p.data.id]?.[field]) cls.push('dg-cell-flag');
        return cls;
      },
    };
    if (numeric || meta.format) def.valueFormatter = (p: ValueFormatterParams<GridRow>) => formatCell(p.value, fmt);
    if (meta.type === 'bar' && meta.bar) {
      def.cellRenderer = 'barCell';
      def.cellRendererParams = { mode: meta.bar.mode, max: meta.bar.max, thresholds: meta.bar.thresholds };
    }
    if (heatCol) def.cellRenderer = 'heatCell';
    if (meta.type === 'badge') def.cellRenderer = 'badgeCell';
    // plain tooltip = ACTUAL value (displayed $MM × multiplier); text cells show their full text
    def.tooltipValueGetter = (p: ITooltipParams<GridRow>) => {
      if (p.value == null || p.value === '') return null;
      if (!numeric) return String(p.value);
      const a = formatActual(p.value, unit, fmt);
      return a == null ? null : unit && cellNumber(p.value) != null ? `${a} (actual)` : a;
    };
    if (meta.tooltip) {
      def.tooltipComponent = 'cellTooltip';
      def.tooltipComponentParams = { config: meta.tooltip, format: fmt, unit };
    }
    return def;
  };

  const map = (wire: WireColDef): AnyColDef => {
    if (!wire.children?.length) return leaf(wire);
    const tone = opts.groupTones?.[groupIdx++ % (opts.groupTones.length || 1)];
    return {
      groupId: wire.headerName,
      headerName: wire.headerName,
      marryChildren: true,
      headerClass: ['dg-group', 'dg-group-start', tone ? `dg-tone-${tone}` : ''].filter(Boolean),
      children: wire.children.map((c, i) => leaf(c, tone, i === 0)),
    } satisfies ColGroupDef<GridRow>;
  };

  return res.columnDefs.map(map);
}
