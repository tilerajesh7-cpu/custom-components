import { createContext, useContext, type ReactNode } from 'react';
import { DEFAULT_NUMBER_DISPLAY, type NumberDisplayOptions } from '../../lib/format/numberDisplay';

const Ctx = createContext<NumberDisplayOptions>(DEFAULT_NUMBER_DISPLAY);

/** Set once per application (e.g. SPARC: minus sign + red negatives). Read by DataGrid, RankedList, charts. */
export function NumberDisplayProvider({ value, children }: { value: Partial<NumberDisplayOptions>; children: ReactNode }) {
  return <Ctx.Provider value={{ ...DEFAULT_NUMBER_DISPLAY, ...value }}>{children}</Ctx.Provider>;
}

export const useNumberDisplay = () => useContext(Ctx);
