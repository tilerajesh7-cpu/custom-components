import clsx from 'clsx';
import { Icon, type IconName } from '../Icon/Icon';
import styles from './SegmentedControl.module.css';

export type SegmentValue = string | number;

export interface SegmentOption<V extends SegmentValue = SegmentValue> {
  value: V;
  label: string;
  icon?: IconName;
}

export interface SegmentedControlProps<V extends SegmentValue> {
  options: SegmentOption<V>[];
  value: V | undefined;
  onChange: (value: V) => void;
  /** dark = navy filter bar · light = header · subtle = card toolbar */
  tone?: 'dark' | 'light' | 'subtle';
  ariaLabel: string;
  /** Render icons only; labels become tooltip + aria-label. */
  iconOnly?: boolean;
  /** Small leading caption, e.g. "Top" before 3 · 5 · 10 · All. */
  prefix?: string;
}

export function SegmentedControl<V extends SegmentValue>({ options, value, onChange, tone = 'light', ariaLabel, iconOnly, prefix }: SegmentedControlProps<V>) {
  return (
    <div role="radiogroup" aria-label={ariaLabel} className={clsx(styles.group, styles[tone], iconOnly && styles.iconOnly)}>
      {prefix ? <span className={styles.prefix}>{prefix}</span> : null}
      {options.map((o) => {
        const on = o.value === value;
        return (
          <button
            key={String(o.value)}
            type="button"
            role="radio"
            aria-checked={on}
            aria-label={iconOnly ? o.label : undefined}
            title={iconOnly ? o.label : undefined}
            className={clsx(styles.item, on && styles.on)}
            onClick={() => onChange(o.value)}
          >
            {o.icon ? <Icon name={o.icon} size={iconOnly ? 15 : 13} /> : null}
            {iconOnly && o.icon ? null : o.label}
          </button>
        );
      })}
    </div>
  );
}
