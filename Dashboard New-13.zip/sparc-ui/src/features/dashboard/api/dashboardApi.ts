import { apiGet } from '@shared/lib/http/client';
import { ContractError, type GridResponse } from '@shared/lib/contract/gridResponse';
import { mergeGrid, parseGridConfig, parseGridData, type GridConfig } from '@shared/lib/contract/gridConfig';
import { parseChartConfig, parseDefinition, parseFilters } from '../model/schemas';
import type { ChartConfigResponse, DashboardDefinition, DashboardFilters, ParamValue } from '../model/types';

/* Endpoints (relative to VITE_API_BASE):
 *   GET /dashboards/{id}/definition    — widgets, layout, bindings (cacheable)
 *   GET /dashboards/{id}/filters       — filter fields, sections, hotkeys
 *   GET /dashboards/{id}/chart-config  — chart configs keyed by chartConfigId
 *   GET {widget.endpoint}/config?{params} — v2 response minus rowData (metadata + pinned rows)
 *   GET {widget.endpoint}/data?{params}   — { rowData } only
 */

export const fetchDefinition = (id: string, signal?: AbortSignal) => apiGet<DashboardDefinition>(`/dashboards/${id}/definition`, undefined, { signal, parse: parseDefinition });

export const fetchFilters = (id: string, signal?: AbortSignal) => apiGet<DashboardFilters>(`/dashboards/${id}/filters`, undefined, { signal, parse: parseFilters });

export const fetchChartConfig = (id: string, signal?: AbortSignal) => apiGet<ChartConfigResponse>(`/dashboards/${id}/chart-config`, undefined, { signal, parse: parseChartConfig });

/* ---------- grid config: shared per endpoint + params, last-good copy in localStorage ---------- */

const STORE_KEY = 'sparc-ui:grid-config:';
const configCache = new Map<string, Promise<GridConfig>>();
const keyOf = (endpoint: string, params: Record<string, ParamValue>) =>
  endpoint + JSON.stringify(Object.keys(params).sort().map((k) => [k, params[k]]));

const readStored = (endpoint: string): GridConfig | null => {
  try {
    const raw = localStorage.getItem(STORE_KEY + endpoint);
    return raw ? parseGridConfig(JSON.parse(raw)) : null;
  } catch {
    return null;
  }
};

const store = (endpoint: string, cfg: GridConfig) => {
  try {
    localStorage.setItem(STORE_KEY + endpoint, JSON.stringify(cfg));
  } catch {
    /* quota / private mode — cache is best-effort */
  }
};

async function withRetry<T>(fn: () => Promise<T>, retries: number, baseMs = 300): Promise<T> {
  for (let i = 0; ; i++) {
    try {
      return await fn();
    } catch (e) {
      if (i >= retries || e instanceof ContractError) throw e;
      await new Promise((r) => setTimeout(r, baseMs * 2 ** i));
    }
  }
}

export class ConfigUnavailableError extends Error {
  constructor(endpoint: string, cause: unknown) {
    super(`Grid configuration unavailable (${endpoint}). ${cause instanceof Error ? cause.message : ''}`.trim());
    this.name = 'ConfigUnavailableError';
  }
}

/**
 * Config carries every v2 block except rowData (incl. rowMetadata, cellMetadata, pinned totals),
 * so it is requested with the same params as the data. One shared request per endpoint + params;
 * on failure falls back to the last-good config for the endpoint (pinned totals may then be stale).
 */
export function fetchGridConfig(endpoint: string, params: Record<string, ParamValue>): Promise<GridConfig> {
  const key = keyOf(endpoint, params);
  const hit = configCache.get(key);
  if (hit) return hit;
  const p = withRetry(() => apiGet<GridConfig>(`${endpoint}/config`, params, { parse: parseGridConfig }), 2)
    .then((cfg) => {
      store(endpoint, cfg);
      return cfg;
    })
    .catch((err: unknown) => {
      configCache.delete(key);
      const stored = readStored(endpoint);
      if (stored) {
        console.warn(`[grid-config] using last-good config for ${endpoint}`, err);
        return stored;
      }
      throw new ConfigUnavailableError(endpoint, err);
    });
  configCache.set(key, p);
  return p;
}

export const invalidateGridConfigs = () => configCache.clear();

/** Config and data are requested in parallel, then merged into the Grid Response v2 shape. */
export async function fetchWidgetData(endpoint: string, params: Record<string, ParamValue>, signal?: AbortSignal): Promise<GridResponse> {
  const [cfg, data] = await Promise.all([fetchGridConfig(endpoint, params), apiGet(`${endpoint}/data`, params, { signal, parse: parseGridData })]);
  return mergeGrid(cfg, data);
}
