import { ApiError, type Transport } from '@shared/lib/http/client';
import { env } from '@shared/config/env';

/**
 * Mock transport — serves src/mocks/data/** for every API call, so the UI runs with no backend.
 *   {endpoint}/config → data/grid-config/{id}.json  (v2 minus rowData; pinned totals re-derived per params)
 *   {endpoint}/data   → data/grid-data/{id}.json  or  data/grid-data/{id}/{key}.json (selection-keyed)
 * Real services return pre-filtered rows; here FILTER_EFFECTS adjust the base rows instead of
 * shipping one file per filter combination.
 */

const files = import.meta.glob<unknown>('./data/**/*.json', { import: 'default' });

/** Data that depends on a selection → file keyed by that param ({key}.json, default "all"). */
const KEYED: Record<string, string> = {
  'component-var-svar': 'rowId',
  'component-var-svar-fs-type': 'rowId',
  'standalone-var-svar-trend': 'rowId',
  'component-var-svar-trend': 'rowId',
  'component-var-svar-fs-type-trend': 'rowId',
  'limit-history': 'limitId',
};

const SCALED = new Set(['standalone-var-svar', 'component-var-svar', 'component-var-svar-fs-type', 'standalone-var-svar-trend', 'component-var-svar-trend', 'component-var-svar-fs-type-trend']);
const VARIANT: Record<string, number> = { '1D': 1, '10D': Math.sqrt(10) };
const ATTRIBUTE: Record<string, number> = { Trading: 1, Economic: 1.12, Volcker: 0.94, 'Basel 3 Regulatory': 1.21, 'Trading & Credit Portfolio': 1.05 };
/** Non-regional rows emulate the region slice with a share factor. */
const REGION_SHARE: Record<string, number> = { All: 1, NA: 0.42, EMEA: 0.27, APAC: 0.19, Latam: 0.07, Global: 0.05 };
/** PCOB further back → older baseline. */
const COMPARE_PCOB: Record<string, number> = { Custom: 1, DoD: 1, WoW: 0.95, MoM: 0.88 };
/** Display filter: services return only the requested measure families. */
const DISPLAY_DROP: Record<string, RegExp | null> = { Both: null, MC: /^(hist|chvar_)/, Hist: /^(mc|cvar_)/ };

type Row = Record<string, unknown> & { id: string };

const round2 = (v: number) => Math.round(v * 100) / 100;
const isTotal = (r: Row) => r.rowType === 'GRAND_TOTAL' || r.rowType === 'SUB_TOTAL';

const dataFile = (id: string, params: Record<string, unknown>) =>
  KEYED[id] ? `./data/grid-data/${id}/${String(params[KEYED[id]] ?? 'all')}.json` : `./data/grid-data/${id}.json`;

function resolveFile(path: string, params: Record<string, unknown>) {
  const p = path.replace(/^\/+/, '');
  const m = /^(?:grids|series)\/([\w-]+)\/(config|data)$/.exec(p);
  if (!m) return `./data/${p}.json`;
  const [, id, part] = m;
  return part === 'config' ? `./data/grid-config/${id}.json` : dataFile(id, params);
}

interface MockCol { field?: string; children?: MockCol[] }
interface MockConfig {
  columnDefs: MockCol[];
  rowMetadata: Record<string, { rowType?: string }>;
  pinnedTopRows: Row[];
  pinnedBottomRows: Row[];
}

function pruneColumns(defs: MockCol[], drop: RegExp): MockCol[] {
  return defs.flatMap((d) => {
    if (d.children?.length) {
      const children = pruneColumns(d.children, drop);
      return children.length ? [{ ...d, children }] : [];
    }
    return d.field && drop.test(d.field) ? [] : [d];
  });
}

/** Emulates the backend: totals / pinned rows and columns follow the same params as the data. */
async function buildConfig(id: string, kind: string, cfg: MockConfig, params: Record<string, unknown>) {
  const loadData = files[dataFile(id, params)];
  const body = loadData ? (structuredClone(await loadData()) as { rowData: Row[] }).rowData : [];
  const tag = (r: Row): Row => ({ ...r, rowType: cfg.rowMetadata[r.id]?.rowType });
  const topIds = new Set(cfg.pinnedTopRows.map((r) => r.id));
  const bottomIds = new Set(cfg.pinnedBottomRows.map((r) => r.id));
  const rows = applyFilterEffects(id, kind, [...body, ...cfg.pinnedTopRows, ...cfg.pinnedBottomRows].map(tag), params);
  const bodyOut = rows.filter((r) => !topIds.has(r.id) && !bottomIds.has(r.id) && !isTotal(r));
  const untag = (r: Row) => {
    const { rowType: _t, ...rest } = r;
    return rest as Row;
  };
  // selection-keyed grids: grand totals must match the selected slice
  const pinned = rows
    .filter((r) => topIds.has(r.id) || bottomIds.has(r.id))
    .map((r) => {
      if (KEYED[id] && r.rowType === 'GRAND_TOTAL') sumInto(r, bodyOut);
      return untag(r);
    });
  const drop = SCALED.has(id) ? DISPLAY_DROP[String(params.display)] : null;
  return {
    ...cfg,
    columnDefs: drop ? pruneColumns(cfg.columnDefs, drop) : cfg.columnDefs,
    pinnedTopRows: pinned.filter((r) => topIds.has(r.id)),
    pinnedBottomRows: pinned.filter((r) => bottomIds.has(r.id)),
  };
}

function sumInto(target: Row, rows: Row[]) {
  Object.keys(target).forEach((k) => {
    if (typeof target[k] !== 'number') return;
    const vals = rows.map((r) => r[k]).filter((v): v is number => typeof v === 'number');
    target[k] = vals.length ? round2(vals.reduce((a, b) => a + b, 0)) : null;
  });
}

function applyFilterEffects(id: string, kind: string, rows: Row[], params: Record<string, unknown>): Row[] {
  let out = rows;
  const region = params.region;
  const regional = out.some((r) => !isTotal(r) && 'region' in r);

  if (typeof region === 'string' && region !== 'All' && regional && !id.includes('region') && !id.startsWith('volcker')) {
    const body = out.filter((r) => !isTotal(r) && r.region === region);
    const totals = out.filter(isTotal).map((t) => {
      const c = { ...t };
      sumInto(c, body);
      if (id === 'limit-utilization') {
        const risk = body.filter((r) => Number(r.utilization) >= 0.8).length;
        const br = body.filter((r) => Number(r.utilization) >= 1).length;
        c.tier = `${risk} at risk · ${br} in breach`;
      }
      return c;
    });
    out = [...body, ...totals];
  }

  if (SCALED.has(id)) {
    const share = !regional && typeof region === 'string' ? (REGION_SHARE[region] ?? 1) : 1;
    const f = (VARIANT[String(params.variant)] ?? 1) * (ATTRIBUTE[String(params.attribute)] ?? 1) * share;
    if (f !== 1) out.forEach((r) => Object.keys(r).forEach((k) => typeof r[k] === 'number' && (r[k] = round2((r[k] as number) * f))));

    const cf = COMPARE_PCOB[String(params.compare)] ?? 1;
    if (kind === 'grids' && cf !== 1) {
      out.forEach((r) =>
        Object.keys(r).forEach((k) => {
          if (!k.endsWith('Pcob') || typeof r[k] !== 'number') return;
          const m = k.slice(0, -4);
          r[k] = round2((r[k] as number) * cf);
          if (typeof r[`${m}Cob`] === 'number') r[`${m}Diff`] = round2((r[`${m}Cob`] as number) - (r[k] as number));
        }),
      );
    }

    const drop = DISPLAY_DROP[String(params.display)];
    if (drop) out.forEach((r) => Object.keys(r).forEach((k) => drop.test(k) && delete r[k]));
  }

  const days = Number(params.days);
  if (kind === 'series' && days > 0) out = out.slice(-days);
  return out;
}

const delay = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => {
      clearTimeout(t);
      reject(new DOMException('Aborted', 'AbortError'));
    });
  });

export const mockTransport: Transport = async ({ path, params = {}, signal }) => {
  const file = resolveFile(path, params);
  await delay(env.mockLatencyMs * (0.6 + Math.random() * 0.8), signal);
  const load = files[file];
  if (!load) throw new ApiError(`Mock not found for ${path} (${file})`, { status: 404, code: 'NOT_FOUND' });
  const raw = structuredClone(await load());
  const m = /^\/?(grids|series)\/([\w-]+)\/(config|data)$/.exec(path);
  if (!m) return raw;
  const [, kind, id, part] = m;
  if (part === 'config') return buildConfig(id, kind, raw as MockConfig, params);
  return { rowData: applyFilterEffects(id, kind, (raw as { rowData: Row[] }).rowData, params) };
};
