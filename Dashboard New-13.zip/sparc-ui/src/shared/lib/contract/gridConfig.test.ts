import { describe, expect, it } from 'vitest';
import { mergeGrid, parseGridConfig, parseGridData, type GridConfig } from './gridConfig';

const cfg: GridConfig = {
  schemaVersion: '2.0',
  gridId: 'g',
  gridMetaData: { title: 'Grid', heatmap: { scope: 'grid', centerline: 0 } },
  columnDefs: [{ field: 'name', colType: 'StringType' }, { field: 'v', colType: 'DoubleType' }],
  columnMetadata: { v: { type: 'heatmap' } },
  rowMetadata: { grand_total: { rowType: 'GRAND_TOTAL', bold: true, excludeHeatMap: true }, sub: { rowType: 'SUB_TOTAL', bold: true } },
  cellMetadata: { a: { v: { tooltip: 'flag' } } },
  pinnedTopRows: [],
  pinnedBottomRows: [{ id: 'grand_total', name: 'Grand Total', v: 3 }],
};

describe('grid config / data split', () => {
  it('merges config + rowData into the v2 response unchanged', () => {
    const res = mergeGrid(cfg, { rowData: [{ id: 'a', name: 'A', v: 1 }, { id: 'sub', name: 'Sub', v: 2 }] });
    expect(res.rowData.map((r) => r.id)).toEqual(['a', 'sub']);
    expect(res.rowMetadata.sub.rowType).toBe('SUB_TOTAL');
    expect(res.cellMetadata.a.v.tooltip).toBe('flag');
    expect(res.pinnedBottomRows[0].id).toBe('grand_total');
  });

  it('drops body rows duplicated in pinned rows', () => {
    const res = mergeGrid(cfg, { rowData: [{ id: 'a' }, { id: 'grand_total' }] });
    expect(res.rowData.map((r) => r.id)).toEqual(['a']);
  });

  it('defaults optional blocks and validates both responses', () => {
    const c = parseGridConfig({ schemaVersion: '2.0', gridId: 'g', columnDefs: [] });
    expect(c.rowMetadata).toEqual({});
    expect(c.pinnedBottomRows).toEqual([]);
    expect(() => parseGridConfig({ schemaVersion: '1.0', gridId: 'g', columnDefs: [] })).toThrow(/schemaVersion/);
    expect(() => parseGridData({ rows: [] })).toThrow(/rowData/);
  });
});
