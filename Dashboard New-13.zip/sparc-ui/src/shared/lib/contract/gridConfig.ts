import { z } from 'zod';
import { ContractError, type GridResponse, type GridRow } from './gridResponse';

/*
 * Grid Config / Data split — Grid Response Contract v2, unchanged, with ONE move:
 *   GET {endpoint}/config?{params} → every v2 block EXCEPT rowData
 *        schemaVersion · gridId · gridMetaData · columnDefs · columnMetadata
 *        rowMetadata · cellMetadata · pinnedTopRows · pinnedBottomRows
 *   GET {endpoint}/data?{params}   → { rowData }
 * mergeGrid() puts rowData back → the exact v2 GridResponse the UI consumes.
 */

export type GridConfig = Omit<GridResponse, 'rowData'>;

export interface GridData {
  rowData: GridRow[];
}

const RowSchema = z.object({ id: z.string() }).passthrough();

/** Tolerant reader: optional blocks default to empty; unknown keys pass through. */
const ConfigSchema = z
  .object({
    schemaVersion: z.string().refine((v) => v.startsWith('2.'), 'Unsupported schemaVersion (expected 2.x)'),
    gridId: z.string(),
    meta: z.record(z.unknown()).optional(),
    gridMetaData: z.record(z.unknown()).default({}),
    columnDefs: z.array(z.record(z.unknown())),
    columnMetadata: z.record(z.record(z.unknown())).default({}),
    rowMetadata: z.record(z.record(z.unknown())).default({}),
    cellMetadata: z.record(z.record(z.record(z.unknown()))).default({}),
    pinnedTopRows: z.array(RowSchema).default([]),
    pinnedBottomRows: z.array(RowSchema).default([]),
  })
  .passthrough();

const DataSchema = z.object({ rowData: z.array(RowSchema) }).passthrough();

const issues = (e: z.ZodError) => e.issues.map((i) => `${i.path.join('.') || 'response'}: ${i.message}`).join('; ');

export function parseGridConfig(raw: unknown): GridConfig {
  const r = ConfigSchema.safeParse(raw);
  if (!r.success) throw new ContractError(`Grid config: ${issues(r.error)}`);
  return r.data as unknown as GridConfig;
}

export function parseGridData(raw: unknown): GridData {
  const r = DataSchema.safeParse(raw);
  if (!r.success) throw new ContractError(`Grid data: ${issues(r.error)}`);
  return r.data as unknown as GridData;
}

/** Re-assembles the v2 response. Rows that also appear pinned are dropped from the body (defensive). */
export function mergeGrid(cfg: GridConfig, data: GridData): GridResponse {
  const pinned = new Set([...cfg.pinnedTopRows, ...cfg.pinnedBottomRows].map((r) => r.id));
  return { ...cfg, rowData: pinned.size ? data.rowData.filter((r) => !pinned.has(r.id)) : data.rowData };
}
