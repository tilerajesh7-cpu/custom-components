import clsx from 'clsx';
import { useCallback, useMemo, useRef } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { CellClickedEvent, GetRowIdParams, GridApi, RowClassParams } from 'ag-grid-community';
import type { GridResponse, GridRow } from '@shared/lib/contract/gridResponse';
import { DENSITY, TOOLTIP_DELAY_MS, type Density } from '@shared/config/tokens';
import { cssVars } from '@shared/lib/cssVars';
import { buildColumnDefs, computeStats, type GridContext } from './buildColumns';
import { BadgeCell, BarCell, HeatCell } from './renderers';
import { CellTooltip } from './CellTooltip';
import { ensureAgGridSetup } from './setup';
import { heatmapGridTheme, standardGridTheme } from './theme';
import '../Tooltip/tooltip.css';
import './DataGrid.css';

ensureAgGridSetup();

/** Flex columns (no width from services) size themselves and scroll horizontally below their minWidth; fixed-width grids are fitted. */
function fitIfFixed(api: GridApi<GridRow>, defs: ReturnType<typeof buildColumnDefs>) {
  const leaves = defs.flatMap((d) => ('children' in d ? d.children : [d])) as { flex?: number }[];
  if (!leaves.some((c) => c.flex)) api.sizeColumnsToFit();
}

const COMPONENTS = { barCell: BarCell, badgeCell: BadgeCell, heatCell: HeatCell, cellTooltip: CellTooltip };

export interface GridEvent {
  type: 'cellClick';
  rowId: string;
  row: GridRow;
  field?: string;
}

export interface DataGridProps {
  response: GridResponse;
  density?: Density;
  /** Highlighted row (controlled). */
  selectedRowId?: string | null;
  /** Rows react to click (pointer cursor + events). */
  interactive?: boolean;
  groupTones?: string[];
  /** px, or 'auto' to size to rows. Defaults to filling the parent. */
  height?: number | 'auto';
  variant?: 'standard' | 'heatmap';
  /** Values available to tooltip templates, e.g. { filter, filterLabel }. */
  templateContext?: Record<string, unknown>;
  /** Changing this remounts the grid (resets sort / column widths). */
  resetToken?: number;
  ariaLabel?: string;
  onEvent?: (e: GridEvent) => void;
}

/**
 * Generic AG Grid wrapper for Grid Response Contract v2.
 * Knows nothing about the domain — columns, renderers, tooltips and row styling all come from the response.
 */
export function DataGrid({ response, density = 'comfortable', selectedRowId = null, interactive = false, groupTones, height, variant = 'standard', templateContext, resetToken = 0, ariaLabel, onEvent }: DataGridProps) {
  const apiRef = useRef<GridApi<GridRow> | null>(null);
  const columnDefs = useMemo(() => buildColumnDefs(response, { groupTones }), [response, groupTones]);
  const stats = useMemo(() => computeStats(response), [response]);

  // Stable, mutable context object: AG Grid reads it lazily from renderers / class rules.
  const ctxRef = useRef<GridContext>({ stats, selectedRowId, templateContext: templateContext ?? {}, response });
  const prevSel = ctxRef.current.selectedRowId;
  ctxRef.current.stats = stats;
  ctxRef.current.selectedRowId = selectedRowId;
  ctxRef.current.templateContext = templateContext ?? {};
  ctxRef.current.response = response;
  if (prevSel !== selectedRowId) queueMicrotask(() => apiRef.current?.redrawRows());

  const rowClassRules = useMemo(
    () => ({
      'dg-row-selected': (p: RowClassParams<GridRow>) => !!p.data && !p.node.rowPinned && (p.context as GridContext).selectedRowId === p.data.id,
    }),
    [],
  );

  const getRowClass = useCallback(
    (p: RowClassParams<GridRow>) => {
      const m = p.data ? response.rowMetadata[p.data.id] : undefined;
      const cls: string[] = [];
      if (p.node.rowPinned || m?.rowType === 'GRAND_TOTAL') cls.push('dg-row-total');
      else if (m?.rowType === 'SUB_TOTAL') cls.push('dg-row-subtotal');
      if (m?.bold) cls.push('dg-row-bold');
      return cls;
    },
    [response],
  );

  const onCellClicked = useCallback(
    (e: CellClickedEvent<GridRow>) => {
      if (!interactive || !e.data || e.node.rowPinned) return;
      if (response.rowMetadata[e.data.id]?.selectable === false) return;
      onEvent?.({ type: 'cellClick', rowId: e.data.id, row: e.data, field: e.colDef.field });
    },
    [interactive, onEvent, response],
  );

  const getRowId = useCallback((p: GetRowIdParams<GridRow>) => String(p.data.id), []);
  const d = DENSITY[density];
  const auto = height === 'auto';

  return (
    <div
      className={clsx('dg-root', `dg-${variant}`, interactive && 'dg-interactive', auto && 'dg-auto')}
      style={typeof height === 'number' ? cssVars({ '--dg-height': `${height}px` }) : undefined}
      aria-label={ariaLabel}
    >
      <AgGridReact<GridRow>
        key={`${density}-${resetToken}`}
        theme={variant === 'heatmap' ? heatmapGridTheme : standardGridTheme}
        rowData={response.rowData}
        pinnedTopRowData={response.pinnedTopRows}
        pinnedBottomRowData={response.pinnedBottomRows}
        columnDefs={columnDefs}
        defaultColDef={{ suppressHeaderMenuButton: true, suppressMovable: true }}
        getRowId={getRowId}
        context={ctxRef.current}
        rowHeight={variant === 'heatmap' ? d.rowHeight + 2 : d.rowHeight}
        headerHeight={d.headerHeight}
        groupHeaderHeight={d.headerHeight}
        domLayout={auto ? 'autoHeight' : 'normal'}
        components={COMPONENTS}
        tooltipShowDelay={TOOLTIP_DELAY_MS}
        tooltipHideDelay={10_000}
        rowClassRules={rowClassRules}
        getRowClass={getRowClass}
        onGridReady={(e) => {
          apiRef.current = e.api;
        }}
        onFirstDataRendered={(e) => fitIfFixed(e.api, columnDefs)}
        onGridSizeChanged={(e) => fitIfFixed(e.api, columnDefs)}
        onCellClicked={onCellClicked}
        suppressCellFocus
        enableCellTextSelection
        animateRows
      />
    </div>
  );
}
