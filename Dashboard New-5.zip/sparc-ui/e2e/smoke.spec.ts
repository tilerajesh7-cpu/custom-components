import { expect, test } from '@playwright/test';

test('VaR Summary: row click drives drilldown, Esc clears', async ({ page }) => {
  await page.goto('/#/daily-risk/equities/var-summary');
  await expect(page.getByRole('heading', { name: 'VaR Summary' })).toBeVisible();
  await expect(page.getByText('Standalone VaR/SVaR ($MM)')).toBeVisible();

  const firstRow = page.locator('[data-widget="widget-1"] .ag-center-cols-container .ag-row').first();
  await firstRow.click();
  await expect(page.locator('[data-chip-kind="DESK"]')).toBeVisible();

  await page.keyboard.press('Escape');
  await expect(page.locator('[data-chip-kind="DESK"]')).toHaveCount(0);
});

test('VaR Summary: top filter change keeps the page usable', async ({ page }) => {
  await page.goto('/#/daily-risk/equities/var-summary');
  await page.getByRole('radio', { name: '10DAY' }).click();
  await expect(page.getByRole('radio', { name: '10DAY' })).toHaveAttribute('aria-checked', 'true');
});

test('Greek Mock 4 renders charts by default', async ({ page }) => {
  await page.goto('/#/daily-risk/equities/greek-dashboard-v2');
  await expect(page.getByRole('heading', { name: 'Global Equities Greek Dashboard' })).toBeVisible();
  await expect(page.locator('.highcharts-root').first()).toBeVisible();
});
