import js from '@eslint/js';
import globals from 'globals';
import tseslint from 'typescript-eslint';
import reactHooks from 'eslint-plugin-react-hooks';
import boundaries from 'eslint-plugin-boundaries';

export default tseslint.config(
  { ignores: ['dist', 'coverage', 'node_modules', 'playwright-report'] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ['src/**/*.{ts,tsx}'],
    languageOptions: { ecmaVersion: 2022, globals: globals.browser },
    plugins: { 'react-hooks': reactHooks, boundaries },
    settings: {
      'import/resolver': { typescript: { project: './tsconfig.app.json' } },
      'boundaries/elements': [
        { type: 'app', pattern: 'src/app/*' },
        { type: 'pages', pattern: 'src/pages/*' },
        { type: 'layouts', pattern: 'src/layouts/*' },
        { type: 'features', pattern: 'src/features/*', capture: ['feature'] },
        { type: 'shared', pattern: 'src/shared/*' },
        { type: 'mocks', pattern: 'src/mocks/*' },
      ],
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      'boundaries/element-types': [
        'error',
        {
          default: 'disallow',
          rules: [
            { from: 'app', allow: ['app', 'pages', 'layouts', 'features', 'shared', 'mocks'] },
            { from: ['pages', 'layouts'], allow: ['features', 'shared', 'pages', 'layouts'] },
            { from: 'features', allow: ['shared', ['features', { feature: '${from.feature}' }]] },
            { from: 'shared', allow: ['shared'] },
            { from: 'mocks', allow: ['shared', 'mocks'] },
          ],
        },
      ],
      'no-restricted-imports': ['error', { patterns: [{ group: ['@features/*/*'], message: 'Import features through their index.ts public API.' }] }],
    },
  },
);
