import { env } from '@shared/config/env';

/** Runs before first render. Mocks are dynamically imported so they never ship in a non-mock build. */
export async function bootstrap() {
  if (env.useMocks) {
    const { registerMockTransport } = await import('@mocks/index');
    registerMockTransport();
  }
}
