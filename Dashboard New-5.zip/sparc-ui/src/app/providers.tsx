import type { ReactNode } from 'react';
import { Provider } from 'react-redux';
import { QueryClientProvider } from '@tanstack/react-query';
import { PersistGate } from 'redux-persist/integration/react';
import { DesignSystemProvider } from '@shared/ui';
import { queryClient } from './queryClient';
import { persistor, store } from './store';

/** Outermost first: design system → Redux → TanStack Query → PersistGate. */
export function AppProviders({ children }: { children: ReactNode }) {
  return (
    <DesignSystemProvider>
      <Provider store={store}>
        <QueryClientProvider client={queryClient}>
          <PersistGate loading={null} persistor={persistor}>
            {children}
          </PersistGate>
        </QueryClientProvider>
      </Provider>
    </DesignSystemProvider>
  );
}
