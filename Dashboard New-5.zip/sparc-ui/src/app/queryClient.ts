import { QueryClient } from '@tanstack/react-query';
import { ApiError } from '@shared/lib/http/client';
import { ContractError } from '@shared/lib/contract/gridResponse';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      gcTime: 30 * 60_000,
      // never retry contract violations or 4xx
      retry: (count, err) => !(err instanceof ContractError) && !(err instanceof ApiError && (err.status ?? 500) < 500) && count < 2,
    },
  },
});
