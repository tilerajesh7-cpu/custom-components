import { lazy } from 'react';
import { createHashRouter, Navigate } from 'react-router-dom';
import AppLayout from '@layouts/AppLayout';

const VarSummaryPage = lazy(() => import('@pages/VarSummaryPage'));
const GreekDashboardPage = lazy(() => import('@pages/GreekDashboardPage'));
const GreekDashboardV2Page = lazy(() => import('@pages/GreekDashboardV2Page'));
const NotFoundPage = lazy(() => import('@pages/NotFoundPage'));

export const DEFAULT_ROUTE = '/daily-risk/equities/var-summary';

/** Hash routing: served from /crmr-sparc with base './' — no server rewrites needed. */
export const router = createHashRouter([
  {
    path: '/',
    element: <AppLayout />,
    children: [
      { index: true, element: <Navigate to={DEFAULT_ROUTE} replace /> },
      { path: 'daily-risk/equities/var-summary', element: <VarSummaryPage /> },
      { path: 'daily-risk/equities/greek-dashboard', element: <GreekDashboardPage /> },
      { path: 'daily-risk/equities/greek-dashboard-v2', element: <GreekDashboardV2Page /> },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
]);
