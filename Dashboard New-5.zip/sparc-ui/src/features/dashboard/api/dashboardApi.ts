import { apiGet } from '@shared/lib/http/client';
import { parseGridResponse, type GridResponse } from '@shared/lib/contract/gridResponse';
import { parseChartConfig, parseDefinition, parseFilters } from '../model/schemas';
import type { ChartConfigResponse, DashboardDefinition, DashboardFilters, ParamValue } from '../model/types';

/* Endpoints (relative to VITE_API_BASE):
 *   GET /dashboards/{id}/definition    — widgets, layout, bindings (cacheable)
 *   GET /dashboards/{id}/filters       — filter fields, sections, hotkeys
 *   GET /dashboards/{id}/chart-config  — chart configs keyed by chartConfigId (separate API)
 *   GET {widget.endpoint}?{params}     — Grid Response v2 (grids and series alike)
 */

export const fetchDefinition = (id: string, signal?: AbortSignal) => apiGet<DashboardDefinition>(`/dashboards/${id}/definition`, undefined, { signal, parse: parseDefinition });

export const fetchFilters = (id: string, signal?: AbortSignal) => apiGet<DashboardFilters>(`/dashboards/${id}/filters`, undefined, { signal, parse: parseFilters });

export const fetchChartConfig = (id: string, signal?: AbortSignal) => apiGet<ChartConfigResponse>(`/dashboards/${id}/chart-config`, undefined, { signal, parse: parseChartConfig });

export const fetchWidgetData = (endpoint: string, params: Record<string, ParamValue>, signal?: AbortSignal) =>
  apiGet<GridResponse>(endpoint, params, { signal, parse: parseGridResponse });
