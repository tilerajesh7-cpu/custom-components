import { keepPreviousData, queryOptions, useQuery } from '@tanstack/react-query';
import { fetchChartConfig, fetchDefinition, fetchFilters, fetchWidgetData } from './dashboardApi';
import type { ParamValue } from '../model/types';

export const dashboardKeys = {
  all: ['dashboard'] as const,
  definition: (id: string) => ['dashboard', id, 'definition'] as const,
  filters: (id: string) => ['dashboard', id, 'filters'] as const,
  chartConfig: (id: string) => ['dashboard', id, 'chart-config'] as const,
  /** Applied filters + selections are part of the key → results cached per combination. */
  widget: (endpoint: string, params: Record<string, ParamValue>) => ['widget-data', endpoint, params] as const,
};

export const useDashboardDefinition = (id: string) =>
  useQuery({ queryKey: dashboardKeys.definition(id), queryFn: ({ signal }) => fetchDefinition(id, signal), staleTime: Infinity });

export const useDashboardFilters = (id: string) =>
  useQuery({ queryKey: dashboardKeys.filters(id), queryFn: ({ signal }) => fetchFilters(id, signal), staleTime: Infinity });

export const useChartConfig = (id: string, enabled: boolean) =>
  useQuery({ queryKey: dashboardKeys.chartConfig(id), queryFn: ({ signal }) => fetchChartConfig(id, signal), staleTime: Infinity, enabled });

export const widgetQueryOptions = (endpoint: string, params: Record<string, ParamValue>, enabled: boolean) =>
  queryOptions({
    queryKey: dashboardKeys.widget(endpoint, params),
    queryFn: ({ signal }) => fetchWidgetData(endpoint, params, signal),
    enabled,
    staleTime: 5 * 60_000,
    placeholderData: keepPreviousData,
  });
