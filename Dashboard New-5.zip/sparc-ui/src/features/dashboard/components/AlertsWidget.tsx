import { useMemo, useState } from 'react';
import { useDispatch } from 'react-redux';
import { formatNumber, toNumber } from '@shared/lib/format/number';
import { AlertBanner, type AlertItem } from '@shared/ui';
import { useDashboardContext } from '../context';
import { useEffectiveSelections, useWidgetData } from '../hooks/useWidgetData';
import { dashboardActions } from '../model/dashboardSlice';
import type { WidgetDef } from '../model/types';

/**
 * Limit alerts strip. Data = Grid Response v2 (rows already filtered to WARNING / BREACH by services,
 * status in rowMetadata). Clicking an alert selects that row in presentation.alerts.targetWidget.
 */
export function AlertsWidget({ widget }: { widget: WidgetDef }) {
  const { dashboardId } = useDashboardContext();
  const dispatch = useDispatch();
  const [dismissed, setDismissed] = useState(false);
  const cfg = widget.presentation?.alerts;
  const { query } = useWidgetData(widget);
  const target = cfg?.targetWidget;
  const targetSel = useEffectiveSelections(target ? [target] : [])[target ?? ''];
  const data = query.data;

  const items = useMemo<AlertItem[]>(() => {
    if (!data) return [];
    return data.rowData
      .map((r) => {
        const st = String(data.rowMetadata[r.id]?.status ?? '').toUpperCase();
        if (st !== 'BREACH' && st !== 'WARNING') return null;
        const util = toNumber(r.utilization);
        const fmt = (k: string) => formatNumber(r[k]);
        return {
          id: r.id,
          status: st === 'BREACH' ? 'breach' : 'warning',
          statusLabel: st === 'BREACH' ? 'Breach' : 'Warning',
          name: String(r.name ?? r.id),
          code: r.limitId != null ? String(r.limitId) : undefined,
          value: formatNumber(util, { style: 'percent', decimals: 1 }),
          tooltip: `Exposure ${fmt('exposure')} · Threshold ${fmt('threshold')} · ${st === 'BREACH' ? 'over by' : 'headroom'} ${formatNumber(Math.abs(toNumber(r.headroom) ?? 0))}`,
          active: targetSel?.rowId === r.id,
        } satisfies AlertItem;
      })
      .filter((x): x is AlertItem => !!x);
  }, [data, targetSel]);

  if (dismissed || !items.length) return null;
  return (
    <AlertBanner
      title={`${items.length} limit${items.length === 1 ? '' : 's'} need attention`}
      items={items}
      onDismiss={cfg?.dismissible ? () => setDismissed(true) : undefined}
      onSelect={(id) => {
        const row = data?.rowData.find((r) => r.id === id);
        if (target && row) dispatch(dashboardActions.selectRow({ dashboardId, widgetId: target, selection: { rowId: id, row } }));
      }}
    />
  );
}
