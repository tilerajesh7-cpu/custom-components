import { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { DENSITY } from '@shared/config/tokens';
import { cssVars } from '@shared/lib/cssVars';
import { interpolate } from '@shared/lib/template/interpolate';
import { CrossFilterStrip, ErrorState, FilterBar, PageLoader, SectionHeading, ShortcutsDialog, type FilterBarSection } from '@shared/ui';
import { useChartConfig, useDashboardDefinition, useDashboardFilters } from '../api/queries';
import { DashboardContext, useDashboardContext, type DashboardContextValue } from '../context';
import { useCrossFilterChips } from '../hooks/useCrossFilterChips';
import { useDashboardHotkeys } from '../hooks/useDashboardHotkeys';
import { defaultFilterValues, filterLabels, fromSearch, withDerived } from '../lib/filters';
import { dashboardActions, selectDensity, selectInstance, type DashboardRootState } from '../model/dashboardSlice';
import type { DashboardDefinition, DashboardFilters } from '../model/types';
import { DashboardHeader } from './DashboardHeader';
import { WidgetRenderer } from './WidgetRenderer';
import styles from './DashboardView.module.css';

/**
 * Renders any dashboard from its backend definition: header + filters + cross-filter strip + sections of widgets.
 * Pages only pass a dashboardId.
 */
export function DashboardView({ dashboardId }: { dashboardId: string }) {
  const def = useDashboardDefinition(dashboardId);
  const flt = useDashboardFilters(dashboardId);
  const needsCharts = !!def.data?.widgets.some((w) => w.chartConfigId);
  const charts = useChartConfig(dashboardId, needsCharts);

  if (def.isError || flt.isError) {
    const err = (def.error ?? flt.error) as Error | null;
    return <ErrorState title="Dashboard could not be loaded" message={err?.message} onRetry={() => { void def.refetch(); void flt.refetch(); }} />;
  }
  if (!def.data || !flt.data || (needsCharts && charts.isPending)) return <PageLoader />;
  return <DashboardScreen definition={def.data} filtersDef={flt.data} charts={charts.data?.charts ?? {}} />;
}

function DashboardScreen({ definition, filtersDef, charts }: { definition: DashboardDefinition; filtersDef: DashboardFilters; charts: DashboardContextValue['chartConfigs'] }) {
  const dashboardId = definition.dashboardId;
  const dispatch = useDispatch();
  const location = useLocation();
  const inst = useSelector((s: DashboardRootState) => selectInstance(s, dashboardId));
  const density = useSelector(selectDensity);
  const defaults = useMemo(() => defaultFilterValues(filtersDef.fields), [filtersDef]);

  useEffect(() => {
    dispatch(dashboardActions.initDashboard({ dashboardId, defaults, overrides: fromSearch(filtersDef.fields, location.search) }));
    // URL overrides apply on entry only
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dashboardId, defaults]);

  const filters = useMemo(() => withDerived(filtersDef.fields, { ...defaults, ...inst.filters }), [filtersDef, defaults, inst.filters]);
  const ctx = useMemo<DashboardContextValue>(
    () => ({
      dashboardId,
      definition,
      filterDefs: filtersDef.fields,
      filters,
      widgetsById: Object.fromEntries(definition.widgets.map((w) => [w.id, w])),
      chartConfigs: charts,
      density,
      resetToken: inst.resetToken,
      expanded: inst.expanded,
      templateBase: { filter: filters, filterLabel: filterLabels(filtersDef.fields, filters) },
    }),
    [dashboardId, definition, filtersDef, filters, charts, density, inst.resetToken, inst.expanded],
  );

  return (
    <DashboardContext.Provider value={ctx}>
      <DashboardBody filtersDef={filtersDef} />
    </DashboardContext.Provider>
  );
}

function DashboardBody({ filtersDef }: { filtersDef: DashboardFilters }) {
  const { dashboardId, definition, filters, widgetsById, expanded, density, templateBase } = useDashboardContext();
  const dispatch = useDispatch();
  const [helpOpen, setHelpOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { chips, appliesTo, clearAll } = useCrossFilterChips();

  useDashboardHotkeys(filtersDef, {
    helpOpen,
    settingsOpen,
    closeHelp: () => setHelpOpen(false),
    closeSettings: () => setSettingsOpen(false),
    toggleHelp: () => setHelpOpen((v) => !v),
  });

  const barSections: FilterBarSection[] = filtersDef.sections.map((sec) => ({
    id: sec.id,
    label: sec.label,
    fields: sec.fields
      .map((id) => filtersDef.fields.find((f) => f.id === id))
      .filter((f): f is NonNullable<typeof f> => !!f && f.placement === 'bar')
      .map((f) => ({ id: f.id, label: f.label, type: f.type === 'select' ? 'select' : 'segmented', options: (f.options ?? []).map((o) => ({ value: o.value, label: o.label })), value: filters[f.id] })),
  }));

  const shortcuts = [
    { keys: ['D'], label: 'Cycle density' },
    { keys: ['?'], label: 'Keyboard shortcuts' },
    { keys: ['Esc'], label: definition.features.crossFilterStrip ? 'Clear cross-filters / close' : 'Restore expanded card / close' },
    ...filtersDef.hotkeys.map((h) => ({ keys: h.keys, label: h.label })),
  ];

  return (
    <div className={styles.page} style={cssVars({ '--gap': `${DENSITY[density].gap}px` })}>
      <div className={styles.sticky}>
        <DashboardHeader settingsOpen={settingsOpen} setSettingsOpen={setSettingsOpen} openHelp={() => setHelpOpen(true)} />
        {definition.features.filterBar && barSections.length ? (
          <FilterBar sections={barSections} onChange={(id, value) => dispatch(dashboardActions.setFilter({ dashboardId, id, value }))} />
        ) : null}
        {definition.features.crossFilterStrip ? <CrossFilterStrip chips={chips} appliesTo={appliesTo} onClearAll={clearAll} /> : null}
      </div>

      <main className={styles.main}>
        {definition.layout.sections.map((sec) => (
          <section key={sec.id} className={styles.section} aria-label={sec.title}>
            {sec.title ? <SectionHeading variant={sec.style} title={sec.title} subtitle={sec.subtitleTemplate ? interpolate(sec.subtitleTemplate, templateBase) : undefined} /> : null}
            {sec.rows.map((row) => {
              const rowExpanded = !!expanded && row.includes(expanded);
              return (
                <div key={row.join('|')} className={styles.row}>
                  {row.map((id) => {
                    const w = widgetsById[id];
                    if (!w) return null;
                    return (
                      <div key={id} className={styles.cell} style={cssVars({ '--w-flex': rowExpanded ? '1 1 100%' : (w.presentation?.flex ?? '1 1 420px') })}>
                        <WidgetRenderer widget={w} />
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </section>
        ))}
        {definition.footnote ? <p className={styles.footnote}>{definition.footnote}</p> : null}
      </main>

      <ShortcutsDialog open={helpOpen} onClose={() => setHelpOpen(false)} shortcuts={shortcuts} />
    </div>
  );
}
