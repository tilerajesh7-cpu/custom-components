import { useMemo } from 'react';
import { leafColumns, type GridResponse } from '@shared/lib/contract/gridResponse';
import { formatNumber, toNumber, type NumberFormat } from '@shared/lib/format/number';
import { EmptyState, RankedList, type RankedListColumn, type RankedListRow, type RankedListSummary } from '@shared/ui';
import { useWidgetData, useWidgetText } from '../hooks/useWidgetData';
import type { WidgetDef } from '../model/types';
import { WidgetFrame } from './WidgetFrame';

const cell = (v: unknown, fmt?: NumberFormat) => ({ value: toNumber(v), text: formatNumber(v, fmt) });

/** Maps a Grid Response v2 onto RankedList: first text column = label, numeric columns = values, type 'bar' columns get a bar. */
export function toRankedList(res: GridResponse, topN: number, shareOfGross: boolean) {
  const leaves = leafColumns(res.columnDefs).filter((c) => c.field && !c.hide);
  const labelCol = leaves.find((c) => c.colType !== 'DoubleType');
  const numCols = leaves.filter((c) => c.colType === 'DoubleType');
  const meta = (f: string) => res.columnMetadata[f] ?? {};

  const columns: RankedListColumn[] = numCols.map((c) => {
    const m = meta(c.field!);
    return { key: c.field!, header: c.headerName ?? c.field!, bar: m.type === 'bar' ? { mode: m.bar?.mode === 'diverging' ? 'diverging' : 'magnitude', tone: m.bar?.tone } : undefined };
  });
  const body = res.rowData.filter((r) => !res.rowMetadata[r.id]?.rowType);
  const rows: RankedListRow[] = body.slice(0, topN).map((r) => ({
    id: r.id,
    label: String(labelCol ? (r[labelCol.field!] ?? '') : r.id),
    cells: numCols.map((c) => cell(r[c.field!], meta(c.field!).format)),
  }));

  let summary: RankedListSummary | undefined;
  const total = res.pinnedTopRows[0];
  if (total && numCols[0]) {
    const f0 = numCols[0].field!;
    const gross = body.reduce((s, r) => s + Math.abs(toNumber(r[f0]) ?? 0), 0);
    const top = body.slice(0, topN).reduce((s, r) => s + Math.abs(toNumber(r[f0]) ?? 0), 0);
    const ratio = gross ? top / gross : 0;
    summary = {
      label: String(labelCol ? total[labelCol.field!] : 'Total'),
      primary: cell(total[f0], meta(f0).format),
      secondary: numCols[1] ? { label: numCols[1].headerName ?? '', cell: cell(total[numCols[1].field!], meta(numCols[1].field!).format) } : undefined,
      share: shareOfGross ? { ratio, text: `Top ${topN} = ${Math.round(ratio * 100)}% of gross` } : undefined,
    };
  }
  return { columns, rows, summary, labelHeader: labelCol?.headerName };
}

export function ListWidget({ widget }: { widget: WidgetDef }) {
  const { query, selections, ready } = useWidgetData(widget);
  const { title, subtitle } = useWidgetText(widget, selections);
  const cfg = widget.presentation?.list;
  const model = useMemo(() => (query.data ? toRankedList(query.data, cfg?.topN ?? 5, !!cfg?.shareOfGross) : null), [query.data, cfg]);

  return (
    <WidgetFrame widget={widget} title={title} subtitle={subtitle} query={query} ready={ready}>
      {() => (model && model.rows.length ? <RankedList {...model} /> : <EmptyState />)}
    </WidgetFrame>
  );
}
