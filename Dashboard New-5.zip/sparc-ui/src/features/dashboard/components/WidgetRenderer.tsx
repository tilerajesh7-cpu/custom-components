import { ErrorBoundary } from '@shared/ui';
import type { WidgetDef } from '../model/types';
import { AlertsWidget } from './AlertsWidget';
import { ChartWidget } from './ChartWidget';
import { GridWidget } from './GridWidget';
import { ListWidget } from './ListWidget';

const REGISTRY = { grid: GridWidget, chart: ChartWidget, list: ListWidget, alerts: AlertsWidget } as const;

/** Maps widget.kind → component. New kinds register here; unknown kinds fail soft. */
export function WidgetRenderer({ widget }: { widget: WidgetDef }) {
  const Cmp = REGISTRY[widget.kind];
  if (!Cmp) {
    console.warn(`[dashboard] unknown widget kind "${widget.kind}" (${widget.id})`);
    return null;
  }
  return (
    <ErrorBoundary fallbackTitle={`${widget.title} failed to render`} resetKey={widget}>
      <Cmp widget={widget} />
    </ErrorBoundary>
  );
}
