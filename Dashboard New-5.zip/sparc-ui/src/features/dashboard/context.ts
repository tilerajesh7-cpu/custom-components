import { createContext, useContext } from 'react';
import type { ChartConfig } from '@shared/lib/chart/buildChartOptions';
import type { Density } from '@shared/config/tokens';
import type { DashboardDefinition, FilterDef, FilterValues, WidgetDef } from './model/types';

export interface DashboardContextValue {
  dashboardId: string;
  definition: DashboardDefinition;
  filterDefs: FilterDef[];
  /** Effective filter values (stored + defaults + derived). */
  filters: FilterValues;
  widgetsById: Record<string, WidgetDef>;
  chartConfigs: Record<string, ChartConfig>;
  density: Density;
  resetToken: number;
  expanded: string | null;
  /** Base template context: { filter, filterLabel } */
  templateBase: Record<string, unknown>;
}

export const DashboardContext = createContext<DashboardContextValue | null>(null);

export function useDashboardContext(): DashboardContextValue {
  const ctx = useContext(DashboardContext);
  if (!ctx) throw new Error('useDashboardContext must be used inside <DashboardView>');
  return ctx;
}
