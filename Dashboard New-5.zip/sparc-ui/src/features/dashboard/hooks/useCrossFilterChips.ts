import { useDispatch, useSelector } from 'react-redux';
import { toneHex } from '@shared/config/tokens';
import { interpolate } from '@shared/lib/template/interpolate';
import type { CrossFilterChip } from '@shared/ui';
import { useDashboardContext } from '../context';
import { dashboardActions, selectInstance, type DashboardRootState } from '../model/dashboardSlice';

/** Chips for explicit user selections on widgets that declare selection.chip. */
export function useCrossFilterChips() {
  const { dashboardId, definition } = useDashboardContext();
  const dispatch = useDispatch();
  const selections = useSelector((s: DashboardRootState) => selectInstance(s, dashboardId).selections);
  const chips: CrossFilterChip[] = [];
  const affects: string[] = [];
  definition.widgets.forEach((w) => {
    const sel = selections[w.id];
    if (!sel || !w.selection?.chip) return;
    chips.push({
      id: w.id,
      kind: w.selection.chip.kind,
      value: interpolate(w.selection.chip.labelTemplate, { row: sel.row }),
      color: toneHex(w.selection.chip.tone),
      onClear: () => dispatch(dashboardActions.selectRow({ dashboardId, widgetId: w.id, selection: null })),
    });
    w.selection.affects?.forEach((a) => !affects.includes(a) && affects.push(a));
  });
  return { chips, appliesTo: affects.join(' · '), clearAll: () => dispatch(dashboardActions.clearSelections({ dashboardId })) };
}
