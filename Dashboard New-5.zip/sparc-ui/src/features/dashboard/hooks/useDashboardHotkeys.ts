import { useDispatch } from 'react-redux';
import { useHotkeys, type HotkeyMap } from '@shared/hooks/useHotkeys';
import { useDashboardContext } from '../context';
import { cycleValue } from '../lib/filters';
import { dashboardActions } from '../model/dashboardSlice';
import type { DashboardFilters } from '../model/types';

interface Overlays {
  helpOpen: boolean;
  settingsOpen: boolean;
  closeHelp: () => void;
  closeSettings: () => void;
  toggleHelp: () => void;
}

/** Built-in shortcuts (D, ?, Esc) + hotkeys declared by the filters API (C, V, 1/2/3 …). */
export function useDashboardHotkeys(filtersDef: DashboardFilters, o: Overlays) {
  const { dashboardId, filters, expanded } = useDashboardContext();
  const dispatch = useDispatch();
  const map: HotkeyMap = {
    Escape: () => {
      if (o.helpOpen) o.closeHelp();
      else if (o.settingsOpen) o.closeSettings();
      else if (expanded) dispatch(dashboardActions.collapseExpanded({ dashboardId }));
      else dispatch(dashboardActions.clearSelections({ dashboardId }));
    },
    d: () => dispatch(dashboardActions.cycleDensity()),
    '?': () => o.toggleHelp(),
  };
  filtersDef.hotkeys.forEach((h) => {
    const def = filtersDef.fields.find((f) => f.id === h.filterId);
    if (!def) return;
    h.keys.forEach((k, i) => {
      map[k] = () => {
        const value = h.action === 'setFilter' ? h.values?.[i] : cycleValue(def, filters[def.id]);
        if (value !== undefined) dispatch(dashboardActions.setFilter({ dashboardId, id: def.id, value }));
      };
    });
  });
  useHotkeys(map);
}
