import { useMemo } from 'react';
import { useSelector } from 'react-redux';
import { useQueries, useQuery } from '@tanstack/react-query';
import { interpolate } from '@shared/lib/template/interpolate';
import { widgetQueryOptions } from '../api/queries';
import { useDashboardContext } from '../context';
import { resolveParams, selectionRefs } from '../lib/bindings';
import { selectInstance, type DashboardRootState } from '../model/dashboardSlice';
import type { WidgetDef, WidgetSelection } from '../model/types';

type Selections = Record<string, WidgetSelection | undefined>;

/**
 * Explicit selections from the store, plus UI-side defaults for widgets with selection.default = 'firstRow'
 * (e.g. Limits grid: row 1 is selected until the user picks another; re-applied when data reloads
 * and the chosen row is no longer present).
 */
export function useEffectiveSelections(ids: string[]): Selections {
  const { dashboardId, widgetsById, filters } = useDashboardContext();
  const explicit = useSelector((s: DashboardRootState) => selectInstance(s, dashboardId).selections);
  const defaults = ids.map((id) => widgetsById[id]).filter((w): w is WidgetDef => w?.selection?.default === 'firstRow');
  const sources = useQueries({
    queries: defaults.map((w) => {
      const r = resolveParams(w.params, { filters, selections: explicit });
      return widgetQueryOptions(w.endpoint, r.params, r.ready);
    }),
  });

  const out: Selections = {};
  ids.forEach((id) => {
    const e = explicit[id];
    if (e) out[id] = e;
  });
  defaults.forEach((w, i) => {
    const rows = sources[i]?.data?.rowData ?? [];
    const e = explicit[w.id];
    if (e && (!rows.length || rows.some((r) => r.id === e.rowId))) return;
    const first = rows[0];
    out[w.id] = first ? { rowId: first.id, row: first, isDefault: true } : undefined;
  });
  return out;
}

/** Resolves a widget's bindings against filters + selections and fetches its Grid Response. */
export function useWidgetData(widget: WidgetDef) {
  const { filters } = useDashboardContext();
  const refs = useMemo(
    () => [...new Set([...selectionRefs(widget.params), ...(widget.contextFrom ? [widget.contextFrom] : []), ...(widget.selection ? [widget.id] : [])])],
    [widget],
  );
  const selections = useEffectiveSelections(refs);
  const { params, ready } = resolveParams(widget.params, { filters, selections });
  const query = useQuery(widgetQueryOptions(widget.endpoint, params, ready));
  return { query, selections, ready };
}

/** Title / subtitle with {sel.*} and {filter.*} templates resolved. */
export function useWidgetText(widget: WidgetDef, selections: Selections) {
  const { templateBase } = useDashboardContext();
  const sel = widget.contextFrom ? selections[widget.contextFrom]?.row : undefined;
  return useMemo(() => {
    const ctx = { ...templateBase, sel };
    const has = !widget.contextFrom || !!sel;
    return {
      templateContext: ctx,
      title: widget.titleTemplate && has ? interpolate(widget.titleTemplate, ctx) : widget.title,
      subtitle: widget.subtitleTemplate && has ? interpolate(widget.subtitleTemplate, ctx) : widget.subtitle,
    };
  }, [templateBase, sel, widget]);
}
