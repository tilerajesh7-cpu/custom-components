export { DashboardView } from './components/DashboardView';
export { dashboardReducer, dashboardActions, type DashboardState } from './model/dashboardSlice';
export type { DashboardDefinition, DashboardFilters, WidgetDef, FilterDef } from './model/types';
