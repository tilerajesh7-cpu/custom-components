import { describe, expect, it } from 'vitest';
import { resolveParams, selectionRefs } from './bindings';

describe('bindings', () => {
  const params = { region: '$filter.region', rowId: '$selection.widget-1.rowId|all', limitId: '$selection.widget-7.rowId', mode: 'daily' };

  it('lists referenced selection sources', () => {
    expect(selectionRefs(params).sort()).toEqual(['widget-1', 'widget-7']);
  });

  it('uses fallbacks and flags missing required selections', () => {
    const r = resolveParams(params, { filters: { region: 'NA' }, selections: {} });
    expect(r.params).toEqual({ region: 'NA', rowId: 'all', mode: 'daily' });
    expect(r.ready).toBe(false);
  });

  it('resolves selections and row paths', () => {
    const r = resolveParams(
      { rowId: '$selection.widget-1.rowId|all', name: '$selection.widget-1.row.name', limitId: '$selection.widget-7.rowId' },
      { filters: {}, selections: { 'widget-1': { rowId: 'row_2', row: { name: 'Desk B' } }, 'widget-7': { rowId: 'lim_1', row: {} } } },
    );
    expect(r).toEqual({ params: { rowId: 'row_2', name: 'Desk B', limitId: 'lim_1' }, ready: true });
  });
});
