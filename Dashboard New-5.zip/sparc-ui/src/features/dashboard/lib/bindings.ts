import { getPath } from '@shared/lib/template/interpolate';
import type { FilterValues, ParamValue, WidgetSelection } from '../model/types';

/** "$filter.region" · "$selection.widget-1.rowId|all" · "$selection.widget-7.row.limitId" */
const REF = /^\$(filter|selection)\.([\w-]+)(?:\.([\w.]+))?(?:\|(.*))?$/;

export interface BindingContext {
  filters: FilterValues;
  selections: Record<string, WidgetSelection | null | undefined>;
}

export interface ResolvedParams {
  params: Record<string, ParamValue>;
  /** false when a required selection (no fallback) is not available yet */
  ready: boolean;
}

export function selectionRefs(params: Record<string, ParamValue>): string[] {
  const ids = new Set<string>();
  Object.values(params).forEach((v) => {
    const m = typeof v === 'string' ? REF.exec(v) : null;
    if (m?.[1] === 'selection') ids.add(m[2]);
  });
  return [...ids];
}

export function resolveParams(params: Record<string, ParamValue>, ctx: BindingContext): ResolvedParams {
  const out: Record<string, ParamValue> = {};
  let ready = true;
  for (const [key, raw] of Object.entries(params)) {
    const m = typeof raw === 'string' ? REF.exec(raw) : null;
    if (!m) {
      out[key] = raw;
      continue;
    }
    const [, kind, id, path, fallback] = m;
    let value: unknown;
    if (kind === 'filter') {
      value = ctx.filters[id];
    } else {
      const sel = ctx.selections[id];
      const p = path ?? 'rowId';
      value = p === 'rowId' ? sel?.rowId : getPath(sel?.row, p.replace(/^row\./, ''));
    }
    if (value == null || value === '') {
      if (fallback !== undefined) value = fallback;
      else {
        if (kind === 'selection') ready = false;
        continue;
      }
    }
    out[key] = value as ParamValue;
  }
  return { params: out, ready };
}
