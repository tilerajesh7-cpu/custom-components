import { describe, expect, it } from 'vitest';
import { isEditableNow, withDerived } from './filters';
import type { FilterDef } from '../model/types';

const defs: FilterDef[] = [
  { id: 'cob', label: 'COB', type: 'date', placement: 'header', default: '2026-09-11', editable: true, editableWhen: { compare: 'Custom' } },
  {
    id: 'pcob', label: 'PCOB', type: 'date', placement: 'header', default: '2026-09-10', editable: true, editableWhen: { compare: 'Custom' },
    derive: { from: 'cob', via: 'compareOffset', compareField: 'compare', manualWhen: 'Custom', offsets: { DoD: { businessDays: -1 }, WoW: { days: -7 }, MoM: { months: -1 } } },
  },
  { id: 'compare', label: 'Compare', type: 'segmented', placement: 'header', default: 'Custom', options: [] },
];

describe('PCOB derivation', () => {
  it('keeps the user value on Custom', () => {
    expect(withDerived(defs, { cob: '2026-09-11', pcob: '2026-09-01', compare: 'Custom' }).pcob).toBe('2026-09-01');
  });
  it('derives DoD (business day), WoW, MoM', () => {
    expect(withDerived(defs, { cob: '2026-09-14', pcob: 'x', compare: 'DoD' }).pcob).toBe('2026-09-11');
    expect(withDerived(defs, { cob: '2026-09-11', pcob: 'x', compare: 'WoW' }).pcob).toBe('2026-09-04');
    expect(withDerived(defs, { cob: '2026-09-11', pcob: 'x', compare: 'MoM' }).pcob).toBe('2026-08-11');
  });
  it('dates are editable only on Custom', () => {
    expect(isEditableNow(defs[0], { compare: 'Custom' })).toBe(true);
    expect(isEditableNow(defs[0], { compare: 'WoW' })).toBe(false);
  });
});
