import { toNumber, formatNumber } from '@shared/lib/format/number';
import type { GridResponse } from '@shared/lib/contract/gridResponse';
import type { StatTile } from '@shared/ui';
import type { StatTileDef } from '../model/types';

export function computeStatTiles(res: GridResponse, defs: StatTileDef[]): StatTile[] {
  return defs.map((d) => {
    const vals = res.rowData.map((r) => toNumber(r[d.field])).filter((v): v is number => v != null);
    const value = !vals.length ? null : d.agg === 'last' ? vals[vals.length - 1] : d.agg === 'max' ? Math.max(...vals) : Math.min(...vals);
    const denomRow = d.ratioTo ? toNumber(res.rowData[res.rowData.length - 1]?.[d.ratioTo]) : null;
    const ratio = value != null && denomRow ? value / denomRow : null;
    const tone = ratio == null ? 'neutral' : ([...(d.thresholds ?? [])].sort((a, b) => b.gte - a.gte).find((t) => ratio >= t.gte)?.tone ?? 'neutral');
    return {
      label: d.label,
      value: formatNumber(value),
      note: ratio != null ? `${Math.round(ratio * 100)}% ${d.noteSuffix ?? ''}`.trim() : undefined,
      tone,
    };
  });
}
