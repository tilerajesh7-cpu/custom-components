import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { DENSITIES, type Density } from '@shared/config/tokens';
import type { FilterValue, FilterValues, ViewMode, WidgetSelection } from './types';

export interface DashboardInstanceState {
  filters: FilterValues;
  /** Explicit (user) selections only. Defaults are derived in the UI. */
  selections: Record<string, WidgetSelection | null>;
  views: Record<string, ViewMode>;
  expanded: string | null;
  resetToken: number;
}

export interface DashboardState {
  density: Density;
  byId: Record<string, DashboardInstanceState>;
}

const initialState: DashboardState = { density: 'comfortable', byId: {} };

const blank = (): DashboardInstanceState => ({ filters: {}, selections: {}, views: {}, expanded: null, resetToken: 0 });

const inst = (s: DashboardState, id: string) => (s.byId[id] ??= blank());

type Scoped<T = object> = PayloadAction<{ dashboardId: string } & T>;

const slice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    /** Seeds defaults for missing filters and applies URL overrides (deep links / copied links). */
    initDashboard(s, a: Scoped<{ defaults: FilterValues; overrides?: FilterValues }>) {
      const d = inst(s, a.payload.dashboardId);
      d.filters = { ...a.payload.defaults, ...d.filters, ...(a.payload.overrides ?? {}) };
    },
    setFilter(s, a: Scoped<{ id: string; value: FilterValue }>) {
      inst(s, a.payload.dashboardId).filters[a.payload.id] = a.payload.value;
    },
    resetFilters(s, a: Scoped<{ defaults: FilterValues }>) {
      const d = inst(s, a.payload.dashboardId);
      d.filters = { ...a.payload.defaults };
      d.selections = {};
    },
    selectRow(s, a: Scoped<{ widgetId: string; selection: WidgetSelection | null }>) {
      inst(s, a.payload.dashboardId).selections[a.payload.widgetId] = a.payload.selection;
    },
    clearSelections(s, a: Scoped) {
      inst(s, a.payload.dashboardId).selections = {};
    },
    setView(s, a: Scoped<{ widgetId: string; view: ViewMode }>) {
      inst(s, a.payload.dashboardId).views[a.payload.widgetId] = a.payload.view;
    },
    toggleExpanded(s, a: Scoped<{ widgetId: string }>) {
      const d = inst(s, a.payload.dashboardId);
      d.expanded = d.expanded === a.payload.widgetId ? null : a.payload.widgetId;
    },
    collapseExpanded(s, a: Scoped) {
      inst(s, a.payload.dashboardId).expanded = null;
    },
    resetLayout(s, a: Scoped) {
      const d = inst(s, a.payload.dashboardId);
      d.views = {};
      d.expanded = null;
      d.resetToken += 1;
    },
    setDensity(s, a: PayloadAction<Density>) {
      s.density = a.payload;
    },
    cycleDensity(s) {
      s.density = DENSITIES[(DENSITIES.indexOf(s.density) + 1) % DENSITIES.length];
    },
  },
});

export const dashboardActions = slice.actions;
export const dashboardReducer = slice.reducer;

export type DashboardRootState = { dashboard: DashboardState };

const EMPTY = blank();
export const selectInstance = (s: DashboardRootState, id: string): DashboardInstanceState => s.dashboard.byId[id] ?? EMPTY;
export const selectDensity = (s: DashboardRootState) => s.dashboard.density;
