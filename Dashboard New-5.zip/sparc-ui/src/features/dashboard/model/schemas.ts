import { z } from 'zod';
import { ContractError } from '@shared/lib/contract/gridResponse';
import type { ChartConfigResponse, DashboardDefinition, DashboardFilters } from './types';

/* Tolerant readers: validate what the UI relies on, pass everything else through. */

const WidgetSchema = z
  .object({
    id: z.string(),
    kind: z.enum(['grid', 'chart', 'list', 'alerts']),
    title: z.string(),
    endpoint: z.string(),
    params: z.record(z.union([z.string(), z.number(), z.boolean()])).default({}),
  })
  .passthrough();

const DefinitionSchema = z
  .object({
    schemaVersion: z.string(),
    dashboardId: z.string(),
    title: z.string(),
    breadcrumb: z.array(z.string()).default([]),
    header: z.object({ actions: z.array(z.string()).default([]) }).passthrough().default({ actions: [] }),
    features: z.record(z.unknown()).default({}),
    widgets: z.array(WidgetSchema),
    layout: z.object({ sections: z.array(z.object({ id: z.string(), rows: z.array(z.array(z.string())) }).passthrough()) }).passthrough(),
  })
  .passthrough();

const FiltersSchema = z
  .object({
    schemaVersion: z.string(),
    dashboardId: z.string(),
    fields: z.array(z.object({ id: z.string(), label: z.string(), type: z.string(), placement: z.string() }).passthrough()),
    sections: z.array(z.object({ id: z.string(), label: z.string(), fields: z.array(z.string()) }).passthrough()).default([]),
    hotkeys: z.array(z.record(z.unknown())).default([]),
  })
  .passthrough();

const ChartConfigSchema = z
  .object({
    schemaVersion: z.string(),
    dashboardId: z.string(),
    charts: z.record(z.object({ type: z.string(), orientation: z.enum(['timeSeries', 'fieldsAsCategories']) }).passthrough()),
  })
  .passthrough();

function parseWith<T>(schema: z.ZodTypeAny, name: string) {
  return (raw: unknown): T => {
    const r = schema.safeParse(raw);
    if (!r.success) throw new ContractError(`${name}: ${r.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ')}`);
    return r.data as T;
  };
}

export const parseDefinition = parseWith<DashboardDefinition>(DefinitionSchema, 'Dashboard definition');
export const parseFilters = parseWith<DashboardFilters>(FiltersSchema, 'Dashboard filters');
export const parseChartConfig = parseWith<ChartConfigResponse>(ChartConfigSchema, 'Chart config');
