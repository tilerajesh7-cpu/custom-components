import { z } from 'zod';
import { useQuery } from '@tanstack/react-query';
import { apiGet } from '@shared/lib/http/client';
import { ContractError } from '@shared/lib/contract/gridResponse';
import type { SideNavItem } from '@shared/ui';

export interface MenuItem {
  id: string;
  label: string;
  icon?: string;
  route?: string;
  badge?: { text: string; tone: string };
  disabled?: boolean;
  children?: MenuItem[];
}

export interface SidebarMenu {
  schemaVersion: string;
  app: { initials: string; name: string; envBadge?: string };
  footerNote?: string;
  defaultRoute: string;
  sections: { id: string; label: string; items: MenuItem[] }[];
}

const ItemSchema: z.ZodType<MenuItem> = z.lazy(() =>
  z.object({
    id: z.string(),
    label: z.string(),
    icon: z.string().optional(),
    route: z.string().optional(),
    badge: z.object({ text: z.string(), tone: z.string() }).optional(),
    disabled: z.boolean().optional(),
    children: z.array(ItemSchema).optional(),
  }),
);

const MenuSchema = z.object({
  schemaVersion: z.string(),
  app: z.object({ initials: z.string(), name: z.string(), envBadge: z.string().optional() }),
  footerNote: z.string().optional(),
  defaultRoute: z.string(),
  sections: z.array(z.object({ id: z.string(), label: z.string(), items: z.array(ItemSchema) })),
});

const parseMenu = (raw: unknown): SidebarMenu => {
  const r = MenuSchema.safeParse(raw);
  if (!r.success) throw new ContractError(`Sidebar menu: ${r.error.message}`);
  return r.data;
};

export const fetchSidebarMenu = (signal?: AbortSignal) => apiGet<SidebarMenu>('/app/sidebar-menu', undefined, { signal, parse: parseMenu });

export const useSidebarMenu = () => useQuery({ queryKey: ['app', 'sidebar-menu'], queryFn: ({ signal }) => fetchSidebarMenu(signal), staleTime: Infinity });

export interface NavEntry extends SideNavItem {
  route?: string;
}

/** Flattens the menu tree into SideNav rows; marks the item whose route matches the current path. */
export function flattenMenu(menu: SidebarMenu, pathname: string): NavEntry[] {
  const out: NavEntry[] = [];
  const walk = (items: MenuItem[], level: number) =>
    items.forEach((it) => {
      out.push({ id: it.id, label: it.label, level, icon: it.icon, badge: it.badge, disabled: it.disabled, route: it.route, navigable: !!it.route, active: !!it.route && it.route === pathname });
      if (it.children) walk(it.children, level + 1);
    });
  menu.sections.forEach((s) => {
    out.push({ id: `h-${s.id}`, label: s.label, level: 0, isHeader: true });
    walk(s.items, 0);
  });
  return out;
}
