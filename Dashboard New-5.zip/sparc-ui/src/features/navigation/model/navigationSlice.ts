import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

export interface NavigationState {
  collapsed: boolean;
}

const slice = createSlice({
  name: 'navigation',
  initialState: { collapsed: false } as NavigationState,
  reducers: {
    toggleSidebar(s) {
      s.collapsed = !s.collapsed;
    },
    setSidebarCollapsed(s, a: PayloadAction<boolean>) {
      s.collapsed = a.payload;
    },
  },
});

export const navigationActions = slice.actions;
export const navigationReducer = slice.reducer;
export const selectSidebarCollapsed = (s: { navigation: NavigationState }) => s.navigation.collapsed;
