import { Suspense, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { flattenMenu, navigationActions, selectSidebarCollapsed, useSidebarMenu, type NavEntry } from '@features/navigation';
import { ErrorBoundary, PageLoader, SideNav } from '@shared/ui';
import styles from './AppLayout.module.css';

/** App shell: sidebar (from the sidebar-menu API) + routed page. Add menu items in the menu API / mock. */
export default function AppLayout() {
  const { data: menu } = useSidebarMenu();
  const collapsed = useSelector(selectSidebarCollapsed);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const items = useMemo(() => (menu ? flattenMenu(menu, pathname) : []), [menu, pathname]);

  return (
    <div className={styles.shell}>
      <SideNav
        brand={menu?.app ?? { initials: '', name: '' }}
        items={items}
        collapsed={collapsed}
        footerNote={menu?.footerNote}
        onToggle={() => dispatch(navigationActions.toggleSidebar())}
        onSelect={(it) => {
          const route = (it as NavEntry).route;
          if (route) navigate(route);
        }}
      />
      <div className={styles.content}>
        <ErrorBoundary fallbackTitle="This page failed to load" resetKey={pathname}>
          <Suspense fallback={<PageLoader />}>
            <Outlet />
          </Suspense>
        </ErrorBoundary>
      </div>
    </div>
  );
}
