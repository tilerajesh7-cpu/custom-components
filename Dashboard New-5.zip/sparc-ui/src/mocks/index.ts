import { setTransport } from '@shared/lib/http/client';
import { mockTransport } from './transport';

export function registerMockTransport() {
  setTransport(mockTransport);
  console.info('[mocks] API calls are served from src/mocks/data');
}
