import { ApiError, type Transport } from '@shared/lib/http/client';
import { env } from '@shared/config/env';

/**
 * Mock transport — serves src/mocks/data/** for every API call, so the UI runs with no backend.
 * Real services return pre-filtered data; here the base files are adjusted by FILTER_EFFECTS instead
 * of shipping one file per filter combination.
 */

const files = import.meta.glob<unknown>('./data/**/*.json', { import: 'default' });

/** Endpoints whose payload depends on a selection → file keyed by that param ({key}.json, default "all"). */
const KEYED: Record<string, string> = {
  'component-var-svar': 'rowId',
  'component-var-svar-fs-type': 'rowId',
  'standalone-var-svar-trend': 'rowId',
  'component-var-svar-trend': 'rowId',
  'component-var-svar-fs-type-trend': 'rowId',
  'limit-history': 'limitId',
};

/** VaR measures scale with Variant (×√10 for 10DAY) and Attribute. */
const SCALED = new Set(['standalone-var-svar', 'component-var-svar', 'component-var-svar-fs-type', 'standalone-var-svar-trend', 'component-var-svar-trend', 'component-var-svar-fs-type-trend']);
/** Series / non-regional grids have no region rows → emulate the region slice with a share factor. */
const REGION_SHARE: Record<string, number> = { All: 1, NA: 0.42, EMEA: 0.27, APAC: 0.19, Latam: 0.07, Global: 0.05 };
/** PCOB further back → older baseline. */
const COMPARE_PCOB: Record<string, number> = { Custom: 1, DoD: 1, WoW: 0.95, MoM: 0.88 };
const VARIANT: Record<string, number> = { '1D': 1, '10D': Math.sqrt(10) };
const ATTRIBUTE: Record<string, number> = { Trading: 1, Economic: 1.12, Volcker: 0.94, 'Basel 3 Regulatory': 1.21, 'Trading & Credit Portfolio': 1.05 };

type Row = Record<string, unknown> & { id: string };
interface MockGrid {
  gridId: string;
  meta?: Record<string, unknown>;
  rowData: Row[];
  pinnedBottomRows: Row[];
  rowMetadata: Record<string, { rowType?: string }>;
}

/** Display filter: services return only the requested measure families. */
const DISPLAY_DROP: Record<string, RegExp | null> = { Both: null, MC: /^hist/, Hist: /^mc/ };

interface MockCol { field?: string; headerName?: string; children?: MockCol[] }

function applyDisplay(res: MockGrid & { columnDefs: MockCol[] }, display: unknown) {
  const drop = DISPLAY_DROP[String(display)];
  if (!drop) return;
  const keep = (c: MockCol): MockCol | null => {
    if (c.children) {
      const ch = c.children.map(keep).filter((x): x is MockCol => !!x);
      return ch.length ? { ...c, children: ch } : null;
    }
    return c.field && drop.test(c.field) ? null : c;
  };
  res.columnDefs = res.columnDefs.map(keep).filter((x): x is MockCol => !!x);
  if (display === 'Hist') {
    const relabel = (c: MockCol) => {
      if (c.headerName) c.headerName = c.headerName.replace('· CVaR', '· CHVaR');
      c.children?.forEach(relabel);
    };
    res.columnDefs.forEach(relabel);
    res.rowData.forEach((r) => Object.keys(r).forEach((k) => k.startsWith('cvar_') && typeof r[k] === 'number' && (r[k] = round2((r[k] as number) * 0.92))));
  }
}

const round2 = (v: number) => Math.round(v * 100) / 100;

function resolveFile(path: string, params: Record<string, unknown>) {
  const p = path.replace(/^\/+/, '');
  const m = /^(grids|series)\/([\w-]+)$/.exec(p);
  if (m && KEYED[m[2]]) return `./data/${p}/${String(params[KEYED[m[2]]] ?? 'all')}.json`;
  return `./data/${p}.json`;
}

function sumInto(target: Row, rows: Row[]) {
  Object.keys(target).forEach((k) => {
    if (typeof target[k] !== 'number') return;
    const vals = rows.map((r) => r[k]).filter((v): v is number => typeof v === 'number');
    target[k] = vals.length ? round2(vals.reduce((a, b) => a + b, 0)) : null;
  });
}

function applyFilterEffects(id: string, kind: string, res: MockGrid, params: Record<string, unknown>): MockGrid {
  const region = params.region;
  if (typeof region === 'string' && region !== 'All' && res.rowData.some((r) => 'region' in r) && !res.gridId.includes('region') && !res.gridId.startsWith('volcker')) {
    res.rowData = res.rowData.filter((r) => r.region === region);
    res.pinnedBottomRows.forEach((t) => sumInto(t, res.rowData));
    if (id === 'limit-utilization') {
      const risk = res.rowData.filter((r) => Number(r.utilization) >= 0.8).length;
      const br = res.rowData.filter((r) => Number(r.utilization) >= 1).length;
      res.pinnedBottomRows.forEach((t) => (t.tier = `${risk} at risk · ${br} in breach`));
    }
  }
  if (SCALED.has(id)) {
    const regional = res.rowData.some((r) => 'region' in r);
    const share = !regional && typeof region === 'string' ? (REGION_SHARE[region] ?? 1) : 1;
    const f = (VARIANT[String(params.variant)] ?? 1) * (ATTRIBUTE[String(params.attribute)] ?? 1) * share;
    if (f !== 1) [...res.rowData, ...res.pinnedBottomRows].forEach((r) => Object.keys(r).forEach((k) => typeof r[k] === 'number' && (r[k] = round2((r[k] as number) * f))));
  }
  const cf = COMPARE_PCOB[String(params.compare)] ?? 1;
  if (SCALED.has(id) && kind === 'grids' && cf !== 1) {
    [...res.rowData, ...res.pinnedBottomRows].forEach((r) =>
      Object.keys(r).forEach((k) => {
        if (!k.endsWith('Pcob') || typeof r[k] !== 'number') return;
        const m = k.slice(0, -4);
        r[k] = round2((r[k] as number) * cf);
        if (typeof r[`${m}Cob`] === 'number') r[`${m}Diff`] = round2((r[`${m}Cob`] as number) - (r[k] as number));
      }),
    );
  }
  if (SCALED.has(id)) applyDisplay(res as MockGrid & { columnDefs: MockCol[] }, params.display);
  const days = Number(params.days);
  if (kind === 'series' && days > 0) res.rowData = res.rowData.slice(-days);
  res.meta = { ...res.meta, params, requestId: `mock-${Date.now().toString(36)}` };
  return res;
}

const delay = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => {
      clearTimeout(t);
      reject(new DOMException('Aborted', 'AbortError'));
    });
  });

export const mockTransport: Transport = async ({ path, params = {}, signal }) => {
  const file = resolveFile(path, params);
  await delay(env.mockLatencyMs * (0.6 + Math.random() * 0.8), signal);
  const load = files[file];
  if (!load) throw new ApiError(`Mock not found for ${path} (${file})`, { status: 404, code: 'NOT_FOUND' });
  const raw = structuredClone(await load());
  const m = /^\/?(grids|series)\/([\w-]+)$/.exec(path);
  return m ? applyFilterEffects(m[2], m[1], raw as MockGrid, params) : raw;
};
