import { DashboardView } from '@features/dashboard';

/** #/daily-risk/equities/greek-dashboard — Mock 3 (grids) */
export default function GreekDashboardPage() {
  return <DashboardView dashboardId="greek-dashboard" />;
}
