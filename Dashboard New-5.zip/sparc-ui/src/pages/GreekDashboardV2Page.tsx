import { DashboardView } from '@features/dashboard';

/** #/daily-risk/equities/greek-dashboard-v2 — Mock 4 (stacked region charts by default, Grid toggle) */
export default function GreekDashboardV2Page() {
  return <DashboardView dashboardId="greek-dashboard-v2" />;
}
