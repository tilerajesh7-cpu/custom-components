import { EmptyState } from '@shared/ui';

export default function NotFoundPage() {
  return <EmptyState message="This page does not exist. Pick a dashboard from the menu." />;
}
