import { DashboardView } from '@features/dashboard';

/** #/daily-risk/equities/var-summary */
export default function VarSummaryPage() {
  return <DashboardView dashboardId="var-summary" />;
}
