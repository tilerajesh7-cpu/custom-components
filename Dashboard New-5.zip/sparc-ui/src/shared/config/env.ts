const flag = (v: string | undefined, fallback: boolean) => (v == null || v === '' ? fallback : v === 'true');

export const env = {
  apiBase: import.meta.env.VITE_API_BASE ?? './api',
  /** Mocks are ON unless VITE_USE_MOCKS=false (set that in .env.production / CI for real services). */
  useMocks: flag(import.meta.env.VITE_USE_MOCKS, true),
  mockLatencyMs: Number(import.meta.env.VITE_MOCK_LATENCY_MS ?? 350),
  agGridLicense: import.meta.env.VITE_AG_GRID_LICENSE ?? '',
} as const;
