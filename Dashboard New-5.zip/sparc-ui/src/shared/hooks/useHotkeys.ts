import { useEffect, useRef } from 'react';

export type HotkeyMap = Record<string, (e: KeyboardEvent) => void>;

const isTyping = (t: EventTarget | null) => t instanceof HTMLElement && (/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName) || t.isContentEditable);

/** Global single-key shortcuts. Keys are KeyboardEvent.key values (case-insensitive for letters). */
export function useHotkeys(map: HotkeyMap, enabled = true) {
  const ref = useRef(map);
  ref.current = map;
  useEffect(() => {
    if (!enabled) return undefined;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape' && (isTyping(e.target) || e.metaKey || e.ctrlKey || e.altKey)) return;
      const fn = ref.current[e.key] ?? ref.current[e.key.toLowerCase()] ?? ref.current[e.key.toUpperCase()];
      if (fn) {
        fn(e);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [enabled]);
}
