export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.replace(/./g, (c) => c + c) : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export const rgba = (hex: string, a: number) => {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r},${g},${b},${Math.round(a * 1000) / 1000})`;
};

/** Darkens a hex colour towards black (0..1) — readable ink on light tints. */
export const shade = (hex: string, amt: number) => {
  const [r, g, b] = hexToRgb(hex).map((c) => Math.round(c * (1 - amt)));
  return `rgb(${r},${g},${b})`;
};
