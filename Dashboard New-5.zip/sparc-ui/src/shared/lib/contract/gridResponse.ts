import { z } from 'zod';
import type { NumberFormat } from '../format/number';

/* Grid Response Contract v2 — backend decides WHAT, UI owns HOW. */

export type ColType = 'StringType' | 'DoubleType' | 'CustomType';
export type RowType = 'GRAND_TOTAL' | 'SUB_TOTAL';

export interface WireColDef {
  headerName?: string;
  field?: string;
  pinned?: 'left' | 'right' | null;
  width?: number;
  hide?: boolean;
  colType?: ColType;
  headerTooltip?: string;
  children?: WireColDef[];
}

export interface TooltipValue {
  label: string;
  /** Row field, or "$self" for the hovered cell value. */
  field: string;
  format?: NumberFormat;
}

export interface TooltipConfig {
  renderer: string;
  titleTemplate?: string;
  facts?: { label: string; value: string }[];
  pathField?: string;
  kicker?: string;
  values?: TooltipValue[];
  showShareOfTotal?: boolean;
  showHeatPct?: boolean;
  nodeField?: string;
  ntrField?: string;
}

export interface BarConfig {
  mode: 'magnitude' | 'diverging' | 'progress';
  /** magnitude bars: tone name (or hex override) */
  tone?: string;
  max?: number;
  thresholds?: { gte: number; tone: string }[];
}

export interface ColumnMeta {
  type?: 'text' | 'value' | 'bar' | 'heatmap' | 'badge' | 'link' | 'action';
  format?: NumberFormat;
  tone?: 'muted' | 'sign';
  bar?: BarConfig;
  tooltip?: TooltipConfig;
  sort?: 'asc' | 'desc';
  sortIndex?: number;
}

export interface RowMeta {
  rowType?: RowType;
  bold?: boolean;
  bgColor?: string;
  excludeHeatMap?: boolean;
  selectable?: boolean;
  status?: string;
}

export interface CellMeta {
  bgColor?: string;
  color?: string;
  tooltip?: string;
  icon?: string;
}

export interface HeatmapConfig {
  scope: 'grid' | 'column';
  /** heatmap fields (informational — columnMetadata.type === 'heatmap' is authoritative) */
  fields?: string[];
  /** grid-level range computed by services over non-excluded heatmap cells */
  min?: number | null;
  max?: number | null;
  centerline?: number;
  positiveColor?: string | null;
  negativeColor?: string | null;
  excludeRowTypes?: RowType[];
}

export interface GridMetaData {
  defaultColDef?: { sortable?: boolean; filter?: boolean; resizable?: boolean; floatingFilter?: boolean };
  pagination?: boolean;
  paginationPageSize?: number;
  rowSelection?: 'none' | 'single' | 'multiple';
  getRowId?: string;
  masterDetail?: boolean;
  pivotMode?: boolean;
  heatmap?: HeatmapConfig | null;
}

export type GridRow = Record<string, unknown> & { id: string };

export interface ResponseMeta {
  queryId?: string;
  requestId?: string;
  asOf?: string;
  params?: Record<string, unknown>;
  source?: string;
}

export interface GridResponse {
  schemaVersion: string;
  gridId: string;
  meta?: ResponseMeta;
  gridMetaData: GridMetaData;
  columnDefs: WireColDef[];
  columnMetadata: Record<string, ColumnMeta>;
  rowData: GridRow[];
  rowMetadata: Record<string, RowMeta>;
  cellMetadata: Record<string, Record<string, CellMeta>>;
  pinnedTopRows: GridRow[];
  pinnedBottomRows: GridRow[];
  summary?: Record<string, unknown>;
}

const RowSchema = z.object({ id: z.string() }).passthrough();

const ColDefSchema = z.lazy(() =>
  z
    .object({
      headerName: z.string().optional(),
      field: z.string().optional(),
      pinned: z.enum(['left', 'right']).nullable().optional(),
      width: z.number().optional(),
      hide: z.boolean().optional(),
      colType: z.enum(['StringType', 'DoubleType', 'CustomType']).optional(),
      headerTooltip: z.string().optional(),
      children: z.array(ColDefSchema).optional(),
    })
    .passthrough(),
) as unknown as z.ZodType<WireColDef>;

/** Tolerant reader: unknown keys pass through, optional blocks default to empty. */
export const GridResponseSchema = z
  .object({
    schemaVersion: z.string().refine((v) => v.startsWith('2.'), 'Unsupported schemaVersion (expected 2.x)'),
    gridId: z.string(),
    meta: z.record(z.unknown()).optional(),
    gridMetaData: z.record(z.unknown()).default({}),
    columnDefs: z.array(ColDefSchema),
    columnMetadata: z.record(z.record(z.unknown())).default({}),
    rowData: z.array(RowSchema),
    rowMetadata: z.record(z.record(z.unknown())).default({}),
    cellMetadata: z.record(z.record(z.record(z.unknown()))).default({}),
    pinnedTopRows: z.array(RowSchema).default([]),
    pinnedBottomRows: z.array(RowSchema).default([]),
    summary: z.record(z.unknown()).optional(),
  })
  .passthrough();

export class ContractError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ContractError';
  }
}

export function parseGridResponse(raw: unknown): GridResponse {
  const r = GridResponseSchema.safeParse(raw);
  if (!r.success) throw new ContractError(r.error.issues.map((i) => `${i.path.join('.') || 'response'}: ${i.message}`).join('; '));
  return r.data as unknown as GridResponse;
}

export const leafColumns = (defs: WireColDef[]): WireColDef[] => defs.flatMap((d) => (d.children?.length ? leafColumns(d.children) : [d]));

export const rowTypeOf = (res: GridResponse, rowId: string): RowType | undefined => res.rowMetadata[rowId]?.rowType;
