import type { CSSProperties } from 'react';

export type CssVarMap = Record<`--${string}`, string | number | undefined>;

/** The only sanctioned way to pass runtime values to styles: CSS custom properties. */
export const cssVars = (vars: CssVarMap): CSSProperties => vars as CSSProperties;
