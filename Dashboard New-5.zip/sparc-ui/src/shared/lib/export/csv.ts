import { leafColumns, type GridResponse } from '../contract/gridResponse';

const cell = (v: unknown) => {
  if (v == null) return '';
  const s = Array.isArray(v) ? v.join(' / ') : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/** Grid and series responses share the v2 shape, so one exporter covers both. */
export function gridResponseToRows(res: GridResponse): string[][] {
  const groups = new Map<string, string>();
  res.columnDefs.forEach((d) => d.children?.forEach((c) => c.field && groups.set(c.field, d.headerName ?? '')));
  const cols = leafColumns(res.columnDefs).filter((c) => c.field && !c.hide);
  const header = cols.map((c) => [groups.get(c.field!), c.headerName ?? c.field].filter(Boolean).join(' '));
  const body = [...res.pinnedTopRows, ...res.rowData, ...res.pinnedBottomRows].map((r) => cols.map((c) => cell(r[c.field!])));
  return [header, ...body];
}

export const rowsToCsv = (rows: string[][]) => rows.map((r) => r.join(',')).join('\n');

export function downloadText(filename: string, text: string, mime = 'text/csv') {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export const safeFileName = (s: string) => s.replace(/[^\w]+/g, '_').replace(/^_|_$/g, '');
