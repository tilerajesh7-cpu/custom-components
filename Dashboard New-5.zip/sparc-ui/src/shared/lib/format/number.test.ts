import { describe, expect, it } from 'vitest';
import { formatNumber, signTone } from './number';

describe('formatNumber', () => {
  it('formats fixed decimals with minus and plus sign', () => {
    expect(formatNumber(1904.651)).toBe('1,904.65');
    expect(formatNumber(-0.85)).toBe('-0.85');
    expect(formatNumber(3.2, { showPlus: true })).toBe('+3.20');
  });
  it('keeps zero unsigned', () => {
    expect(formatNumber(0, { showPlus: true })).toBe('0.00');
  });
  it('formats compact Greek style with parentheses', () => {
    expect(formatNumber(-278, { style: 'compact', negative: 'parentheses' })).toBe('(278)');
    expect(formatNumber(25.84, { style: 'compact' })).toBe('25.8');
  });
  it('formats percent', () => {
    expect(formatNumber(1.188, { style: 'percent' })).toBe('119%');
  });
  it('handles missing values', () => {
    expect(formatNumber(null)).toBe('—');
    expect(formatNumber(undefined, { empty: '' })).toBe('');
  });
  it('derives sign tone', () => {
    expect(signTone(-1)).toBe('negative');
    expect(signTone(2)).toBe('positive');
    expect(signTone(null)).toBe('neutral');
  });
});
