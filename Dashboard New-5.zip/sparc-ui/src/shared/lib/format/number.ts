export interface NumberFormat {
  /** fixed = N decimals; compact = integer ≥ 100, else 1 decimal; percent = ratio × 100 */
  style?: 'fixed' | 'compact' | 'percent';
  decimals?: number;
  negative?: 'minus' | 'parentheses';
  showPlus?: boolean;
  /** Text for null / missing values (default em dash). */
  empty?: string;
}

const isNum = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

export function formatNumber(value: unknown, fmt: NumberFormat = {}): string {
  if (!isNum(value)) return fmt.empty ?? '—';
  const abs = Math.abs(value);
  const style = fmt.style ?? 'fixed';
  let body: string;
  if (style === 'percent') {
    body = `${(abs * 100).toFixed(fmt.decimals ?? 0)}%`;
  } else if (style === 'compact') {
    body = abs >= 100 ? Math.round(abs).toLocaleString('en-US') : (Math.round(abs * 10) / 10).toLocaleString('en-US', { maximumFractionDigits: 1 });
  } else {
    const d = fmt.decimals ?? 2;
    body = abs.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
  }
  if (/^0(\.0+)?%?$/.test(body)) return body;
  if (value < 0) return fmt.negative === 'parentheses' ? `(${body})` : `-${body}`;
  return fmt.showPlus ? `+${body}` : body;
}

export type SignTone = 'positive' | 'negative' | 'neutral';

export const signTone = (value: unknown): SignTone => (!isNum(value) || value === 0 ? 'neutral' : value > 0 ? 'positive' : 'negative');

export const toNumber = (value: unknown): number | null => (isNum(value) ? value : null);
