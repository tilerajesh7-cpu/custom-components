import { env } from '@shared/config/env';

export interface ApiRequest {
  path: string;
  params?: Record<string, unknown>;
  signal?: AbortSignal;
}

export type Transport = (req: ApiRequest) => Promise<unknown>;

export class ApiError extends Error {
  readonly status?: number;
  readonly code?: string;
  readonly requestId?: string;
  constructor(message: string, opts: { status?: number; code?: string; requestId?: string } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = opts.status;
    this.code = opts.code;
    this.requestId = opts.requestId;
  }
}

interface ErrorEnvelope {
  error?: { message?: string; code?: string; requestId?: string };
}

export function toQueryString(params: Record<string, unknown> = {}): string {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v == null || v === '') continue;
    q.set(k, typeof v === 'object' ? JSON.stringify(v) : String(v));
  }
  const s = q.toString();
  return s ? `?${s}` : '';
}

export const fetchTransport: Transport = async ({ path, params, signal }) => {
  const res = await fetch(`${env.apiBase}${path}${toQueryString(params)}`, {
    signal,
    credentials: 'include',
    headers: { Accept: 'application/json' },
  });
  const body: unknown = await res.json().catch(() => null);
  if (!res.ok) {
    const e = (body as ErrorEnvelope | null)?.error;
    throw new ApiError(e?.message ?? `Request failed (${res.status})`, { status: res.status, code: e?.code, requestId: e?.requestId });
  }
  return body;
};

let transport: Transport = fetchTransport;

/** Swap the transport (mock transport in dev, fetch in prod). Called once from app/bootstrap. */
export const setTransport = (t: Transport) => {
  transport = t;
};

export async function apiGet<T>(path: string, params?: Record<string, unknown>, opts: { signal?: AbortSignal; parse?: (raw: unknown) => T } = {}): Promise<T> {
  const raw = await transport({ path, params, signal: opts.signal });
  return opts.parse ? opts.parse(raw) : (raw as T);
}
