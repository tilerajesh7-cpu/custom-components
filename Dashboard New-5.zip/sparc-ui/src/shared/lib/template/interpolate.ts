export function getPath(obj: unknown, path: string): unknown {
  return path.split('.').reduce<unknown>((acc, key) => (acc != null && typeof acc === 'object' ? (acc as Record<string, unknown>)[key] : undefined), obj);
}

/** Replaces `{a.b}` tokens with values from ctx; unknown tokens become ''. */
export function interpolate(template: string, ctx: Record<string, unknown>): string {
  return template.replace(/\{([\w.-]+)\}/g, (_, path: string) => {
    const v = getPath(ctx, path);
    return v == null ? '' : String(v);
  });
}
