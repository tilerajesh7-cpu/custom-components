import clsx from 'clsx';
import { Icon } from '../Icon/Icon';
import styles from './AlertBanner.module.css';

export interface AlertItem {
  id: string;
  status: 'breach' | 'warning';
  statusLabel: string;
  name: string;
  code?: string;
  value: string;
  tooltip?: string;
  active?: boolean;
}

export interface AlertBannerProps {
  title: string;
  items: AlertItem[];
  onSelect?: (id: string) => void;
  onDismiss?: () => void;
}

/** Attention strip: one pill per alert (status · name · id · value). Domain-free. */
export function AlertBanner({ title, items, onSelect, onDismiss }: AlertBannerProps) {
  if (!items.length) return null;
  return (
    <section className={styles.banner} role="region" aria-label={title}>
      <div className={styles.head}>
        <span className={styles.ico}>
          <Icon name="alert" size={17} />
        </span>
        <b className={styles.title}>{title}</b>
      </div>
      <div className={styles.items}>
        {items.map((a) => (
          <button key={a.id} type="button" title={a.tooltip} aria-pressed={a.active} className={clsx(styles.item, styles[a.status], a.active && styles.active)} onClick={() => onSelect?.(a.id)}>
            <span className={styles.tag}>{a.statusLabel}</span>
            <b className={styles.name}>{a.name}</b>
            {a.code ? <span className={styles.code}>{a.code}</span> : null}
            <b className={styles.value}>{a.value}</b>
            <span className={styles.go}>
              <Icon name="chevronRight" size={13} />
            </span>
          </button>
        ))}
      </div>
      {onDismiss ? (
        <button type="button" className={styles.close} title="Hide until next load" aria-label="Hide alerts" onClick={onDismiss}>
          <Icon name="close" size={14} />
        </button>
      ) : null}
    </section>
  );
}
