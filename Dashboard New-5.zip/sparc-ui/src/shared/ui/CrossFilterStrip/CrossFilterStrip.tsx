import clsx from 'clsx';
import { cssVars } from '../../lib/cssVars';
import { Icon } from '../Icon/Icon';
import styles from './CrossFilterStrip.module.css';

export interface CrossFilterChip {
  id: string;
  kind: string;
  value: string;
  color: string;
  onClear: () => void;
}

export interface CrossFilterStripProps {
  chips: CrossFilterChip[];
  appliesTo?: string;
  onClearAll: () => void;
  emptyHint?: string;
}

export function CrossFilterStrip({ chips, appliesTo, onClearAll, emptyHint = 'Click a row, bar or legend to filter related panels' }: CrossFilterStripProps) {
  const any = chips.length > 0;
  return (
    <div className={styles.strip} aria-live="polite">
      <span className={styles.label}>
        <Icon name="filter" size={13} />
        CROSS-FILTERS
        <span className={clsx(styles.count, any && styles.countOn)}>{chips.length}</span>
      </span>
      {!any ? <span className={styles.hint}>{emptyHint}</span> : null}
      {chips.map((c) => (
        <div key={c.id} className={styles.chip} data-chip-kind={c.kind}>
          <span className={styles.dot} style={cssVars({ '--dot': c.color })} />
          <span className={styles.kind}>{c.kind}</span>
          <span className={styles.value} title={c.value}>
            {c.value}
          </span>
          <button type="button" className={styles.remove} aria-label={`Remove ${c.kind} filter`} onClick={c.onClear}>
            ×
          </button>
        </div>
      ))}
      {any ? (
        <>
          {appliesTo ? <span className={styles.hint}>→ {appliesTo}</span> : null}
          <span className={styles.spacer} />
          <button type="button" className={styles.clearAll} onClick={onClearAll}>
            Clear all <span className={styles.kbd}>Esc</span>
          </button>
        </>
      ) : null}
    </div>
  );
}
