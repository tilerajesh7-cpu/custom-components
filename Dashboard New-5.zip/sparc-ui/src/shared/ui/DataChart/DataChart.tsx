import { useEffect, useRef } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { cssVars } from '../../lib/cssVars';
import '../Tooltip/tooltip.css';
import styles from './DataChart.module.css';

let configured = false;
function ensureHighchartsSetup() {
  if (configured) return;
  Highcharts.setOptions({ lang: { thousandsSep: ',' }, chart: { style: { fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" } } });
  configured = true;
}
ensureHighchartsSetup();

export interface DataChartProps {
  options: Highcharts.Options;
  ariaLabel?: string;
  /** Chart fills its card; this is the floor (px). */
  minHeight?: number;
}

/** Thin Highcharts wrapper: reflows on container resize (expand / collapse / sidebar). */
export function DataChart({ options, ariaLabel, minHeight = 300 }: DataChartProps) {
  const wrap = useRef<HTMLDivElement>(null);
  const chartRef = useRef<HighchartsReact.RefObject>(null);
  useEffect(() => {
    const el = wrap.current;
    if (!el || typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(() => chartRef.current?.chart?.reflow());
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return (
    <div ref={wrap} className={styles.root} role="img" aria-label={ariaLabel} style={cssVars({ '--chart-min-h': `${minHeight}px` })}>
      <HighchartsReact ref={chartRef} highcharts={Highcharts} options={options} immutable containerProps={{ className: styles.container }} />
    </div>
  );
}
