import clsx from 'clsx';
import { Fragment } from 'react';
import type { ColDef } from 'ag-grid-community';
import type { CustomTooltipProps } from 'ag-grid-react';
import type { GridRow, TooltipConfig } from '@shared/lib/contract/gridResponse';
import { formatNumber, type NumberFormat } from '@shared/lib/format/number';
import { interpolate } from '@shared/lib/template/interpolate';
import type { GridContext } from './buildColumns';

type Props = CustomTooltipProps<GridRow> & { config: TooltipConfig; format?: NumberFormat };

/** Compact dark cell tooltip — same card style as chart tooltips (.ct). Driven by columnMetadata.tooltip. */
export function CellTooltip({ config, format, value, data, colDef, node, context }: Props) {
  const ctx = context as GridContext;
  const row = (data ?? {}) as GridRow;
  const col = colDef as ColDef<GridRow> | undefined;
  const field = col?.field ?? '';
  const tctx = { ...ctx.templateContext, row, col: { headerName: col?.headerName ?? field } };
  const pinned = !!node?.rowPinned;
  const rich = !!config.facts?.length;

  const title = config.titleTemplate ? interpolate(config.titleTemplate, tctx).trim() : undefined;
  const facts = config.facts?.map((f) => ({ label: f.label, value: interpolate(f.value, tctx) }));
  const rawPath = config.pathField ? row[config.pathField] : undefined;
  const path = Array.isArray(rawPath) ? rawPath.map(String) : [];
  const values = (config.values ?? []).map((v) => {
    const raw = v.field === '$self' ? value : row[v.field];
    const fmt = v.format ?? format;
    const n = typeof raw === 'number' ? raw : null;
    return { label: interpolate(v.label, tctx), text: formatNumber(raw, fmt), neg: n != null && n < 0, pos: n != null && n > 0 && !!fmt?.showPlus };
  });

  const extras: { label: string; text: string }[] = [];
  if (config.showShareOfTotal && !pinned && typeof value === 'number') {
    const total = ctx.stats.totals[field];
    if (total) extras.push({ label: 'Share of Grand Total', text: `${Math.round((value / total) * 100)}%` });
  }
  if (config.showHeatPct && !pinned && typeof value === 'number' && ctx.stats.heatMax > 0) {
    extras.push({ label: 'Heat vs grid max', text: `${Math.round((Math.abs(value) / ctx.stats.heatMax) * 100)}%` });
  }
  const note = row.id ? ctx.response.cellMetadata[row.id]?.[field]?.tooltip : undefined;
  const nodeText = config.nodeField ? row[config.nodeField] : undefined;
  const ntr = config.ntrField ? row[config.ntrField] : undefined;

  return (
    <div className={clsx('ct', rich && 'ct-rich')}>
      {title ? (
        <div className="ct-head">
          <span>{title}</span>
        </div>
      ) : null}
      {facts?.length ? (
        <div className="ct-kv">
          {facts.map((f) => (
            <Fragment key={f.label}>
              <span className="ct-k">{f.label}:</span>
              <b>{f.value}</b>
            </Fragment>
          ))}
        </div>
      ) : null}
      {path.length ? (
        <>
          <div className="ct-rule" />
          <div className="ct-path">
            {path.map((p, i) => (
              <b key={`${p}-${i}`}>{p}</b>
            ))}
          </div>
        </>
      ) : null}
      {values.length ? (
        <>
          {rich ? <div className="ct-rule" /> : null}
          {config.kicker ? <span className="ct-kicker">{config.kicker}</span> : null}
          {values.map((v) => (
            <div key={v.label} className="ct-row">
              <span className="ct-key">
                {v.label}
                {rich ? ':' : ''}
              </span>
              <b className={clsx('ct-val', v.neg && 'ct-neg', v.pos && 'ct-pos')}>{v.text}</b>
            </div>
          ))}
        </>
      ) : null}
      {extras.map((x) => (
        <div key={x.label} className="ct-row">
          <span className="ct-key">{x.label}</span>
          <b className="ct-val ct-dim">{x.text}</b>
        </div>
      ))}
      {note ? <div className="ct-note">{note}</div> : null}
      {nodeText != null && !pinned ? (
        <>
          <div className="ct-rule" />
          <div className="ct-mono">
            <span>{String(nodeText)}</span>
            {ntr != null ? (
              <span>
                NTR: <b>{String(ntr)}</b>
              </span>
            ) : null}
          </div>
        </>
      ) : null}
    </div>
  );
}
