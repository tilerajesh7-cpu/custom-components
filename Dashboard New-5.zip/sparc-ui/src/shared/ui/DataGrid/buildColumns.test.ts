import { describe, expect, it } from 'vitest';
import { buildColumnDefs, computeStats, heatColor } from './buildColumns';
import type { GridResponse } from '@shared/lib/contract/gridResponse';

const res: GridResponse = {
  schemaVersion: '2.0',
  gridId: 'g',
  gridMetaData: { heatmap: { scope: 'grid', excludeRowTypes: ['GRAND_TOTAL'] } },
  columnDefs: [
    { field: 'name', headerName: 'Name', colType: 'StringType', pinned: 'left' },
    { headerName: 'Monte Carlo', children: [{ field: 'cob', headerName: 'COB', colType: 'DoubleType' }, { field: 'diff', headerName: 'Diff', colType: 'DoubleType' }] },
  ],
  columnMetadata: { cob: { type: 'heatmap' }, diff: { type: 'bar', bar: { mode: 'diverging' } } },
  rowData: [{ id: 'a', name: 'A', cob: 10, diff: -2 }, { id: 'b', name: 'B', cob: -40, diff: 4 }],
  rowMetadata: {},
  cellMetadata: {},
  pinnedTopRows: [],
  pinnedBottomRows: [{ id: 'grand_total', name: 'Total', cob: -30, diff: 2 }],
};

describe('DataGrid adapter', () => {
  it('maps nested columnDefs into groups with tone classes', () => {
    const defs = buildColumnDefs(res, { groupTones: ['series1'] });
    expect(defs).toHaveLength(2);
    const group = defs[1] as { children: { field: string; cellRenderer?: string }[]; headerClass: string[] };
    expect(group.headerClass).toContain('dg-tone-series1');
    expect(group.children[1].cellRenderer).toBe('barCell');
  });

  it('computes bar maxima, heat max and grand totals', () => {
    const s = computeStats(res);
    expect(s.maxAbs.cob).toBe(40);
    expect(s.heatMax).toBe(40);
    expect(s.totals.cob).toBe(-30);
  });

  it('scales heat colour on one grid-level range', () => {
    const s = { center: 0, max: 40, pos: '#0f9b6c', neg: '#d6453b', custom: false };
    expect(heatColor(40, s)?.bg).toBe('#86cf9e');
    expect(heatColor(-4, s)?.bg).toBe('#fdebe9');
    expect(heatColor(-4, s)?.ink).toBe('#8a1c12');
    expect(heatColor(-4, { ...s, custom: true })?.bg).toMatch(/^rgba\(214,69,59,/);
    expect(heatColor(0, s)).toBeNull();
    expect(heatColor(0.5, s)).not.toBeNull();
  });

  it('uses services min/max when sent', () => {
    const s = computeStats({ ...res, gridMetaData: { heatmap: { scope: 'grid', min: -100, max: 60, centerline: 0 } } });
    expect(s.heatMax).toBe(100);
  });
});
