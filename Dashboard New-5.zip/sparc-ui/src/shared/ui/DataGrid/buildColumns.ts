import type { CellClassParams, ColDef, ColGroupDef, ITooltipParams, ValueFormatterParams } from 'ag-grid-community';
import { leafColumns, type GridResponse, type GridRow, type RowType, type WireColDef } from '@shared/lib/contract/gridResponse';
import { formatNumber, signTone } from '@shared/lib/format/number';
import { rgba, shade } from '@shared/lib/color';
import { toneHex } from '@shared/config/tokens';

export interface GridStats {
  /** max |value| per numeric field over body rows (bars) */
  maxAbs: Record<string, number>;
  /** max |value − centerline| across all heatmap cells (grid scope) — one scale for the whole grid */
  heatMax: number;
  heat: HeatScale | null;
  /** grand-total row values (share-of-total in tooltips) */
  totals: Record<string, number | null>;
}

export interface HeatScale {
  center: number;
  max: number;
  pos: string;
  neg: string;
  /** services overrode colours with hex → continuous alpha tint of that hex */
  custom: boolean;
}

/** UI-owned palette — matches the frozen Greek design (3 soft steps, coloured ink). */
const HEAT_POS = ['#e7f6ec', '#bfe6cb', '#86cf9e'];
const HEAT_NEG = ['#fdebe9', '#f9c6c0', '#f0928a'];
export const HEAT_INK = { pos: '#0f5132', neg: '#8a1c12', zero: '#98a2b3' };

export interface GridContext {
  stats: GridStats;
  selectedRowId: string | null;
  templateContext: Record<string, unknown>;
  response: GridResponse;
}

export type AnyColDef = ColDef<GridRow> | ColGroupDef<GridRow>;

const abs = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? Math.abs(v) : 0);

export function heatExcluded(res: GridResponse, rowId: string | undefined, excl: RowType[]) {
  if (!rowId) return true;
  const m = res.rowMetadata[rowId];
  return !!m?.excludeHeatMap || (!!m?.rowType && excl.includes(m.rowType));
}

export function computeStats(res: GridResponse): GridStats {
  const leaves = leafColumns(res.columnDefs).filter((c) => c.field && c.colType === 'DoubleType');
  const body = res.rowData.filter((r) => !res.rowMetadata[r.id]?.rowType);
  const maxAbs: Record<string, number> = {};
  leaves.forEach((c) => {
    maxAbs[c.field!] = Math.max(1e-9, ...body.map((r) => abs(r[c.field!])));
  });

  let heatMax = 0;
  let heat: HeatScale | null = null;
  const hm = res.gridMetaData.heatmap;
  if (hm) {
    const center = hm.centerline ?? 0;
    if (typeof hm.min === 'number' && typeof hm.max === 'number') {
      // services computed the grid-level range
      heatMax = Math.max(Math.abs(hm.max - center), Math.abs(hm.min - center));
    } else {
      const excl = hm.excludeRowTypes ?? ['GRAND_TOTAL', 'SUB_TOTAL'];
      const fields = leaves.filter((c) => res.columnMetadata[c.field!]?.type === 'heatmap').map((c) => c.field!);
      const rows = [...res.pinnedTopRows, ...res.rowData, ...res.pinnedBottomRows].filter((r) => !heatExcluded(res, r.id, excl));
      heatMax = Math.max(0, ...rows.flatMap((r) => fields.map((f) => (typeof r[f] === 'number' ? Math.abs((r[f] as number) - center) : 0))));
    }
    heat = { center, max: heatMax, pos: toneHex(hm.positiveColor ?? 'heatPositive'), neg: toneHex(hm.negativeColor ?? 'heatNegative'), custom: !!(hm.positiveColor || hm.negativeColor) };
  }

  const totalRow =
    res.pinnedBottomRows.find((r) => res.rowMetadata[r.id]?.rowType === 'GRAND_TOTAL' || r.id === 'grand_total') ??
    res.rowData.find((r) => res.rowMetadata[r.id]?.rowType === 'GRAND_TOTAL');
  const totals: Record<string, number | null> = {};
  leaves.forEach((c) => {
    const v = totalRow?.[c.field!];
    totals[c.field!] = typeof v === 'number' ? v : null;
  });
  return { maxAbs, heatMax, heat, totals };
}

/** Continuous grid-level heat colour: tint strength ∝ |v − centerline| / grid max (perceptual curve). */
export function heatColor(v: unknown, s: HeatScale): { bg: string; ink: string } | null {
  if (typeof v !== 'number' || !Number.isFinite(v) || s.max <= 0) return null;
  const d = v - s.center;
  const t = Math.min(1, Math.abs(d) / s.max);
  if (Math.abs(d) < 1e-9) return null;
  // sqrt curve on ONE grid-wide max: every non-zero cell gets at least the lightest tint
  const step = Math.min(2, Math.floor(Math.sqrt(t) * 3));
  if (s.custom) {
    const hex = d > 0 ? s.pos : s.neg;
    return { bg: rgba(hex, 0.14 + step * 0.16), ink: shade(hex, 0.5) };
  }
  return { bg: (d > 0 ? HEAT_POS : HEAT_NEG)[step], ink: d > 0 ? HEAT_INK.pos : HEAT_INK.neg };
}

export interface BuildColumnsOptions {
  groupTones?: string[];
}

export function buildColumnDefs(res: GridResponse, opts: BuildColumnsOptions = {}): AnyColDef[] {
  const sortable = res.gridMetaData.defaultColDef?.sortable ?? true;
  const resizable = res.gridMetaData.defaultColDef?.resizable ?? true;
  const heatExcl = res.gridMetaData.heatmap?.excludeRowTypes ?? ['GRAND_TOTAL', 'SUB_TOTAL'];
  let groupIdx = 0;

  const leaf = (wire: WireColDef, tone?: string, groupStart = false): ColDef<GridRow> => {
    const field = wire.field ?? '';
    const meta = res.columnMetadata[field] ?? {};
    const numeric = wire.colType === 'DoubleType';
    const def: ColDef<GridRow> = {
      colId: field,
      field,
      headerName: wire.headerName ?? field,
      headerTooltip: wire.headerTooltip ?? wire.headerName,
      hide: wire.hide,
      pinned: wire.pinned ?? undefined,
      width: wire.width,
      // no width from services → equal-width flex columns
      flex: wire.width ? undefined : 1,
      minWidth: meta.type === 'heatmap' ? (res.columnDefs.length > 2 && res.rowData.some((r) => 'segment' in r) ? 86 : 74) : numeric ? 56 : wire.width ? 84 : 110,
      maxWidth: !numeric && !wire.width && meta.type !== 'heatmap' ? 120 : undefined,
      sortable,
      resizable,
      sort: meta.sort ?? null,
      sortIndex: meta.sortIndex,
      type: numeric ? 'rightAligned' : undefined,
      headerClass: [groupStart ? 'dg-group-start' : '', tone ? `dg-tone-${tone}` : ''].filter(Boolean),
      cellClass: (p: CellClassParams<GridRow>) => {
        const cls: string[] = [];
        if (numeric) cls.push('dg-num');
        if (groupStart) cls.push('dg-group-start');
        if (tone) cls.push(`dg-tone-${tone}`);
        if (meta.tone === 'muted') cls.push('dg-muted');
        if (meta.tone === 'sign') cls.push(`dg-sign-${signTone(p.value)}`);
        if (meta.type === 'heatmap') cls.push('dg-heat-cell');
        if (p.data && res.cellMetadata[p.data.id]?.[field]) cls.push('dg-cell-flag');
        return cls;
      },
    };
    if (numeric || meta.format) def.valueFormatter = (p: ValueFormatterParams<GridRow>) => formatNumber(p.value, meta.format);
    if (meta.type === 'bar' && meta.bar) {
      def.cellRenderer = 'barCell';
      def.cellRendererParams = { mode: meta.bar.mode, max: meta.bar.max, thresholds: meta.bar.thresholds };
    }
    if (meta.type === 'heatmap') {
      def.cellRenderer = 'heatCell';
      def.cellRendererParams = { excludeRowTypes: heatExcl };
    }
    if (meta.type === 'badge') def.cellRenderer = 'badgeCell';
    def.tooltipValueGetter = (p: ITooltipParams<GridRow>) => (p.value == null || p.value === '' ? null : String(p.value));
    if (meta.tooltip) {
      def.tooltipComponent = 'cellTooltip';
      def.tooltipComponentParams = { config: meta.tooltip, format: meta.format };
    }
    return def;
  };

  const map = (wire: WireColDef): AnyColDef => {
    if (!wire.children?.length) return leaf(wire);
    const tone = opts.groupTones?.[groupIdx++ % (opts.groupTones.length || 1)];
    return {
      groupId: wire.headerName,
      headerName: wire.headerName,
      marryChildren: true,
      headerClass: ['dg-group', 'dg-group-start', tone ? `dg-tone-${tone}` : ''].filter(Boolean),
      children: wire.children.map((c, i) => leaf(c, tone, i === 0)),
    } satisfies ColGroupDef<GridRow>;
  };

  return res.columnDefs.map(map);
}
