import { ModuleRegistry } from 'ag-grid-community';
import { AllEnterpriseModule, LicenseManager } from 'ag-grid-enterprise';
import { env } from '@shared/config/env';

let ready = false;

/** Registers AG Grid Enterprise once per app (licence key comes from env). */
export function ensureAgGridSetup() {
  if (ready) return;
  ModuleRegistry.registerModules([AllEnterpriseModule]);
  if (env.agGridLicense) LicenseManager.setLicenseKey(env.agGridLicense);
  ready = true;
}
