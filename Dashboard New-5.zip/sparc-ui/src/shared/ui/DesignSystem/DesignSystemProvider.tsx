import type { ReactNode } from 'react';

/**
 * Adapter for the company design system (ICGDS 7). Wire the real providers here so the rest of the
 * app never imports ICGDS directly — swapping UI libraries only touches shared/ui.
 *
 *   import { CssProvider, ThemeProvider } from '<icgds-package>';
 *   return (
 *     <CssProvider module cssVars="legacy">
 *       <ThemeProvider theme="light">{children}</ThemeProvider>
 *     </CssProvider>
 *   );
 */
export function DesignSystemProvider({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
