import { Component, type ErrorInfo, type ReactNode } from 'react';
import { ErrorState } from '../StateViews/StateViews';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
  resetKey?: unknown;
}

/** Isolates render failures to one widget / route instead of blanking the page. */
export class ErrorBoundary extends Component<Props, { error: Error | null; key: unknown }> {
  state = { error: null as Error | null, key: this.props.resetKey };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  static getDerivedStateFromProps(props: Props, state: { error: Error | null; key: unknown }) {
    return props.resetKey !== state.key ? { error: null, key: props.resetKey } : null;
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  render() {
    if (this.state.error) return <ErrorState title={this.props.fallbackTitle ?? 'Something went wrong'} message={this.state.error.message} onRetry={() => this.setState({ error: null })} />;
    return this.props.children;
  }
}
