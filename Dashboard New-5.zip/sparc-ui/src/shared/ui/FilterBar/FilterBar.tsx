import { SegmentedControl, type SegmentOption, type SegmentValue } from '../SegmentedControl/SegmentedControl';
import styles from './FilterBar.module.css';

export interface FilterBarField {
  id: string;
  label: string;
  type: 'segmented' | 'select';
  options: SegmentOption[];
  value: SegmentValue | undefined;
}

export interface FilterBarSection {
  id: string;
  label: string;
  fields: FilterBarField[];
}

export interface FilterBarProps {
  sections: FilterBarSection[];
  onChange: (fieldId: string, value: SegmentValue) => void;
}

/** One navy row of labelled filter groups. Every change is one click. */
export function FilterBar({ sections, onChange }: FilterBarProps) {
  if (!sections.length) return null;
  return (
    <div className={styles.bar} role="toolbar" aria-label="Dashboard filters">
      {sections.map((sec) => (
        <div key={sec.id} className={styles.section}>
          <span className={styles.tag}>{sec.label}</span>
          {sec.fields.map((f) => (
            <div key={f.id} className={styles.field}>
              {sec.fields.length > 1 ? <span className={styles.fieldLabel}>{f.label}</span> : null}
              {f.type === 'select' ? (
                <select className={styles.select} aria-label={f.label} value={String(f.value ?? '')} onChange={(e) => onChange(f.id, f.options.find((o) => String(o.value) === e.target.value)?.value ?? e.target.value)}>
                  {f.options.map((o) => (
                    <option key={String(o.value)} value={String(o.value)}>
                      {o.label}
                    </option>
                  ))}
                </select>
              ) : (
                <SegmentedControl tone="dark" ariaLabel={f.label} options={f.options} value={f.value} onChange={(v) => onChange(f.id, v)} />
              )}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
