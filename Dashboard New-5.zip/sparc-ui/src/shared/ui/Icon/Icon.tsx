import clsx from 'clsx';
import styles from './Icon.module.css';

export const ICON_PATHS = {
  calendar: 'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',
  swap: 'M7 7h13M17 4l3 3-3 3M17 17H4M7 14l-3 3 3 3',
  settings:
    'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  link: 'M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71',
  download: 'M12 3v12M7 10l5 5 5-5M4 21h16',
  expand: 'M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4',
  collapse: 'M3 12h7M14 12h7M6 8l4 4-4 4M18 8l-4 4 4 4',
  fullscreen: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
  filter: 'M4 5h16l-6 8v6l-4-2v-4L4 5z',
  keyboard: 'M3 7h18v10H3zM7 10h.01M11 10h.01M15 10h.01M7 14h10',
  columns: 'M4 4h16v16H4zM9 4v16M15 4v16',
  close: 'M18 6 6 18M6 6l12 12',
  chevronRight: 'M9 6l6 6-6 6',
  grid: 'M4 4h16v16H4zM4 10h16M10 4v16',
  chart: 'M4 19V5M4 19h16M8 16v-5M12 16V8M16 16v-3',
  stress: 'M13 3L5 14h6l-1 7 8-11h-6z',
  alert: 'M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h.01',
  pulse: 'M3 12h4l3-8 4 16 3-8h4',
  trendUp: 'M3 17l6-6 4 4 8-8M15 7h6v6',
  globe: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c2.5 2.5 3.8 5.5 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.5-3.8-9S9.5 5.5 12 3z',
  dashboard: 'M4 4h7v7H4zM13 4h7v4h-7zM13 10h7v10h-7zM4 13h7v7H4z',
  pie: 'M12 3a9 9 0 1 0 9 9h-9V3zM15 3.3A9 9 0 0 1 20.7 9H15V3.3z',
  percent: 'M19 5L5 19M7.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM16.5 18a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z',
  card: 'M3 6h18v12H3zM3 10h18M7 15h4',
  greek: 'M4 18L10 12l4 4 6-8M16 8h4v4',
  delta: 'M3 17l6-6 4 4 8-8M15 7h6v6',
  gamma: 'M5 17l7-10 7 10',
  vega: 'M3 12c2.5-5 4.5-5 6 0s3.5 5 6 0 3.5-5 6 0',
  borrow: 'M4 12h11M11 8l4 4-4 4M20 5v14',
  dividend: 'M7 4v16M7 4l-3 3M7 4l3 3M17 20V4M17 20l-3-3M17 20l3-3',
  shield: 'M12 3l8 3v6c0 4.6-3.4 8.1-8 9-4.6-.9-8-4.4-8-9V6z',
  layers: 'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5',
  density1: 'M4 5h16M4 9.5h16M4 14h16M4 18.5h16',
  density2: 'M4 6h16M4 12h16M4 18h16',
  density3: 'M4 8h16M4 16h16',
} as const;

export type IconName = keyof typeof ICON_PATHS;

export interface IconProps {
  name: IconName;
  size?: 13 | 14 | 15 | 17 | 22;
  className?: string;
  title?: string;
}

export function Icon({ name, size = 15, className, title }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" className={clsx(styles.icon, className)} aria-hidden={title ? undefined : true} role={title ? 'img' : undefined}>
      {title ? <title>{title}</title> : null}
      <path d={ICON_PATHS[name] ?? ICON_PATHS.grid} />
    </svg>
  );
}

export const isIconName = (v: unknown): v is IconName => typeof v === 'string' && v in ICON_PATHS;
