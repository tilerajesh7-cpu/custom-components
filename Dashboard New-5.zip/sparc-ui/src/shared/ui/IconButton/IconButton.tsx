import clsx from 'clsx';
import type { ButtonHTMLAttributes } from 'react';
import { Icon, type IconName } from '../Icon/Icon';
import styles from './IconButton.module.css';

export interface IconButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
  icon: IconName;
  label: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'primary' | 'ghost';
  active?: boolean;
}

export function IconButton({ icon, label, size = 'md', variant = 'default', active, className, type = 'button', ...rest }: IconButtonProps) {
  return (
    <button {...rest} type={type} title={label} aria-label={label} aria-pressed={active} className={clsx(styles.btn, styles[size], styles[variant], active && styles.active, className)}>
      <Icon name={icon} size={size === 'lg' ? 17 : size === 'sm' ? 13 : 15} />
    </button>
  );
}
