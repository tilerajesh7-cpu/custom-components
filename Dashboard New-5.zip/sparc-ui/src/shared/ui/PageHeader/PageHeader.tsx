import clsx from 'clsx';
import { useRef, type ReactNode } from 'react';
import { fmtDisplayDate } from '../../lib/format/date';
import { Icon, type IconName } from '../Icon/Icon';
import styles from './PageHeader.module.css';

export interface PageHeaderProps {
  breadcrumb: string[];
  title: string;
  actions?: ReactNode;
}

export function PageHeader({ breadcrumb, title, actions }: PageHeaderProps) {
  return (
    <header className={styles.header}>
      <div className={styles.titles}>
        <nav aria-label="Breadcrumb" className={styles.crumbs}>
          {breadcrumb.map((c, i) => (
            <span key={c} className={styles.crumb}>
              {i ? <span className={styles.sep}>/</span> : null}
              {c}
            </span>
          ))}
        </nav>
        <h1 className={styles.title}>{title}</h1>
      </div>
      <div className={styles.actions}>{actions}</div>
    </header>
  );
}

export interface DatePillProps {
  label: string;
  /** ISO yyyy-mm-dd — always displayed as dd-Mon-yyyy */
  value: string;
  icon?: IconName;
  /** When set, the pill opens the native date picker. */
  onChange?: (iso: string) => void;
  /** Shown but locked (e.g. dates are derived unless Compare = Custom). */
  disabled?: boolean;
  disabledHint?: string;
  max?: string;
}

export function DatePill({ label, value, icon = 'calendar', onChange, disabled, disabledHint, max }: DatePillProps) {
  const ref = useRef<HTMLInputElement>(null);
  const editable = !!onChange && !disabled;
  const open = () => {
    const el = ref.current;
    if (!el || !editable) return;
    if (typeof el.showPicker === 'function') el.showPicker();
    else el.focus();
  };
  return (
    <div
      className={clsx(styles.pill, editable && styles.editable, disabled && styles.disabled)}
      title={disabled ? disabledHint : editable ? `Change ${label}` : undefined}
      role={editable ? 'button' : undefined}
      tabIndex={editable ? 0 : undefined}
      aria-disabled={disabled || undefined}
      onClick={open}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && open()}
    >
      <Icon name={icon} />
      <span className={styles.pillText}>
        <span className={styles.pillLabel}>{label}</span>
        <span className={styles.pillValue}>{value ? fmtDisplayDate(value) : '—'}</span>
      </span>
      {onChange ? (
        <input ref={ref} type="date" tabIndex={-1} aria-label={label} className={styles.input} value={value} max={max} disabled={!editable} onChange={(e) => e.target.value && onChange(e.target.value)} />
      ) : null}
    </div>
  );
}
