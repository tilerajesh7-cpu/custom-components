import clsx from 'clsx';
import { useCallback, useRef, type ReactNode } from 'react';
import { useClickOutside } from '../../hooks/dom';
import styles from './Popover.module.css';

export interface PopoverProps {
  open: boolean;
  onClose: () => void;
  trigger: ReactNode;
  children: ReactNode;
  align?: 'left' | 'right';
  width?: 'sm' | 'md';
  label: string;
}

export function Popover({ open, onClose, trigger, children, align = 'right', width = 'md', label }: PopoverProps) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useCallback(() => onClose(), [onClose]);
  useClickOutside(ref, close, open);
  return (
    <div ref={ref} className={styles.anchor} data-noprint="">
      {trigger}
      {open ? (
        <div role="dialog" aria-label={label} className={clsx(styles.panel, styles[align], styles[width])}>
          {children}
        </div>
      ) : null}
    </div>
  );
}
