import clsx from 'clsx';
import { toneHex } from '../../config/tokens';
import { cssVars } from '../../lib/cssVars';
import styles from './RankedList.module.css';

export interface RankedListColumn {
  key: string;
  header: string;
  /** Draws a bar (sized on this column) immediately before the value. */
  bar?: { mode: 'diverging' | 'magnitude'; tone?: string };
}

export interface RankedListCell {
  value: number | null;
  text: string;
}

export interface RankedListRow {
  id: string;
  label: string;
  cells: RankedListCell[];
}

export interface RankedListSummary {
  label: string;
  primary: RankedListCell;
  secondary?: { label: string; cell: RankedListCell };
  /** e.g. top-N share of gross exposure */
  share?: { ratio: number; text: string };
}

export interface RankedListProps {
  columns: RankedListColumn[];
  rows: RankedListRow[];
  labelHeader?: string;
  summary?: RankedListSummary;
}

const neg = (c: RankedListCell) => c.value != null && c.value < 0;

/** Compact ranked “top names” list with an optional total summary. Domain-free. */
export function RankedList({ columns, rows, labelHeader = 'Name', summary }: RankedListProps) {
  const max = columns.map((_, i) => Math.max(1e-9, ...rows.map((r) => Math.abs(r.cells[i]?.value ?? 0))));
  const template = ['18px', 'minmax(0, 1.5fr)', ...columns.flatMap((c) => (c.bar ? ['minmax(34px, 0.9fr)', 'auto'] : ['auto']))].join(' ');

  return (
    <div className={styles.root}>
      {summary ? (
        <div className={styles.summary}>
          <div className={styles.sumTop}>
            <span className={styles.sumLabel}>{summary.label}</span>
            <span className={styles.sumVals}>
              <b className={clsx(styles.sumPrimary, neg(summary.primary) && styles.neg)}>{summary.primary.text}</b>
              {summary.secondary ? (
                <span className={styles.sumSecondary}>
                  {summary.secondary.label} <b className={clsx(neg(summary.secondary.cell) && styles.neg)}>{summary.secondary.cell.text}</b>
                </span>
              ) : null}
            </span>
          </div>
          {summary.share ? (
            <div className={styles.share}>
              <span className={styles.shareTrack}>
                <span className={clsx(styles.shareFill, neg(summary.primary) && styles.shareNeg)} style={cssVars({ '--pct': `${Math.min(100, Math.round(summary.share.ratio * 100))}%` })} />
              </span>
              <span className={styles.shareText}>{summary.share.text}</span>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className={styles.table} role="table" style={cssVars({ '--cols': template })}>
        <div className={clsx(styles.row, styles.head)} role="row">
          <span />
          <span role="columnheader">{labelHeader}</span>
          {columns.map((c) => (
            <span key={c.key} role="columnheader" className={clsx(styles.num, c.bar && styles.span2)}>
              {c.header}
            </span>
          ))}
        </div>
        {rows.map((r, idx) => (
          <div key={r.id} className={styles.row} role="row">
            <span className={styles.rank}>{idx + 1}</span>
            <span className={styles.label} title={r.label} role="cell">
              {r.label}
            </span>
            {columns.map((c, i) => {
              const cell = r.cells[i] ?? { value: null, text: '' };
              const v = cell.value ?? 0;
              const ratio = Math.min(1, Math.abs(v) / max[i]);
              return [
                c.bar ? (
                  c.bar.mode === 'diverging' ? (
                    <span key={`${c.key}-bar`} className={styles.div} aria-hidden="true">
                      <span className={clsx(styles.divFill, v >= 0 ? styles.pos : styles.negFill)} style={cssVars({ '--w': `${ratio * 50}%` })} />
                    </span>
                  ) : (
                    <span key={`${c.key}-bar`} className={styles.mag} aria-hidden="true">
                      <span className={styles.magFill} style={cssVars({ '--w': `${Math.max(3, ratio * 100)}%`, '--bar': toneHex(c.bar.tone, toneHex('series1')) })} />
                    </span>
                  )
                ) : null,
                <span key={c.key} role="cell" className={clsx(styles.num, neg(cell) && styles.neg)}>
                  {cell.text}
                </span>,
              ];
            })}
          </div>
        ))}
      </div>
    </div>
  );
}
