import clsx from 'clsx';
import { DENSITIES, type Density } from '../../config/tokens';
import { Icon, type IconName } from '../Icon/Icon';
import styles from './SettingsPanel.module.css';

const DENSITY_ICON: Record<Density, IconName> = { compact: 'density1', comfortable: 'density2', spacious: 'density3' };

export interface MenuItem {
  id: string;
  label: string;
  icon: IconName;
  shortcut?: string;
  tag?: string;
  sub?: string;
  onClick: () => void;
}

export function SettingsPanel({ density, onDensity, items }: { density: Density; onDensity: (d: Density) => void; items: MenuItem[] }) {
  return (
    <>
      <div className={styles.head}>
        <span className={styles.title}>Display</span>
        <span className="kbd">D</span>
      </div>
      <span className={styles.caption}>DENSITY · WHOLE SCREEN</span>
      <div className={styles.dens} role="radiogroup" aria-label="Density">
        {DENSITIES.map((d) => (
          <button key={d} type="button" role="radio" aria-checked={density === d} className={clsx(styles.densBtn, density === d && styles.on)} onClick={() => onDensity(d)}>
            <Icon name={DENSITY_ICON[d]} size={22} />
            {d[0].toUpperCase() + d.slice(1)}
          </button>
        ))}
      </div>
      <span className={styles.note}>Row height, card padding and spacing adapt across every grid and chart.</span>
      <div className={styles.rule} />
      <MenuList items={items} />
    </>
  );
}

export function MenuList({ items }: { items: MenuItem[] }) {
  return (
    <div className={styles.menu} role="menu">
      {items.map((it) => (
        <button key={it.id} type="button" role="menuitem" className={styles.item} onClick={it.onClick}>
          {it.tag ? <span className={styles.tag}>{it.tag}</span> : <Icon name={it.icon} />}
          <span className={styles.itemText}>
            <span>{it.label}</span>
            {it.sub ? <span className={styles.itemSub}>{it.sub}</span> : null}
          </span>
          {it.shortcut ? <span className="kbd">{it.shortcut}</span> : null}
        </button>
      ))}
    </div>
  );
}
