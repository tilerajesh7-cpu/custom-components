import clsx from 'clsx';
import { cssVars } from '../../lib/cssVars';
import { Icon, isIconName } from '../Icon/Icon';
import styles from './SideNav.module.css';

export interface SideNavItem {
  id: string;
  label: string;
  level: number;
  icon?: string;
  badge?: { text: string; tone: string };
  isHeader?: boolean;
  active?: boolean;
  disabled?: boolean;
  navigable?: boolean;
}

export interface SideNavProps {
  brand: { initials: string; name: string; envBadge?: string };
  items: SideNavItem[];
  collapsed: boolean;
  onToggle: () => void;
  onSelect: (item: SideNavItem) => void;
  footerNote?: string;
}

export function SideNav({ brand, items, collapsed, onToggle, onSelect, footerNote }: SideNavProps) {
  return (
    <aside className={clsx(styles.nav, collapsed && styles.collapsed)} aria-label="Main navigation">
      <div className={styles.brand}>
        <div className={styles.logo}>{brand.initials}</div>
        {!collapsed ? (
          <div className={styles.brandText}>
            <span className={styles.brandName}>{brand.name}</span>
            {brand.envBadge ? <span className={styles.env}>{brand.envBadge}</span> : null}
          </div>
        ) : null}
      </div>
      <nav className={styles.list}>
        {items.map((it) =>
          it.isHeader ? (
            <div key={it.id} className={styles.header}>
              {collapsed ? '' : it.label}
            </div>
          ) : (
            <button
              key={it.id}
              type="button"
              title={it.label}
              aria-current={it.active ? 'page' : undefined}
              aria-disabled={it.disabled || undefined}
              className={clsx(styles.item, it.active && styles.active, it.disabled && styles.disabled, it.level === 2 && styles.leaf)}
              style={cssVars({ '--pad': `${collapsed ? 8 : 8 + it.level * 14}px` })}
              onClick={() => it.navigable && !it.disabled && onSelect(it)}
            >
              <span className={styles.ico}>
                <Icon name={isIconName(it.icon) ? it.icon : 'dashboard'} />
              </span>
              {!collapsed ? (
                <>
                  <span className={styles.label}>{it.label}</span>
                  {it.badge ? (
                    <span className={styles.badge} data-tone={it.badge.tone}>
                      {it.badge.text}
                    </span>
                  ) : null}
                </>
              ) : null}
            </button>
          ),
        )}
      </nav>
      <div className={styles.foot}>
        {!collapsed && footerNote ? <span className={styles.note}>{footerNote}</span> : null}
        <button type="button" className={styles.toggle} onClick={onToggle} aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
          <span className={styles.mono}>{collapsed ? '»' : '«'}</span>
          {!collapsed ? <span>Collapse</span> : null}
        </button>
      </div>
    </aside>
  );
}
