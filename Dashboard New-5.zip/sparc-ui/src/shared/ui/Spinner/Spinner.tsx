import clsx from 'clsx';
import styles from './Spinner.module.css';

export interface SpinnerProps {
  label?: string;
  /** Frosted overlay over existing content (refetch). */
  overlay?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

/** Dual counter-rotating gradient arcs with a pulsing core and shimmering caption. */
export function Spinner({ label = 'Loading', overlay = false, size = 'md', showLabel = size !== 'sm' }: SpinnerProps) {
  return (
    <div role="status" aria-live="polite" className={clsx(styles.wrap, overlay && styles.overlay, styles[size])}>
      <span className={styles.orb} aria-hidden="true">
        <span className={styles.halo} />
        <span className={styles.track} />
        <span className={styles.arc} />
        <span className={styles.arc2} />
        <span className={styles.core} />
      </span>
      {showLabel ? <span className={styles.label}>{label}</span> : <span className={styles.sr}>{label}</span>}
    </div>
  );
}

export function PageLoader({ label = 'Loading dashboard' }: { label?: string }) {
  return (
    <div className={styles.page}>
      <Spinner size="lg" label={label} />
    </div>
  );
}
