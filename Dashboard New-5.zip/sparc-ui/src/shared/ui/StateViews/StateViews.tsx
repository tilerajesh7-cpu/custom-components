import styles from './StateViews.module.css';

export function ErrorState({ title = 'Could not load data', message, onRetry }: { title?: string; message?: string; onRetry?: () => void }) {
  return (
    <div role="alert" className={styles.box}>
      <b className={styles.title}>{title}</b>
      {message ? <span className={styles.msg}>{message}</span> : null}
      {onRetry ? (
        <button type="button" className={styles.retry} onClick={onRetry}>
          Retry
        </button>
      ) : null}
    </div>
  );
}

export function EmptyState({ message = 'No data for the selected filters' }: { message?: string }) {
  return <div className={styles.box}><span className={styles.msg}>{message}</span></div>;
}
