import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

const r = (p: string) => fileURLToPath(new URL(p, import.meta.url));

const CHUNKS: [RegExp, string][] = [
  [/[\\/](react|react-dom|scheduler)[\\/]/, 'react'],
  [/react-router/, 'router'],
  [/@reduxjs|react-redux|redux-persist|[\\/]redux[\\/]/, 'state'],
  [/@tanstack/, 'query'],
  [/icgds/, 'icgds'],
  [/ag-grid/, 'ag-grid'],
  [/highcharts/, 'highcharts'],
];

export default defineConfig({
  base: './',
  plugins: [react()],
  resolve: {
    alias: {
      '@app': r('./src/app'),
      '@pages': r('./src/pages'),
      '@features': r('./src/features'),
      '@shared': r('./src/shared'),
      '@layouts': r('./src/layouts'),
      '@mocks': r('./src/mocks'),
    },
  },
  server: { port: 4000 },
  preview: { port: 4000 },
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes('node_modules')) return undefined;
          return CHUNKS.find(([re]) => re.test(id))?.[1] ?? 'vendor';
        },
      },
    },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setup.ts'],
    include: ['src/**/*.test.{ts,tsx}'],
    coverage: { provider: 'v8', reporter: ['text', 'lcov'], reportsDirectory: 'coverage' },
  },
});
