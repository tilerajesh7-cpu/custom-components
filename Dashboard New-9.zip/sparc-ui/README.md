# sparc-ui — VaR Summary & Greek dashboards

React 19 + TypeScript + Vite 7 · AG Grid Enterprise · Highcharts · Redux Toolkit + redux-persist · TanStack Query · zod.
Built to the frozen design **VaR Summary v7** (Mock 2) and **Greek Dashboard Mock 3 / Mock 4**.

```bash
cp .env.example .env      # VITE_USE_MOCKS=true runs with no backend
npm install
npm start                 # http://localhost:4000
npm test · npm run lint · npm run typecheck · npm run e2e
```

Routes: `#/daily-risk/equities/var-summary` · `#/daily-risk/equities/greek-dashboard` (Mock 3) · `#/daily-risk/equities/greek-dashboard-v2` (Mock 4).

## How it works

Every page is **one generic renderer**: `pages/*Page.tsx` → `<DashboardView dashboardId="…"/>`.

```
GET /app/sidebar-menu                 → layouts/AppLayout (SideNav)
GET /dashboards/{id}/definition       → widgets, layout sections/rows, bindings, selection rules
GET /dashboards/{id}/filters          → header + filter-bar fields, derived fields (PCOB), hotkeys
GET /dashboards/{id}/chart-config     → chart configs keyed by widget.chartConfigId  (separate API)
GET {widget.endpoint}/config         → grid/series config (cached + last-good in localStorage, configVersion)
GET {widget.endpoint}/data?{params}  → { rowData } only — merged with config into Grid Response v2 (shared/lib/contract/gridConfig.ts)
```

- **Bindings** in `widget.params`: `$filter.region`, `$selection.widget-1.rowId|all` (fallback after `|`). The resolved params are the TanStack query key, so every filter/selection combination is cached.
- **Drilldown (VaR)**: only widget‑1 (Standalone) and widget‑7 (Limits) are clickable.
  - Row or cell click on Standalone → widgets 2–6 refetch with `rowId`. Click the same row again or press Esc → back to `all`.
  - Limits: `selection.default = "firstRow"` → the UI selects row 1 and loads the limit chart. A click selects another limit. If a filter change removes the selected row, it falls back to row 1.
- **Top filters**: Region / Variant / Attribute / COB / Compare refetch through the query key; Days refetches series only; Compare derives PCOB from its option.
- **Charts** are built from the same v2 payload by `shared/lib/chart/buildChartOptions` + `chartMetaData` from the chart-config API.

## Folders

```
app/        store · router · providers · bootstrap (mock transport) · global.css
layouts/    AppLayout (sidebar + <Outlet/>)
pages/      one lazy route per dashboard
features/
  dashboard/   api (fetchers + TanStack hooks) · model (slice, types, zod) · lib (bindings, filters, stat tiles)
               hooks (useWidgetData, hotkeys, chips) · components (DashboardView, Header, Grid/Chart widgets)
  navigation/  sidebar menu API + collapsed state
shared/
  ui/      DataGrid · DataChart · WidgetCard · FilterBar · CrossFilterStrip · PageHeader/DatePill · SideNav
           SettingsPanel · ShortcutsDialog · StatTiles/SectionHeading · SegmentedControl · Popover · IconButton
           Icon · Spinner · ErrorBoundary · StateViews · DesignSystemProvider (ICGDS adapter)
  lib/     contract (Grid Response v2 types + zod) · chart · format · export (CSV) · http (transport) · template
  config/  env · tokens (tone → hex, density) · hooks/ useHotkeys, dom
mocks/     transport.ts + data/** (one JSON per endpoint / selection key)
```

`shared/ui` is domain-free and only imports `shared/*`, so it can move into the common UI library unchanged. Styling uses CSS Modules (plus prefixed global CSS for AG Grid / Highcharts). There is no inline CSS: runtime values are passed only through `cssVars()` custom properties.

## Mock data → services hand-off

`src/mocks/data` mirrors the endpoints: `grid-config/{id}.json` and `grid-data/{id}.json` | `grid-data/{id}/{rowId|all|limitId}.json`. The transport applies Region (row filter), Variant/Attribute (scale) and Days (last N rows) to emulate the backend.

Additions to Grid Response v2 that need sign-off:
- chart-config API (`type`, `stacking`, `orientation`, `valueFields`, `seriesField`, row-type include/exclude, `seriesTones`, `stackTotals`, `referenceLines`, `derivedSeries`, `colorByRatio`, `secondaryAxis`)
- trend **series responses** in the v2 shape: one row per `cobDate`
- `columnMetadata.tooltip` (facts, path, values, kicker, share/heat %)
- `bar.mode` (magnitude / diverging / progress)
- widget `selection` (`toggle`, `default: firstRow`, `chip`)

## ICGDS

Wire `CssProvider` / `ThemeProvider` in `shared/ui/DesignSystem/DesignSystemProvider.tsx`. Primitives in `shared/ui` can be re-implemented over ICGDS components without touching features.
