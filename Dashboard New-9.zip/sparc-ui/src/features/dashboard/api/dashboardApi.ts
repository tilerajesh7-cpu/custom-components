import { apiGet } from '@shared/lib/http/client';
import { ContractError, type GridResponse } from '@shared/lib/contract/gridResponse';
import { mergeGrid, parseGridConfig, parseGridData, type GridConfig } from '@shared/lib/contract/gridConfig';
import { parseChartConfig, parseDefinition, parseFilters } from '../model/schemas';
import type { ChartConfigResponse, DashboardDefinition, DashboardFilters, ParamValue } from '../model/types';

/* Endpoints (relative to VITE_API_BASE):
 *   GET /dashboards/{id}/definition    — widgets, layout, bindings (cacheable)
 *   GET /dashboards/{id}/filters       — filter fields, sections, hotkeys
 *   GET /dashboards/{id}/chart-config  — chart configs keyed by chartConfigId
 *   GET {widget.endpoint}/config       — grid / series config (cached, versioned)
 *   GET {widget.endpoint}/data?{params} — { rowData } only
 */

export const fetchDefinition = (id: string, signal?: AbortSignal) => apiGet<DashboardDefinition>(`/dashboards/${id}/definition`, undefined, { signal, parse: parseDefinition });

export const fetchFilters = (id: string, signal?: AbortSignal) => apiGet<DashboardFilters>(`/dashboards/${id}/filters`, undefined, { signal, parse: parseFilters });

export const fetchChartConfig = (id: string, signal?: AbortSignal) => apiGet<ChartConfigResponse>(`/dashboards/${id}/chart-config`, undefined, { signal, parse: parseChartConfig });

/* ---------- grid config: in-memory per session + last-good copy in localStorage ---------- */

const STORE_KEY = 'sparc-ui:grid-config:';
const configCache = new Map<string, Promise<GridConfig>>();

const readStored = (endpoint: string): GridConfig | null => {
  try {
    const raw = localStorage.getItem(STORE_KEY + endpoint);
    return raw ? parseGridConfig(JSON.parse(raw)) : null;
  } catch {
    return null;
  }
};

const store = (endpoint: string, cfg: GridConfig) => {
  try {
    localStorage.setItem(STORE_KEY + endpoint, JSON.stringify(cfg));
  } catch {
    /* quota / private mode — cache is best-effort */
  }
};

async function withRetry<T>(fn: () => Promise<T>, retries: number, baseMs = 300): Promise<T> {
  for (let i = 0; ; i++) {
    try {
      return await fn();
    } catch (e) {
      if (i >= retries || e instanceof ContractError) throw e;
      await new Promise((r) => setTimeout(r, baseMs * 2 ** i));
    }
  }
}

export class ConfigUnavailableError extends Error {
  constructor(endpoint: string, cause: unknown) {
    super(`Grid configuration unavailable (${endpoint}). ${cause instanceof Error ? cause.message : ''}`.trim());
    this.name = 'ConfigUnavailableError';
  }
}

/** One shared request per endpoint; on failure falls back to the last-good stored config. */
export function fetchGridConfig(endpoint: string): Promise<GridConfig> {
  const hit = configCache.get(endpoint);
  if (hit) return hit;
  const p = withRetry(() => apiGet<GridConfig>(`${endpoint}/config`, undefined, { parse: parseGridConfig }), 2)
    .then((cfg) => {
      store(endpoint, cfg);
      return cfg;
    })
    .catch((err: unknown) => {
      configCache.delete(endpoint);
      const stored = readStored(endpoint);
      if (stored) {
        console.warn(`[grid-config] using cached config v${stored.configVersion} for ${endpoint}`, err);
        return stored;
      }
      throw new ConfigUnavailableError(endpoint, err);
    });
  configCache.set(endpoint, p);
  return p;
}

/** Drops cached configs (e.g. after a release / configVersion bump). */
export const invalidateGridConfigs = () => configCache.clear();

/** Config and data are requested in parallel, then merged into the Grid Response v2 shape. */
export async function fetchWidgetData(endpoint: string, params: Record<string, ParamValue>, signal?: AbortSignal): Promise<GridResponse> {
  const [cfg, data] = await Promise.all([fetchGridConfig(endpoint), apiGet(`${endpoint}/data`, params, { signal, parse: parseGridData })]);
  return mergeGrid(cfg, data);
}
