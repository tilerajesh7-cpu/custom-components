import type { Options, SeriesOptionsType, YAxisOptions } from 'highcharts';
import { leafColumns, type GridResponse, type GridRow, type RowType } from '../contract/gridResponse';
import { formatNumber, toNumber, type NumberFormat } from '../format/number';
import { fmtShortDate, fmtWeekdayDate, isIsoDate } from '../format/date';
import { buildTooltipModel, renderTooltipHtml, splitSeriesName, type ChartTooltipConfig } from './tooltip';
import { DEFAULT_SERIES_TONES, toneHex, type Tone } from '../../config/tokens';

/**
 * Chart config (served by the separate chart-config API, referenced by widget.chartConfigId).
 * Charts are drawn from the SAME Grid Response v2 payload as grids — no chart-specific data API.
 */
export interface ChartConfig {
  type: 'line' | 'area' | 'column' | 'bar';
  stacking?: 'normal' | 'percent';
  /** timeSeries: one row per category (date), one series per value field.
   *  fieldsAsCategories: one series per row, one category per value field.
   *  rowsAsCategories: one category per row (e.g. top names), one series per value field.
   */
  orientation: 'timeSeries' | 'fieldsAsCategories' | 'rowsAsCategories';
  categoryField?: string;
  /** Explicit field list, or '*' = every visible DoubleType leaf column. */
  valueFields?: string[] | '*';
  excludeFields?: string[];
  seriesField?: string;
  includeRowTypes?: RowType[];
  excludeRowTypes?: RowType[];
  seriesLabels?: Record<string, string>;
  seriesTones?: Record<string, Tone> | Tone[];
  seriesStyle?: Record<string, { dash?: string }>;
  areaFirstSeries?: boolean;
  categoryLabelReplace?: [string, string][];
  xAxis?: { title?: string; labelRotation?: number };
  yAxis?: { title?: string; zeroLine?: boolean };
  stackTotals?: boolean;
  /** colour each point by its sign (e.g. navy long / red short) */
  colorBySign?: { positive: Tone; negative: Tone };
  dataLabels?: boolean;
  colorByRatio?: { numerator: string; denominator: string; baseTone: Tone; thresholds: { gte: number; tone: Tone }[] };
  referenceLines?: { field: string; label: string; tone: Tone }[];
  derivedSeries?: { id: string; label: string; numerator: string; denominator: string; tone: Tone; axis?: 'secondary' }[];
  secondaryAxis?: { max?: number; format?: 'percent' };
  legend?: { enabled?: boolean; position?: 'top' | 'bottom'; title?: string };
  /** @deprecated use chartTooltip */
  tooltip?: ChartTooltipConfig;
  chartTooltip?: ChartTooltipConfig;
  valueFormat?: NumberFormat;
  height?: number;
}

export interface ChartBuildOptions {
  onPointClick?: (e: { seriesKey: string; category: string; rowId?: string }) => void;
}

const FONT = "'Plus Jakarta Sans', system-ui, sans-serif";
const MONO = "'IBM Plex Mono', monospace";

const hexToRgba = (hex: string, a: number) => {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.replace(/./g, (c) => c + c) : h, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};

function rowsFor(res: GridResponse, cfg: ChartConfig): GridRow[] {
  return res.rowData.filter((r) => {
    const t = res.rowMetadata[r.id]?.rowType;
    if (cfg.includeRowTypes?.length && (!t || !cfg.includeRowTypes.includes(t))) return false;
    if (cfg.excludeRowTypes?.length && t && cfg.excludeRowTypes.includes(t)) return false;
    return true;
  });
}

function valueFieldsFor(res: GridResponse, cfg: ChartConfig): string[] {
  const present = new Set(leafColumns(res.columnDefs).filter((c) => !c.hide).map((c) => c.field));
  // services may drop fields (e.g. Display = MC VaR); only plot what the response contains
  if (Array.isArray(cfg.valueFields)) return cfg.valueFields.filter((f) => present.has(f));
  const skip = new Set([...(cfg.excludeFields ?? []), cfg.categoryField, cfg.seriesField].filter(Boolean) as string[]);
  return leafColumns(res.columnDefs)
    .filter((c) => c.field && !c.hide && c.colType === 'DoubleType' && !skip.has(c.field))
    .map((c) => c.field!);
}

function toneFor(cfg: ChartConfig, key: string, idx: number): string {
  const t = cfg.seriesTones;
  if (Array.isArray(t)) return toneHex(t[idx % t.length]);
  return toneHex(t?.[key], toneHex(DEFAULT_SERIES_TONES[idx % DEFAULT_SERIES_TONES.length]));
}

const ratioTone = (ratio: number, cfg: NonNullable<ChartConfig['colorByRatio']>) =>
  [...cfg.thresholds].sort((a, b) => b.gte - a.gte).find((t) => ratio >= t.gte)?.tone ?? cfg.baseTone;

interface TipPoint {
  x?: number;
  y?: number | null;
  color?: unknown;
  category?: string | number;
  series: { name: string; userOptions?: { custom?: { percent?: boolean } } };
  point?: TipPoint;
}

const tipConfig = (cfg: ChartConfig): ChartTooltipConfig => ({ ...(cfg.tooltip ?? {}), ...(cfg.chartTooltip ?? {}) });

function tooltipFormatter(cfg: ChartConfig, header: (x: number, cat: unknown) => string) {
  const tip = tipConfig(cfg);
  const fmt = cfg.valueFormat ?? { decimals: 2 };
  const pctThresholds = cfg.colorByRatio?.thresholds;
  return function (this: unknown) {
    const ctx = this as TipPoint & { points?: TipPoint[] };
    const pts = (ctx.points ?? [ctx]).map((p) => {
      const pt = p.point ?? p;
      return { series: p.series, x: pt.x ?? p.x, category: pt.category ?? p.category, y: p.y ?? pt.y ?? null, color: pt.color ?? p.color };
    });
    const first = pts[0];
    const title = header(typeof first?.x === 'number' ? first.x : 0, first?.category);
    const model = buildTooltipModel(
      title,
      pts.map((p) => ({ seriesName: p.series.name, color: typeof p.color === 'string' ? p.color : undefined, y: p.y ?? null, percent: !!p.series.userOptions?.custom?.percent })),
      tip,
      fmt,
      pctThresholds,
    );
    return renderTooltipHtml(model);
  };
}

function baseOptions(cfg: ChartConfig): Options {
  const top = (cfg.legend?.position ?? 'top') === 'top';
  return {
    chart: { type: cfg.type, backgroundColor: 'transparent', height: null, spacing: [8, 6, 6, 4], style: { fontFamily: FONT }, animation: { duration: 300 } },
    title: { text: null },
    subtitle: { text: null },
    credits: { enabled: false },
    exporting: { enabled: false },
    accessibility: { enabled: false },
    legend: {
      enabled: cfg.legend?.enabled ?? true,
      align: top ? 'left' : 'center',
      verticalAlign: top ? 'top' : 'bottom',
      itemDistance: 14,
      symbolRadius: 3,
      title: cfg.legend?.title ? { text: cfg.legend.title, style: { color: '#667085', fontSize: '11px', fontWeight: '600' } } : undefined,
      itemStyle: { color: '#475467', fontSize: '12px', fontWeight: '500' },
      itemHoverStyle: { color: '#1d4596' },
    },
    tooltip: { useHTML: true, shared: tipConfig(cfg).shared ?? true, backgroundColor: 'transparent', borderWidth: 0, shadow: false, padding: 0, outside: true, className: 'ct-wrap' },
    plotOptions: {
      series: { animation: { duration: 300 }, states: { inactive: { opacity: 0.35 } }, marker: { enabled: false, radius: 3 } },
      column: { stacking: cfg.stacking, borderWidth: 0, borderRadius: 2, pointPadding: 0.08, groupPadding: 0.12, maxPointWidth: 42 },
      bar: { borderWidth: 0, borderRadius: 3, pointPadding: 0.1, groupPadding: 0.08, maxPointWidth: 36 },
      line: { lineWidth: 2.25 },
      area: { lineWidth: 2.25 },
    },
  };
}

const yAxisBase = (cfg: ChartConfig): YAxisOptions => ({
  title: { text: cfg.yAxis?.title ?? null, style: { color: '#8a94a8', fontSize: '11px', fontWeight: '600' } },
  gridLineColor: '#eef1f6',
  labels: { style: { color: '#98a2b3', fontSize: '11px', fontFamily: MONO } },
  plotLines: cfg.yAxis?.zeroLine ? [{ value: 0, color: '#98a2b3', width: 1, zIndex: 3 }] : undefined,
});

/** Highcharts merges explicit `undefined` over its defaults (e.g. legend.title → crash reading 'text'). Strip them. */
export function pruneUndefined<T>(v: T): T {
  if (Array.isArray(v)) return v.map(pruneUndefined) as T;
  if (v && typeof v === 'object' && Object.getPrototypeOf(v) === Object.prototype) {
    const out: Record<string, unknown> = {};
    for (const [k, x] of Object.entries(v as Record<string, unknown>)) if (x !== undefined) out[k] = pruneUndefined(x);
    return out as T;
  }
  return v;
}

export function buildChartOptions(res: GridResponse, cfg: ChartConfig, opts: ChartBuildOptions = {}): Options {
  return pruneUndefined(buildRaw(res, cfg, opts));
}

function buildRaw(res: GridResponse, cfg: ChartConfig, opts: ChartBuildOptions): Options {
  const base = baseOptions(cfg);
  const rows = rowsFor(res, cfg);
  const fields = valueFieldsFor(res, cfg);
  const headers = new Map(leafColumns(res.columnDefs).map((c) => [c.field, c.headerName ?? c.field ?? '']));
  const label = (f: string) => cfg.seriesLabels?.[f] ?? headers.get(f) ?? f;

  if (cfg.orientation === 'timeSeries') {
    const catField = cfg.categoryField ?? 'cobDate';
    const raw = rows.map((r) => String(r[catField] ?? ''));
    const categories = raw.map((c) => (isIsoDate(c) ? fmtShortDate(c) : c));
    const series: SeriesOptionsType[] = fields.map((f, i) => {
      const color = toneFor(cfg, f, i);
      const isArea = cfg.areaFirstSeries && i === 0 && cfg.type === 'line';
      const tip = tipConfig(cfg);
      // grouped stacked columns: one stack per tooltip column (e.g. CVaR stack beside CHVaR stack)
      const stack = cfg.stacking && tip.groupingEnabled ? splitSeriesName(label(f), tip.separators?.length ? tip.separators : [' · '], tip.namePattern)?.column : undefined;
      const data = cfg.colorByRatio
        ? rows.map((r) => {
            const n = toNumber(r[cfg.colorByRatio!.numerator]);
            const d = toNumber(r[cfg.colorByRatio!.denominator]);
            return { y: toNumber(r[f]), color: n != null && d ? toneHex(ratioTone(n / d, cfg.colorByRatio!)) : color };
          })
        : rows.map((r) => toNumber(r[f]));
      return {
        type: isArea ? 'area' : cfg.type,
        id: f,
        name: label(f),
        color,
        data,
        stack,
        dashStyle: (cfg.seriesStyle?.[f]?.dash as 'Dash' | undefined) ?? 'Solid',
        fillColor: isArea ? { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, hexToRgba(color, 0.2)], [1, hexToRgba(color, 0)]] } : undefined,
      } as SeriesOptionsType;
    });
    cfg.referenceLines?.forEach((l) =>
      series.push({ type: 'line', id: `ref-${l.field}`, name: l.label, color: toneHex(l.tone), lineWidth: 2, data: rows.map((r) => toNumber(r[l.field])), marker: { enabled: false }, zIndex: 4 } as SeriesOptionsType),
    );
    cfg.derivedSeries?.forEach((d) =>
      series.push({
        type: 'line',
        id: d.id,
        name: d.label,
        color: toneHex(d.tone),
        lineWidth: 1.75,
        yAxis: d.axis === 'secondary' ? 1 : 0,
        custom: { percent: cfg.secondaryAxis?.format === 'percent' },
        data: rows.map((r) => {
          const n = toNumber(r[d.numerator]);
          const den = toNumber(r[d.denominator]);
          return n != null && den ? n / den : null;
        }),
        zIndex: 5,
      } as SeriesOptionsType),
    );
    const yAxis: YAxisOptions[] = [yAxisBase(cfg)];
    if (cfg.derivedSeries?.some((d) => d.axis === 'secondary')) {
      yAxis.push({
        opposite: true,
        min: 0,
        max: cfg.secondaryAxis?.max,
        gridLineWidth: 0,
        title: { text: null },
        labels: { style: { color: '#98a2b3', fontSize: '11px', fontFamily: MONO }, formatter() { return cfg.secondaryAxis?.format === 'percent' ? `${Math.round(Number(this.value) * 100)}%` : String(this.value); } },
      });
    }
    return {
      ...base,
      xAxis: { categories, tickInterval: Math.max(1, Math.round(categories.length / 5)), lineColor: '#e6ebf3', tickLength: 0, labels: { style: { color: '#98a2b3', fontSize: '11px' } } },
      yAxis,
      tooltip: { ...base.tooltip, formatter: tooltipFormatter(cfg, (x) => (isIsoDate(raw[x]) ? fmtWeekdayDate(raw[x]) : raw[x] ?? '')) as never },
      series,
    };
  }

  if (cfg.orientation === 'rowsAsCategories') {
    const catField = cfg.categoryField ?? 'name';
    const fmtR = cfg.valueFormat ?? { decimals: 1 };
    const categories = rows.map((r) => String(r[catField] ?? r.id));
    const series: SeriesOptionsType[] = fields.map((f, i) => {
      const color = toneFor(cfg, f, i);
      return {
        type: cfg.type,
        id: f,
        name: label(f),
        color,
        data: rows.map((r) => {
          const y = toNumber(r[f]);
          return cfg.colorBySign ? { y, color: toneHex(y != null && y < 0 ? cfg.colorBySign.negative : cfg.colorBySign.positive) } : y;
        }),
        dataLabels: cfg.dataLabels
          ? { enabled: true, crop: false, overflow: 'allow', style: { color: '#344054', fontSize: '10.5px', fontWeight: '600', textOutline: 'none', fontFamily: MONO }, formatter() { return formatNumber(this.y, fmtR); } }
          : undefined,
      } as SeriesOptionsType;
    });
    return {
      ...base,
      xAxis: { categories, lineColor: '#e6ebf3', tickLength: 0, labels: { style: { color: '#475467', fontSize: '11px', fontFamily: MONO } } },
      yAxis: { ...yAxisBase(cfg), plotLines: [{ value: 0, color: '#98a2b3', width: 1, zIndex: 3 }] },
      tooltip: { ...base.tooltip, formatter: tooltipFormatter(cfg, (x) => categories[x] ?? '') as never },
      series,
    };
  }

  // fieldsAsCategories
  const categories = fields.map((f) => (cfg.categoryLabelReplace ?? []).reduce((s, [a, b]) => s.split(a).join(b), headers.get(f) ?? f));
  const seriesField = cfg.seriesField ?? 'id';
  const series: SeriesOptionsType[] = rows.map((r, k) => {
    const name = String(r[seriesField] ?? r.id);
    return {
      type: cfg.type,
      id: r.id,
      name,
      color: toneFor(cfg, name, k),
      data: fields.map((f) => toNumber(r[f]) ?? 0),
      point: opts.onPointClick ? { events: { click() { opts.onPointClick?.({ seriesKey: name, category: String((this as { category?: unknown }).category ?? ''), rowId: r.id }); } } } : undefined,
    } as SeriesOptionsType;
  });
  const fmt = cfg.valueFormat ?? { decimals: 1 };
  return {
    ...base,
    chart: { ...base.chart, spacingTop: 18 },
    xAxis: {
      categories,
      lineColor: '#e6ebf3',
      title: cfg.xAxis?.title ? { text: cfg.xAxis.title, style: { color: '#667085', fontSize: '11.5px', fontWeight: '600' } } : undefined,
      labels: { rotation: cfg.xAxis?.labelRotation, style: { color: '#475467', fontSize: '11px' } },
    },
    yAxis: {
      ...yAxisBase(cfg),
      stackLabels: cfg.stackTotals
        ? { enabled: true, crop: false, allowOverlap: true, style: { color: '#344054', fontSize: '10.5px', fontWeight: '600', textOutline: 'none', fontFamily: MONO }, formatter() { return formatNumber(this.total, { ...fmt, decimals: 1 }); } }
        : undefined,
    },
    tooltip: { ...base.tooltip, formatter: tooltipFormatter(cfg, (_x, cat) => String(cat ?? '')) as never },
    series,
  };
}
