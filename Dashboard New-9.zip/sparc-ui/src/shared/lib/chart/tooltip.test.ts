import { describe, expect, it } from 'vitest';
import { buildTooltipModel, renderTooltipHtml, splitSeriesName } from './tooltip';

describe('chart tooltip', () => {
  it('splits series names by separator and pattern', () => {
    expect(splitSeriesName('EQDL · CVaR', [' · ', ' '])).toEqual({ row: 'EQDL', column: 'CVaR' });
    expect(splitSeriesName('MC SVaR', [' · ', ' '], 'column·row')).toEqual({ row: 'SVaR', column: 'MC' });
    expect(splitSeriesName('VaR', [' '])).toBeNull();
  });

  it('groups into an FS type × measure table with per-column footer', () => {
    const m = buildTooltipModel(
      'Mon, Aug 31, 2026',
      [
        { seriesName: 'BCID · CVaR', y: 517.18, color: '#2f62c9' },
        { seriesName: 'BCID · CHVaR', y: 430.1 },
        { seriesName: 'EQDL · CVaR', y: 100 },
        { seriesName: 'EQDL · CHVaR', y: 50 },
      ],
      { groupingEnabled: true, groupedRowHeader: 'FS Type', footerWhenGrouped: true, footerLabelSuffix: 'Trend' },
    );
    expect(m.headers).toEqual(['FS Type', 'CVaR', 'CHVaR']);
    expect(m.rows.map((r) => r.label)).toEqual(['BCID', 'EQDL']);
    expect(m.rows[0].cells.map((c) => c.text)).toEqual(['517.18', '430.10']);
    expect(m.footer).toMatchObject([{ label: 'CVaR Trend', column: 1, text: '617.18' }, { label: 'CHVaR Trend', column: 2, text: '480.10' }]);
    expect(renderTooltipHtml(m)).toContain('<th>FS Type</th>');
  });

  it('falls back to a flat list with percent tones', () => {
    const m = buildTooltipModel(
      'Tue, Sep 1, 2026',
      [{ seriesName: 'VaR', y: 16.33 }, { seriesName: 'Limit', y: 15 }, { seriesName: 'Utilization', y: 1.089, percent: true }],
      { groupingEnabled: true, note: '$MM · negatives in ( )' },
      { decimals: 2 },
      [{ gte: 0.8, tone: 'warning' }, { gte: 1, tone: 'negative' }],
    );
    expect(m.headers).toEqual([]);
    expect(m.rows[2].cells[0]).toEqual({ text: '108.9%', tone: 'neg' });
    expect(m.note).toBe('$MM · negatives in ( )');
  });
});
