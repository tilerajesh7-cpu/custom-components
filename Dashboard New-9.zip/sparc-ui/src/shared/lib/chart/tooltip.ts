import { formatNumber, type NumberFormat } from '../format/number';

/**
 * Chart tooltip config (chart-config API → charts[id].chartTooltip). All optional; the UI derives
 * everything from series names + values, so services only describe HOW to group.
 *
 * Grouped mode splits each series name into (row, column) with the first matching separator:
 *   "EQDL · CVaR"  + namePattern "row·column"  → row EQDL, column CVaR
 *   "MC VaR"       + namePattern "column·row"  → row VaR,  column MC
 */
export interface ChartTooltipConfig {
  shared?: boolean;
  /** Header of the label column in flat (ungrouped) mode. */
  rowHeader?: string;
  /** Optional header for the value column in flat mode. */
  valueHeader?: string;
  groupingEnabled?: boolean;
  /** Header of the label column when grouped (e.g. "FS Type"). */
  groupedRowHeader?: string;
  separators?: string[];
  namePattern?: 'row·column' | 'column·row';
  /** Display text for column keys, e.g. { MC: "MC ($MM)" }. */
  columnLabels?: Record<string, string>;
  /** One footer row per column with the column total ("CVaR Trend  10,191.48"). */
  footerWhenGrouped?: boolean;
  footerLabelSuffix?: string;
  /** Flat mode: total row across all points. */
  showTotal?: boolean;
  totalLabel?: string;
  /** Small caption at the bottom, e.g. "$MM · negatives in ( )". */
  note?: string;
}

export interface TipInput {
  seriesName: string;
  color?: string;
  y: number | null;
  /** value is a ratio → render as percent */
  percent?: boolean;
}

type Tone = 'neg' | 'warn' | undefined;

export interface TooltipModel {
  title: string;
  headers: string[];
  rows: { label: string; color?: string; cells: { text: string; tone?: Tone }[] }[];
  footer: { label: string; column: number; text: string; tone?: Tone }[];
  note?: string;
}

const DEFAULT_SEPARATORS = [' · ', ' . ', '·', '.'];

export function splitSeriesName(name: string, separators: string[], pattern: ChartTooltipConfig['namePattern'] = 'row·column') {
  for (const sep of separators) {
    const i = name.indexOf(sep);
    if (i > 0 && i < name.length - sep.length) {
      const a = name.slice(0, i).trim();
      const b = name.slice(i + sep.length).trim();
      return pattern === 'column·row' ? { row: b, column: a } : { row: a, column: b };
    }
  }
  return null;
}

function cellOf(y: number | null, percent: boolean | undefined, fmt: NumberFormat, pctThresholds?: { gte: number; tone: string }[]) {
  if (percent) {
    const th = [...(pctThresholds ?? [])].sort((a, b) => b.gte - a.gte).find((t) => y != null && y >= t.gte);
    return { text: formatNumber(y, { style: 'percent', decimals: 1 }), tone: (th?.tone === 'negative' ? 'neg' : th ? 'warn' : undefined) as Tone };
  }
  return { text: formatNumber(y, fmt), tone: (y != null && y < 0 ? 'neg' : undefined) as Tone };
}

export function buildTooltipModel(title: string, points: TipInput[], cfg: ChartTooltipConfig = {}, fmt: NumberFormat = { decimals: 2 }, pctThresholds?: { gte: number; tone: string }[]): TooltipModel {
  const seps = cfg.separators?.length ? cfg.separators : DEFAULT_SEPARATORS;
  const parsed = cfg.groupingEnabled ? points.map((p) => (p.percent ? null : splitSeriesName(p.seriesName, seps, cfg.namePattern))) : [];
  const grouped = !!cfg.groupingEnabled && points.length > 0 && parsed.every(Boolean);

  if (grouped) {
    const cols: string[] = [];
    const rows = new Map<string, { color?: string; vals: Map<string, number | null> }>();
    points.forEach((p, i) => {
      const { row, column } = parsed[i]!;
      if (!cols.includes(column)) cols.push(column);
      const r = rows.get(row) ?? { color: p.color, vals: new Map() };
      r.vals.set(column, p.y);
      rows.set(row, r);
    });
    const footer = cfg.footerWhenGrouped
      ? cols.map((c, ci) => {
          const sum = [...rows.values()].reduce((s, r) => s + (r.vals.get(c) ?? 0), 0);
          return { label: [c, cfg.footerLabelSuffix].filter(Boolean).join(' '), column: ci + 1, ...cellOf(sum, false, fmt) };
        })
      : [];
    return {
      title,
      headers: [cfg.groupedRowHeader ?? cfg.rowHeader ?? '', ...cols.map((c) => cfg.columnLabels?.[c] ?? c)],
      rows: [...rows.entries()].map(([label, r]) => ({ label, color: r.color, cells: cols.map((c) => (r.vals.has(c) ? cellOf(r.vals.get(c) ?? null, false, fmt) : { text: '—' })) })),
      footer,
      note: cfg.note,
    };
  }

  const footer = cfg.showTotal
    ? [{ label: cfg.totalLabel ?? 'Total', column: 1, ...cellOf(points.filter((p) => !p.percent).reduce((s, p) => s + (p.y ?? 0), 0), false, fmt) }]
    : [];
  return {
    title,
    headers: cfg.rowHeader ? [cfg.rowHeader, cfg.valueHeader ?? ''] : [],
    rows: points.map((p) => ({ label: p.seriesName, color: p.color, cells: [cellOf(p.y, p.percent, fmt, pctThresholds)] })),
    footer,
    note: cfg.note,
  };
}

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!);
const td = (c: { text: string; tone?: Tone }) => `<td class="${c.tone ? `ct-${c.tone}` : ''}">${esc(c.text)}</td>`;

/** Highcharts tooltip formatters must return HTML strings; styling lives in shared/ui/Tooltip/tooltip.css. */
export function renderTooltipHtml(m: TooltipModel): string {
  const nCols = Math.max(1, ...m.rows.map((r) => r.cells.length));
  const head = m.headers.length ? `<thead><tr>${m.headers.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead>` : '';
  const body = m.rows
    .map((r) => `<tr><td><span class="ct-label"><i class="ct-sw" style="--sw:${esc(r.color ?? '#98a2b3')}"></i>${esc(r.label)}</span></td>${r.cells.map(td).join('')}</tr>`)
    .join('');
  const foot = m.footer.length
    ? `<tfoot>${m.footer
        .map((f) => `<tr><td>${esc(f.label)}</td>${Array.from({ length: nCols }, (_, i) => (i + 1 === f.column ? td(f) : '<td></td>')).join('')}</tr>`)
        .join('')}</tfoot>`
    : '';
  const note = m.note ? `<div class="ct-foot-note">${esc(m.note)}</div>` : '';
  return `<div class="ct ct-chart"><div class="ct-title">${esc(m.title)}</div><table class="ct-table">${head}<tbody>${body}</tbody>${foot}</table>${note}</div>`;
}
