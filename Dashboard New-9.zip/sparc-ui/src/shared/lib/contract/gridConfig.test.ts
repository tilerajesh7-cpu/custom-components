import { describe, expect, it } from 'vitest';
import { mergeGrid, parseGridConfig, parseGridData, type GridConfig } from './gridConfig';

const cfg: GridConfig = {
  schemaVersion: '2.0',
  gridId: 'g',
  configVersion: '2026.10.1',
  gridMetaData: { title: 'Grid', rowTypes: { GRAND_TOTAL: { bold: true, excludeHeatMap: true, pinned: 'bottom' }, SUB_TOTAL: { bold: true, pinned: 'none' } } },
  columnDefs: [
    { field: 'name', colType: 'StringType' },
    { headerName: 'Monte Carlo', children: [{ field: 'mcCob', colType: 'DoubleType' }] },
    { headerName: 'Historical', children: [{ field: 'histCob', colType: 'DoubleType' }] },
  ],
  columnMetadata: {},
};

describe('mergeGrid', () => {
  it('pins rows by rowType, derives rowMetadata from row fields and hides missing columns', () => {
    const res = mergeGrid(cfg, {
      rowData: [
        { id: 'a', name: 'A', mcCob: 1, status: 'BREACH' },
        { id: 'sub', name: 'AMER Total', mcCob: 3, rowType: 'SUB_TOTAL' },
        { id: 'gt', name: 'Grand Total', mcCob: 4, rowType: 'GRAND_TOTAL' },
      ],
    });
    expect(res.rowData.map((r) => r.id)).toEqual(['a', 'sub']);
    expect(res.pinnedBottomRows.map((r) => r.id)).toEqual(['gt']);
    expect(res.rowMetadata.gt).toEqual({ bold: true, excludeHeatMap: true, rowType: 'GRAND_TOTAL' });
    expect(res.rowMetadata.a).toEqual({ status: 'BREACH' });
    // Display = MC VaR: no row carries histCob → Historical group removed
    expect(res.columnDefs.map((c) => c.headerName ?? c.field)).toEqual(['name', 'Monte Carlo']);
    expect(res.gridMetaData).not.toHaveProperty('rowTypes');
    expect(res.meta?.configVersion).toBe('2026.10.1');
  });

  it('keeps all columns when data is empty', () => {
    expect(mergeGrid(cfg, { rowData: [] }).columnDefs).toHaveLength(3);
  });

  it('validates both responses', () => {
    expect(() => parseGridConfig({ schemaVersion: '2.0', gridId: 'g', columnDefs: [] })).toThrow(/configVersion/);
    expect(() => parseGridData({ rows: [] })).toThrow(/rowData/);
    expect(parseGridData({ rowData: [{ id: 'x' }] }).rowData).toHaveLength(1);
  });
});
