import { z } from 'zod';
import { ContractError, type ColumnMeta, type GridMetaData, type GridResponse, type GridRow, type RowMeta, type RowType, type WireColDef } from './gridResponse';

/*
 * Grid Config / Data split.
 *   GET {endpoint}/config → GridConfig   (cached, versioned; WHAT the grid looks like)
 *   GET {endpoint}/data   → GridData     (rowData only; per filter / selection)
 * mergeGrid() rebuilds the Grid Response v2 shape the rest of the UI already consumes.
 */

export interface RowTypeRule {
  bold?: boolean;
  bgColor?: string;
  excludeHeatMap?: boolean;
  selectable?: boolean;
  /** Where rows of this type render: pinned top / bottom, or in the body ('none'). */
  pinned?: 'top' | 'bottom' | 'none';
}

export interface GridConfigMeta extends GridMetaData {
  /** Styling / behaviour per row type (rows carry their type as a plain field). */
  rowTypes?: Partial<Record<RowType, RowTypeRule>>;
  /** rowMetadata key → rowData field, e.g. { rowType: 'rowType', status: 'status' }. */
  rowMetadataFields?: Record<string, string>;
  /** Hide configured columns that no row carries (e.g. Display = MC VaR drops Hist fields). Default true. */
  hideMissingColumns?: boolean;
}

export interface GridConfig {
  schemaVersion: string;
  gridId: string;
  configVersion: string;
  gridMetaData: GridConfigMeta;
  columnDefs: WireColDef[];
  columnMetadata: Record<string, ColumnMeta>;
}

export interface GridData {
  rowData: GridRow[];
}

const RowSchema = z.object({ id: z.string() }).passthrough();

const ConfigSchema = z
  .object({
    schemaVersion: z.string().refine((v) => v.startsWith('2.'), 'Unsupported schemaVersion (expected 2.x)'),
    gridId: z.string(),
    configVersion: z.string(),
    gridMetaData: z.record(z.unknown()).default({}),
    columnDefs: z.array(z.record(z.unknown())),
    columnMetadata: z.record(z.record(z.unknown())).default({}),
  })
  .passthrough();

const DataSchema = z.object({ rowData: z.array(RowSchema) }).passthrough();

const issues = (e: z.ZodError) => e.issues.map((i) => `${i.path.join('.') || 'response'}: ${i.message}`).join('; ');

export function parseGridConfig(raw: unknown): GridConfig {
  const r = ConfigSchema.safeParse(raw);
  if (!r.success) throw new ContractError(`Grid config: ${issues(r.error)}`);
  return r.data as unknown as GridConfig;
}

export function parseGridData(raw: unknown): GridData {
  const r = DataSchema.safeParse(raw);
  if (!r.success) throw new ContractError(`Grid data: ${issues(r.error)}`);
  return r.data as unknown as GridData;
}

/** UI fallbacks; the config's rowTypes win. */
const DEFAULT_ROW_TYPES: Record<RowType, RowTypeRule> = {
  GRAND_TOTAL: { bold: true, excludeHeatMap: true, selectable: false, pinned: 'bottom' },
  SUB_TOTAL: { bold: true, excludeHeatMap: true, selectable: false, pinned: 'none' },
};
const DEFAULT_META_FIELDS = { rowType: 'rowType', status: 'status' };

function pruneColumns(defs: WireColDef[], keep: (field: string) => boolean): WireColDef[] {
  return defs.flatMap((d) => {
    if (d.children?.length) {
      const children = pruneColumns(d.children, keep);
      return children.length ? [{ ...d, children }] : [];
    }
    return !d.field || keep(d.field) ? [d] : [];
  });
}

export function mergeGrid(cfg: GridConfig, data: GridData): GridResponse {
  const { rowTypes, rowMetadataFields, hideMissingColumns, ...gridMetaData } = cfg.gridMetaData;
  const rules: Partial<Record<RowType, RowTypeRule>> = { ...DEFAULT_ROW_TYPES, ...rowTypes };
  const fields = rowMetadataFields ?? DEFAULT_META_FIELDS;

  const rowMetadata: Record<string, RowMeta> = {};
  const top: GridRow[] = [];
  const body: GridRow[] = [];
  const bottom: GridRow[] = [];
  const present = new Set<string>();

  for (const r of data.rowData) {
    Object.keys(r).forEach((k) => present.add(k));
    const derived: Record<string, unknown> = {};
    for (const [metaKey, field] of Object.entries(fields)) {
      const v = r[field];
      if (v != null && v !== '') derived[metaKey] = v;
    }
    const rule = typeof derived.rowType === 'string' ? rules[derived.rowType as RowType] : undefined;
    const { pinned, ...ruleMeta } = rule ?? {};
    const meta = { ...ruleMeta, ...derived } as RowMeta;
    if (Object.keys(meta).length) rowMetadata[r.id] = meta;
    (pinned === 'top' ? top : pinned === 'bottom' ? bottom : body).push(r);
  }

  const columnDefs = hideMissingColumns !== false && data.rowData.length ? pruneColumns(cfg.columnDefs, (f) => present.has(f)) : cfg.columnDefs;

  return {
    schemaVersion: cfg.schemaVersion,
    gridId: cfg.gridId,
    meta: { configVersion: cfg.configVersion },
    gridMetaData,
    columnDefs,
    columnMetadata: cfg.columnMetadata,
    rowData: body,
    rowMetadata,
    cellMetadata: {},
    pinnedTopRows: top,
    pinnedBottomRows: bottom,
  };
}
