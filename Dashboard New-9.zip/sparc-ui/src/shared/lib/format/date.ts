const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const parts = (iso: string) => {
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return { y, m, d };
};

export const isIsoDate = (v: unknown): v is string => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}/.test(v);

/** "2026-09-11" → "Sep 11" */
export const fmtShortDate = (iso: string) => {
  const { m, d } = parts(iso);
  return `${MON[m - 1]} ${d}`;
};

/** "2026-09-11" → "Sep 11, 2026" */
export const fmtLongDate = (iso: string) => {
  const { y, m, d } = parts(iso);
  return `${MON[m - 1]} ${d}, ${y}`;
};

/** "2026-09-11" → "11-Sep-2026" */
export const fmtDisplayDate = (iso: string) => {
  const { y, m, d } = parts(iso);
  return `${String(d).padStart(2, '0')}-${MON[m - 1]}-${y}`;
};

const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** "2026-08-31" → "Mon, Aug 31, 2026" (chart tooltip header) */
export const fmtWeekdayDate = (iso: string) => {
  const { y, m, d } = parts(iso);
  return `${WD[new Date(Date.UTC(y, m - 1, d)).getUTCDay()]}, ${MON[m - 1]} ${d}, ${y}`;
};

export const addMonthsIso = (iso: string, months: number) => {
  const { y, m, d } = parts(iso);
  const last = new Date(Date.UTC(y, m - 1 + months + 1, 0)).getUTCDate();
  return new Date(Date.UTC(y, m - 1 + months, Math.min(d, last))).toISOString().slice(0, 10);
};

/** Skips Sat/Sun (holiday calendars belong to services). */
export const addBusinessDaysIso = (iso: string, n: number) => {
  const { y, m, d } = parts(iso);
  const t = new Date(Date.UTC(y, m - 1, d));
  const step = n < 0 ? -1 : 1;
  for (let left = Math.abs(n); left > 0; ) {
    t.setUTCDate(t.getUTCDate() + step);
    const wd = t.getUTCDay();
    if (wd !== 0 && wd !== 6) left -= 1;
  }
  return t.toISOString().slice(0, 10);
};

export const addDaysIso = (iso: string, days: number) => {
  const { y, m, d } = parts(iso);
  const t = new Date(Date.UTC(y, m - 1, d + days));
  return t.toISOString().slice(0, 10);
};
