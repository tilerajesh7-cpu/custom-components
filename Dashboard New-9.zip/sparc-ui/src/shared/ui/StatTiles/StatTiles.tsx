import type { ReactNode } from 'react';
import styles from './StatTiles.module.css';

export interface StatTile {
  label: string;
  value: string;
  note?: string;
  tone?: 'neutral' | 'warning' | 'negative';
}

export function StatTiles({ tiles }: { tiles: StatTile[] }) {
  return (
    <div className={styles.grid}>
      {tiles.map((t) => (
        <div key={t.label} className={styles.tile}>
          <span className={styles.label}>{t.label}</span>
          <span className={styles.value}>{t.value}</span>
          {t.note ? (
            <span className={styles.note} data-tone={t.tone ?? 'neutral'}>
              {t.note}
            </span>
          ) : null}
        </div>
      ))}
    </div>
  );
}

export function SectionHeading({ title, subtitle, variant = 'heading', actions }: { title: string; subtitle?: string; variant?: 'heading' | 'kicker'; actions?: ReactNode }) {
  if (variant === 'kicker') return <h3 className={styles.kicker}>{title}</h3>;
  return (
    <div className={styles.heading}>
      <span className={styles.bar} />
      <h2 className={styles.hTitle}>{title}</h2>
      {subtitle ? <span className={styles.hSub}>{subtitle}</span> : null}
      {actions ? <span className={styles.hActions}>{actions}</span> : null}
    </div>
  );
}
