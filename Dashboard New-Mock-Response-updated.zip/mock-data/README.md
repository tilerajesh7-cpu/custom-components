# Initial mock data — VaR Summary + Greek Dashboard

These files are the responses for the **first page load only**, with default filters and no user selection. Each response follows Grid Response Contract v2. `rowData` is the only block moved into a separate data response, and no `meta` block is included.

```
app/sidebar-menu.json                      GET /app/sidebar-menu
{dashboard}/dashboard-definition.json      GET /dashboards/{id}/definition
{dashboard}/filters.json                   GET /dashboards/{id}/filters
{dashboard}/chart-config.json              GET /dashboards/{id}/chart-config
{dashboard}/grid-config/{gridId}.json      GET /grids/{gridId}/config?{params}   (v2 without rowData)
{dashboard}/grid-data/{gridId}.json        GET /grids/{gridId}/data?{params}     ({ rowData } only)
```

**Grid config** contains these blocks: `schemaVersion`, `gridId`, `gridMetaData`, `columnDefs`, `columnMetadata`, `rowMetadata`, `cellMetadata`, `pinnedTopRows` and `pinnedBottomRows`.

**Grid data** contains only `{ "rowData": [...] }`, with plain values and no rowType or status fields.

## Initial state

**VaR Summary**
- Filters are at their defaults: COB 11-Sep-2026, Custom, Region All, 1DAY, Trading, Display Both, 30 days.
- No Standalone row is selected, so widgets 2–6 load the `all` data.
- The Limits grid has its first row selected on the UI side (`lim_504875`). `grid-data/limit-history.json` holds the data for that limit.

**Greek Dashboard** (the old Mock 4): COB 11-Sep-2026.

Charts have no data files of their own. Each chart is built from its widget's grid config plus grid data, together with `chart-config.json`.
