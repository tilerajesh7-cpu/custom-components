# Handoff: Widget Platform — Phase 1 (Sprints 0–3)

## Overview
A backend-driven, widget-based dashboard platform (React 19 + TypeScript + Vite 7, AG Grid Enterprise, Highcharts, Redux Toolkit, TanStack Query). Every panel is a widget described by JSON from services; grids receive AG Grid-ready rows, charts reuse the same rows via a generic encoding. Phase 1 runs entirely on **mock data** that follows the response contracts.

## What's in this folder
| Path | What it is |
|---|---|
| `reference/Widget-Platform-Plan.html` | The architecture plan (v0.9) — contracts, component rules, mock plan, sprint plan. **Source of truth.** Open offline. |
| `reference/VaR-Dashboard-prototype.html` | The **high-fidelity** HTML prototype — the target look and behaviour. Open offline. |
| `starter/` | Starter codebase for Sprints 0–3: npm workspaces, contracts, tokens, widget packages, app, mocks. |
| `SPRINTS.md` | What the starter already implements per sprint, and the remaining tickets with acceptance criteria. |

## About the design files
The two HTML files are **design references**, not production code. Recreate them in the starter codebase using its patterns (widgets, contracts, registries). Fidelity is **high**: match colours, type, spacing, radii, shadows and interactions of the prototype. All tokens are in `starter/packages/widget-tokens/src/tokens.css`.

## Status of the starter — read this first
- The code was **written, not executed**: it has not been installed, type-checked or run. Expect a first pass of small fixes (import paths, AG Grid / Highcharts API names for the exact versions you install).
- Versions assumed: AG Grid ≥ 33 (Theming API, `rowSelection` object, `cellSelection`), Highcharts 12 (side-effect module imports), React Router 7, MSW 2, zod 3.
- Everything domain-specific is generic (`dataset-1`, `widget-3`, `g1Current`, `Item 1`). Real names arrive as display text from services.

## Quick start
```bash
cd starter
npm install
npx msw init apps/dashboards-app/public --save        # one-off: MSW service worker
echo "VITE_AG_GRID_LICENSE=<your key>" > apps/dashboards-app/.env.local
npm start                                              # http://localhost:4000/#/dashboards/dashboard-1
```
Mock scenarios: append `?scenario=slow|error|empty|stale|forbidden|newBatch` (and `&ds=dataset-3` to target one dataset), e.g. `http://localhost:4000/#/dashboards/dashboard-1?scenario=slow`.

## Architecture in one screen
```
starter/
  apps/dashboards-app/src/
    app/        store (RTK + redux-persist), router (hash), providers
    pages/      DashboardPage
    features/dashboard/   api (TanStack Query) · model (filters, selection, preferences) · components (FilterBar, DashboardRenderer)
    shared/ui/  UI adapter — only place allowed to import Radix / Lucide (swap to ICGDS 7 later)
    layouts/    AppShell (navy sidebar)
    mocks/      world (seeded) · generators (6 datasets + dashboard) · handlers (MSW) · browser
  packages/
    widget-contracts/  zod schemas = the contract (ColDef subset, datasets, widgets, dashboard)
    widget-tokens/     CSS tokens · AG Grid theme · Highcharts theme · tones
    widget-core/       WidgetFrame (states + spinner) · registry · formats · rule compiler · KPI
    widget-grid/       GridWidget (passthrough) · column types · style/renderer rules · renderers · tooltip
    widget-charts/     ChartWidget · presets · encoding mapper
```
Rules (enforced by `eslint.config.js`): only `widget-grid` imports AG Grid; only `widget-charts` imports Highcharts; features talk through `index.ts`; mocks load only in dev; datasets never go into Redux.

## Key contracts (see plan §5–6)
- **Grid dataset**: `rowData`, `columnDefs` (allowed AG Grid subset + `styleRules`, `rendererRules`), `pinnedBottomRowData`, `gridOptions`, per-row `_meta` (row tone, badges, per-cell tone/flag/note).
- **Series dataset**: `rowData` keyed by `date` + `seriesDefs` (name, palette index, dash, stack).
- **Widget config**: `grid` · `chart` (preset + encoding) · `kpi` · `summary`, with `interactions.emits/listens` for cross-filtering.
- **Tones**: positive, negative, warn, breach, info, muted, highlight → classes in `tokens.css`. Services never send colours.

## Design tokens (from the prototype)
Navy `#1a2b5c → #101c40` · primary `#5b86f5 → #2f5fd6` · risk up `#c2392f` · warn `#d08a0e` · risk down `#16895a` · ink `#101828 / #344054 / #667085` · lines `#e4e8f0 / #eef1f6` · card radius 16, controls 10–12, chips 999 · card shadow `0 1px 2px rgba(16,24,40,.04), 0 8px 24px -8px rgba(16,24,40,.10)` · fonts IBM Plex Sans / IBM Plex Mono · density row heights 34 / 40 / 48 px.
