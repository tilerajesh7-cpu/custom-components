# Sprints 0–3 — status and tickets

Legend: ✅ in the starter (written, not yet run) · ⬜ to build

## Sprint 0 — setup · exit: a dashboard renders from the mock bootstrap
- ✅ npm workspaces, `tsconfig.base.json`, project references
- ✅ ESLint boundaries + vendor/UI-library import restrictions (`eslint.config.js`)
- ✅ Tokens: CSS variables, density scale, tone classes; AG Grid theme; Highcharts theme
- ✅ Contracts v1 in zod: ColDef subset, grid/series datasets, widgets, dashboard, events
- ✅ Mock world (seeded), 6 dataset generators, dashboard generator, MSW handlers, scenarios
- ✅ App shell (navy sidebar), hash router, RTK store + redux-persist, TanStack Query
- ⬜ First install / type-check pass; fix API names for installed AG Grid / Highcharts versions
- ⬜ `npx msw init` committed; `.env.example` with `VITE_AG_GRID_LICENSE`
- ⬜ Storybook 8 setup with tokens loaded; size-limit config; CI (lint, typecheck, test, contracts:check)
- ⬜ `contracts:export` script (zod → JSON Schema + OpenAPI + fixture snapshots) — **AC:** writes `/handoff` with one file per endpoint and scenario

## Sprint 1 — grid · exit: summary, breakdown and threshold grids on mocks
- ✅ WidgetFrame: header, “Filtered by” badge, states (loading shimmer + dual-ring spinner, refreshing, empty, error + retry, forbidden)
- ✅ GridWidget passthrough: column types, tones from type defaults / `styleRules` / `_meta`, `rendererRules`, row tone, external filter for client filters + selections, row selection → cross-filter, change flash, column state
- ✅ Renderers: labelCell (+ σ badges), smartCell (bar + previous tick + change chip), thresholdCell, totalCell, emptyCell; detailTooltip (sections from params); money value tooltip
- ✅ DashboardRenderer (flex rows from layout), WidgetHost (status mapping, subtitle placeholders), FilterBar (one-click segmented filters) + cross-filter strip
- ⬜ Grid toolbar: search box (`quickFilterText`), Smart | Table toggle (`presentation.cellMode`), Columns panel + group chips (column API) — **AC:** matches prototype; choices saved to preferences
- ⬜ Unit tests: `compileCondition`, `resolveColumnDefs`, `buildGridOptions`; Storybook story per grid state

## Sprint 2 — charts · exit: the whole reference screen matches the prototype
- ✅ ChartWidget + presets: line, column, column.stacked, column.reference, bar.diverging; encoding mapper (arrays + keys); 30/60/90 range selector; zone colouring vs threshold
- ✅ KPI widget (totals row, change, sparkline from a series dataset)
- ✅ Selection-driven dataset (dataset-6 loads when a threshold row is selected)
- ⬜ Summary widget (“Daily brief”) + rules registry (`largestChange`, `highestRatio`, `anomalyCount`) — **AC:** each item applies a cross-filter
- ⬜ Chart interactions: legend click → filter (FS-type style), point click → selection, shared crosshair tooltip styled as prototype
- ⬜ Exposure chart extras: stat tiles (current, peak, days in excess), excess dots
- ⬜ Visual check against `reference/VaR-Dashboard-prototype.html` for every widget

## Sprint 3 — workflow · exit: all user features in plan Table 22
- ⬜ Saved views (feature `saved-views`): built-in + personal, save dialog, manage list, default ★, share link, 1–9 shortcuts; persisted via `PUT /users/me/dashboards/{id}`
- ⬜ Export menu per widget: CSV, copy for Excel, JSON, Excel (AG Grid Enterprise, tones → `excelStyles`); chart PNG / SVG (Highcharts exporting)
- ⬜ Live refresh (feature `live-refresh`): poll `/api/batches/latest`, countdown ring, interval picker, ask-first banner vs auto-apply, hold while tooltip/menu open, pause when tab hidden, row flash on apply
- ⬜ Command palette (⌘K, cmdk), keyboard shortcuts (J/K, C, M, D, R, S, E, /, Esc, ?), help dialog
- ⬜ Display settings (gear): density compact / comfortable / spacious → `data-density`
- ⬜ Navigation endpoint (`GET /me/navigation`) feeding the sidebar

## Definition of done (every widget)
Storybook story per state · unit tests for mapping and rules · visual baseline · keyboard + screen-reader check · no field names or vendor imports outside its package · meets its render budget.
