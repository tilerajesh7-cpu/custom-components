import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { RouterProvider, createHashRouter, Navigate } from 'react-router-dom';
import { store, persistor } from './store';
import { AppShell } from '../layouts/AppShell';
import DashboardPage from '../pages/DashboardPage';

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 60_000, gcTime: 10 * 60_000, refetchOnWindowFocus: false, retry: 1 } },
});

const router = createHashRouter([
  { path: '/', element: <AppShell />, children: [
    { index: true, element: <Navigate to="/dashboards/dashboard-1" replace /> },
    { path: 'dashboards/:dashboardId', element: <DashboardPage /> },
  ] },
]);

export function App() {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <QueryClientProvider client={queryClient}>
          <RouterProvider router={router} />
        </QueryClientProvider>
      </PersistGate>
    </Provider>
  );
}
