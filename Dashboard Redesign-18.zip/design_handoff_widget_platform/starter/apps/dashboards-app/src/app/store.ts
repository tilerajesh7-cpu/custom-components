import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { persistReducer, persistStore, FLUSH, PAUSE, PERSIST, PURGE, REGISTER, REHYDRATE } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import { filtersReducer, selectionReducer, preferencesReducer } from '../features/dashboard';

const rootReducer = combineReducers({
  filters: filtersReducer,
  selection: selectionReducer,
  preferences: persistReducer({ key: 'preferences', storage }, preferencesReducer), // only local prefs persist
});

export const store = configureStore({
  reducer: rootReducer,
  middleware: (gdm) => gdm({ serializableCheck: { ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER] } }),
});
export const persistor = persistStore(store);
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
