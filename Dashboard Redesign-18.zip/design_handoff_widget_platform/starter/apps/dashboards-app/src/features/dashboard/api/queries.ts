import { useQueries, useQuery, keepPreviousData } from '@tanstack/react-query';
import { Dashboard, Dataset, type DatasetRef, type SelectionState } from '@widgets/contracts';
import { resolveParams } from '../lib/resolveParams';

const API = '/api';

async function getJson<T>(url: string, parse: (x: unknown) => T): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw Object.assign(new Error(`${res.status} ${url}`), { status: res.status });
  return parse(await res.json());          // runtime contract check (zod)
}

export function useDashboard(dashboardId: string) {
  return useQuery({
    queryKey: ['dashboard', dashboardId],
    queryFn: () => getJson(`${API}/dashboards/${dashboardId}`, (x) => Dashboard.parse(x)),
    staleTime: Infinity,
  });
}

/**
 * One query per dataset so each widget paints as its data lands (same effect as the streamed bootstrap).
 * Server-scope params come from filters; onSelection datasets wait for a selection.
 */
export function useDatasets(refs: DatasetRef[] | undefined, filters: Record<string, string>, selection: SelectionState) {
  const list = refs ?? [];
  const results = useQueries({
    queries: list.map((ref) => {
      const params = resolveParams(ref.params, filters, selection);
      const qs = params ? new URLSearchParams(params).toString() : '';
      return {
        queryKey: ['dataset', ref.datasetId, qs],
        queryFn: () => getJson(`${API}/datasets/${ref.datasetId}?${qs}`, (x) => Dataset.parse(x)),
        enabled: params !== null,
        placeholderData: keepPreviousData,        // keep old data visible while a server filter reloads
      };
    }),
  });
  return Object.fromEntries(list.map((ref, i) => [ref.datasetId, results[i]!]));
}
