import { useCallback, useMemo } from 'react';
import type { UseQueryResult } from '@tanstack/react-query';
import type { Dashboard, Dataset, WidgetConfig, WidgetEvent, WidgetStatus } from '@widgets/contracts';
import { WidgetFrame, getWidgetComponent } from '@widgets/core';
import { useAppDispatch, useAppSelector } from '../../../app/hooks';
import { clearSelection, setSelection } from '../model/slices';

type DatasetResults = Record<string, UseQueryResult<Dataset>>;

function statusOf(q: UseQueryResult<Dataset> | undefined, needsSelection: boolean): WidgetStatus {
  if (!q) return 'error';
  if (needsSelection && q.fetchStatus === 'idle' && !q.data) return 'empty';
  if (q.isError) return (q.error as { status?: number }).status === 403 ? 'forbidden' : 'error';
  if (q.isPending) return 'loading';
  if (q.isFetching) return 'refreshing';
  return q.data && q.data.rowData.length === 0 ? 'empty' : 'ready';
}

function WidgetHost({ widget, dashboard, datasets }: { widget: WidgetConfig; dashboard: Dashboard; datasets: DatasetResults }) {
  const dispatch = useAppDispatch();
  const selection = useAppSelector((s) => s.selection.byWidget);
  const filters = useAppSelector((s) => s.filters.values);
  const datasetId = 'datasetId' in widget ? widget.datasetId : undefined;
  const q = datasetId ? datasets[datasetId] : undefined;
  const ref = dashboard.datasets.find((d) => d.datasetId === datasetId);
  const status = widget.type === 'summary' ? 'ready' : statusOf(q, ref?.load === 'onSelection');
  const Component = getWidgetComponent(widget.type);

  const clientFilters = useMemo(() => Object.fromEntries(
    dashboard.filters.filter((f) => f.scope === 'client' && f.field).map((f) => [f.field!, filters[f.filterId] ?? 'all'])), [dashboard.filters, filters]);
  const related = useMemo(() => Object.fromEntries(Object.entries(datasets).map(([k, v]) => [k, v.data])), [datasets]);
  const onEvent = useCallback((e: WidgetEvent) => { if (e.kind === 'selection') dispatch(setSelection({ widgetId: e.widgetId, keys: e.keys })); }, [dispatch]);

  const filteredBy = (widget.interactions?.listens ?? []).filter((l) => selection[l.from]?.length).map((l) => `${l.field} ${selection[l.from]!.join(', ')}`);
  const subtitle = widget.subtitle?.replace(/\{filter\.(\w+)\}/g, (_, id: string) => filters[id] ?? '');
  const emptyText = ref?.load === 'onSelection' ? 'Select a row to see its history' : widget.states?.empty;

  if (widget.type === 'kpi') {
    return <WidgetFrame title="" status={status} style={{ height: '100%' }}>{Component && <Component config={widget as never} dataset={q?.data} related={related} status={status} selection={selection} clientFilters={clientFilters} onEvent={onEvent} />}</WidgetFrame>;
  }
  return (
    <WidgetFrame title={widget.title} subtitle={subtitle} status={status} emptyText={emptyText} filteredBy={filteredBy}
      onClearFilter={() => (widget.interactions?.listens ?? []).forEach((l) => dispatch(clearSelection(l.from)))}
      onRetry={() => void q?.refetch()} loadingLabel="Updating" style={{ height: '100%' }}>
      {Component
        ? <Component config={widget as never} dataset={q?.data} related={related} status={status} selection={selection} clientFilters={clientFilters} onEvent={onEvent} />
        : <div className="wf-state">Unknown widget type “{widget.type}”</div>}
    </WidgetFrame>
  );
}

/** Renders backend flex rows (plan §8.4). Widgets size only from their slot. */
export function DashboardRenderer({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const byId = useMemo(() => new Map(dashboard.widgets.map((w) => [w.widgetId, w])), [dashboard.widgets]);
  return (
    <div className="dash" style={{ display: 'flex', flexDirection: 'column', gap: dashboard.layout.gap }}>
      {dashboard.layout.rows.map((row, i) => (
        <div key={i} style={{ display: 'flex', flexWrap: 'wrap', gap: dashboard.layout.gap, alignItems: 'stretch' }}>
          {row.items.map((it) => {
            const w = byId.get(it.widgetId);
            return w ? (
              <div key={it.widgetId} style={{ flex: `${it.grow} 1 ${it.basis}px`, minWidth: it.minW ?? 0, minHeight: it.minH, display: 'flex', flexDirection: 'column' }}>
                <WidgetHost widget={w} dashboard={dashboard} datasets={datasets} />
              </div>
            ) : null;
          })}
        </div>
      ))}
    </div>
  );
}
