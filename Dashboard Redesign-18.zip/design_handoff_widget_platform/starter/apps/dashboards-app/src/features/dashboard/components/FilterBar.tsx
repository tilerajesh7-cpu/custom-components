import type { Dashboard } from '@widgets/contracts';
import { SegmentedControl } from '../../../shared/ui';
import { useAppDispatch, useAppSelector } from '../../../app/hooks';
import { clearAllSelections, clearSelection, setFilter } from '../model/slices';
import './filter-bar.css';

/** Navy filter bar + cross-filter strip (prototype). One click per change. */
export function FilterBar({ dashboard }: { dashboard: Dashboard }) {
  const dispatch = useAppDispatch();
  const values = useAppSelector((s) => s.filters.values);
  const selection = useAppSelector((s) => s.selection.byWidget);
  const chips = Object.entries(selection);
  const segmented = dashboard.filters.filter((f) => f.control === 'segmented');
  const date = dashboard.filters.find((f) => f.control === 'date');

  return (
    <div className="fb-sticky">
      <header className="fb-head">
        <div>
          <div className="fb-crumb">{dashboard.breadcrumb?.join(' / ')}</div>
          <h1 className="fb-title">{dashboard.title}</h1>
        </div>
        {date && (
          <label className="fb-date">As of
            <input type="date" value={values[date.filterId] ?? ''} onChange={(e) => dispatch(setFilter({ id: date.filterId, value: e.target.value }))} />
          </label>
        )}
      </header>
      <div className="fb-bar">
        {segmented.map((f) => (
          <SegmentedControl key={f.filterId} label={f.label} value={values[f.filterId] ?? f.default} options={f.options ?? []}
            onChange={(v) => dispatch(setFilter({ id: f.filterId, value: v }))} />
        ))}
      </div>
      <div className="fb-cross">
        <span className="fb-cross-label">CROSS-FILTERS <b>{chips.length}</b></span>
        {chips.length === 0 && <span className="fb-cross-hint">Click a row or bar to filter related panels</span>}
        {chips.map(([wid, keys]) => (
          <span key={wid} className="fb-chip">
            <span className="fb-chip-kind">{dashboard.widgets.find((w) => w.widgetId === wid)?.title ?? wid}</span>
            <b>{keys.join(', ')}</b>
            <button type="button" aria-label="Remove" onClick={() => dispatch(clearSelection(wid))}>×</button>
          </span>
        ))}
        {chips.length > 0 && <button type="button" className="fb-clear" onClick={() => dispatch(clearAllSelections())}>Clear all</button>}
      </div>
    </div>
  );
}
