import { registerWidgetType, KpiWidget } from '@widgets/core';
import { GridWidget } from '@widgets/grid';
import { ChartWidget } from '@widgets/charts';
import { filtersSlice, preferencesSlice, selectionSlice } from './model/slices';

/** Widget registry wiring — the only place that maps type → component. */
registerWidgetType('grid', GridWidget);
registerWidgetType('chart', ChartWidget);
registerWidgetType('kpi', KpiWidget);

export { DashboardRenderer } from './components/DashboardRenderer';
export { FilterBar } from './components/FilterBar';
export { useDashboard, useDatasets } from './api/queries';
export { initFilters, setFilter, applyView, setSelection, clearAllSelections, setDensity } from './model/slices';
export const filtersReducer = filtersSlice.reducer;
export const selectionReducer = selectionSlice.reducer;
export const preferencesReducer = preferencesSlice.reducer;
