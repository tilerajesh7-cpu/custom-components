import type { SelectionState } from '@widgets/contracts';

/** Resolve "$filter.x" / "$selection.widget-n" bindings. Returns null when a required selection is missing. */
export function resolveParams(params: Record<string, string | number>, filters: Record<string, string>, selection: SelectionState): Record<string, string> | null {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(params)) {
    if (typeof v === 'string' && v.startsWith('$filter.')) out[k] = filters[v.slice(8)] ?? '';
    else if (typeof v === 'string' && v.startsWith('$selection.')) {
      const sel = selection[v.slice(11)]?.[0];
      if (!sel) return null;
      out[k] = sel;
    } else out[k] = String(v);
  }
  return out;
}
