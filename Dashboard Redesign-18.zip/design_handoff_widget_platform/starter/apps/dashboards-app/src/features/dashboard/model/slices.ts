import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { SelectionState } from '@widgets/contracts';

/** Global filter values (server + client scope). Defaults come from the dashboard definition. */
export const filtersSlice = createSlice({
  name: 'filters',
  initialState: { values: {} as Record<string, string> },
  reducers: {
    initFilters: (s, a: PayloadAction<Record<string, string>>) => { s.values = { ...a.payload, ...s.values }; },
    setFilter: (s, a: PayloadAction<{ id: string; value: string }>) => { s.values[a.payload.id] = a.payload.value; },
    applyView: (s, a: PayloadAction<Record<string, string>>) => { s.values = { ...s.values, ...a.payload }; },
  },
});

/** Cross-filter selections: widgetId → selected row keys. */
export const selectionSlice = createSlice({
  name: 'selection',
  initialState: { byWidget: {} as SelectionState },
  reducers: {
    setSelection: (s, a: PayloadAction<{ widgetId: string; keys: string[] }>) => {
      if (a.payload.keys.length) s.byWidget[a.payload.widgetId] = a.payload.keys; else delete s.byWidget[a.payload.widgetId];
    },
    clearSelection: (s, a: PayloadAction<string>) => { delete s.byWidget[a.payload]; },
    clearAllSelections: (s) => { s.byWidget = {}; },
  },
});

/** Local preferences (persisted with redux-persist). Saved views go to services in Sprint 3. */
export const preferencesSlice = createSlice({
  name: 'preferences',
  initialState: { density: 'compact' as 'compact' | 'comfortable' | 'spacious', sidebarOpen: true },
  reducers: {
    setDensity: (s, a: PayloadAction<'compact' | 'comfortable' | 'spacious'>) => { s.density = a.payload; },
  },
});

export const { initFilters, setFilter, applyView } = filtersSlice.actions;
export const { setSelection, clearSelection, clearAllSelections } = selectionSlice.actions;
export const { setDensity } = preferencesSlice.actions;
