import { Outlet, NavLink } from 'react-router-dom';
import { LayoutDashboard, ChevronsLeft, ChevronsRight } from '../shared/ui';
import { useState } from 'react';
import './app-shell.css';

/** App shell: navy sidebar + content outlet. Navigation items come from GET /me/navigation in Sprint 3. */
export function AppShell() {
  const [open, setOpen] = useState(true);
  return (
    <div className="shell">
      <aside className="side" style={{ width: open ? 248 : 64 }}>
        <div className="side-brand"><span className="side-logo">RA</span>{open && <b>Risk Analytics</b>}</div>
        <nav className="side-nav">
          <NavLink to="/dashboards/dashboard-1" className={({ isActive }) => 'side-item' + (isActive ? ' is-active' : '')}>
            <span className="side-ico"><LayoutDashboard size={15} /></span>{open && 'Summary'}
          </NavLink>
        </nav>
        <button type="button" className="side-toggle" onClick={() => setOpen(!open)} aria-label="Toggle sidebar">
          {open ? <ChevronsLeft size={15} /> : <ChevronsRight size={15} />}{open && 'Collapse'}
        </button>
      </aside>
      <main className="content"><Outlet /></main>
    </div>
  );
}
