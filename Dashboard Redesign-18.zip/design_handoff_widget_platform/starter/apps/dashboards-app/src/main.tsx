import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { setupAgGrid } from '@widgets/grid';
import { applyHighchartsTheme } from '@widgets/tokens';
import { App } from './app/App';
import './app/global.css';

async function start() {
  setupAgGrid(import.meta.env.VITE_AG_GRID_LICENSE as string | undefined);
  applyHighchartsTheme();
  // Mocks load only in dev / mock mode, via guarded dynamic import (plan §3.2).
  if (import.meta.env.DEV || import.meta.env.MODE === 'mock') {
    const { startMocks } = await import('./mocks/browser');
    await startMocks();
  }
  createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
}
void start();
