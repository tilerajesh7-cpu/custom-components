import type { Dashboard } from '@widgets/contracts';

const seg = (id: string, label: string, def: string, opts: [string, string][], scope: 'server' | 'client' = 'server', field?: string) =>
  ({ filterId: id, label, control: 'segmented' as const, default: def, scope, field, options: opts.map(([value, l]) => ({ value, label: l })) });

/** Reference dashboard — mirrors the HTML prototype layout with generic names. */
export function buildDashboard(): Dashboard {
  const P = { asOf: '$filter.asOfDate', compare: '$filter.compareTo', scenario: '$filter.scenario', measure: '$filter.measure', horizon: '$filter.horizon', attribute: '$filter.attribute' };
  return {
    schemaVersion: '1.0', dashboardId: 'dashboard-1', version: 1, title: 'Summary', breadcrumb: ['Section', 'Area', 'Summary'],
    filters: [
      { filterId: 'asOfDate', label: 'As of', control: 'date', default: '2026-09-11', scope: 'server' },
      seg('compareTo', 'Compare', '1D', [['1D', '1D'], ['1W', '1W'], ['1M', '1M']]),
      seg('segment', 'Segment', 'all', [['all', 'All'], ['A', 'A'], ['B', 'B'], ['C', 'C'], ['D', 'D'], ['E', 'E']], 'client', 'category'),
      seg('horizon', 'Horizon', '1D', [['1D', '1D'], ['10D', '10D']]),
      seg('scenario', 'Model', 'm1', [['m1', 'Model 1'], ['m2', 'Model 2'], ['both', 'Both']]),
      seg('attribute', 'Attribute', 'a1', [['a1', 'Attr 1'], ['a2', 'Attr 2'], ['a3', 'Attr 3']]),
      seg('measure', 'Measure', 'both', [['a', 'A'], ['b', 'B'], ['both', 'Both']]),
    ],
    datasets: [
      { datasetId: 'dataset-1', kind: 'grid', params: P, load: 'bootstrap' },
      { datasetId: 'dataset-2', kind: 'series', params: { ...P, days: 90 }, load: 'bootstrap' },
      { datasetId: 'dataset-3', kind: 'grid', params: P, load: 'bootstrap' },
      { datasetId: 'dataset-4', kind: 'series', params: { ...P, days: 90 }, load: 'bootstrap' },
      { datasetId: 'dataset-5', kind: 'grid', params: { asOf: '$filter.asOfDate' }, load: 'bootstrap' },
      { datasetId: 'dataset-6', kind: 'series', params: { asOf: '$filter.asOfDate', rowId: '$selection.widget-8' }, load: 'onSelection' },
    ],
    widgets: [
      { widgetId: 'widget-1', type: 'kpi', configVersion: 1, title: 'Total · first group', datasetId: 'dataset-1', row: 'pinnedBottom', value: 'g1Current', compare: 'g1Previous', tone: 'higherIsWorse', spark: 'dataset-2:s1', subtitle: 'vs previous · $MM' },
      { widgetId: 'widget-2', type: 'kpi', configVersion: 1, title: 'Threshold exposure', datasetId: 'dataset-5', row: 'pinnedBottom', value: 'exposure', compare: 'previous', tone: 'higherIsWorse', subtitle: 'all thresholds · $MM' },
      { widgetId: 'widget-3', type: 'grid', configVersion: 1, title: 'Summary by item', subtitle: '$MM · {filter.compareTo}', datasetId: 'dataset-1',
        interactions: { emits: [{ on: 'rowClick', selection: 'rowKey' }] }, actions: ['export.excel', 'export.csv', 'inspect'],
        presentation: { cellMode: 'smart', features: { search: true, columnsPanel: true, rowFlash: true } } },
      { widgetId: 'widget-4', type: 'chart', configVersion: 1, title: 'Trend', subtitle: '$MM · business days', preset: 'line', datasetId: 'dataset-2',
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { ranges: [30, 60, 90], sharedTooltip: true } },
      { widgetId: 'widget-5', type: 'chart', configVersion: 1, title: 'Top changes', subtitle: 'largest moves vs previous', preset: 'bar.diverging', datasetId: 'dataset-1',
        encoding: { x: 'label', y: ['g1Change'], sort: 'abs.desc', limit: 6 } },
      { widgetId: 'widget-6', type: 'grid', configVersion: 1, title: 'Breakdown by type', subtitle: '$MM', datasetId: 'dataset-3', presentation: { cellMode: 'smart' } },
      { widgetId: 'widget-7', type: 'chart', configVersion: 1, title: 'Breakdown over time', subtitle: 'top 6 types + other · $MM', preset: 'column.stacked', datasetId: 'dataset-4',
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { ranges: [30, 60, 90] } },
      { widgetId: 'widget-8', type: 'grid', configVersion: 1, title: 'Thresholds', subtitle: 'sorted by utilisation · click a row', datasetId: 'dataset-5',
        interactions: { emits: [{ on: 'rowClick', selection: 'rowKey' }] } },
      { widgetId: 'widget-9', type: 'chart', configVersion: 1, title: 'Value vs threshold', subtitle: '90 business days', preset: 'column.reference', datasetId: 'dataset-6',
        encoding: { x: 'date', y: ['value'], reference: [{ field: 'threshold', label: 'Threshold' }, { field: 'threshold', scale: 0.8, style: 'dashed', label: '80%' }], zones: { ratioOf: 'threshold', steps: [[0.8, 'warn'], [1, 'breach']] } } },
    ],
    layout: { type: 'flex', gap: 16, rows: [
      { items: [{ widgetId: 'widget-1', basis: 260, grow: 1 }, { widgetId: 'widget-2', basis: 260, grow: 1 }] },
      { items: [{ widgetId: 'widget-3', basis: 620, grow: 7, minW: 480, minH: 520 }, { widgetId: 'widget-4', basis: 360, grow: 5, minW: 320, minH: 520 }] },
      { items: [{ widgetId: 'widget-6', basis: 520, grow: 6, minH: 460 }, { widgetId: 'widget-7', basis: 420, grow: 5, minH: 460 }] },
      { items: [{ widgetId: 'widget-8', basis: 520, grow: 6, minH: 460 }, { widgetId: 'widget-9', basis: 420, grow: 5, minH: 460 }] },
      { items: [{ widgetId: 'widget-5', basis: 480, grow: 1, minH: 340 }] },
    ] },
  };
}
