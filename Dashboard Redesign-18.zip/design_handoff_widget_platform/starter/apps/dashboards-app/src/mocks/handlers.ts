import { http, HttpResponse, delay } from 'msw';
import { buildDashboard } from './generators/dashboard';
import { buildDataset } from './generators';

/** Scenarios (plan §16): ?scenario=normal|slow|error|empty|large|newBatch|stale|forbidden&ds=dataset-3 */
function scenario() {
  const q = new URLSearchParams(location.hash.split('?')[1] ?? location.search);
  return { name: q.get('scenario') ?? 'normal', ds: q.get('ds') };
}

let batch = 4812;
let prefs: Record<string, unknown> = {};

export const handlers = [
  http.get('/api/dashboards/:id', async () => { await delay(120); return HttpResponse.json(buildDashboard()); }),

  http.get('/api/datasets/:id', async ({ params, request }) => {
    const id = String(params.id), s = scenario();
    const base = 120 + Math.random() * 180;
    await delay(s.name === 'slow' ? base * 4 : base);
    const targeted = !s.ds || s.ds === id;
    if (s.name === 'error' && targeted) return new HttpResponse(null, { status: 503 });
    if (s.name === 'forbidden' && (s.ds ?? 'dataset-5') === id) return new HttpResponse(null, { status: 403 });
    const p = Object.fromEntries(new URL(request.url).searchParams);
    const ds = buildDataset(id, p, batch);
    if (s.name === 'empty' && targeted) ds.rowData = [];
    if (s.name === 'stale') ds.asOf = new Date(Date.now() - 2 * 3600e3).toISOString();
    return HttpResponse.json(ds);
  }),

  // Sprint 3: push + deltas. The UI polls this to learn about new batches.
  http.get('/api/batches/latest', () => HttpResponse.json({ batchId: batch })),
  http.post('/api/batches/next', () => { batch += 1; return HttpResponse.json({ batchId: batch }); }),

  http.get('/api/users/me/dashboards/:id', () => HttpResponse.json(prefs)),
  http.put('/api/users/me/dashboards/:id', async ({ request }) => { prefs = (await request.json()) as Record<string, unknown>; return HttpResponse.json(prefs); }),
];

// newBatch scenario: publish a batch every 30 s.
if (scenario().name === 'newBatch') setInterval(() => { batch += 1; }, 30_000);
