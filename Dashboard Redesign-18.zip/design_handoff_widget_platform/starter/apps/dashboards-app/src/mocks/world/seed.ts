// Seeded "mock world" (plan §16). Same seed → same numbers everywhere. Values seeded from the HTML prototype.

export function rng(seed: number) {
  let a = seed >>> 0;
  return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

export const CATEGORIES = ['A', 'B', 'C', 'D', 'E'];

/** 16 generic items: [category, measureA base, measureB base, limit] in base units (USD). */
const BASE: [string, number, number, number][] = [
  ['A', 52.4, 68.1, 62], ['A', 29.85, 41.32, 40], ['B', 24.73, 29.0, 35], ['B', 11.4, 28.25, 10],
  ['E', 6.9, 9.39, 12], ['A', 6.18, 6.95, 12], ['E', 6.07, 4.31, 9], ['B', 3.87, 3.49, 6],
  ['C', 3.41, 3.1, 15], ['C', 2.59, 3.42, 5], ['D', 1.02, 1.17, 3], ['D', 0.6, 0.84, 2],
  ['E', 0.42, 2.19, 2], ['E', 0.09, 0.17, 3], ['E', 0.03, 0.01, 1], ['E', 0.01, 0.01, 1],
];

export const ITEMS = BASE.map(([category, a, b, limit], i) => ({
  id: 'r-' + String(i + 1).padStart(3, '0'),
  label: 'Item ' + (i + 1),
  category,
  base: { a: a * 1e6, b: b * 1e6 },
  limit: limit * 1e6,
}));

export const MODELS = [{ id: 'm1', label: 'Model 1', factor: 1 }, { id: 'm2', label: 'Model 2', factor: 0.91 }];
export const MEASURES = [{ id: 'a', label: 'Measure A' }, { id: 'b', label: 'Measure B' }];
export const BREAKDOWN = Array.from({ length: 16 }, (_, i) => ({ id: 'T' + String(i + 1).padStart(2, '0'), label: 'Type ' + (i + 1), weight: [.40, .19, .08, .07, .06, .05, .04, .03, .025, .02, .015, .012, .006, .004, .002, .003][i]! }));
export const THRESHOLDS = Array.from({ length: 15 }, (_, i) => ({ id: 'L-' + String(i + 1).padStart(2, '0'), label: 'Threshold ' + (i + 1), unit: 'Unit ' + 'ABCD'[i % 4], itemIndex: i }));

/** Business days ending at asOf (inclusive), oldest first. */
export function businessDays(asOf: string, n: number): string[] {
  const out: string[] = []; let d = new Date(asOf + 'T00:00:00Z');
  while (out.length < n) { const w = d.getUTCDay(); if (w && w < 6) out.unshift(d.toISOString().slice(0, 10)); d = new Date(d.getTime() - 864e5); }
  return out;
}

/** 250-day seeded random walk that ends exactly at `end`. */
export function history(seed: number, end: number, n = 250): number[] {
  const r = rng(seed); const raw: number[] = [1];
  for (let i = 1; i < n; i++) raw.push(raw[i - 1]! * (1 + (r() - 0.5) * 0.06));
  const last = raw[n - 1]!; return raw.map((x) => (x / last) * end);
}

export const COMPARE_OFFSET: Record<string, number> = { '1D': 1, '1W': 5, '1M': 21 };
export const HORIZON_FACTOR: Record<string, number> = { '1D': 1, '10D': Math.sqrt(10) };
export const ATTRIBUTE_FACTOR: Record<string, number> = { a1: 1, a2: 1.07, a3: 0.94 };
