import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { DashboardRenderer, FilterBar, initFilters, useDashboard, useDatasets } from '../features/dashboard';
import { useAppDispatch, useAppSelector } from '../app/hooks';

/** Route: /#/dashboards/:dashboardId — everything on screen comes from the dashboard definition. */
export default function DashboardPage() {
  const { dashboardId = 'dashboard-1' } = useParams();
  const dispatch = useAppDispatch();
  const dash = useDashboard(dashboardId);
  const filters = useAppSelector((s) => s.filters.values);
  const selection = useAppSelector((s) => s.selection.byWidget);
  const density = useAppSelector((s) => s.preferences.density);

  useEffect(() => {
    if (dash.data) dispatch(initFilters(Object.fromEntries(dash.data.filters.map((f) => [f.filterId, f.default]))));
  }, [dash.data, dispatch]);

  const ready = !!dash.data && dash.data.filters.every((f) => f.filterId in filters);
  const datasets = useDatasets(ready ? dash.data!.datasets : undefined, filters, selection);

  if (dash.isError) return <div className="wf-state">Couldn’t load this dashboard.</div>;
  if (!dash.data) return <div className="wf-state">Loading…</div>;
  return (
    <div data-density={density}>
      <FilterBar dashboard={dash.data} />
      <DashboardRenderer dashboard={dash.data} datasets={datasets} />
    </div>
  );
}
