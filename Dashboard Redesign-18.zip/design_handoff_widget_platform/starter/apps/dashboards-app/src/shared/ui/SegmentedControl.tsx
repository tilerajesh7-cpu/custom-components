import * as ToggleGroup from '@radix-ui/react-toggle-group';
import './ui.css';

export interface SegmentedOption { value: string; label: string }
interface Props { label?: string; value: string; options: SegmentedOption[]; onChange: (v: string) => void; tone?: 'light' | 'dark' }

/** One-click segmented control (prototype filter bar). Adapter over Radix; ICGDS later. */
export function SegmentedControl({ label, value, options, onChange, tone = 'dark' }: Props) {
  return (
    <div className={'seg seg-' + tone}>
      {label && <span className="seg-label">{label}</span>}
      <ToggleGroup.Root type="single" value={value} onValueChange={(v) => v && onChange(v)} className="seg-track" aria-label={label}>
        {options.map((o) => <ToggleGroup.Item key={o.value} value={o.value} className="seg-item">{o.label}</ToggleGroup.Item>)}
      </ToggleGroup.Root>
    </div>
  );
}
