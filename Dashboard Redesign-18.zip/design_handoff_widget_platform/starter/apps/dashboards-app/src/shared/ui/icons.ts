// UI adapter (plan §3.4). The only place allowed to import the interim UI library and icons.
// Swap to ICGDS 7 by re-implementing these exports with the same props.
export { LayoutDashboard, ChevronsLeft, ChevronsRight, Download, Database, X, Search, Settings } from 'lucide-react';
