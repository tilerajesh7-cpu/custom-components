import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

const pkg = (p: string) => fileURLToPath(new URL(`../../packages/${p}/src`, import.meta.url));

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@widgets/contracts': pkg('widget-contracts'),
      '@widgets/tokens': pkg('widget-tokens'),
      '@widgets/core': pkg('widget-core'),
      '@widgets/grid': pkg('widget-grid'),
      '@widgets/charts': pkg('widget-charts'),
    },
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-aggrid': ['ag-grid-community', 'ag-grid-enterprise', 'ag-grid-react'],
          'vendor-highcharts': ['highcharts', 'highcharts-react-official'],
        },
      },
    },
  },
});
