// Architecture boundaries (plan §3.2). `npm run lint` fails on violations.
import tseslint from 'typescript-eslint';
import boundaries from 'eslint-plugin-boundaries';

export default tseslint.config(
  ...tseslint.configs.recommended,
  {
    plugins: { boundaries },
    settings: {
      'boundaries/elements': [
        { type: 'app',       pattern: 'apps/*/src/app/**' },
        { type: 'pages',     pattern: 'apps/*/src/pages/**' },
        { type: 'feature',   pattern: 'apps/*/src/features/*/**', capture: ['feature'] },
        { type: 'shared',    pattern: 'apps/*/src/shared/**' },
        { type: 'layouts',   pattern: 'apps/*/src/layouts/**' },
        { type: 'mocks',     pattern: 'apps/*/src/mocks/**' },
        { type: 'contracts', pattern: 'packages/widget-contracts/**' },
        { type: 'tokens',    pattern: 'packages/widget-tokens/**' },
        { type: 'core',      pattern: 'packages/widget-core/**' },
        { type: 'grid',      pattern: 'packages/widget-grid/**' },
        { type: 'charts',    pattern: 'packages/widget-charts/**' },
      ],
    },
    rules: {
      'boundaries/element-types': ['error', {
        default: 'disallow',
        rules: [
          { from: 'app',       allow: ['*'] },
          { from: 'pages',     allow: ['feature', 'layouts', 'shared', 'core', 'contracts'] },
          { from: 'feature',   allow: [['feature', { feature: '${from.feature}' }], 'shared', 'contracts', 'core', 'grid', 'charts', 'tokens'] },
          { from: 'layouts',   allow: ['shared', 'feature'] },
          { from: 'shared',    allow: ['shared', 'tokens'] },
          { from: 'mocks',     allow: ['contracts'] },
          { from: 'contracts', allow: [] },
          { from: 'tokens',    allow: [] },
          { from: 'core',      allow: ['contracts', 'tokens'] },
          { from: 'grid',      allow: ['core', 'contracts', 'tokens'] },
          { from: 'charts',    allow: ['core', 'contracts', 'tokens'] },
        ],
      }],
      // Other features only through their index.ts
      'boundaries/entry-point': ['error', { default: 'allow', rules: [{ target: ['feature'], disallow: ['**'], allow: ['index.ts'] }] }],
    },
  },
  // Vendor isolation: only the grid/charts packages import vendors; only shared/ui imports the interim UI library.
  {
    files: ['**/*.{ts,tsx}'],
    ignores: ['packages/widget-grid/**', 'packages/widget-tokens/src/agGridTheme.ts'],
    rules: { 'no-restricted-imports': ['error', { patterns: ['ag-grid-*'] }] },
  },
  {
    files: ['**/*.{ts,tsx}'],
    ignores: ['packages/widget-charts/**', 'packages/widget-tokens/src/highchartsTheme.ts'],
    rules: { 'no-restricted-imports': ['error', { patterns: ['highcharts', 'highcharts/*', 'highcharts-react-official'] }] },
  },
  {
    files: ['apps/**/*.{ts,tsx}'],
    ignores: ['apps/*/src/shared/ui/**'],
    rules: { 'no-restricted-imports': ['error', { patterns: ['@radix-ui/*', 'lucide-react'] }] },
  },
);
