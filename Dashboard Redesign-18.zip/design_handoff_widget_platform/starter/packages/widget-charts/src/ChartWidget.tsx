import { useMemo, useState } from 'react';
import Highcharts, { type Options } from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import 'highcharts/modules/exporting';
import 'highcharts/modules/export-data';
import 'highcharts/modules/accessibility';
import type { ChartWidgetConfig, Row } from '@widgets/contracts';
import type { WidgetProps } from '@widgets/core';
import { formats } from '@widgets/core';
import { encode, pointColors } from './encode';
import { presets } from './presets';
import './charts.css';

/** Generic chart widget: preset + encoding over any dataset's rows (plan §6.3). */
export function ChartWidget({ config, dataset, selection, clientFilters, onEvent }: WidgetProps<ChartWidgetConfig>) {
  const ranges = config.options?.ranges;
  const [range, setRange] = useState<number | undefined>(ranges?.[0]);

  const rows = useMemo<Row[]>(() => {
    if (!dataset) return [];
    const listens = config.interactions?.listens ?? [];
    return dataset.rowData.filter((r) =>
      Object.entries(clientFilters).every(([f, v]) => !v || v === 'all' || !(f in r) || String(r[f]) === v) &&
      listens.every((l) => { const k = selection[l.from]; return !k?.length || !(l.field in r) || k.includes(String(r[l.field])); }));
  }, [dataset, clientFilters, selection, config.interactions?.listens]);

  const options = useMemo<Options>(() => {
    if (!dataset) return {};
    const base = presets[config.preset] ?? {};
    const { series, xAxis } = encode(dataset, config.encoding, rows, range);
    if (config.encoding.zones && Array.isArray(config.encoding.y)) {
      const colors = pointColors(config.encoding, rows.slice(range ? -range : 0), config.encoding.y[0] ?? '');
      const s0 = series[0] as { data?: unknown[] } | undefined;
      if (s0?.data) s0.data = s0.data.map((d, i) => (colors[i] ? { x: (d as number[])[0], y: (d as number[])[1], color: colors[i] } : d));
    }
    const emit = config.interactions?.emits?.find((e) => e.on === 'pointClick' || e.on === 'itemClick');
    return {
      ...base,
      chart: { ...base.chart, height: null as unknown as number },
      xAxis: { ...(base.xAxis as object), ...(xAxis ?? {}) },
      tooltip: {
        ...base.tooltip,
        pointFormatter(this: { series: { name: string; color: string }; y?: number | null }) {
          return `<div><span style="color:${this.series.color}">●</span> ${this.series.name} <b style="font-family:var(--font-mono)">${formats.full(this.y)}</b></div>`;
        },
      },
      exporting: { enabled: false, filename: config.widgetId },
      plotOptions: {
        ...base.plotOptions,
        series: {
          ...(base.plotOptions?.series ?? {}),
          cursor: emit ? 'pointer' : undefined,
          point: emit ? { events: { click(this: { category?: string }) { if (this.category) onEvent({ kind: 'selection', widgetId: config.widgetId, keys: [String(this.category)] }); } } } : undefined,
        },
      },
      series,
    };
  }, [dataset, rows, range, config, onEvent]);

  return (
    <div className="cw">
      {ranges && ranges.length > 1 && (
        <div className="cw-ranges" role="group" aria-label="Range">
          {ranges.map((r) => <button key={r} type="button" aria-pressed={r === range} onClick={() => setRange(r)}>{r}D</button>)}
        </div>
      )}
      <HighchartsReact highcharts={Highcharts} options={options} immutable={false} updateArgs={[true, true, false]} containerProps={{ className: 'cw-chart' }} />
    </div>
  );
}
