import type { SeriesOptionsType, XAxisOptions } from 'highcharts';
import type { Dataset, Encoding, Row } from '@widgets/contracts';
import { isNum } from '@widgets/core';
import { SERIES_PALETTE } from '@widgets/tokens';

const ts = (v: unknown) => (typeof v === 'string' ? Date.parse(v + 'T00:00:00Z') : Number(v));

/**
 * The only chart "transformation": map row fields to series by name (plan §6.6).
 * Rows go into series.data as arrays — no per-point objects.
 */
export function encode(ds: Dataset, enc: Encoding, rows: Row[], range?: number): { series: SeriesOptionsType[]; xAxis?: XAxisOptions } {
  let data = rows;
  if (range && ds.kind === 'series') data = rows.slice(-range);

  const yFields = Array.isArray(enc.y) ? enc.y.map((f) => ({ field: f, name: f, palette: undefined as number | undefined, dash: false, stack: undefined as string | undefined }))
    : ds.kind === 'series' ? ds.seriesDefs.map((s) => ({ field: s.field, name: s.name, palette: s.palette, dash: !!s.dash, stack: s.stack })) : [];

  const isTime = ds.kind === 'series';
  if (!isTime) {                                           // category chart from grid rows
    if (enc.sort) {
      const f = yFields[0]?.field ?? '';
      const val = (r: Row) => (isNum(r[f]) ? (r[f] as number) : 0);
      data = [...data].sort((a, b) => enc.sort === 'asc' ? val(a) - val(b) : enc.sort === 'abs.desc' ? Math.abs(val(b)) - Math.abs(val(a)) : val(b) - val(a));
    }
    if (enc.limit) data = data.slice(0, enc.limit);
    return {
      xAxis: { categories: data.map((r) => String(r[enc.x] ?? '')) },
      series: yFields.map((y, i) => ({ type: undefined as never, id: y.field, name: y.name, color: SERIES_PALETTE[(y.palette ?? i + 1) - 1], data: data.map((r) => (isNum(r[y.field]) ? (r[y.field] as number) : null)) })),
    };
  }

  const series: SeriesOptionsType[] = yFields.map((y, i) => ({
    type: undefined as never, id: y.field, name: y.name, stack: y.stack,
    color: SERIES_PALETTE[(y.palette ?? i + 1) - 1],
    dashStyle: y.dash ? 'ShortDash' : 'Solid',
    keys: ['x', 'y'],
    data: data.map((r) => [ts(r[enc.x]), isNum(r[y.field]) ? r[y.field] : null]),
    zones: enc.zones ? zonesFor(enc, data) : undefined,
  }) as SeriesOptionsType);

  for (const ref of enc.reference ?? []) {
    series.push({
      type: 'line', name: ref.label ?? ref.field, color: ref.style === 'dashed' ? '#d08a0e' : '#101828',
      dashStyle: ref.style === 'dashed' ? 'Dash' : 'Solid', lineWidth: ref.style === 'dashed' ? 1.5 : 2, step: 'left',
      enableMouseTracking: true, keys: ['x', 'y'],
      data: data.map((r) => [ts(r[enc.x]), isNum(r[ref.field]) ? (r[ref.field] as number) * (ref.scale ?? 1) : null]),
    } as SeriesOptionsType);
  }
  return { series };
}

/** Colour points by ratio to a reference field (warn / breach). Highcharts zones are axis-based,
 *  so for a varying threshold we colour per point instead. */
function zonesFor(_enc: Encoding, _rows: Row[]) { return undefined; }

export function pointColors(enc: Encoding, rows: Row[], yField: string): (string | undefined)[] {
  if (!enc.zones) return [];
  return rows.map((r) => {
    const v = r[yField], ref = r[enc.zones!.ratioOf];
    if (!isNum(v) || !isNum(ref) || ref === 0) return undefined;
    const ratio = v / ref;
    const hit = [...enc.zones!.steps].reverse().find(([t]) => ratio >= t);
    return hit ? (hit[1] === 'breach' ? '#c2392f' : '#d08a0e') : undefined;
  });
}
