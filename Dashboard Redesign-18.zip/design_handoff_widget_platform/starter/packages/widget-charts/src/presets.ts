import type { Options } from 'highcharts';
import { formats } from '@widgets/core';

const moneyAxis = { labels: { formatter(this: { value: number }) { return formats.millions(this.value); } } };

/** Chart presets hold the full look; widget config only adds encoding (plan §6.5). */
export const presets: Record<string, Options> = {
  line: {
    chart: { type: 'line' },
    xAxis: { type: 'datetime', crosshair: { color: '#98a2b3', dashStyle: 'Dash' } },
    yAxis: moneyAxis,
    tooltip: { shared: true },
    plotOptions: { line: { lineWidth: 2.25 } },
  },
  column: {
    chart: { type: 'column' },
    xAxis: { type: 'category' },
    yAxis: moneyAxis,
    plotOptions: { column: { borderRadius: 3, borderWidth: 0, pointPadding: 0.08, groupPadding: 0.1 } },
  },
  'column.stacked': {
    chart: { type: 'column' },
    xAxis: { type: 'datetime', crosshair: true },
    yAxis: moneyAxis,
    tooltip: { shared: true },
    legend: { enabled: true, align: 'left', verticalAlign: 'top', itemStyle: { fontSize: '11.5px', fontWeight: '500' } },
    plotOptions: { column: { stacking: 'normal', borderWidth: 0, pointPadding: 0.05, groupPadding: 0.05 } },
  },
  'column.reference': {
    chart: { type: 'column' },
    xAxis: { type: 'datetime' },
    yAxis: moneyAxis,
    tooltip: { shared: true },
    plotOptions: { column: { borderWidth: 0, pointPadding: 0.05, groupPadding: 0.05 } },
  },
  'bar.diverging': {
    chart: { type: 'bar' },
    xAxis: { type: 'category', labels: { style: { fontSize: '12px', color: '#344054' } } },
    yAxis: { ...moneyAxis, plotLines: [{ value: 0, color: '#cfd4dc', width: 1 }] },
    plotOptions: { bar: { borderRadius: 4, borderWidth: 0, negativeColor: '#16895a', color: '#c2392f' } },
  },
};
