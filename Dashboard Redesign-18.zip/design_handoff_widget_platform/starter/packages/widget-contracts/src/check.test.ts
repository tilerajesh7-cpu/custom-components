// `npm run contracts:check` — every mock response must satisfy the contract.
import { describe, expect, it } from 'vitest';
import { Dashboard, Dataset } from './index';
import { buildDashboard } from '../../../apps/dashboards-app/src/mocks/generators/dashboard';
import { buildDataset } from '../../../apps/dashboards-app/src/mocks/generators';

const params = { asOf: '2026-09-11', compare: '1D', scenario: 'both', measure: 'both', horizon: '1D', attribute: 'a1' };

describe('contract fixtures', () => {
  it('dashboard-1 is valid', () => {
    expect(() => Dashboard.parse(buildDashboard())).not.toThrow();
  });
  for (const id of ['dataset-1', 'dataset-2', 'dataset-3', 'dataset-4', 'dataset-5', 'dataset-6']) {
    it(`${id} is valid`, () => {
      expect(() => Dataset.parse(buildDataset(id, { ...params, rowId: 'r-001' }, 4812))).not.toThrow();
    });
  }
});
