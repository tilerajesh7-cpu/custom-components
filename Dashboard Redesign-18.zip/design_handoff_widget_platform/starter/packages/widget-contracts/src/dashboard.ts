import { z } from 'zod';
import { WidgetConfig } from './widget';

export const Filter = z.object({
  filterId: z.string(),
  label: z.string(),
  control: z.enum(['date', 'segmented', 'select']),
  options: z.array(z.object({ value: z.string(), label: z.string() })).optional(),
  default: z.string(),
  scope: z.enum(['server', 'client']),
  field: z.string().optional(),                  // client scope: row field to filter on
}).strict();
export type Filter = z.infer<typeof Filter>;

/** Param values are literals or bindings: "$filter.<id>" | "$selection.<widgetId>". */
export const DatasetRef = z.object({
  datasetId: z.string(),
  kind: z.enum(['grid', 'series']),
  params: z.record(z.union([z.string(), z.number()])),
  load: z.enum(['bootstrap', 'onSelection']).default('bootstrap'),
}).strict();
export type DatasetRef = z.infer<typeof DatasetRef>;

export const LayoutItem = z.object({
  widgetId: z.string(),
  basis: z.number(),
  grow: z.number().default(1),
  minW: z.number().optional(),
  minH: z.number().optional(),
}).strict();

export const Layout = z.object({
  type: z.literal('flex'),
  gap: z.number().default(16),
  rows: z.array(z.object({ items: z.array(LayoutItem) })),
}).strict();

export const Dashboard = z.object({
  schemaVersion: z.literal('1.0'),
  dashboardId: z.string(),
  version: z.number().int(),
  title: z.string(),
  breadcrumb: z.array(z.string()).optional(),
  minLibraryVersion: z.string().optional(),
  filters: z.array(Filter),
  datasets: z.array(DatasetRef),
  widgets: z.array(WidgetConfig),
  layout: Layout,
}).strict();
export type Dashboard = z.infer<typeof Dashboard>;
export type Layout = z.infer<typeof Layout>;
