import { z } from 'zod';

/** Semantic tones — mapped to theme classes by the library. Services never send colours. */
export const Tone = z.enum(['positive', 'negative', 'warn', 'breach', 'info', 'muted', 'highlight']);
export type Tone = z.infer<typeof Tone>;

/** Declarative condition. No code, no expressions. */
export const Condition = z.object({
  op: z.enum(['gt', 'gte', 'lt', 'lte', 'eq', 'neq', 'between', 'in', 'isNull']).optional(),
  value: z.unknown().optional(),
  ref: z.string().optional(),      // compare against another field of the same row
  scale: z.number().optional(),    // multiply the operand (value or ref)
  row: z.enum(['pinned', 'group', 'leaf']).optional(),
}).strict();
export type Condition = z.infer<typeof Condition>;

export const StyleRule = z.object({ when: Condition, tone: Tone, emphasis: z.boolean().optional() }).strict();
export const RendererRule = z.object({ when: Condition, renderer: z.string() }).strict();
export type StyleRule = z.infer<typeof StyleRule>;
export type RendererRule = z.infer<typeof RendererRule>;

/** Allowed, JSON-safe subset of AG Grid ColDef (plan §5.3) + our styling keys (§6.7). */
export interface ColumnContract {
  field: string;
  headerName: string;
  headerTooltip?: string;
  type?: string[];
  cellDataType?: 'text' | 'number' | 'boolean' | 'date' | 'dateString';
  pinned?: 'left' | 'right';
  width?: number; minWidth?: number; flex?: number;
  hide?: boolean;
  sort?: 'asc' | 'desc'; sortIndex?: number;
  cellRenderer?: string;
  cellRendererParams?: Record<string, unknown>;
  tooltipComponent?: string;
  tooltipComponentParams?: Record<string, unknown>;
  tooltipField?: string;
  columnGroupShow?: 'open' | 'closed';
  rowGroup?: boolean; enableRowGroup?: boolean; enableValue?: boolean;
  aggFunc?: 'sum' | 'avg' | 'min' | 'max' | 'count';
  styleRules?: StyleRule[];
  rendererRules?: RendererRule[];
}
export interface ColumnGroupContract {
  groupId: string;
  headerName: string;
  headerTooltip?: string;
  children: ColDefContract[];
}
export type ColDefContract = ColumnContract | ColumnGroupContract;

const Column: z.ZodType<ColumnContract> = z.object({
  field: z.string(), headerName: z.string(), headerTooltip: z.string().optional(),
  type: z.array(z.string()).optional(),
  cellDataType: z.enum(['text', 'number', 'boolean', 'date', 'dateString']).optional(),
  pinned: z.enum(['left', 'right']).optional(),
  width: z.number().optional(), minWidth: z.number().optional(), flex: z.number().optional(),
  hide: z.boolean().optional(),
  sort: z.enum(['asc', 'desc']).optional(), sortIndex: z.number().int().optional(),
  cellRenderer: z.string().optional(),
  cellRendererParams: z.record(z.unknown()).optional(),
  tooltipComponent: z.string().optional(), tooltipComponentParams: z.record(z.unknown()).optional(), tooltipField: z.string().optional(),
  columnGroupShow: z.enum(['open', 'closed']).optional(),
  rowGroup: z.boolean().optional(), enableRowGroup: z.boolean().optional(), enableValue: z.boolean().optional(),
  aggFunc: z.enum(['sum', 'avg', 'min', 'max', 'count']).optional(),
  styleRules: z.array(StyleRule).optional(),
  rendererRules: z.array(RendererRule).optional(),
}).strict();

export const ColDefContract: z.ZodType<ColDefContract> = z.lazy(() =>
  z.union([
    z.object({ groupId: z.string(), headerName: z.string(), headerTooltip: z.string().optional(), children: z.array(ColDefContract) }).strict(),
    Column,
  ]),
);

export const RowMeta = z.object({
  row: z.object({
    tone: Tone.optional(),
    badges: z.array(z.object({ text: z.string(), tone: Tone, tooltip: z.string().optional() })).optional(),
  }).optional(),
  cells: z.record(z.object({ tone: Tone.optional(), flag: z.string().optional(), note: z.string().optional() })).optional(),
}).strict();
export type RowMeta = z.infer<typeof RowMeta>;

export const Row = z.object({ _meta: RowMeta.optional() }).catchall(z.unknown());
export type Row = z.infer<typeof Row>;

export const DatasetMeta = z.object({
  rowCount: z.number().int(),
  batchId: z.number().int(),
  queryId: z.string().optional(),
  ms: z.number().optional(),
  cache: z.enum(['HIT', 'MISS']).optional(),
});

export const GridOptionsContract = z.object({
  rowModel: z.literal('clientSide').default('clientSide'),     // Phase 1: client-side only
  rowSelection: z.enum(['none', 'single', 'multiple']).optional(),
  grandTotalRow: z.enum(['top', 'bottom']).optional(),
  groupDefaultExpanded: z.number().int().optional(),
  sideBar: z.enum(['none', 'columns', 'columnsAndFilters']).optional(),
  statusBar: z.enum(['none', 'aggregations']).optional(),
}).strict();
export type GridOptionsContract = z.infer<typeof GridOptionsContract>;

const Common = {
  datasetId: z.string(),
  version: z.string(),
  asOf: z.string(),
  rowKey: z.string(),
  rowData: z.array(Row),
  meta: DatasetMeta,
};

export const GridDataset = z.object({
  ...Common,
  kind: z.literal('grid'),
  columnDefs: z.array(ColDefContract),
  pinnedBottomRowData: z.array(Row).optional(),
  gridOptions: GridOptionsContract.optional(),
}).strict();

export const SeriesDef = z.object({
  field: z.string(),
  name: z.string(),
  type: z.array(z.string()).optional(),
  palette: z.number().int().min(1).optional(),
  dash: z.boolean().optional(),
  stack: z.string().optional(),
}).strict();

export const SeriesDataset = z.object({
  ...Common,
  kind: z.literal('series'),
  seriesDefs: z.array(SeriesDef),
}).strict();

export const Dataset = z.discriminatedUnion('kind', [GridDataset, SeriesDataset]);
export type GridDataset = z.infer<typeof GridDataset>;
export type SeriesDataset = z.infer<typeof SeriesDataset>;
export type SeriesDef = z.infer<typeof SeriesDef>;
export type Dataset = z.infer<typeof Dataset>;

export const isGroup = (c: ColDefContract): c is ColumnGroupContract => 'children' in c;
