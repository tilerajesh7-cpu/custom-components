export * from './dataset';
export * from './widget';
export * from './dashboard';

/** Selection state: widgetId → selected row keys. */
export type SelectionState = Record<string, string[]>;

export type WidgetStatus = 'loading' | 'refreshing' | 'ready' | 'empty' | 'error' | 'stale' | 'forbidden';

export type WidgetEvent =
  | { kind: 'selection'; widgetId: string; keys: string[] }
  | { kind: 'action'; widgetId: string; action: string }
  | { kind: 'preferenceChange'; widgetId: string; key: string; value: unknown };
