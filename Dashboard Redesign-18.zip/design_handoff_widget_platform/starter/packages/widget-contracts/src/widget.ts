import { z } from 'zod';

export const Interactions = z.object({
  emits: z.array(z.object({ on: z.enum(['rowClick', 'pointClick', 'itemClick', 'legendClick']), selection: z.string() })).optional(),
  listens: z.array(z.object({ from: z.string(), field: z.string() })).optional(),
}).strict();

const Base = {
  widgetId: z.string(),
  configVersion: z.number().int().default(1),
  title: z.string(),
  subtitle: z.string().optional(),               // may contain {filter.x} placeholders
  interactions: Interactions.optional(),
  actions: z.array(z.string()).optional(),       // export.csv · export.excel · export.copy · export.png · inspect · fullscreen
  states: z.object({ empty: z.string().optional() }).optional(),
  layoutHints: z.object({ minW: z.number().optional(), minH: z.number().optional() }).optional(),
  permissions: z.array(z.string()).optional(),
};

export const GridWidgetConfig = z.object({
  ...Base,
  type: z.literal('grid'),
  datasetId: z.string(),
  presentation: z.object({
    cellMode: z.enum(['smart', 'table']).optional(),
    columnState: z.array(z.object({ colId: z.string(), hide: z.boolean().optional(), width: z.number().optional() })).optional(),
    columnPresets: z.array(z.string()).optional(),
    features: z.object({
      search: z.boolean().optional(), columnsPanel: z.boolean().optional(),
      rowFlash: z.boolean().optional(), density: z.enum(['inherit', 'compact', 'comfortable', 'spacious']).optional(),
    }).optional(),
  }).optional(),
}).strict();

export const Encoding = z.object({
  x: z.string(),
  y: z.union([z.array(z.string()), z.object({ fromSeriesDefs: z.literal(true) })]),
  sort: z.enum(['asc', 'desc', 'abs.desc']).optional(),
  limit: z.number().int().optional(),
  reference: z.array(z.object({ field: z.string(), scale: z.number().optional(), label: z.string().optional(), style: z.enum(['line', 'dashed']).optional() })).optional(),
  zones: z.object({ ratioOf: z.string(), steps: z.array(z.tuple([z.number(), z.enum(['warn', 'breach'])])) }).optional(),
}).strict();
export type Encoding = z.infer<typeof Encoding>;

export const ChartWidgetConfig = z.object({
  ...Base,
  type: z.literal('chart'),
  preset: z.enum(['line', 'column', 'column.stacked', 'column.reference', 'bar.diverging']),
  datasetId: z.string(),
  encoding: Encoding,
  options: z.object({ ranges: z.array(z.number().int()).optional(), sharedTooltip: z.boolean().optional() }).optional(),
}).strict();

export const KpiWidgetConfig = z.object({
  ...Base,
  type: z.literal('kpi'),
  datasetId: z.string(),
  row: z.enum(['pinnedBottom', 'first']),
  value: z.string(),
  compare: z.string().optional(),
  tone: z.enum(['higherIsWorse', 'higherIsBetter']).optional(),
  spark: z.string().optional(),                  // "dataset-2:s1"
}).strict();

export const SummaryWidgetConfig = z.object({
  ...Base,
  type: z.literal('summary'),
  rules: z.array(z.string()),
  sources: z.array(z.string()),
}).strict();

export const WidgetConfig = z.discriminatedUnion('type', [GridWidgetConfig, ChartWidgetConfig, KpiWidgetConfig, SummaryWidgetConfig]);
export type WidgetConfig = z.infer<typeof WidgetConfig>;
export type GridWidgetConfig = z.infer<typeof GridWidgetConfig>;
export type ChartWidgetConfig = z.infer<typeof ChartWidgetConfig>;
export type KpiWidgetConfig = z.infer<typeof KpiWidgetConfig>;
export type SummaryWidgetConfig = z.infer<typeof SummaryWidgetConfig>;
