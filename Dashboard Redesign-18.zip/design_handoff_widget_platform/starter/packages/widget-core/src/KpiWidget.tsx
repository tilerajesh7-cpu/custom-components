import type { GridDataset, KpiWidgetConfig, Row } from '@widgets/contracts';
import type { WidgetProps } from './registry';
import { formats, isNum } from './formats';
import './kpi.css';

/** KPI tile: reads the totals row (or first row) + optional sparkline from a series dataset. */
export function KpiWidget({ config, dataset, related }: WidgetProps<KpiWidgetConfig>) {
  const ds = dataset?.kind === 'grid' ? (dataset as GridDataset) : undefined;
  const row: Row | undefined = config.row === 'pinnedBottom' ? ds?.pinnedBottomRowData?.[0] : ds?.rowData[0];
  const v = row?.[config.value], c = config.compare ? row?.[config.compare] : undefined;
  const d = isNum(v) && isNum(c) ? v - c : undefined;
  const worse = config.tone !== 'higherIsBetter';
  const tone = d === undefined || d === 0 ? 'muted' : (d > 0) === worse ? 'negative' : 'positive';

  const [sparkId, sparkField] = (config.spark ?? '').split(':');
  const spark = sparkId ? related?.[sparkId]?.rowData.slice(-30).map((r) => r[sparkField ?? '']).filter(isNum) : undefined;
  const path = spark && spark.length > 1 ? sparkPath(spark as number[]) : undefined;

  return (
    <div className="kpi">
      <span className="kpi-label">{config.title}</span>
      <div className="kpi-row">
        <span className="kpi-value">{formats.millions(v)}</span>
        {d !== undefined && <span className={'kpi-delta tone-' + tone}>{formats.millionsSigned(d)} ({formats.percent1(isNum(c) && c ? d / c : 0)})</span>}
      </div>
      {path && <svg className="kpi-spark" viewBox="0 0 120 28" preserveAspectRatio="none"><path d={path} /></svg>}
      {config.subtitle && <span className="kpi-sub">{config.subtitle}</span>}
    </div>
  );
}

function sparkPath(vals: number[]) {
  const lo = Math.min(...vals), hi = Math.max(...vals), span = hi - lo || 1;
  return vals.map((v, i) => `${i ? 'L' : 'M'}${(i / (vals.length - 1) * 120).toFixed(1)} ${(26 - (v - lo) / span * 24).toFixed(1)}`).join(' ');
}
