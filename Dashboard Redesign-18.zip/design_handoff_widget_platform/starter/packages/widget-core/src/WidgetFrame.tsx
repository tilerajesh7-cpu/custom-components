import type { CSSProperties, ReactNode } from 'react';
import type { WidgetStatus } from '@widgets/contracts';
import './widget-frame.css';

interface Props {
  title: string;
  subtitle?: string;
  filteredBy?: string[];
  onClearFilter?: () => void;
  actions?: ReactNode;
  status: WidgetStatus;
  emptyText?: string;
  onRetry?: () => void;
  loadingLabel?: string;
  style?: CSSProperties;
  children: ReactNode;
}

/** One wrapper for every widget: header, badge, actions, states (plan §8.2). */
export function WidgetFrame({ title, subtitle, filteredBy, onClearFilter, actions, status, emptyText, onRetry, loadingLabel, style, children }: Props) {
  const showBody = status === 'ready' || status === 'refreshing' || status === 'stale';
  return (
    <section className="wf" style={style} aria-busy={status === 'loading' || status === 'refreshing'}>
      <header className="wf-head">
        <div className="wf-titles">
          <h2 className="wf-title">{title}</h2>
          {subtitle && <span className="wf-sub">{subtitle}</span>}
          {filteredBy && filteredBy.length > 0 && (
            <button type="button" className="wf-badge" onClick={onClearFilter} title="Clear this filter">
              <span className="wf-badge-dot" />Filtered by {filteredBy.join(' + ')}<span aria-hidden>×</span>
            </button>
          )}
        </div>
        {actions && <div className="wf-actions">{actions}</div>}
      </header>
      <div className="wf-body">
        {showBody && children}
        {status === 'empty' && <div className="wf-state">{emptyText ?? 'No data for these filters'}</div>}
        {status === 'forbidden' && <div className="wf-state">You don’t have access to this panel</div>}
        {status === 'error' && (
          <div className="wf-state wf-error">
            <span className="wf-error-icon">!</span>
            <b>Couldn’t load this panel</b>
            {onRetry && <button type="button" className="wf-retry" onClick={onRetry}>Retry</button>}
          </div>
        )}
        {(status === 'loading' || status === 'refreshing') && (
          <div className="wf-loader" role="status">
            <span className="wf-shimmer" />
            <span className="wf-spinner"><span className="wf-ring" /><span className="wf-ring wf-ring-inner" /></span>
            {loadingLabel && <span className="wf-loader-label">{loadingLabel}</span>}
          </div>
        )}
      </div>
    </section>
  );
}
