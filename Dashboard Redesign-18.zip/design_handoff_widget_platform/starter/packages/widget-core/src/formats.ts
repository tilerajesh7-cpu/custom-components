// Number/date formatting shared by grid column types and chart tooltips.
const nf = (dp: number) => new Intl.NumberFormat('en-US', { minimumFractionDigits: dp, maximumFractionDigits: dp });
const full = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
const n2 = nf(2), n1 = nf(1), n0 = nf(0);

export const isNum = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

export const formats = {
  /** Base units → millions, 2 dp (grid display). */
  millions: (v: unknown) => (isNum(v) ? n2.format(v / 1e6) : ''),
  /** Signed millions for change columns. */
  millionsSigned: (v: unknown) => (isNum(v) ? (v > 0 ? '+' : v < 0 ? '−' : '') + n2.format(Math.abs(v) / 1e6) : ''),
  /** Exact amount for the value tooltip. */
  full: (v: unknown) => (isNum(v) ? (v < 0 ? '−$' : '$') + full.format(Math.abs(v)) : ''),
  percent0: (v: unknown) => (isNum(v) ? n0.format(v * 100) + '%' : ''),
  percent1: (v: unknown) => (isNum(v) ? n1.format(v * 100) + '%' : ''),
  date: (v: unknown) => (typeof v === 'string' ? new Date(v + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : ''),
};
export type FormatName = keyof typeof formats;
