import type { ComponentType } from 'react';
import type { Dataset, SelectionState, WidgetConfig, WidgetEvent, WidgetStatus } from '@widgets/contracts';

/** The single props contract every widget implements (plan §6.10). */
export interface WidgetProps<C extends WidgetConfig = WidgetConfig> {
  config: C;
  dataset: Dataset | undefined;
  /** Extra datasets a widget reads (KPI sparkline, summary sources). */
  related?: Record<string, Dataset | undefined>;
  status: WidgetStatus;
  selection: SelectionState;
  /** Client-scope filters: field → allowed value. */
  clientFilters: Record<string, string>;
  onEvent: (e: WidgetEvent) => void;
}

const registry = new Map<string, ComponentType<WidgetProps<never>>>();

export function registerWidgetType<C extends WidgetConfig>(type: C['type'], component: ComponentType<WidgetProps<C>>): void {
  registry.set(type, component as ComponentType<WidgetProps<never>>);
}
export function getWidgetComponent(type: string): ComponentType<WidgetProps<never>> | undefined {
  return registry.get(type);
}
