import type { Condition, Row } from '@widgets/contracts';
import { isNum } from './formats';

export interface RuleContext { value: unknown; data: Row | undefined; rowPinned?: boolean; group?: boolean }

/** Compile a declarative condition once into a fast predicate (plan §6.7). */
export function compileCondition(c: Condition): (ctx: RuleContext) => boolean {
  const { op, value, ref, scale = 1, row } = c;
  const rowCheck = row === 'pinned' ? (x: RuleContext) => !!x.rowPinned
    : row === 'group' ? (x: RuleContext) => !!x.group
    : row === 'leaf' ? (x: RuleContext) => !x.rowPinned && !x.group
    : () => true;
  if (!op) return rowCheck;
  const operand = (x: RuleContext): unknown => {
    const base = ref ? x.data?.[ref] : value;
    return isNum(base) ? base * scale : base;
  };
  const test: (v: unknown, o: unknown) => boolean = {
    gt: (v: unknown, o: unknown) => isNum(v) && isNum(o) && v > o,
    gte: (v: unknown, o: unknown) => isNum(v) && isNum(o) && v >= o,
    lt: (v: unknown, o: unknown) => isNum(v) && isNum(o) && v < o,
    lte: (v: unknown, o: unknown) => isNum(v) && isNum(o) && v <= o,
    eq: (v: unknown, o: unknown) => v === o,
    neq: (v: unknown, o: unknown) => v !== o,
    between: (v: unknown, o: unknown) => isNum(v) && Array.isArray(o) && v >= (o[0] as number) && v <= (o[1] as number),
    in: (v: unknown, o: unknown) => Array.isArray(o) && o.includes(v),
    isNull: (v: unknown) => v === null || v === undefined || v === '',
  }[op];
  return (x) => rowCheck(x) && test(x.value, operand(x));
}
