import type { ITooltipParams } from 'ag-grid-community';
import type { Row } from '@widgets/contracts';
import { formats, isNum } from '@widgets/core';

/**
 * Rich tooltip card (plan §6.7). Sections come from tooltipComponentParams.sections
 * so services can choose what the card shows without code.
 */
export function DetailTooltip(p: ITooltipParams & { sections?: { label: string; field: string; type?: 'money' | 'percent' | 'change' }[]; titleField?: string }) {
  const data = p.data as Row | undefined;
  if (!data) return null;
  const meta = data._meta;
  const title = String(data[p.titleField ?? 'label'] ?? '');
  const fmt = (v: unknown, t?: string) => t === 'percent' ? formats.percent1(v) : t === 'change' ? (isNum(v) ? (v >= 0 ? '+' : '−') + formats.full(Math.abs(v)).slice(1) : '') : formats.full(v);
  return (
    <div className="dt">
      <div className="dt-head">
        <b className="dt-title">{title}</b>
        {!!meta?.row?.badges?.length && <div className="dt-badges">{meta.row.badges.map((b, i) => <span key={i} className={'lc-badge tone-' + b.tone}>{b.text}</span>)}</div>}
      </div>
      <div className="dt-body">
        {(p.sections ?? []).map((s) => (
          <div key={s.field} className="dt-kv"><span>{s.label}</span><b className={s.type === 'change' && isNum(data[s.field]) ? ((data[s.field] as number) > 0 ? 'tone-negative' : 'tone-positive') : ''}>{fmt(data[s.field], s.type)}</b></div>
        ))}
      </div>
      {meta?.cells && Object.values(meta.cells).some((c) => c.note) && (
        <div className="dt-note">{Object.values(meta.cells).map((c) => c.note).filter(Boolean).join(' · ')}</div>
      )}
    </div>
  );
}
