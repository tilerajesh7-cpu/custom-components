import { useCallback, useEffect, useMemo, useRef } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { GetRowIdParams, GridApi, IRowNode, RowClickedEvent } from 'ag-grid-community';
import type { GridDataset, GridWidgetConfig, Row } from '@widgets/contracts';
import { riskGridTheme } from '@widgets/tokens';
import type { WidgetProps } from '@widgets/core';
import { columnTypes } from './columnTypes';
import { resolveColumnDefs } from './resolveColumnDefs';
import { buildGridOptions, type ConsumerOverrides } from './buildGridOptions';
import { gridComponents } from './renderers';
import { DetailTooltip } from './DetailTooltip';
import './grid.css';

const components = { ...gridComponents, detailTooltip: DetailTooltip };

/**
 * Grid widget: rowData / columnDefs pass straight through to AG Grid (plan §6.6).
 * Consumer props stay minimal: config, dataset, onEvent (+ optional overrides).
 */
export function GridWidget(props: WidgetProps<GridWidgetConfig> & { overrides?: ConsumerOverrides; quickFilter?: string }) {
  const { config, dataset, selection, clientFilters, onEvent, overrides, quickFilter } = props;
  const ds = dataset?.kind === 'grid' ? (dataset as GridDataset) : undefined;
  const apiRef = useRef<GridApi | null>(null);

  const columnDefs = useMemo(() => (ds ? resolveColumnDefs(ds.columnDefs, { cellMode: config.presentation?.cellMode }) : []),
    // columns change only when the dataset schema version changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [ds?.version.split('-')[0], ds?.columnDefs, config.presentation?.cellMode]);
  const gridOptions = useMemo(() => buildGridOptions(ds?.gridOptions, overrides), [ds?.gridOptions, overrides]);
  const getRowId = useCallback((p: GetRowIdParams<Row>) => String(p.data[ds?.rowKey ?? 'id']), [ds?.rowKey]);

  // Client filters + selections from other widgets → AG Grid external filter (no data copy).
  const listens = config.interactions?.listens ?? [];
  const activeFilters = useMemo(() => {
    const f: [string, string[]][] = Object.entries(clientFilters).filter(([, v]) => v && v !== 'all').map(([k, v]) => [k, [v]]);
    for (const l of listens) { const keys = selection[l.from]; if (keys?.length) f.push([l.field, keys]); }
    return f;
  }, [clientFilters, selection, listens]);
  const isExternalFilterPresent = useCallback(() => activeFilters.length > 0, [activeFilters]);
  const doesExternalFilterPass = useCallback((node: IRowNode<Row>) => activeFilters.every(([field, vals]) => vals.includes(String(node.data?.[field]))), [activeFilters]);
  useEffect(() => { apiRef.current?.onFilterChanged(); }, [activeFilters]);

  // Highlight this widget's own selection.
  const mine = selection[config.widgetId];
  useEffect(() => {
    const api = apiRef.current; if (!api) return;
    api.forEachNode((n) => n.setSelected(!!mine?.includes(n.id ?? '')));
  }, [mine]);

  const emit = config.interactions?.emits?.find((e) => e.on === 'rowClick');
  const onRowClicked = useCallback((e: RowClickedEvent<Row>) => {
    if (!emit || e.rowPinned || !e.data) return;
    const key = String(e.data[ds?.rowKey ?? 'id']);
    onEvent({ kind: 'selection', widgetId: config.widgetId, keys: mine?.includes(key) ? [] : [key] });
  }, [emit, ds?.rowKey, onEvent, config.widgetId, mine]);

  // User column state (layer 4) — applied once columns exist.
  useEffect(() => {
    const s = config.presentation?.columnState; if (s?.length) apiRef.current?.applyColumnState({ state: s, applyOrder: false });
  }, [columnDefs, config.presentation?.columnState]);

  return (
    <div className="gw">
      <AgGridReact<Row>
        theme={riskGridTheme}
        {...gridOptions}
        columnTypes={columnTypes}
        components={components}
        columnDefs={columnDefs}
        rowData={ds?.rowData}
        pinnedBottomRowData={ds?.pinnedBottomRowData}
        getRowId={getRowId}
        quickFilterText={quickFilter}
        isExternalFilterPresent={isExternalFilterPresent}
        doesExternalFilterPass={doesExternalFilterPass}
        getRowClass={(p) => (p.data?._meta?.row?.tone ? 'row-tone-' + p.data._meta.row.tone : undefined)}
        onRowClicked={onRowClicked}
        onGridReady={(e) => { apiRef.current = e.api; }}
      />
    </div>
  );
}
