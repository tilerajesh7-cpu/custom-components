import type { GridOptions } from 'ag-grid-community';
import type { GridOptionsContract } from '@widgets/contracts';

/** Layer 1 — library defaults (plan §6.8). */
export const libraryDefaults: GridOptions = {
  defaultColDef: { sortable: true, resizable: true, filter: true, enableCellChangeFlash: true, minWidth: 64 },
  animateRows: false,
  tooltipShowDelay: 300,
  tooltipInteraction: true,
  enableCellTextSelection: true,
  cellSelection: true,
  suppressDragLeaveHidesColumns: true,
  enableCharts: false,                       // Highcharts is the standard
  getContextMenuItems: () => ['copy', 'copyWithHeaders', 'separator', 'excelExport', 'csvExport'],
};

const SIDEBARS = {
  none: undefined,
  columns: { toolPanels: ['columns'] },
  columnsAndFilters: { toolPanels: ['columns', 'filters'] },
} as const;

/** Layer 2 — service options, allowlisted. */
function fromService(o: GridOptionsContract | undefined): GridOptions {
  if (!o) return {};
  return {
    rowSelection: o.rowSelection && o.rowSelection !== 'none' ? { mode: o.rowSelection === 'single' ? 'singleRow' : 'multiRow', checkboxes: false, enableClickSelection: true } : undefined,
    grandTotalRow: o.grandTotalRow,
    groupDefaultExpanded: o.groupDefaultExpanded,
    sideBar: o.sideBar ? SIDEBARS[o.sideBar] : undefined,
    statusBar: o.statusBar === 'aggregations' ? { statusPanels: [{ statusPanel: 'agAggregationComponent' }] } : undefined,
  };
}

export interface ConsumerOverrides { exportExcel?: boolean; contextMenu?: string[] }

/** Merge: library → service → consumer (user column state is applied via the grid API). */
export function buildGridOptions(service: GridOptionsContract | undefined, consumer: ConsumerOverrides = {}): GridOptions {
  const merged: GridOptions = { ...libraryDefaults, ...stripUndefined(fromService(service)) };
  if (consumer.exportExcel === false) merged.getContextMenuItems = () => ['copy', 'copyWithHeaders'];
  return merged;
}

const stripUndefined = <T extends object>(o: T): Partial<T> =>
  Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined)) as Partial<T>;
