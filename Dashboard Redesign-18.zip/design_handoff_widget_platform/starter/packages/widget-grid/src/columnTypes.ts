import type { ColTypeDef, ValueFormatterParams } from 'ag-grid-community';
import { formats } from '@widgets/core';

const fmt = (f: (v: unknown) => string) => (p: ValueFormatterParams) => f(p.value);

/** Column-type registry (plan §6.5, Table "column types"). Services reference these by name in `type`. */
export const columnTypes: Record<string, ColTypeDef> = {
  text:      { cellDataType: 'text' },
  tag:       { cellDataType: 'text', cellClass: 'cell-tag' },
  date:      { cellDataType: 'dateString', valueFormatter: fmt(formats.date) },
  money:     {
    cellDataType: 'number', cellClass: 'cell-num', headerClass: 'ag-right-aligned-header',
    valueFormatter: fmt(formats.millions),
    tooltipValueGetter: (p) => formats.full(p.value),          // normal tooltip: exact amount
  },
  change:    { valueFormatter: fmt(formats.millionsSigned) },  // combined with money; tone via default rules below
  percent:   { cellDataType: 'number', cellClass: 'cell-num', headerClass: 'ag-right-aligned-header', valueFormatter: fmt(formats.percent1) },
  threshold: { cellRenderer: 'thresholdCell' },
};

/** Default style rules carried by a type, so services don't repeat them per column. */
export const typeDefaultRules: Record<string, { op: 'gt' | 'lt'; value: number; tone: 'negative' | 'positive' }[]> = {
  change: [ { op: 'gt', value: 0, tone: 'negative' }, { op: 'lt', value: 0, tone: 'positive' } ],   // higher is worse
};
