import { ModuleRegistry } from 'ag-grid-community';
import { AllEnterpriseModule, LicenseManager } from 'ag-grid-enterprise';

/** Call once at app start. Phase 2: register only the modules actually used to cut bundle size. */
export function setupAgGrid(licenseKey: string | undefined): void {
  ModuleRegistry.registerModules([AllEnterpriseModule]);
  if (licenseKey) LicenseManager.setLicenseKey(licenseKey);
}

export { GridWidget } from './GridWidget';
export { resolveColumnDefs } from './resolveColumnDefs';
export { buildGridOptions, libraryDefaults, type ConsumerOverrides } from './buildGridOptions';
export { columnTypes } from './columnTypes';
