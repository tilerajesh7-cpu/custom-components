import type { ICellRendererParams } from 'ag-grid-community';
import type { Row } from '@widgets/contracts';
import { formats, isNum } from '@widgets/core';

/** Name + row badges from _meta (e.g. "▲ 2.4σ"). */
export function LabelCell(p: ICellRendererParams) {
  const badges = (p.data as Row | undefined)?._meta?.row?.badges ?? [];
  return (
    <span className="lc">
      <span className="lc-text">{String(p.value ?? '')}</span>
      {badges.map((b, i) => <span key={i} className={'lc-badge tone-' + b.tone} title={b.tooltip}>{b.text}</span>)}
    </span>
  );
}

/** Current value with bar, previous-value tick and change chip (prototype “Smart” cell). */
export function SmartCell(p: ICellRendererParams & { previousField?: string; changeField?: string; max?: number }) {
  const v = p.value, data = p.data as Row | undefined;
  const prev = p.previousField ? data?.[p.previousField] : undefined;
  const chg = p.changeField ? data?.[p.changeField] : undefined;
  const max = p.max ?? 1;
  const w = isNum(v) ? Math.min(100, Math.abs(v) / max * 100) : 0;
  const t = isNum(prev) ? Math.min(100, Math.abs(prev) / max * 100) : null;
  const tone = isNum(chg) ? (chg > 0 ? 'negative' : chg < 0 ? 'positive' : 'muted') : 'muted';
  return (
    <span className="sc">
      <span className="sc-bar" style={{ width: w + '%' }} />
      {t !== null && <span className="sc-tick" style={{ left: t + '%' }} />}
      <span className="sc-val">{formats.millions(v)}</span>
      {isNum(chg) && <span className={'sc-chip tone-' + tone}>{formats.millionsSigned(chg)}</span>}
    </span>
  );
}

/** Utilisation bar with 80% marker; tone from the column's style rules. */
export function ThresholdCell(p: ICellRendererParams & { warn?: number; breach?: number }) {
  const v = isNum(p.value) ? p.value : 0, warn = p.warn ?? 0.8, breach = p.breach ?? 1;
  const tone = v >= breach ? 'breach' : v >= warn ? 'warn' : 'info';
  return (
    <span className="tc">
      <span className="tc-track"><span className={'tc-fill tc-' + tone} style={{ width: Math.min(100, v * 100) + '%' }} /><span className="tc-mark" style={{ left: warn * 100 + '%' }} /></span>
      <span className="tc-val">{formats.percent1(v)}</span>
    </span>
  );
}

export function TotalCell(p: ICellRendererParams) {
  return <b className="cell-total">{p.colDef?.type?.includes?.('money') ? formats.millions(p.value) : String(p.value ?? '')}</b>;
}

export function EmptyCell() { return <span className="tone-muted">—</span>; }

export const gridComponents = { labelCell: LabelCell, smartCell: SmartCell, thresholdCell: ThresholdCell, totalCell: TotalCell, emptyCell: EmptyCell };
