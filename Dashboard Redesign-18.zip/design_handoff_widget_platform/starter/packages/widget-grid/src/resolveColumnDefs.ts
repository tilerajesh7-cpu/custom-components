import type { CellClassParams, ColDef, ColGroupDef, ICellRendererParams } from 'ag-grid-community';
import { isGroup, type ColDefContract, type ColumnContract, type Row } from '@widgets/contracts';
import { compileCondition } from '@widgets/core';
import { typeDefaultRules } from './columnTypes';

const ctxOf = (p: CellClassParams | ICellRendererParams) => ({
  value: p.value, data: p.data as Row | undefined, rowPinned: !!p.node?.rowPinned, group: !!p.node?.group,
});

/** Tones from type defaults + styleRules + per-cell _meta → AG Grid cellClassRules (compiled once). */
function buildClassRules(c: ColumnContract): ColDef['cellClassRules'] {
  const rules: Record<string, (p: CellClassParams) => boolean> = {};
  const add = (cls: string, fn: (p: CellClassParams) => boolean) => {
    const prev = rules[cls];
    rules[cls] = prev ? (p) => prev(p) || fn(p) : fn;
  };
  for (const t of c.type ?? []) for (const r of typeDefaultRules[t] ?? []) {
    const test = compileCondition({ op: r.op, value: r.value });
    add('tone-' + r.tone, (p) => test(ctxOf(p)));
  }
  for (const r of c.styleRules ?? []) {
    const test = compileCondition(r.when);
    add('tone-' + r.tone, (p) => test(ctxOf(p)));
    if (r.emphasis) add('tone-emphasis', (p) => test(ctxOf(p)));
  }
  for (const tone of ['positive', 'negative', 'warn', 'breach', 'info', 'muted', 'highlight'])
    add('tone-' + tone, (p) => (p.data as Row | undefined)?._meta?.cells?.[c.field]?.tone === tone);
  return rules;
}

function buildRendererSelector(c: ColumnContract): ColDef['cellRendererSelector'] {
  if (!c.rendererRules?.length) return undefined;
  const compiled = c.rendererRules.map((r) => ({ test: compileCondition(r.when), renderer: r.renderer }));
  return (p) => {
    const hit = compiled.find((r) => r.test(ctxOf(p)));
    return hit ? { component: hit.renderer } : c.cellRenderer ? { component: c.cellRenderer } : undefined;
  };
}

/**
 * Contract columns → AG Grid ColDefs. The contract is already an AG Grid subset,
 * so this only strips our keys and adds compiled rules. No reshaping of data.
 */
export function resolveColumnDefs(defs: ColDefContract[], opts: { cellMode?: 'smart' | 'table' } = {}): (ColDef | ColGroupDef)[] {
  return defs.map((d): ColDef | ColGroupDef => {
    if (isGroup(d)) return { groupId: d.groupId, headerName: d.headerName, headerTooltip: d.headerTooltip, children: resolveColumnDefs(d.children, opts) };
    const { styleRules: _s, rendererRules: _r, cellRenderer, ...rest } = d;
    const useSmart = cellRenderer === 'smartCell' && opts.cellMode !== 'table';
    return {
      ...rest,
      colId: d.field,
      cellRenderer: useSmart || cellRenderer !== 'smartCell' ? cellRenderer : undefined,
      cellClassRules: buildClassRules(d),
      cellRendererSelector: buildRendererSelector(d),
      tooltipComponent: d.tooltipComponent,
    };
  });
}
