// Tokens → AG Grid Theming API. Only this file (and widget-grid) may import ag-grid.
import { themeQuartz } from 'ag-grid-community';

export const riskGridTheme = themeQuartz.withParams({
  fontFamily: "'IBM Plex Sans', system-ui, sans-serif",
  fontSize: 13,
  foregroundColor: '#101828',
  headerTextColor: '#667085',
  headerFontSize: 11.5,
  headerFontWeight: 600,
  headerBackgroundColor: 'rgba(248,250,253,.97)',
  backgroundColor: '#ffffff',
  oddRowBackgroundColor: '#ffffff',
  rowHoverColor: '#f5f8fd',
  selectedRowBackgroundColor: '#edf2fd',
  borderColor: '#eef1f6',
  rowBorder: { color: '#f1f3f7' },
  columnBorder: false,
  wrapperBorder: false,
  wrapperBorderRadius: 16,
  accentColor: '#2f5fd6',
  cellHorizontalPadding: 10,
  rowHeight: 'var(--row-height)' as unknown as number,
  headerHeight: 36,
});
