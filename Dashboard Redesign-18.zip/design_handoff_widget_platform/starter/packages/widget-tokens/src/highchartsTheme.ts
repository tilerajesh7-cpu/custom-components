// Tokens → Highcharts global theme. Only this file (and widget-charts) may import highcharts.
import Highcharts from 'highcharts';

export const SERIES_PALETTE = ['#2f62c9', '#7fa2fb', '#12918a', '#5cc9bf', '#d08a0e', '#7a5af0', '#c2392f'];

export function applyHighchartsTheme(): void {
  Highcharts.setOptions({
    colors: SERIES_PALETTE,
    chart: { backgroundColor: 'transparent', style: { fontFamily: "'IBM Plex Sans', system-ui, sans-serif" }, spacing: [8, 4, 8, 4], animation: false },
    title: { text: undefined },
    credits: { enabled: false },
    legend: { enabled: false },
    xAxis: { lineColor: '#eef1f6', tickColor: '#eef1f6', labels: { style: { color: '#98a2b3', fontSize: '11px' } } },
    yAxis: { gridLineColor: '#eef1f6', title: { text: undefined }, labels: { style: { color: '#98a2b3', fontSize: '11px', fontFamily: "'IBM Plex Mono', monospace" } } },
    tooltip: {
      backgroundColor: 'rgba(16,24,40,.94)', borderWidth: 0, borderRadius: 12, shadow: false,
      style: { color: '#ffffff', fontSize: '12px' }, useHTML: true, shared: true,
    },
    plotOptions: { series: { animation: false, marker: { enabled: false }, states: { inactive: { opacity: 0.35 } } } },
    accessibility: { enabled: true },
  });
}
