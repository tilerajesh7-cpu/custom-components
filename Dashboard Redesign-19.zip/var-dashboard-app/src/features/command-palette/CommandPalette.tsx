import { useEffect, useMemo, useRef, useState } from 'react';
import type { Dashboard } from '@/contracts';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { clearAllSelections, setDensity, setDevOpen, setFilter, setHelp, setPalette } from '@/features/dashboard/model';
import { useViews } from '@/features/saved-views/SavedViews';
import { devBus } from '@/features/dev-tools/bus';
import { Icon } from '@/shared/ui/icons';
import { Kbd, Modal } from '@/shared/ui/controls';
import './palette.css';

interface Command { id: string; group: string; label: string; hint?: string; icon: string; run: () => void }

export function scrollToWidget(widgetId: string) {
  const el = document.getElementById('w-' + widgetId);
  if (!el) return;
  const top = el.getBoundingClientRect().top + window.scrollY - 230;
  window.scrollTo({ top, behavior: 'smooth' });
  el.classList.add('wf-flash');
  setTimeout(() => el.classList.remove('wf-flash'), 1200);
}

function useCommands(dashboard: Dashboard, onRefresh: () => void): Command[] {
  const dispatch = useAppDispatch();
  const { all, apply } = useViews(dashboard);
  return useMemo(() => [
    ...all.map((v, i) => ({ id: 'view-' + v.viewId, group: 'Views', label: `Open view: ${v.name}`, hint: i < 9 ? String(i + 1) : undefined, icon: 'bookmark', run: () => apply(v) })),
    ...dashboard.filters.filter((f) => f.control === 'segmented').flatMap((f) => (f.options ?? []).map((o) => ({
      id: `f-${f.filterId}-${o.value}`, group: 'Filters', label: `${f.label}: ${o.label}`, icon: 'sliders', run: () => dispatch(setFilter({ id: f.filterId, value: o.value })),
    }))),
    ...dashboard.widgets.filter((w) => w.type !== 'kpi').map((w) => ({ id: 'go-' + w.widgetId, group: 'Go to', label: w.title, icon: 'dashboard', run: () => scrollToWidget(w.widgetId) })),
    { id: 'refresh', group: 'Actions', label: 'Refresh data now', hint: 'R', icon: 'refresh', run: onRefresh },
    { id: 'clear', group: 'Actions', label: 'Clear all cross-filters', hint: 'C', icon: 'x', run: () => dispatch(clearAllSelections()) },
    ...(['compact', 'comfortable', 'spacious'] as const).map((d) => ({ id: 'd-' + d, group: 'Display', label: `Density: ${d}`, icon: 'settings', run: () => dispatch(setDensity(d)) })),
    { id: 'help', group: 'Help', label: 'Keyboard shortcuts', hint: '?', icon: 'help', run: () => dispatch(setHelp(true)) },
    ...(devBus.enabled ? [{ id: 'dev', group: 'Developer', label: 'Open dev console', hint: 'Ctrl ⇧ D', icon: 'terminal', run: () => dispatch(setDevOpen(true)) }] : []),
  ], [all, apply, dashboard, dispatch, onRefresh]);
}

/** ⌘K / Ctrl+K command palette. */
export function CommandPalette({ dashboard, onRefresh }: { dashboard: Dashboard; onRefresh: () => void }) {
  const open = useAppSelector((s) => s.ui.paletteOpen);
  const dispatch = useAppDispatch();
  const commands = useCommands(dashboard, onRefresh);
  const [q, setQ] = useState('');
  const [idx, setIdx] = useState(0);
  const input = useRef<HTMLInputElement>(null);
  const list = useMemo(() => {
    const words = q.toLowerCase().split(/\s+/).filter(Boolean);
    return commands.filter((c) => words.every((w) => (c.label + ' ' + c.group).toLowerCase().includes(w))).slice(0, 40);
  }, [q, commands]);
  useEffect(() => { if (open) { setQ(''); setIdx(0); setTimeout(() => input.current?.focus(), 0); } }, [open]);
  useEffect(() => setIdx(0), [q]);
  const close = () => dispatch(setPalette(false));
  const run = (c?: Command) => { if (!c) return; close(); c.run(); };

  let lastGroup = '';
  return (
    <Modal open={open} onClose={close} width={600} title={<span style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Icon name="command" size={15} />Command palette</span>}>
      <div className="cmd">
        <label className="cmd-input">
          <Icon name="search" size={16} />
          <input ref={input} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search views, filters, panels, actions…"
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') { e.preventDefault(); setIdx((i) => Math.min(list.length - 1, i + 1)); }
              if (e.key === 'ArrowUp') { e.preventDefault(); setIdx((i) => Math.max(0, i - 1)); }
              if (e.key === 'Enter') { e.preventDefault(); run(list[idx]); }
            }} />
        </label>
        <div className="cmd-list" role="listbox">
          {list.length === 0 && <div className="cmd-empty">No matches</div>}
          {list.map((c, i) => {
            const head = c.group !== lastGroup ? (lastGroup = c.group) : null;
            return (
              <div key={c.id}>
                {head && <div className="menu-title">{head}</div>}
                <button type="button" role="option" aria-selected={i === idx} className={'cmd-item' + (i === idx ? ' is-active' : '')} onMouseEnter={() => setIdx(i)} onClick={() => run(c)}>
                  <Icon name={c.icon} size={14} /><span>{c.label}</span>{c.hint && <Kbd>{c.hint}</Kbd>}
                </button>
              </div>
            );
          })}
        </div>
        <div className="cmd-foot"><span><Kbd>↑</Kbd><Kbd>↓</Kbd> move</span><span><Kbd>Enter</Kbd> run</span><span><Kbd>Esc</Kbd> close</span></div>
      </div>
    </Modal>
  );
}
