import { useEffect } from 'react';
import type { Dashboard } from '@/contracts';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { clearAllSelections, cycleDensity, openInspector, setDevOpen, setHelp, setPalette } from '@/features/dashboard/model';
import { useViews } from '@/features/saved-views/SavedViews';
import { devBus } from '@/features/dev-tools/bus';
import { Kbd, Modal, toast } from '@/shared/ui/controls';

const typing = (e: KeyboardEvent) => {
  const t = e.target as HTMLElement | null;
  return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable || !!t.closest('.ag-cell-edit-wrapper'));
};

/** Global keyboard shortcuts. Ignored while typing. */
export function useShortcuts(dashboard: Dashboard | undefined, onRefresh: () => void) {
  const dispatch = useAppDispatch();
  const ui = useAppSelector((s) => s.ui);
  const { all, apply } = useViews(dashboard);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key.toLowerCase() === 'k') { e.preventDefault(); dispatch(setPalette(!ui.paletteOpen)); return; }
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd' && devBus.enabled) { e.preventDefault(); dispatch(setDevOpen(!ui.devOpen)); return; }
      if (mod || e.altKey || typing(e)) return;
      if (e.key === 'Escape') {
        if (ui.paletteOpen || ui.helpOpen || ui.inspector) return; // modals close themselves
        dispatch(clearAllSelections()); return;
      }
      if (ui.paletteOpen || ui.helpOpen) return;
      if (e.key === '?') { dispatch(setHelp(true)); return; }
      if (e.key === '/') {
        const el = document.querySelector<HTMLInputElement>('.gw-search');
        if (el) { e.preventDefault(); el.focus(); }
        return;
      }
      const k = e.key.toLowerCase();
      if (k === 'r') { onRefresh(); toast('Refreshing'); }
      else if (k === 'd') dispatch(cycleDensity());
      else if (k === 'c') dispatch(clearAllSelections());
      else if (/^[1-9]$/.test(e.key)) { const v = all[Number(e.key) - 1]; if (v) { apply(v); toast(`View: ${v.name}`); } }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [dispatch, ui, all, apply, onRefresh]);
  useEffect(() => { if (!ui.devOpen && ui.inspector) dispatch(openInspector(null)); }, [ui.devOpen, ui.inspector, dispatch]);
}

const SHORTCUTS: [string[], string][] = [
  [['Ctrl', 'K'], 'Command palette (⌘K on Mac)'],
  [['1–9'], 'Switch saved view'],
  [['/'], 'Search the first grid'],
  [['R'], 'Refresh data now'],
  [['C'], 'Clear all cross-filters'],
  [['Esc'], 'Close dialog · clear cross-filters'],
  [['D'], 'Cycle density'],
  [['?'], 'This help'],
  [['↑', '↓', '←', '→'], 'Move between grid cells'],
  [['Ctrl', 'C'], 'Copy selected cells'],
];

export function HelpDialog() {
  const open = useAppSelector((s) => s.ui.helpOpen);
  const dispatch = useAppDispatch();
  return (
    <Modal open={open} onClose={() => dispatch(setHelp(false))} title="Keyboard shortcuts" width={460}>
      <div className="help-list">
        {SHORTCUTS.map(([keys, label]) => (
          <div key={label} className="help-row"><span>{label}</span><span className="help-keys">{keys.map((k) => <Kbd key={k}>{k}</Kbd>)}</span></div>
        ))}
        {devBus.enabled && <div className="help-row"><span>Dev console (dev only)</span><span className="help-keys"><Kbd>Ctrl</Kbd><Kbd>⇧</Kbd><Kbd>D</Kbd></span></div>}
      </div>
    </Modal>
  );
}
