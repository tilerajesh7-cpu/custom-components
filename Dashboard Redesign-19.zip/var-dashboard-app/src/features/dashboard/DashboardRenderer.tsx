import { useMemo } from 'react';
import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { WidgetHost } from './WidgetHost';

/** Renders the backend flex layout. Widgets size only from their slot, so layouts can change without code. */
export function DashboardRenderer({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const byId = useMemo(() => new Map(dashboard.widgets.map((w) => [w.widgetId, w])), [dashboard.widgets]);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--gap)' }}>
      {dashboard.layout.rows.map((row, i) => (
        <div key={i} style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--gap)', alignItems: 'stretch' }}>
          {row.items.map((it) => {
            const w = byId.get(it.widgetId);
            if (!w) return null;
            return (
              <div key={it.widgetId} style={{ flex: `${it.grow} 1 ${it.basis}px`, minWidth: it.minW ? `min(${it.minW}px, 100%)` : 0, display: 'flex', flexDirection: 'column' }}>
                <WidgetHost widget={w} dashboard={dashboard} datasets={datasets} />
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
