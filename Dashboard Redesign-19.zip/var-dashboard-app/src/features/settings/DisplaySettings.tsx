import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { resetAllGridPrefs, setDensity } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import { Popover, SegmentedControl, toast } from '@/shared/ui/controls';
import type { Density } from '@/shared/ui/widgets';

/** Gear menu: whole-screen density + reset of grid layouts. */
export function DisplaySettings() {
  const dispatch = useAppDispatch();
  const density = useAppSelector((s) => s.preferences.density);
  return (
    <Popover width={300} title="Display settings" trigger={<span className="hdr-btn is-icon"><Icon name="settings" size={16} /></span>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: 4 }}>
        <div className="menu-title">Density <span style={{ float: 'right', textTransform: 'none', letterSpacing: 0 }}><kbd className="kbd">D</kbd></span></div>
        <SegmentedControl tone="light" value={density} onChange={(v) => dispatch(setDensity(v as Density))}
          options={[{ value: 'compact', label: 'Compact' }, { value: 'comfortable', label: 'Comfortable' }, { value: 'spacious', label: 'Spacious' }]} />
        <div className="menu-sep" />
        <button type="button" className="menu-item" onClick={() => { dispatch(resetAllGridPrefs()); toast('Grid layouts reset'); }}>
          <Icon name="columns" size={14} />Reset columns and cell style on all grids
        </button>
      </div>
    </Popover>
  );
}
