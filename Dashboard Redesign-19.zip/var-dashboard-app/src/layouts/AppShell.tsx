import { NavLink, Outlet } from 'react-router-dom';
import { useNavigation } from '@/api/queries';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { toggleSidebar } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import './app-shell.css';

/** Navy sidebar (navigation from services) + content outlet. */
export function AppShell() {
  const open = useAppSelector((s) => s.preferences.sidebarOpen);
  const dispatch = useAppDispatch();
  const nav = useNavigation();
  const sections = [...new Set((nav.data ?? []).map((n) => n.section))];

  return (
    <div className="shell">
      <aside className={'side' + (open ? '' : ' is-collapsed')}>
        <div className="side-brand">
          <span className="side-logo">RA</span>
          {open && <span className="side-brand-text"><b>Risk Analytics</b><small>Workspace</small></span>}
        </div>
        <nav className="side-nav" aria-label="Main">
          {sections.map((sec) => (
            <div key={sec} className="side-sec">
              {open && <div className="side-sec-title">{sec}</div>}
              {(nav.data ?? []).filter((n) => n.section === sec).map((n) =>
                n.route && !n.disabled ? (
                  <NavLink key={n.id} to={n.route} title={n.label} className={({ isActive }) => 'side-item' + (isActive ? ' is-active' : '')}>
                    <span className="side-ico"><Icon name={n.icon} size={15} /></span>{open && <span>{n.label}</span>}
                  </NavLink>
                ) : (
                  <span key={n.id} className="side-item is-disabled" title={`${n.label} · coming soon`}>
                    <span className="side-ico"><Icon name={n.icon} size={15} /></span>{open && <span>{n.label}</span>}
                    {open && <span className="side-soon">Soon</span>}
                  </span>
                ),
              )}
            </div>
          ))}
        </nav>
        <button type="button" className="side-toggle" onClick={() => dispatch(toggleSidebar())} aria-label={open ? 'Collapse sidebar' : 'Expand sidebar'}>
          <Icon name={open ? 'chevronsLeft' : 'chevronsRight'} size={15} />{open && 'Collapse'}
        </button>
      </aside>
      <main className="content"><Outlet /></main>
    </div>
  );
}
