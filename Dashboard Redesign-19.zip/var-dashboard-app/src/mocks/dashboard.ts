// Mock dashboard definition + navigation — same shape services will return.
import type { Dashboard, NavItem } from '@/contracts';

const seg = (filterId: string, label: string, def: string, opts: [string, string][]) =>
  ({ filterId, label, control: 'segmented' as const, default: def, scope: 'server' as const, options: opts.map(([value, l]) => ({ value, label: l })) });

const EXPORT_GRID = ['export.excel', 'export.csv', 'export.copy', 'export.json'];
const EXPORT_CHART = ['export.png', 'export.svg', 'export.csv'];

export function buildDashboard(): Dashboard {
  const P = {
    asOf: '$filter.asOfDate', compare: '$filter.compareTo', segment: '$filter.segment', scenario: '$filter.scenario',
    measure: '$filter.measure', horizon: '$filter.horizon', attribute: '$filter.attribute',
  };
  const item = '$selection?.widget-3';
  return {
    schemaVersion: '1.0', dashboardId: 'dashboard-1', version: 1, title: 'Summary', breadcrumb: ['Management', 'Summary'],
    filters: [
      { filterId: 'asOfDate', label: 'As of', control: 'date', default: '2026-09-11', scope: 'server' },
      seg('compareTo', 'Compare', '1D', [['1D', '1D'], ['1W', '1W'], ['1M', '1M']]),
      seg('segment', 'Segment', 'all', [['all', 'All'], ['A', 'A'], ['B', 'B'], ['C', 'C'], ['D', 'D'], ['E', 'E']]),
      seg('horizon', 'Horizon', '1D', [['1D', '1D'], ['10D', '10D']]),
      seg('scenario', 'Model', 'm1', [['m1', 'Model 1'], ['m2', 'Model 2'], ['both', 'Both']]),
      seg('attribute', 'Attribute', 'a1', [['a1', 'Attr 1'], ['a2', 'Attr 2'], ['a3', 'Attr 3']]),
      seg('measure', 'Measure', 'both', [['a', 'A'], ['b', 'B'], ['both', 'Both']]),
    ],
    datasets: [
      { datasetId: 'dataset-1', kind: 'grid', params: P },
      { datasetId: 'dataset-2', kind: 'series', params: { ...P, days: 90, itemId: item } },
      { datasetId: 'dataset-3', kind: 'grid', params: { ...P, itemId: item } },
      { datasetId: 'dataset-4', kind: 'series', params: { ...P, days: 90, itemId: item } },
      { datasetId: 'dataset-5', kind: 'grid', params: { asOf: '$filter.asOfDate' } },
      { datasetId: 'dataset-6', kind: 'series', params: { asOf: '$filter.asOfDate', thresholdId: '$selection?.widget-8' } },
    ],
    widgets: [
      { widgetId: 'widget-1', type: 'kpi', title: 'Total · first group', subtitle: 'vs previous · $MM', datasetId: 'dataset-1', row: 'pinnedBottom', value: 'g1Current', compare: 'g1Previous', tone: 'higherIsWorse', spark: 'dataset-2:s1' },
      { widgetId: 'widget-2', type: 'kpi', title: 'Threshold exposure', subtitle: 'all thresholds · $MM', datasetId: 'dataset-5', row: 'pinnedBottom', value: 'exposure', compare: 'previous', tone: 'higherIsWorse' },
      { widgetId: 'widget-10', type: 'summary', title: 'Daily brief', subtitle: 'click an item to focus it', items: [
        { label: 'Largest increase', rule: 'max', datasetId: 'dataset-1', field: 'g1Change', target: 'widget-3', format: 'moneySigned' },
        { label: 'Largest decrease', rule: 'min', datasetId: 'dataset-1', field: 'g1Change', target: 'widget-3', format: 'moneySigned' },
        { label: 'Highest utilisation', rule: 'max', datasetId: 'dataset-5', field: 'ratio', target: 'widget-8', format: 'percent' },
        { label: 'Unusual moves', rule: 'countBadges', datasetId: 'dataset-1', field: 'label', format: 'count' },
      ] },
      { widgetId: 'widget-3', type: 'grid', title: 'Summary by item', subtitle: '$MM · compared with {filter.compareTo}', datasetId: 'dataset-1',
        interactions: { emits: [{ on: 'rowClick' }] }, actions: EXPORT_GRID,
        presentation: { height: 470, cellMode: 'smart', features: { search: true, columnsPanel: true, cellModeToggle: true } } },
      { widgetId: 'widget-4', type: 'chart', title: 'Trend', subtitle: '$MM · business days', preset: 'line', datasetId: 'dataset-2',
        interactions: { listens: [{ from: 'widget-3', field: '$param' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { ranges: [30, 60, 90], height: 440 } },
      { widgetId: 'widget-6', type: 'grid', title: 'Breakdown by type', subtitle: '$MM', datasetId: 'dataset-3',
        interactions: { listens: [{ from: 'widget-3', field: '$param' }, { from: 'widget-7', field: 'label' }] }, actions: EXPORT_GRID,
        presentation: { height: 380, cellMode: 'smart', features: { search: true } } },
      { widgetId: 'widget-7', type: 'chart', title: 'Breakdown over time', subtitle: 'top 6 types + other · click the legend to filter', preset: 'column.stacked', datasetId: 'dataset-4',
        interactions: { emits: [{ on: 'legendClick' }], listens: [{ from: 'widget-3', field: '$param' }, { from: 'widget-7', field: '$series' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { ranges: [30, 60, 90], height: 360 } },
      { widgetId: 'widget-8', type: 'grid', title: 'Thresholds', subtitle: 'sorted by utilisation · click a row', datasetId: 'dataset-5',
        interactions: { emits: [{ on: 'rowClick' }] }, actions: EXPORT_GRID, presentation: { height: 400, features: { search: true } } },
      { widgetId: 'widget-9', type: 'chart', title: 'Exposure vs threshold', subtitle: '90 business days', preset: 'column.reference', datasetId: 'dataset-6',
        interactions: { listens: [{ from: 'widget-8', field: '$param' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: ['value'], reference: [{ field: 'threshold', label: 'Threshold' }, { field: 'threshold', scale: 0.8, style: 'dashed', label: '80% of threshold' }], zones: { ratioOf: 'threshold', steps: [[0.8, 'warn'], [1, 'breach']] } },
        options: { height: 300, stats: true } },
      { widgetId: 'widget-5', type: 'chart', title: 'Top changes', subtitle: 'largest moves vs previous · click a bar', preset: 'bar.diverging', datasetId: 'dataset-1',
        interactions: { emits: [{ on: 'pointClick', target: 'widget-3' }] }, actions: EXPORT_CHART,
        encoding: { x: 'label', y: ['g1Change'], sort: 'abs.desc', limit: 8 }, options: { height: 320 } },
    ],
    layout: { type: 'flex', gap: 16, rows: [
      { items: [{ widgetId: 'widget-1', basis: 260, grow: 1 }, { widgetId: 'widget-2', basis: 260, grow: 1 }, { widgetId: 'widget-10', basis: 460, grow: 2 }] },
      { items: [{ widgetId: 'widget-3', basis: 640, grow: 7, minW: 460 }, { widgetId: 'widget-4', basis: 380, grow: 5, minW: 320 }] },
      { items: [{ widgetId: 'widget-6', basis: 520, grow: 6, minW: 400 }, { widgetId: 'widget-7', basis: 420, grow: 5, minW: 320 }] },
      { items: [{ widgetId: 'widget-8', basis: 520, grow: 6, minW: 400 }, { widgetId: 'widget-9', basis: 420, grow: 5, minW: 320 }] },
      { items: [{ widgetId: 'widget-5', basis: 480, grow: 1 }] },
    ] },
    views: [
      { viewId: 'v-default', name: 'Default', filters: {} },
      { viewId: 'v-week', name: 'Week over week', filters: { compareTo: '1W' } },
      { viewId: 'v-month', name: 'Month over month', filters: { compareTo: '1M' } },
      { viewId: 'v-both', name: 'Both models · 10D', filters: { scenario: 'both', horizon: '10D' } },
    ],
  };
}

export const NAVIGATION: NavItem[] = [
  { id: 'nav-1', section: 'Management', label: 'Summary', icon: 'dashboard', route: '/dashboards/dashboard-1' },
  { id: 'nav-2', section: 'Management', label: 'Exposure', icon: 'gauge', disabled: true },
  { id: 'nav-3', section: 'Management', label: 'Breakdown', icon: 'pie', disabled: true },
  { id: 'nav-4', section: 'Management', label: 'Thresholds', icon: 'layers', disabled: true },
  { id: 'nav-5', section: 'Management', label: 'History', icon: 'history', disabled: true },
  { id: 'nav-6', section: 'Management', label: 'Reports', icon: 'fileText', disabled: true },
];
