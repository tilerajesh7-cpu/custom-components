// Mock dataset builders — responses follow src/contracts exactly (AG Grid-ready rows + columnDefs).
import type { ColDefContract, Dataset, Row } from '@/contracts';
import { ATTRIBUTE_FACTOR, BREAKDOWN, COMPARE_OFFSET, HORIZON_FACTOR, ITEMS, MEASURES, MODELS, THRESHOLDS, businessDays, history } from './seed';

export type Params = Record<string, string>;
const N = 250;
const ASOF = (p: Params) => (p.asOf || '2026-09-11') + 'T11:41:00-04:00';

function groupsFor(p: Params) {
  const models = p.scenario === 'both' ? MODELS : MODELS.filter((m) => m.id === (p.scenario || 'm1'));
  const measures = !p.measure || p.measure === 'both' ? MEASURES : MEASURES.filter((m) => m.id === p.measure);
  const out: { key: string; model: (typeof MODELS)[number]; measure: (typeof MEASURES)[number] }[] = [];
  for (const me of measures) for (const mo of models) out.push({ key: 'g' + (out.length + 1), model: mo, measure: me });
  return out;
}
type Group = ReturnType<typeof groupsFor>[number];

/** Items in scope: segment filter, optional single item (cross-filter from the summary grid). */
function scope(p: Params, useItem: boolean) {
  return ITEMS.map((it, i) => ({ it, i })).filter(({ it }) =>
    (!p.segment || p.segment === 'all' || it.category === p.segment) && (!useItem || !p.itemId || it.id === p.itemId));
}

/** Each batch nudges ~half the rows so deltas and row flash have something to show. */
const nudge = (i: number, batch: number) => {
  const h = (i * 2654435761 + batch * 40503) >>> 0;
  return h % 2 ? 1 + ((h % 100) / 100 - 0.48) * 0.08 : 1;
};

function series(i: number, g: Group, p: Params, batch: number) {
  const f = g.model.factor * (HORIZON_FACTOR[p.horizon || '1D'] ?? 1) * (ATTRIBUTE_FACTOR[p.attribute || 'a1'] ?? 1) * nudge(i, batch);
  const seed = i * 97 + (g.measure.id === 'b' ? 13 : 0) + (g.model.id === 'm2' ? 29 : 0);
  return history(seed, ITEMS[i].base[g.measure.id as 'a' | 'b'] * f, N);
}

const LINEAGE: Record<string, string[]> = {
  'dataset-1': ['source.positions', 'engine.calc_daily', 'mart.summary_by_item'],
  'dataset-2': ['source.positions', 'engine.calc_daily', 'mart.history_total'],
  'dataset-3': ['source.positions', 'engine.calc_components', 'mart.breakdown'],
  'dataset-4': ['source.positions', 'engine.calc_components', 'mart.breakdown_history'],
  'dataset-5': ['ref.thresholds', 'engine.calc_daily', 'mart.threshold_use'],
  'dataset-6': ['ref.thresholds', 'mart.threshold_history'],
};
function meta(id: string, rows: number, batch: number, p: Params) {
  const where = Object.entries(p).filter(([, v]) => v).map(([k]) => `${k} = :${k}`).join('\n  AND ');
  return {
    rowCount: rows, batchId: batch,
    queryId: `q-${id.split('-')[1]}-${batch.toString(16)}`,
    cache: (batch + rows) % 3 ? ('HIT' as const) : ('MISS' as const),
    lineage: LINEAGE[id],
    sql: `SELECT *\nFROM ${LINEAGE[id]?.[LINEAGE[id].length - 1] ?? id}\nWHERE batch_id = ${batch}${where ? '\n  AND ' + where : ''}`,
  };
}
const money = (field: string, headerName: string, extra: Partial<ColDefContract> = {}) => ({ field, headerName, type: ['money'], ...extra }) as ColDefContract;
function sd(xs: number[]) {
  const d = xs.slice(1).map((x, i) => x - xs[i]);
  const m = d.reduce((a, b) => a + b, 0) / d.length;
  return Math.sqrt(d.reduce((a, b) => a + (b - m) ** 2, 0) / d.length) || 1;
}

// dataset-1 · summary grid (one row per item, column group per model × measure)
function dataset1(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), off = COMPARE_OFFSET[p.compare || '1D'] ?? 1;
  const hf = (HORIZON_FACTOR[p.horizon || '1D'] ?? 1) * (ATTRIBUTE_FACTOR[p.attribute || 'a1'] ?? 1);
  const maxBy: Record<string, number> = {};
  const rows: Row[] = scope(p, false).map(({ it, i }) => {
    const r: Row = { id: it.id, label: it.label, category: it.category, limit: Math.round(it.limit * hf) };
    for (const g of groups) {
      const s = series(i, g, p, batch), cur = s[N - 1], prev = s[N - 1 - off];
      r[g.key + 'Current'] = Math.round(cur);
      r[g.key + 'Previous'] = Math.round(prev);
      r[g.key + 'Change'] = Math.round(cur) - Math.round(prev);
      maxBy[g.key] = Math.max(maxBy[g.key] ?? 0, cur);
      if (g.key === 'g1') {
        const z = (cur - prev) / (sd(s.slice(-61)) * Math.sqrt(off));
        if (Math.abs(z) >= 2) r._meta = { row: { badges: [{ text: (z > 0 ? '▲ ' : '▼ ') + Math.abs(z).toFixed(1) + 'σ', tone: z > 0 ? 'negative' : 'positive', tooltip: 'Unusual move vs typical daily change' }] } };
      }
    }
    r.ratio1 = (r.g1Current as number) / (r.limit as number);
    return r;
  });
  const total: Row = { id: 'total', label: 'Total' };
  for (const g of groups) for (const k of ['Current', 'Previous', 'Change']) total[g.key + k] = rows.reduce((a, r) => a + (r[g.key + k] as number), 0);
  const many = groups.length > 2;
  const columnDefs: ColDefContract[] = [
    {
      field: 'label', headerName: 'Item', pinned: 'left', minWidth: 190, type: ['text'], cellRenderer: 'labelCell', tooltipField: 'label', tooltipComponent: 'detailTooltip',
      tooltipComponentParams: { sections: [{ label: 'Current', field: 'g1Current' }, { label: 'Previous', field: 'g1Previous' }, { label: 'Change', field: 'g1Change', type: 'change' }, { label: 'Threshold', field: 'limit' }, { label: 'Utilisation', field: 'ratio1', type: 'percent' }] },
      rendererRules: [{ when: { row: 'pinned' }, renderer: 'totalCell' }],
    },
    { field: 'category', headerName: 'Segment', type: ['tag'], width: 96 },
    ...groups.map((g): ColDefContract => ({
      groupId: g.key, headerName: `${g.model.label} · ${g.measure.label}`,
      children: [
        money(g.key + 'Current', 'Current', { cellRenderer: 'smartCell', minWidth: 150, cellRendererParams: { previousField: g.key + 'Previous', changeField: g.key + 'Change', max: maxBy[g.key] || 1 } }),
        money(g.key + 'Previous', 'Previous', { hide: many }),
        money(g.key + 'Change', 'Change', { type: ['money', 'change'], hide: many }),
      ],
    })),
    { field: 'limit', headerName: 'Threshold', type: ['money'], hide: true },
    { field: 'ratio1', headerName: 'Utilisation', type: ['percent', 'threshold'], minWidth: 150, cellRendererParams: { warn: 0.8, breach: 1 },
      styleRules: [{ when: { op: 'gte', value: 1 }, tone: 'breach', emphasis: true }] },
  ];
  return {
    datasetId: 'dataset-1', kind: 'grid', version: `b${batch}-1`, asOf: ASOF(p), rowKey: 'id', columnDefs, rowData: rows, pinnedBottomRowData: [total],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'single', sideBar: 'none', statusBar: 'aggregations' }, meta: meta('dataset-1', rows.length, batch, p),
  };
}

// dataset-2 · trend (one row per business day, one field per series)
function dataset2(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), days = Number(p.days || 90), dates = businessDays(p.asOf || '2026-09-11', days);
  const items = scope(p, true);
  const sums = groups.map((g) => {
    const acc = new Array(N).fill(0);
    items.forEach(({ i }) => series(i, g, p, batch).forEach((v, k) => { acc[k] += v; }));
    return acc.slice(-days);
  });
  return {
    datasetId: 'dataset-2', kind: 'series', version: `b${batch}-2`, asOf: ASOF(p), rowKey: 'date',
    seriesDefs: groups.map((g, i) => ({ field: 's' + (i + 1), name: `${g.model.label} · ${g.measure.label}`, type: ['money'], palette: i + 1, dash: g.model.id === 'm2' })),
    rowData: dates.map((d, k) => Object.fromEntries([['date', d], ...groups.map((_, i) => ['s' + (i + 1), Math.round(sums[i][k])])])),
    meta: meta('dataset-2', days, batch, p),
  };
}

// dataset-3 · breakdown grid (one row per type)
function dataset3(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), off = COMPARE_OFFSET[p.compare || '1D'] ?? 1, items = scope(p, true);
  const totals = groups.map((g) => items.reduce((a, { i }) => { const s = series(i, g, p, batch); return [a[0] + s[N - 1], a[1] + s[N - 1 - off]]; }, [0, 0]));
  const rows: Row[] = BREAKDOWN.map((t, j) => {
    const r: Row = { id: t.id, label: t.label };
    groups.forEach((g, gi) => {
      const w = t.weight * (1 + 0.3 * Math.sin(j * 1.3 + gi)), wp = w * (1 + 0.05 * Math.cos(j + gi));
      r[g.key + 'Current'] = Math.round(totals[gi][0] * w);
      r[g.key + 'Previous'] = Math.round(totals[gi][1] * wp);
      r[g.key + 'Change'] = (r[g.key + 'Current'] as number) - (r[g.key + 'Previous'] as number);
    });
    return r;
  });
  const t1 = rows.reduce((a, r) => a + (r.g1Current as number), 0) || 1;
  rows.forEach((r) => { r.share = (r.g1Current as number) / t1; });
  rows.sort((a, b) => (b.g1Current as number) - (a.g1Current as number));
  const max = Math.max(1, ...rows.map((r) => r.g1Current as number));
  return {
    datasetId: 'dataset-3', kind: 'grid', version: `b${batch}-3`, asOf: ASOF(p), rowKey: 'id', rowData: rows,
    columnDefs: [
      { field: 'label', headerName: 'Type', pinned: 'left', minWidth: 120, type: ['text'] },
      ...groups.map((g): ColDefContract => ({
        groupId: g.key, headerName: `${g.model.label} · ${g.measure.label}`,
        children: [
          money(g.key + 'Current', 'Current', { cellRenderer: 'smartCell', minWidth: 150, cellRendererParams: { previousField: g.key + 'Previous', changeField: g.key + 'Change', max } }),
          money(g.key + 'Change', 'Change', { type: ['money', 'change'], hide: groups.length > 2 }),
        ],
      })),
      { field: 'share', headerName: 'Share', type: ['percent'], width: 100 },
    ],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'none' },
    meta: meta('dataset-3', rows.length, batch, p),
  };
}

// dataset-4 · breakdown over time (stacked series: top 6 types + other)
function dataset4(p: Params, batch: number): Dataset {
  const g = groupsFor(p)[0], days = Number(p.days || 90), dates = businessDays(p.asOf || '2026-09-11', days);
  const tot = new Array(N).fill(0);
  scope(p, true).forEach(({ i }) => series(i, g, p, batch).forEach((v, k) => { tot[k] += v; }));
  const top = BREAKDOWN.slice(0, 6);
  const rows = dates.map((d, k) => {
    const t = tot[N - days + k]; const r: Row = { date: d }; let used = 0;
    top.forEach((b, j) => { const v = t * b.weight * (1 + 0.14 * Math.sin(k / 4.3 + j * 1.7)); r['t' + (j + 1)] = Math.round(v); used += v; });
    r.other = Math.round(Math.max(0, t - used));
    return r;
  });
  return {
    datasetId: 'dataset-4', kind: 'series', version: `b${batch}-4`, asOf: ASOF(p), rowKey: 'date', rowData: rows,
    seriesDefs: [...top.map((b, j) => ({ field: 't' + (j + 1), name: b.label, type: ['money'], palette: j + 1, stack: 's' })), { field: 'other', name: 'Other', type: ['money'], palette: 8, stack: 's' }],
    meta: meta('dataset-4', days, batch, p),
  };
}

// dataset-5 · thresholds grid
function dataset5(p: Params, batch: number): Dataset {
  const g = groupsFor({ scenario: 'm1', measure: 'a' })[0];
  const rows: Row[] = THRESHOLDS.map((t) => {
    const s = series(t.itemIndex, g, p, batch), limit = ITEMS[t.itemIndex].limit;
    const exposure = Math.round(s[N - 1]), previous = Math.round(s[N - 2]);
    return { id: t.id, label: t.label, unit: t.unit, threshold: limit, exposure, previous, change: exposure - previous, ratio: exposure / limit };
  }).sort((a, b) => (b.ratio as number) - (a.ratio as number));
  const sum = (f: string) => rows.reduce((a, r) => a + (r[f] as number), 0);
  const total: Row = { id: 'total', label: 'Total', threshold: sum('threshold'), exposure: sum('exposure'), previous: sum('previous'), change: sum('change') };
  return {
    datasetId: 'dataset-5', kind: 'grid', version: `b${batch}-5`, asOf: ASOF(p), rowKey: 'id', rowData: rows, pinnedBottomRowData: [total],
    columnDefs: [
      { field: 'id', headerName: 'Id', pinned: 'left', width: 90, type: ['text'], rendererRules: [{ when: { row: 'pinned' }, renderer: 'emptyCell' }] },
      { field: 'label', headerName: 'Threshold', minWidth: 140, type: ['text'], rendererRules: [{ when: { row: 'pinned' }, renderer: 'totalCell' }] },
      { field: 'unit', headerName: 'Owner', type: ['tag'], width: 100 },
      money('threshold', 'Threshold'),
      money('exposure', 'Exposure'),
      { field: 'ratio', headerName: 'Utilisation', type: ['percent', 'threshold'], minWidth: 150, cellRendererParams: { warn: 0.8, breach: 1 } },
      money('change', '1D change', { type: ['money', 'change'] }),
    ],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'single' }, meta: meta('dataset-5', rows.length, batch, p),
  };
}

// dataset-6 · exposure vs threshold history for one threshold (default: highest utilisation)
function dataset6(p: Params, batch: number): Dataset {
  const ranked = [...THRESHOLDS].sort((a, b) => ITEMS[b.itemIndex].base.a / ITEMS[b.itemIndex].limit - ITEMS[a.itemIndex].base.a / ITEMS[a.itemIndex].limit);
  const t = THRESHOLDS.find((x) => x.id === p.thresholdId) ?? ranked[0];
  const limit = ITEMS[t.itemIndex].limit;
  const g = groupsFor({ scenario: 'm1', measure: 'a' })[0];
  const s = series(t.itemIndex, g, p, batch).slice(-90), dates = businessDays(p.asOf || '2026-09-11', 90);
  return {
    datasetId: 'dataset-6', kind: 'series', version: `b${batch}-6-${t.id}`, asOf: ASOF(p), rowKey: 'date',
    seriesDefs: [{ field: 'value', name: `${t.label} · exposure`, type: ['money'], palette: 1 }],
    rowData: dates.map((d, k) => ({ date: d, value: Math.round(s[k]), threshold: k < 45 ? Math.round(limit * 0.9) : limit })),
    meta: meta('dataset-6', 90, batch, { ...p, thresholdId: t.id }),
  };
}

const BUILDERS: Record<string, (p: Params, b: number) => Dataset> = {
  'dataset-1': dataset1, 'dataset-2': dataset2, 'dataset-3': dataset3, 'dataset-4': dataset4, 'dataset-5': dataset5, 'dataset-6': dataset6,
};
export const MOCK_DATASET_IDS = Object.keys(BUILDERS);

export function buildDataset(id: string, params: Params, batch: number): Dataset {
  const b = BUILDERS[id];
  if (!b) throw new Error('Unknown dataset ' + id);
  return b(params, batch);
}
