import type { ICellRendererParams, ITooltipParams } from 'ag-grid-community';
import type { Row } from '@/contracts';
import { formats, isNum } from '../lib/formats';

/** Name + row badges from _meta (e.g. "▲ 2.4σ"). */
export function LabelCell(p: ICellRendererParams) {
  const badges = (p.data as Row | undefined)?._meta?.row?.badges ?? [];
  return (
    <span className="lc">
      <span className="lc-text">{String(p.value ?? '')}</span>
      {badges.map((b, i) => <span key={i} className={'lc-badge tone-' + b.tone} title={b.tooltip}>{b.text}</span>)}
    </span>
  );
}

export function TagCell(p: ICellRendererParams) {
  return p.value ? <span className="tag">{String(p.value)}</span> : null;
}

/** Current value + bar + previous-value tick + change chip. */
export function SmartCell(p: ICellRendererParams & { previousField?: string; changeField?: string; max?: number }) {
  const v = p.value, data = p.data as Row | undefined;
  if (p.node?.rowPinned) return <span className="sc sc-total">{formats.millions(v)}</span>;
  const prev = p.previousField ? data?.[p.previousField] : undefined;
  const chg = p.changeField ? data?.[p.changeField] : undefined;
  const max = p.max || 1;
  const w = isNum(v) ? Math.min(100, (Math.abs(v) / max) * 100) : 0;
  const t = isNum(prev) ? Math.min(100, (Math.abs(prev) / max) * 100) : null;
  const tone = isNum(chg) ? (chg > 0 ? 'negative' : chg < 0 ? 'positive' : 'muted') : 'muted';
  return (
    <span className="sc">
      <span className="sc-track"><span className="sc-bar" style={{ width: w + '%' }} />{t !== null && <span className="sc-tick" style={{ left: t + '%' }} />}</span>
      <span className="sc-val">{formats.millions(v)}</span>
      {isNum(chg) && <span className={'sc-chip tone-' + tone}>{formats.millionsSigned(chg)}</span>}
    </span>
  );
}

/** Utilisation bar with warn marker. */
export function ThresholdCell(p: ICellRendererParams & { warn?: number; breach?: number }) {
  if (!isNum(p.value)) return null;
  const v = p.value, warn = p.warn ?? 0.8, breach = p.breach ?? 1;
  const tone = v >= breach ? 'breach' : v >= warn ? 'warn' : 'ok';
  return (
    <span className="tc">
      <span className="tc-track"><span className={'tc-fill tc-' + tone} style={{ width: Math.min(100, v * 100) + '%' }} /><span className="tc-mark" style={{ left: warn * 100 + '%' }} /></span>
      <span className={'tc-val tc-val-' + tone}>{formats.percent0(v)}</span>
    </span>
  );
}

export function TotalCell(p: ICellRendererParams) {
  const money = Array.isArray(p.colDef?.type) && p.colDef?.type.includes('money');
  return <b className="cell-total">{money ? formats.millions(p.value) : String(p.value ?? '')}</b>;
}

export function EmptyCell() { return <span className="tone-muted">—</span>; }

type Section = { label: string; field: string; type?: 'money' | 'percent' | 'change' };

/** Rich tooltip card. Sections come from tooltipComponentParams (service-defined). */
export function DetailTooltip(p: ITooltipParams & { sections?: Section[]; titleField?: string }) {
  const data = p.data as Row | undefined;
  if (!data) return null;
  const meta = data._meta;
  const f = (v: unknown, t?: string) => (t === 'percent' ? formats.percent1(v) : t === 'change' ? formats.fullSigned(v) : formats.full(v));
  const notes = meta?.cells ? Object.values(meta.cells).map((c) => c.note).filter(Boolean) : [];
  return (
    <div className="dt">
      <div className="dt-head">
        <b className="dt-title">{String(data[p.titleField ?? 'label'] ?? '')}</b>
        {!!data.category && <span className="tag">Segment {String(data.category)}</span>}
        {meta?.row?.badges?.map((b, i) => <span key={i} className={'lc-badge tone-' + b.tone}>{b.text} · {b.tooltip}</span>)}
      </div>
      <div className="dt-body">
        {(p.sections ?? []).filter((s) => data[s.field] !== undefined).map((s) => {
          const v = data[s.field];
          const tone = s.type === 'change' && isNum(v) ? (v > 0 ? 'tone-negative' : 'tone-positive') : s.type === 'percent' && isNum(v) && v >= 0.8 ? 'tone-warn-fg' : '';
          return <div key={s.field} className="dt-kv"><span>{s.label}</span><b className={tone}>{f(v, s.type)}</b></div>;
        })}
      </div>
      {notes.length > 0 && <div className="dt-note">{notes.join(' · ')}</div>}
    </div>
  );
}

export const gridComponents = {
  labelCell: LabelCell, tagCell: TagCell, smartCell: SmartCell, thresholdCell: ThresholdCell,
  totalCell: TotalCell, emptyCell: EmptyCell, detailTooltip: DetailTooltip,
};
