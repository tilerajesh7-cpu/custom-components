import type { KpiWidgetConfig, Row } from '@/contracts';
import { formats, isNum } from '../lib/formats';
import { Icon } from '../icons';
import type { WidgetProps } from './registry';

/** KPI tile: totals row (or first row) + change + sparkline from a related series dataset. */
export function KpiWidget({ config, dataset, related }: WidgetProps<KpiWidgetConfig>) {
  const row: Row | undefined = dataset?.kind === 'grid' && config.row === 'pinnedBottom' ? dataset.pinnedBottomRowData?.[0] : dataset?.rowData[0];
  const v = row?.[config.value];
  const c = config.compare ? row?.[config.compare] : undefined;
  const d = isNum(v) && isNum(c) ? v - c : undefined;
  const worse = config.tone !== 'higherIsBetter';
  const tone = d === undefined || d === 0 ? 'muted' : (d > 0) === worse ? 'negative' : 'positive';

  const [sparkId, sparkField] = (config.spark ?? '').split(':');
  const spark = sparkId ? (related[sparkId]?.rowData ?? []).slice(-40).map((r) => r[sparkField ?? '']).filter(isNum) : [];
  const paths = spark.length > 1 ? sparkPaths(spark) : undefined;

  return (
    <div className="kpi">
      <span className="kpi-label">{config.title}</span>
      <div className="kpi-row">
        <span className="kpi-value" title={formats.full(v)}>{formats.millions(v)}</span>
        <span className="kpi-unit">$MM</span>
        {d !== undefined && (
          <span className={'kpi-delta tone-' + tone} title={formats.fullSigned(d)}>
            <Icon name={d >= 0 ? 'trendUp' : 'trendDown'} size={12} />
            {formats.millionsSigned(d)} · {formats.percent1(isNum(c) && c ? d / c : 0)}
          </span>
        )}
      </div>
      {paths && (
        <svg className="kpi-spark" viewBox="0 0 120 34" preserveAspectRatio="none" aria-hidden="true">
          <defs><linearGradient id="kpiGrad" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#2f62c9" stopOpacity=".18" /><stop offset="1" stopColor="#2f62c9" stopOpacity="0" /></linearGradient></defs>
          <path className="area" d={paths.area} /><path className="line" d={paths.line} />
        </svg>
      )}
      {config.subtitle && <span className="kpi-sub">{config.subtitle}</span>}
    </div>
  );
}

function sparkPaths(vals: number[]) {
  const lo = Math.min(...vals), hi = Math.max(...vals), span = hi - lo || 1;
  const pts = vals.map((v, i) => [(i / (vals.length - 1)) * 120, 31 - ((v - lo) / span) * 28]);
  const line = pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');
  return { line, area: `${line} L120 34 L0 34 Z` };
}
