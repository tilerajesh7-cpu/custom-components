import type { ComponentType, MutableRefObject } from 'react';
import type { Dataset, SelectionState, WidgetConfig, WidgetEvent, WidgetStatus } from '@/contracts';

export type Density = 'compact' | 'comfortable' | 'spacious';
export interface GridPrefs { columns?: Record<string, boolean>; cellMode?: 'smart' | 'table' }
export type WidgetActions = Record<string, (() => void) | undefined>;

/** The one props contract every widget implements. Widgets never fetch or read global stores. */
export interface WidgetProps<C extends WidgetConfig = WidgetConfig> {
  config: C;
  dataset?: Dataset;
  related: Record<string, Dataset | undefined>;
  status: WidgetStatus;
  selection: SelectionState;
  clientFilters: Record<string, string>;
  density: Density;
  prefs?: GridPrefs;
  actionRef: MutableRefObject<WidgetActions>;
  onEvent: (e: WidgetEvent) => void;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const registry = new Map<string, ComponentType<WidgetProps<any>>>();
export function registerWidgetType<C extends WidgetConfig>(type: C['type'], component: ComponentType<WidgetProps<C>>) {
  registry.set(type, component);
}
export const getWidgetComponent = (type: string) => registry.get(type);
