import { themeQuartz } from 'ag-grid-community';

/** Tokens → AG Grid Theming API. Row height comes from density (see GridWidget). */
export const gridTheme = themeQuartz.withParams({
  fontFamily: "'IBM Plex Sans', system-ui, sans-serif",
  fontSize: 13,
  foregroundColor: '#101828',
  headerTextColor: '#667085',
  headerFontSize: 11.5,
  headerFontWeight: 600,
  headerBackgroundColor: '#f8fafd',
  backgroundColor: '#ffffff',
  oddRowBackgroundColor: '#ffffff',
  rowHoverColor: '#f5f8fd',
  selectedRowBackgroundColor: '#edf2fd',
  borderColor: '#eef1f6',
  rowBorder: { color: '#f1f3f7' },
  columnBorder: false,
  wrapperBorder: false,
  wrapperBorderRadius: 0,
  accentColor: '#2f5fd6',
  cellHorizontalPadding: 10,
  rangeSelectionBorderColor: '#2f5fd6',
});

export const ROW_HEIGHT = { compact: 34, comfortable: 40, spacious: 48 } as const;
export const HEADER_HEIGHT = { compact: 34, comfortable: 38, spacious: 42 } as const;
