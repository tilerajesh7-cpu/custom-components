import Highcharts from 'highcharts';
import * as Exporting from 'highcharts/modules/exporting';
import * as OfflineExporting from 'highcharts/modules/offline-exporting';
import * as ExportData from 'highcharts/modules/export-data';
import * as Accessibility from 'highcharts/modules/accessibility';

// Works for Highcharts 12 (modules self-register on import) and 11 (factory function).
function init(m: unknown) {
  const f = (m as { default?: unknown }).default ?? m;
  if (typeof f === 'function') (f as (h: typeof Highcharts) => void)(Highcharts);
}

export const SERIES_PALETTE = ['#2f62c9', '#7fa2fb', '#12918a', '#5cc9bf', '#d08a0e', '#7a5af0', '#c2392f', '#cfd5de'];

export function applyHighchartsTheme(): void {
  [Exporting, OfflineExporting, ExportData, Accessibility].forEach(init);
  Highcharts.setOptions({
    colors: SERIES_PALETTE,
    chart: { backgroundColor: 'transparent', style: { fontFamily: "'IBM Plex Sans', system-ui, sans-serif" }, spacing: [8, 6, 6, 4], animation: { duration: 250 } },
    title: { text: undefined },
    credits: { enabled: false },
    legend: { enabled: false },
    lang: { thousandsSep: ',' },
    xAxis: { lineColor: '#e4e8f0', tickColor: '#e4e8f0', labels: { style: { color: '#98a2b3', fontSize: '11px' } } },
    yAxis: { gridLineColor: '#eef1f6', title: { text: undefined }, labels: { style: { color: '#98a2b3', fontSize: '11px', fontFamily: "'IBM Plex Mono', monospace" } } },
    tooltip: {
      backgroundColor: 'rgba(16,24,40,.95)', borderWidth: 0, borderRadius: 12, shadow: false, padding: 10,
      style: { color: '#ffffff', fontSize: '12px' }, useHTML: true,
    },
    plotOptions: { series: { animation: { duration: 250 }, marker: { enabled: false }, states: { inactive: { opacity: 0.3 } } } },
    exporting: { enabled: false, fallbackToExportServer: false },
  } as Highcharts.Options);
}
