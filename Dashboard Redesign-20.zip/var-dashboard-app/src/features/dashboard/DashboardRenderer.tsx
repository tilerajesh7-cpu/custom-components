import { useMemo } from 'react';
import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { useAppSelector } from '@/app/hooks';
import { cssVars } from '@/shared/ui/controls';
import { WidgetHost } from './WidgetHost';
import './dashboard.css';

/** Renders the backend flex layout (rows filtered by the active tab). An item is one widget or a vertical stack. */
export function DashboardRenderer({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const tabId = useAppSelector((s) => s.ui.tab);
  const byId = useMemo(() => new Map(dashboard.widgets.map((w) => [w.widgetId, w])), [dashboard.widgets]);
  const tab = dashboard.tabs?.find((t) => t.tabId === tabId) ?? dashboard.tabs?.[0];
  const rows = dashboard.layout.rows.map((row, i) => ({ row, i })).filter(({ i }) => !tab || tab.rows.includes(i));
  const host = (id: string) => { const w = byId.get(id); return w ? <WidgetHost key={id} widget={w} dashboard={dashboard} datasets={datasets} /> : null; };
  return (
    <div className="dash">
      {rows.map(({ row, i }) => (
        <div key={i} className="dash-row">
          {row.items.map((it, j) => (
            <div key={it.widgetId ?? j} className="dash-slot" style={cssVars({ '--grow': it.grow, '--basis': it.basis + 'px', '--min-w': it.minW ? it.minW + 'px' : '0px' })}>
              {it.stack ? it.stack.map(host) : it.widgetId ? host(it.widgetId) : null}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
