import type { ReactNode } from 'react';
import type { Dashboard } from '@/contracts';
import { SegmentedControl } from '@/shared/ui/controls';
import { Icon } from '@/shared/ui/icons';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { clearAllSelections, clearSelection, setFilter } from './model';
import './filter-bar.css';

/** Sticky top area: title row + navy filter bar + cross-filter strip. Every change is one click. */
export function FilterBar({ dashboard, actions, banner, tabs, labelFor }: { dashboard: Dashboard; actions?: ReactNode; banner?: ReactNode; tabs?: ReactNode; labelFor: (widgetId: string, key: string) => string }) {
  const dispatch = useAppDispatch();
  const values = useAppSelector((s) => s.filters.values);
  const selection = useAppSelector((s) => s.selection.byWidget);
  const chips = Object.entries(selection);
  const date = dashboard.filters.find((f) => f.control === 'date');
  const segmented = dashboard.filters.filter((f) => f.control === 'segmented');

  return (
    <div className="fb-sticky">
      <header className="fb-head">
        <div className="fb-titles">
          {dashboard.breadcrumb && <div className="fb-crumb">{dashboard.breadcrumb.join(' / ')}</div>}
          <h1 className="fb-title">{dashboard.title}</h1>
        </div>
        {tabs}
        <div className="fb-actions">{actions}</div>
      </header>
      <div className="fb-bar">
        {date && (
          <label className="fb-date">
            <Icon name="history" size={14} />
            <span className="seg-label">{date.label}</span>
            <input type="date" value={values[date.filterId] ?? date.default} onChange={(e) => e.target.value && dispatch(setFilter({ id: date.filterId, value: e.target.value }))} />
          </label>
        )}
        {segmented.map((f) => (
          <SegmentedControl key={f.filterId} label={f.label} value={values[f.filterId] ?? f.default} options={f.options ?? []}
            onChange={(v) => dispatch(setFilter({ id: f.filterId, value: v }))} />
        ))}
      </div>
      <div className={'fb-cross' + (chips.length ? ' has-chips' : '')}>
        <span className="fb-cross-label"><Icon name="filter" size={12} />Cross-filters<b>{chips.length}</b></span>
        {chips.length === 0 && <span className="fb-cross-hint">Click a desk, FS type, legend or limit to filter related panels</span>}
        {chips.map(([wid, keys]) => (
          <span key={wid} className="fb-chip">
            <span className="fb-chip-kind">{dashboard.widgets.find((w) => w.widgetId === wid)?.title ?? wid}</span>
            <b>{keys.map((k) => labelFor(wid, k)).join(', ')}</b>
            <button type="button" aria-label="Remove filter" onClick={() => dispatch(clearSelection(wid))}><Icon name="x" size={11} strokeWidth={2.4} /></button>
          </span>
        ))}
        {chips.length > 0 && <button type="button" className="fb-clear" onClick={() => dispatch(clearAllSelections())}>Clear all <kbd className="kbd">Esc</kbd></button>}
      </div>
      {banner}
    </div>
  );
}
