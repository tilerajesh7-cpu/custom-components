import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { IconButton } from '@/shared/ui/controls';
import { formats, isNum } from '@/shared/ui/lib/formats';
import { dismissAlert, setSelection, setTab } from './model';
import { scrollToWidget } from '@/features/command-palette/scroll';

/** Tab bar from dashboard.tabs. */
export function TabBar({ dashboard }: { dashboard: Dashboard }) {
  const dispatch = useAppDispatch();
  const current = useAppSelector((s) => s.ui.tab);
  if (!dashboard.tabs?.length) return null;
  const active = dashboard.tabs.find((t) => t.tabId === current) ? current : dashboard.tabs[0].tabId;
  return (
    <div className="tabs" role="tablist" aria-label="Sections">
      {dashboard.tabs.map((t) => (
        <button key={t.tabId} type="button" role="tab" aria-selected={t.tabId === active} className={'tab' + (t.tabId === active ? ' is-on' : '')} onClick={() => dispatch(setTab(t.tabId))}>{t.label}</button>
      ))}
    </div>
  );
}

/** “Limits need attention” strip: rows ≥ warn; each pill selects the row in the target grid. */
export function AttentionStrip({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const dispatch = useAppDispatch();
  const dismissed = useAppSelector((s) => s.ui.alertDismissed);
  const selected = useAppSelector((s) => (dashboard.alerts ? s.selection.byWidget[dashboard.alerts.target] : undefined));
  const cfg = dashboard.alerts;
  const ds = cfg ? datasets[cfg.datasetId]?.data : undefined;
  if (!cfg || !ds || dismissed) return null;
  const hits = ds.rowData.filter((r) => isNum(r[cfg.field]) && (r[cfg.field] as number) >= cfg.warn).sort((a, b) => (b[cfg.field] as number) - (a[cfg.field] as number));
  if (!hits.length) return null;
  return (
    <div className="alert" role="status">
      <span className="alert-title"><span className="alert-dot" />{hits.length} limit{hits.length === 1 ? '' : 's'} need attention</span>
      {hits.map((r) => {
        const key = String(r[ds.rowKey]), v = r[cfg.field] as number, on = selected?.includes(key);
        return (
          <button key={key} type="button" className={'alert-pill ' + (v >= cfg.breach ? 'is-breach' : 'is-warn') + (on ? ' is-on' : '')}
            onClick={() => { dispatch(setSelection({ widgetId: cfg.target, keys: on ? [] : [key] })); dispatch(setTab(dashboard.tabs?.[0]?.tabId ?? 'overview')); scrollToWidget(cfg.target); }}>
            {String(r[cfg.labelField] ?? key)}<b>{formats.percent0(v)}</b>
          </button>
        );
      })}
      <IconButton icon="x" title="Dismiss" className="alert-close" onClick={() => dispatch(dismissAlert())} />
    </div>
  );
}
