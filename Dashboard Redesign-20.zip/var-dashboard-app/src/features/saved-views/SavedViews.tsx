import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import type { Dashboard } from '@/contracts';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { applyFilters, clearAllSelections, setSaveOpen } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import { Modal, Popover, toast } from '@/shared/ui/controls';
import { copyText } from '@/shared/ui/lib/download';
import { addView, removeView, setDefaultView } from './model';
import './views.css';

export interface ViewItem { viewId: string; name: string; filters: Record<string, string>; builtIn: boolean }

const encode = (f: Record<string, string>) => btoa(unescape(encodeURIComponent(JSON.stringify(f))));
const decode = (s: string): Record<string, string> | null => { try { return JSON.parse(decodeURIComponent(escape(atob(s)))); } catch { return null; } };

/** Built-in views (from services) + personal views; full filter sets merged over defaults. */
export function useViews(dashboard: Dashboard | undefined) {
  const dispatch = useAppDispatch();
  const personal = useAppSelector((s) => s.savedViews.views);
  const defaults = useAppSelector((s) => s.savedViews.defaults);
  const filters = useAppSelector((s) => s.filters.values);
  const base = useMemo(() => Object.fromEntries((dashboard?.filters ?? []).filter((f) => f.control !== 'date').map((f) => [f.filterId, f.default])), [dashboard]);

  const all: ViewItem[] = useMemo(() => [
    ...(dashboard?.views ?? []).map((v) => ({ viewId: v.viewId, name: v.name, filters: { ...base, ...v.filters }, builtIn: true })),
    ...personal.filter((v) => v.dashboardId === dashboard?.dashboardId).map((v) => ({ viewId: v.viewId, name: v.name, filters: { ...base, ...v.filters }, builtIn: false })),
  ], [dashboard, personal, base]);

  const active = all.find((v) => Object.keys(base).every((k) => v.filters[k] === filters[k]));
  const apply = useCallback((v: ViewItem) => { dispatch(applyFilters(v.filters)); dispatch(clearAllSelections()); }, [dispatch]);
  const defaultId = dashboard ? defaults[dashboard.dashboardId] : undefined;
  const current = useMemo(() => Object.fromEntries(Object.keys(base).map((k) => [k, filters[k]])), [base, filters]);
  return { all, active, apply, defaultId, current };
}

/** On first load: ?view=<encoded> from a shared link wins, else the user's default view. */
export function useInitialView(dashboard: Dashboard | undefined, ready: boolean) {
  const { all, apply, defaultId } = useViews(dashboard);
  const [params, setParams] = useSearchParams();
  const done = useRef(false);
  const dispatch = useAppDispatch();
  useEffect(() => {
    if (!dashboard || !ready || done.current) return;
    done.current = true;
    const shared = params.get('view');
    if (shared) {
      const f = decode(shared);
      if (f) { dispatch(applyFilters(f)); toast('Shared view applied'); }
      params.delete('view'); setParams(params, { replace: true });
      return;
    }
    const def = all.find((v) => v.viewId === defaultId);
    if (def) apply(def);
  }, [dashboard, ready, all, apply, defaultId, params, setParams, dispatch]);
}

export function SavedViewsMenu({ dashboard }: { dashboard: Dashboard }) {
  const dispatch = useAppDispatch();
  const { all, active, apply, defaultId, current } = useViews(dashboard);
  const [name, setName] = useState('');

  const save = () => {
    const n = name.trim(); if (!n) return;
    dispatch(addView({ viewId: 'u-' + Date.now().toString(36), dashboardId: dashboard.dashboardId, name: n, filters: current, createdAt: Date.now() }));
    setName(''); toast(`View “${n}” saved`);
  };
  const share = async () => {
    const url = `${location.origin}${location.pathname}#/dashboards/${dashboard.dashboardId}?view=${encode(current)}`;
    if (await copyText(url)) toast('Link copied');
  };

  return (
    <Popover width={320} title="Saved views" trigger={
      <span className="hdr-btn"><Icon name="bookmark" size={14} /><span className="sv-name">{active?.name ?? 'Custom view'}</span><Icon name="chevronDown" size={13} /></span>
    }>
      {(close) => (
        <div className="sv">
          <div className="menu-title">Views</div>
          {all.map((v, i) => (
            <div key={v.viewId} className={'sv-item' + (active?.viewId === v.viewId ? ' is-active' : '')}>
              <button type="button" className="sv-apply" onClick={() => { apply(v); close(); }}>
                <span className="sv-num">{i < 9 ? i + 1 : ''}</span>
                <span className="sv-label">{v.name}</span>
                {v.builtIn && <span className="sv-tag">Built-in</span>}
              </button>
              <button type="button" className={'sv-star' + (defaultId === v.viewId ? ' is-on' : '')} title={defaultId === v.viewId ? 'Default view (click to unset)' : 'Open this view by default'}
                onClick={() => dispatch(setDefaultView({ dashboardId: dashboard.dashboardId, viewId: defaultId === v.viewId ? null : v.viewId }))}>
                <Icon name="star" size={14} fill={defaultId === v.viewId ? 'currentColor' : 'none'} />
              </button>
              {!v.builtIn && <button type="button" className="sv-del" title="Delete view" onClick={() => dispatch(removeView(v.viewId))}><Icon name="trash" size={14} /></button>}
            </div>
          ))}
          <div className="menu-sep" />
          <form className="sv-save" onSubmit={(e) => { e.preventDefault(); save(); }}>
            <input className="input" placeholder="Name this view…" value={name} onChange={(e) => setName(e.target.value)} aria-label="View name" />
            <button type="submit" className="btn btn-primary" disabled={!name.trim()}>Save</button>
          </form>
          <button type="button" className="menu-item" onClick={() => { void share(); close(); }}><Icon name="link" size={14} />Copy link to this view</button>
          <div className="sv-hint">Press <kbd className="kbd">1</kbd>–<kbd className="kbd">9</kbd> to switch views</div>
        </div>
      )}
    </Popover>
  );
}

/** "S" shortcut / palette: save the current filters as a personal view. */
export function SaveViewDialog({ dashboard }: { dashboard: Dashboard }) {
  const open = useAppSelector((s) => s.ui.saveOpen);
  const dispatch = useAppDispatch();
  const { current } = useViews(dashboard);
  const [name, setName] = useState('');
  const close = () => { dispatch(setSaveOpen(false)); setName(''); };
  const save = () => {
    const n = name.trim(); if (!n) return;
    dispatch(addView({ viewId: 'u-' + Date.now().toString(36), dashboardId: dashboard.dashboardId, name: n, filters: current, createdAt: Date.now() }));
    toast(`View “${n}” saved`); close();
  };
  const summary = dashboard.filters.filter((f) => f.control !== 'date').map((f) => f.options?.find((o) => o.value === current[f.filterId])?.label ?? current[f.filterId]).join(' · ');
  return (
    <Modal open={open} onClose={close} title="Save current view" width={440}>
      <form className="sv-dialog" onSubmit={(e) => { e.preventDefault(); save(); }}>
        <input className="input" autoFocus placeholder="e.g. Morning EMEA check" value={name} onChange={(e) => setName(e.target.value)} aria-label="View name" />
        <p className="sv-summary">{summary}</p>
        <div className="sv-dialog-actions">
          <button type="button" className="btn" onClick={close}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={!name.trim()}>Save view</button>
        </div>
      </form>
    </Modal>
  );
}
