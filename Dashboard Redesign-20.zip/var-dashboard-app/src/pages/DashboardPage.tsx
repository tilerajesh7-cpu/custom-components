import { useCallback, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useDashboard, useDatasets } from '@/api/queries';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { initFilters, setHelp, setPalette } from '@/features/dashboard/model';
import { DashboardRenderer } from '@/features/dashboard/DashboardRenderer';
import { FilterBar } from '@/features/dashboard/FilterBar';
import { labelFor } from '@/features/dashboard/labels';
import { SaveViewDialog, SavedViewsMenu, useInitialView } from '@/features/saved-views/SavedViews';
import { AttentionStrip, TabBar } from '@/features/dashboard/Sections';
import { LiveBanner, LiveRefreshControl, useLiveRefresh } from '@/features/live-refresh/LiveRefresh';
import { DisplaySettings } from '@/features/settings/DisplaySettings';
import { CommandPalette } from '@/features/command-palette/CommandPalette';
import { HelpDialog, useShortcuts } from '@/features/command-palette/shortcuts';
import { DevConsole } from '@/features/dev-tools/DevConsole';
import { QueryInspector } from '@/features/dev-tools/QueryInspector';
import { devBus } from '@/features/dev-tools/bus';
import { WidgetFrame } from '@/shared/ui/widgets';
import { Icon } from '@/shared/ui/icons';
import { Kbd } from '@/shared/ui/controls';

/** Route /#/dashboards/:dashboardId — everything on screen comes from the dashboard definition. */
export default function DashboardPage() {
  const { dashboardId = 'dashboard-1' } = useParams();
  const dispatch = useAppDispatch();
  const dash = useDashboard(dashboardId);
  const filters = useAppSelector((s) => s.filters.values);
  const selection = useAppSelector((s) => s.selection.byWidget);
  const density = useAppSelector((s) => s.preferences.density);

  useEffect(() => {
    if (dash.data) dispatch(initFilters(Object.fromEntries(dash.data.filters.map((f) => [f.filterId, f.default]))));
  }, [dash.data, dispatch]);

  const ready = !!dash.data && dash.data.filters.every((f) => f.filterId in filters);
  useInitialView(dash.data, ready);
  const datasets = useDatasets(ready ? dash.data!.datasets : undefined, filters, selection);
  const live = useLiveRefresh();
  const refresh = useCallback(() => live.apply(), [live]);
  useShortcuts(dash.data, refresh);

  useEffect(() => { document.documentElement.dataset.density = density; }, [density]);

  if (dash.isError) {
    return <div className="page-state"><WidgetFrame title="Dashboard" status="error" onRetry={() => void dash.refetch()}><span /></WidgetFrame></div>;
  }
  if (!dash.data) {
    return <div className="page-state page-loading"><div className="page-loading-card"><WidgetFrame status="loading"><span /></WidgetFrame></div></div>;
  }
  const d = dash.data;
  return (
    <div data-density={density}>
      <FilterBar
        dashboard={d}
        labelFor={(wid, key) => labelFor(d, datasets, wid, key)}
        tabs={<TabBar dashboard={d} />}
        banner={<LiveBanner live={live} />}
        actions={
          <>
            <SavedViewsMenu dashboard={d} />
            <LiveRefreshControl live={live} />
            <button type="button" className="hdr-btn" onClick={() => dispatch(setPalette(true))} title="Command palette"><Icon name="search" size={14} />Search<Kbd>Ctrl K</Kbd></button>
            <DisplaySettings />
            <button type="button" className="hdr-btn is-icon" onClick={() => dispatch(setHelp(true))} title="Keyboard shortcuts (?)"><Icon name="help" size={16} /></button>
          </>
        }
      />
      <AttentionStrip dashboard={d} datasets={datasets} />
      <DashboardRenderer dashboard={d} datasets={datasets} />
      <SaveViewDialog dashboard={d} />
      <CommandPalette dashboard={d} onRefresh={refresh} />
      <HelpDialog dashboard={d} />
      {devBus.enabled && <DevConsole dashboard={d} datasets={datasets} />}
      {devBus.enabled && <QueryInspector dashboard={d} datasets={datasets} />}
    </div>
  );
}
