import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { GetRowIdParams, GridApi, IRowNode, RowClassParams, RowClickedEvent } from 'ag-grid-community';
import type { GridWidgetConfig, Row } from '@/contracts';
import { gridTheme, HEADER_HEIGHT, ROW_HEIGHT } from '@/theme/agGridTheme';
import { downloadText, copyText } from '../lib/download';
import { cssVars } from '../controls';
import type { WidgetProps } from '../widgets/registry';
import { columnTypes, excelStyles } from './columnTypes';
import { resolveColumnDefs } from './resolveColumnDefs';
import { buildGridOptions } from './buildGridOptions';
import { gridComponents } from './renderers';
import { GridToolbar } from './GridToolbar';
import './grid.css';

/** Grid widget: service rowData / columnDefs pass straight to AG Grid (client-side row model). */
export function GridWidget({ config, dataset, selection, clientFilters, onEvent, density, prefs, actionRef }: WidgetProps<GridWidgetConfig>) {
  const ds = dataset?.kind === 'grid' ? dataset : undefined;
  const apiRef = useRef<GridApi<Row> | null>(null);
  const [search, setSearch] = useState('');
  const features = config.presentation?.features ?? {};
  const cellMode = prefs?.cellMode ?? config.presentation?.cellMode ?? 'smart';
  const visibility = prefs?.columns ?? {};

  // Rebuild columns only when the column contract, mode or visibility actually change.
  const colKey = ds ? JSON.stringify(ds.columnDefs) : '';
  const visKey = JSON.stringify(visibility);
  const columnDefs = useMemo(
    () => (ds ? resolveColumnDefs(ds.columnDefs, { cellMode, visibility }) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [colKey, cellMode, visKey],
  );
  const gridOptions = useMemo(() => buildGridOptions(ds?.gridOptions), [JSON.stringify(ds?.gridOptions ?? {})]); // eslint-disable-line react-hooks/exhaustive-deps
  const rowKey = ds?.rowKey ?? 'id';
  const getRowId = useCallback((p: GetRowIdParams<Row>) => String(p.data[rowKey]), [rowKey]);

  // Client filters + selections from other widgets → external filter (no data copy).
  const listens = config.interactions?.listens ?? [];
  const active = useMemo(() => {
    const f: [string, string[]][] = Object.entries(clientFilters).filter(([, v]) => v && v !== 'all').map(([k, v]) => [k, [v]]);
    for (const l of listens) { const keys = selection[l.from]; if (keys?.length && !l.field.startsWith('$')) f.push([l.field, keys]); }
    return f;
  }, [clientFilters, selection, listens]);
  const activeRef = useRef(active);
  activeRef.current = active;
  const isExternalFilterPresent = useCallback(() => activeRef.current.length > 0, []);
  const doesExternalFilterPass = useCallback((n: IRowNode<Row>) => activeRef.current.every(([field, vals]) => vals.includes(String(n.data?.[field]))), []);
  useEffect(() => { apiRef.current?.onFilterChanged(); }, [active]);

  // Highlight this widget's selection.
  const mine = selection[config.widgetId];
  const syncSelection = useCallback(() => {
    const api = apiRef.current;
    if (!api || !ds?.gridOptions?.rowSelection || ds.gridOptions.rowSelection === 'none') return;
    api.forEachNode((n) => n.setSelected(!!mine?.includes(n.id ?? ''), false, 'api'));
  }, [mine, ds?.gridOptions?.rowSelection]);
  useEffect(syncSelection, [syncSelection, ds?.version]);

  useEffect(() => { apiRef.current?.resetRowHeights(); }, [density]);

  const emit = config.interactions?.emits?.find((e) => e.on === 'rowClick');
  const onRowClicked = useCallback((e: RowClickedEvent<Row>) => {
    if (!emit || e.rowPinned || !e.data) return;
    const key = String(e.data[rowKey]);
    const target = emit.target ?? config.widgetId;
    onEvent({ kind: 'selection', widgetId: target, keys: selection[target]?.includes(key) ? [] : [key] });
  }, [emit, rowKey, onEvent, config.widgetId, selection]);

  const getRowClass = useCallback((p: RowClassParams<Row>) => {
    const t = p.data?._meta?.row?.tone;
    return [t ? 'row-tone-' + t : '', emit && !p.node.rowPinned ? 'row-clickable' : ''].filter(Boolean).join(' ') || undefined;
  }, [emit]);

  // Export actions for the frame's menu.
  actionRef.current = {
    'export.csv': () => apiRef.current?.exportDataAsCsv({ fileName: `${config.widgetId}.csv` }),
    'export.excel': () => apiRef.current?.exportDataAsExcel({ fileName: `${config.widgetId}.xlsx`, sheetName: config.title.slice(0, 31) }),
    'export.copy': () => { const t = apiRef.current?.getDataAsCsv({ columnSeparator: '\t' }); if (t) void copyText(t); },
    'export.json': () => { if (ds) downloadText(`${config.widgetId}.json`, JSON.stringify(ds.rowData, null, 2), 'application/json'); },
  };

  const hasSmart = !!ds && JSON.stringify(ds.columnDefs).includes('"smartCell"');
  return (
    <div className="gw">
      {(features.search || features.columnsPanel || features.cellModeToggle) && ds && (
        <GridToolbar
          defs={ds.columnDefs}
          rowCount={ds.rowData.length}
          visibility={visibility}
          showColumns={!!features.columnsPanel}
          onVisibility={(patch) => onEvent({ kind: 'preferenceChange', widgetId: config.widgetId, key: 'columns', value: patch })}
          onReset={() => onEvent({ kind: 'preferenceChange', widgetId: config.widgetId, key: 'reset' })}
          search={features.search ? { value: search, onChange: setSearch } : undefined}
          cellMode={features.cellModeToggle && hasSmart ? { value: cellMode, onChange: (v) => onEvent({ kind: 'preferenceChange', widgetId: config.widgetId, key: 'cellMode', value: v }) } : undefined}
        />
      )}
      <div className="gw-grid" style={cssVars({ '--grid-h': (config.presentation?.height ?? 420) + 'px' })}>
        <AgGridReact<Row>
          theme={gridTheme}
          {...gridOptions}
          rowHeight={ROW_HEIGHT[density]}
          headerHeight={HEADER_HEIGHT[density]}
          groupHeaderHeight={HEADER_HEIGHT[density]}
          columnTypes={columnTypes}
          components={gridComponents}
          excelStyles={excelStyles}
          columnDefs={columnDefs}
          rowData={ds?.rowData}
          pinnedBottomRowData={ds?.pinnedBottomRowData}
          getRowId={getRowId}
          quickFilterText={search}
          isExternalFilterPresent={isExternalFilterPresent}
          doesExternalFilterPass={doesExternalFilterPass}
          getRowClass={getRowClass}
          onRowClicked={onRowClicked}
          onGridReady={(e) => { apiRef.current = e.api; syncSelection(); }}
          onRowDataUpdated={syncSelection}
        />
      </div>
    </div>
  );
}
