import type { MutableRefObject } from 'react';
import { Icon } from '../icons';
import { Popover, toast } from '../controls';
import type { WidgetActions } from './registry';

const LABELS: Record<string, [string, string]> = {
  'export.excel': ['Excel (.xlsx)', 'Keeps colours and number formats'],
  'export.csv': ['CSV', 'Raw values'],
  'export.copy': ['Copy for Excel', 'Paste into any sheet'],
  'export.json': ['JSON', 'Rows as delivered'],
  'export.png': ['PNG image', ''],
  'export.svg': ['SVG vector', ''],
};

export function ExportMenu({ actions, actionRef }: { actions: string[]; actionRef: MutableRefObject<WidgetActions> }) {
  const list = actions.filter((a) => a.startsWith('export.'));
  if (!list.length) return null;
  return (
    <Popover title="Export" width={250} trigger={<span className="export-btn"><Icon name="download" size={14} />Export</span>}>
      {(close) => (
        <>
          <div className="menu-title">Export data</div>
          {list.map((a) => (
            <button key={a} type="button" className="menu-item" onClick={() => {
              const fn = actionRef.current[a];
              close();
              if (fn) { fn(); toast(a === 'export.copy' ? 'Copied to clipboard' : `${LABELS[a]?.[0] ?? a} downloaded`); }
            }}>
              <Icon name={a === 'export.copy' ? 'copy' : 'download'} size={14} />
              <span className="menu-item-text">
                <span>{LABELS[a]?.[0] ?? a}</span>
                {LABELS[a]?.[1] && <span className="menu-item-sub">{LABELS[a][1]}</span>}
              </span>
            </button>
          ))}
        </>
      )}
    </Popover>
  );
}
