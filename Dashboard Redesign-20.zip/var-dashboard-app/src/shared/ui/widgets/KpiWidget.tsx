import type { KpiWidgetConfig, Row } from '@/contracts';
import { formats, isNum } from '../lib/formats';
import { Icon } from '../icons';
import { cssVars } from '../controls';
import type { WidgetProps } from './registry';

const FMT = { money: formats.millions, moneySigned: formats.millionsSigned, percent: formats.percent1, count: formats.count };

/** KPI tile. Modes: value (+ change + sparkline or bar) · countAtRisk (rows ≥ 80% / ≥ 100%) · maxAbs (largest move + its label). */
export function KpiWidget({ config, dataset, related, clientFilters }: WidgetProps<KpiWidgetConfig>) {
  const fmt = FMT[config.format ?? 'money'];
  const rows: Row[] = dataset?.rowData ?? [];
  const mode = config.mode ?? 'value';
  let value: unknown, sub = config.subtitle?.replace(/\{filter\.(\w+)\}/g, (_, k: string) => clientFilters[k] ?? '') ?? '', delta: number | undefined, pct: number | undefined, tone = 'muted', bar: number | undefined;

  if (mode === 'countAtRisk') {
    const at = rows.filter((r) => isNum(r[config.value]) && (r[config.value] as number) >= 0.8);
    const over = at.filter((r) => (r[config.value] as number) >= 1).length;
    value = at.length;
    sub = `${over} above 100% · ${at.length - over} at 80–100%`;
    tone = over ? 'negative' : at.length ? 'warn' : 'positive';
  } else if (mode === 'maxAbs') {
    const top = rows.filter((r) => isNum(r[config.value])).sort((a, b) => Math.abs(b[config.value] as number) - Math.abs(a[config.value] as number))[0];
    value = top?.[config.value];
    sub = top ? String(top[config.labelField ?? 'label'] ?? '') : '';
    tone = isNum(value) ? (value > 0 ? 'negative' : value < 0 ? 'positive' : 'muted') : 'muted';
  } else {
    const row: Row | undefined = dataset?.kind === 'grid' && config.row === 'pinnedBottom' ? dataset.pinnedBottomRowData?.[0] : rows[0];
    value = row?.[config.value];
    const c = config.compare ? row?.[config.compare] : undefined;
    if (isNum(value) && isNum(c)) {
      delta = value - c; pct = c ? delta / c : 0;
      const worse = config.tone !== 'higherIsBetter';
      tone = delta === 0 ? 'muted' : (delta > 0) === worse ? 'negative' : 'positive';
    }
    if (config.bar && isNum(value)) { bar = value; tone = value >= 1 ? 'negative' : value >= 0.8 ? 'warn' : 'info'; }
  }

  const [sparkId, sparkField] = (config.spark ?? '').split(':');
  const spark = sparkId ? (related[sparkId]?.rowData ?? []).slice(-30).map((r) => r[sparkField ?? '']).filter(isNum) : [];
  const paths = spark.length > 1 ? sparkPaths(spark) : undefined;
  const valueTone = mode === 'maxAbs' || mode === 'countAtRisk' ? ' tone-' + tone : '';

  return (
    <div className="kpi">
      <span className="kpi-label">{config.title}</span>
      <div className="kpi-row">
        <span className={'kpi-value' + valueTone} title={config.format === 'percent' || config.format === 'count' ? undefined : formats.full(value)}>
          {(config.format ?? 'money') === 'money' && '$'}{fmt(value)}
        </span>
        {delta !== undefined && (
          <span className={'kpi-delta tone-' + tone} title={formats.fullSigned(delta)}>
            <Icon name={delta >= 0 ? 'trendUp' : 'trendDown'} size={12} />{formats.millionsSigned(delta)} · {pct !== undefined && (pct >= 0 ? '+' : '')}{formats.percent1(pct)}
          </span>
        )}
      </div>
      {paths && (
        <svg className="kpi-spark" viewBox="0 0 120 34" preserveAspectRatio="none" aria-hidden="true">
          <defs><linearGradient id={'kg-' + config.widgetId} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#2f62c9" stopOpacity=".18" /><stop offset="1" stopColor="#2f62c9" stopOpacity="0" /></linearGradient></defs>
          <path d={paths.area} fill={`url(#kg-${config.widgetId})`} /><path className="line" d={paths.line} />
        </svg>
      )}
      {bar !== undefined && (
        <div className="kpi-bar"><span className={'kpi-bar-fill tone-' + tone} style={cssVars({ '--pct': Math.min(100, bar * 100) + '%' })} /><span className="kpi-bar-mark" /></div>
      )}
      {sub && <span className="kpi-sub">{sub}</span>}
    </div>
  );
}

function sparkPaths(vals: number[]) {
  const lo = Math.min(...vals), hi = Math.max(...vals), span = hi - lo || 1;
  const pts = vals.map((v, i) => [(i / (vals.length - 1)) * 120, 31 - ((v - lo) / span) * 28]);
  const line = pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');
  return { line, area: `${line} L120 34 L0 34 Z` };
}
