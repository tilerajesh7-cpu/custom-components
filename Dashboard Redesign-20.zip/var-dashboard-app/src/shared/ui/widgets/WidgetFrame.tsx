import type { ReactNode } from 'react';
import type { WidgetStatus } from '@/contracts';
import { Icon } from '../icons';
import './widgets.css';

interface Props {
  id?: string;
  title?: string;
  subtitle?: string;
  filteredBy?: string[];
  onClearFilter?: () => void;
  actions?: ReactNode;
  status: WidgetStatus;
  emptyText?: string;
  onRetry?: () => void;
  bare?: boolean;
  children: ReactNode;
}

/** Card for every widget: header, "Filtered by" badge, actions, per-widget loading / empty / error states. */
export function WidgetFrame({ id, title, subtitle, filteredBy, onClearFilter, actions, status, emptyText, onRetry, bare, children }: Props) {
  const showBody = status === 'ready' || status === 'refreshing';
  const busy = status === 'loading' || status === 'refreshing';
  return (
    <section id={id} className={'wf' + (bare ? ' wf-bare' : '')} aria-busy={busy}>
      {(title || actions) && (
        <header className="wf-head">
          <div className="wf-titles">
            {title && <h2 className="wf-title">{title}</h2>}
            {subtitle && <span className="wf-sub">{subtitle}</span>}
          </div>
          {actions && <div className="wf-actions">{actions}</div>}
        </header>
      )}
      {filteredBy && filteredBy.length > 0 && (
        <button type="button" className="wf-badge" onClick={onClearFilter} title="Clear this filter">
          <Icon name="filter" size={12} />
          <span>Filtered by <b>{filteredBy.join(' + ')}</b></span>
          <Icon name="x" size={12} />
        </button>
      )}
      <div className="wf-body">
        {showBody && children}
        {status === 'empty' && <div className="wf-state"><span className="wf-state-icon"><Icon name="search" size={18} /></span>{emptyText ?? 'No data for these filters'}</div>}
        {status === 'forbidden' && <div className="wf-state"><span className="wf-state-icon"><Icon name="alert" size={18} /></span>You don’t have access to this panel</div>}
        {status === 'error' && (
          <div className="wf-state">
            <span className="wf-state-icon wf-state-err"><Icon name="alert" size={18} /></span>
            <b>Couldn’t load this panel</b>
            {onRetry && <button type="button" className="btn btn-primary" onClick={onRetry}><Icon name="refresh" size={13} />Retry</button>}
          </div>
        )}
        {busy && (
          <div className={'wf-loader' + (status === 'loading' ? ' is-initial' : '')} role="status" aria-label="Loading">
            <span className="wf-shimmer" />
            <span className="wf-spinner"><span className="wf-ring" /><span className="wf-ring wf-ring-inner" /><span className="wf-core" /></span>
            <span className="wf-loader-label">{status === 'loading' ? 'Loading' : 'Updating'}</span>
          </div>
        )}
      </div>
    </section>
  );
}
