import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { Icon } from '../icons';
import './controls.css';

/** Runtime values only (widths, positions, backend-driven sizes) — passed as CSS custom properties; all styling lives in .css files. */
export const cssVars = (vars: Record<string, string | number>) => vars as CSSProperties;

export interface SegmentedOption { value: string; label: string }

/** One-click segmented control. */
export function SegmentedControl({ label, value, options, onChange, tone = 'dark', size = 'md' }: {
  label?: string; value: string; options: SegmentedOption[]; onChange: (v: string) => void; tone?: 'dark' | 'light'; size?: 'sm' | 'md';
}) {
  return (
    <div className={`seg seg-${tone} seg-${size}`}>
      {label && <span className="seg-label">{label}</span>}
      <div className="seg-track" role="radiogroup" aria-label={label}>
        {options.map((o) => (
          <button key={o.value} type="button" role="radio" aria-checked={o.value === value}
            className={'seg-item' + (o.value === value ? ' is-on' : '')} onClick={() => o.value !== value && onChange(o.value)}>
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

/** Button + floating panel. Closes on outside click and Escape. */
export function Popover({ trigger, children, align = 'right', width = 280, className = '', title }: {
  trigger: ReactNode; children: ReactNode | ((close: () => void) => ReactNode); align?: 'left' | 'right'; width?: number; className?: string; title?: string;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDown); document.removeEventListener('keydown', onKey); };
  }, [open]);
  const close = () => setOpen(false);
  return (
    <div className={'pop ' + className} ref={ref}>
      <button type="button" className={'pop-trigger' + (open ? ' is-open' : '')} aria-expanded={open} title={title} onClick={() => setOpen(!open)}>{trigger}</button>
      {open && <div className={`pop-panel pop-${align}`} style={cssVars({ '--pop-w': width + 'px' })} role="dialog">{typeof children === 'function' ? children(close) : children}</div>}
    </div>
  );
}

export function IconButton({ icon, title, onClick, active, className = '' }: { icon: string; title: string; onClick?: () => void; active?: boolean; className?: string }) {
  return (
    <button type="button" className={'icon-btn' + (active ? ' is-active' : '') + ' ' + className} title={title} aria-label={title} onClick={onClick}>
      <Icon name={icon} size={15} />
    </button>
  );
}

export function Modal({ open, onClose, title, children, width = 560 }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; width?: number }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" style={cssVars({ '--modal-w': width + 'px' })} role="dialog" aria-modal="true">
        <header className="modal-head"><b>{title}</b><IconButton icon="x" title="Close" onClick={onClose} /></header>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
}

// ---- toasts
type Toast = { id: number; text: string };
let toasts: Toast[] = [];
const toastSubs = new Set<(t: Toast[]) => void>();
export function toast(text: string) {
  const t = { id: Date.now() + Math.random(), text };
  toasts = [...toasts, t]; toastSubs.forEach((f) => f(toasts));
  setTimeout(() => { toasts = toasts.filter((x) => x.id !== t.id); toastSubs.forEach((f) => f(toasts)); }, 2400);
}
export function Toaster() {
  const [list, setList] = useState<Toast[]>(toasts);
  useEffect(() => { toastSubs.add(setList); return () => { toastSubs.delete(setList); }; }, []);
  return <div className="toaster" aria-live="polite">{list.map((t) => <div key={t.id} className="toast"><Icon name="check" size={14} />{t.text}</div>)}</div>;
}

export function Kbd({ children }: { children: ReactNode }) { return <kbd className="kbd">{children}</kbd>; }
