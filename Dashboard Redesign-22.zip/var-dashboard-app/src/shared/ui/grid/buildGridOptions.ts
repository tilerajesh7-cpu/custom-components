import type { GridOptions } from 'ag-grid-community';
import type { GridOptionsContract } from '@/contracts';

/** Layer 1 — library defaults. */
export const libraryDefaults: GridOptions = {
  defaultColDef: { sortable: true, resizable: true, filter: true, enableCellChangeFlash: true, minWidth: 64, suppressHeaderMenuButton: false },
  animateRows: true,
  tooltipShowDelay: 250,
  tooltipHideDelay: 8000,
  tooltipInteraction: true,
  cellSelection: true,
  suppressDragLeaveHidesColumns: true,
  getContextMenuItems: () => ['copy', 'copyWithHeaders', 'separator', 'excelExport', 'csvExport'],
};

const SIDEBARS = {
  none: undefined,
  columns: { toolPanels: ['columns'] },
  columnsAndFilters: { toolPanels: ['columns', 'filters'] },
};

/** Layer 2 — allowlisted service options. Layer 3/4 (consumer, user) are applied via props and column state. */
export function buildGridOptions(service: GridOptionsContract | undefined): GridOptions {
  const o: GridOptions = { ...libraryDefaults };
  if (!service) return o;
  if (service.rowSelection && service.rowSelection !== 'none') {
    o.rowSelection = { mode: service.rowSelection === 'single' ? 'singleRow' : 'multiRow', checkboxes: false, enableClickSelection: false };
  }
  if (service.sideBar && service.sideBar !== 'none') o.sideBar = SIDEBARS[service.sideBar];
  if (service.statusBar === 'aggregations') o.statusBar = { statusPanels: [{ statusPanel: 'agAggregationComponent', align: 'right' }] };
  return o;
}
