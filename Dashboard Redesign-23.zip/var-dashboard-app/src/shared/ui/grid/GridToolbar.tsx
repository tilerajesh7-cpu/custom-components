import { useMemo } from 'react';
import { isGroup, leafColumns, type ColDefContract } from '@/contracts';
import { Icon } from '../icons';
import { Popover, SegmentedControl } from '../controls';

interface ToolsProps {
  defs: ColDefContract[];
  visibility: Record<string, boolean>;
  onVisibility: (patch: Record<string, boolean>) => void;
  onReset: () => void;
  search?: { value: string; onChange: (v: string) => void; placeholder: string };
  cellMode?: { value: 'smart' | 'table'; onChange: (v: 'smart' | 'table') => void };
  showColumns: boolean;
}

const useCols = (defs: ColDefContract[], visibility: Record<string, boolean>) => {
  const leaves = useMemo(() => leafColumns(defs).filter((c) => !c.pinned), [defs]);
  const isVisible = (field: string, hide?: boolean) => visibility[field] ?? !hide;
  return { leaves, isVisible, groups: defs.filter(isGroup), loose: defs.filter((d) => !isGroup(d) && !d.pinned) as ReturnType<typeof leafColumns> };
};

/** Header tools (rendered into the card header): Smart | Table · Columns · Search. */
export function GridTools({ defs, visibility, onVisibility, onReset, search, cellMode, showColumns }: ToolsProps) {
  const { leaves, isVisible, groups, loose } = useCols(defs, visibility);
  const visibleCount = leaves.filter((c) => isVisible(c.field, c.hide)).length;
  return (
    <div className="gt-tools">
      {cellMode && (
        <div className="gt-mode">
          <SegmentedControl tone="light" size="sm" value={cellMode.value} onChange={(v) => cellMode.onChange(v as 'smart' | 'table')}
            options={[{ value: 'smart', label: 'Smart' }, { value: 'table', label: 'Table' }]} />
        </div>
      )}
      {showColumns && (
        <Popover width={340} title="Columns" trigger={<span className="gt-btn"><Icon name="columns" size={14} />Columns <b className="gt-count">{visibleCount} of {leaves.length}</b></span>}>
          <div className="cp">
            <div className="cp-head">
              <span className="menu-title">Show columns</span>
              <div className="cp-actions">
                <button type="button" className="cp-link" onClick={() => onVisibility(Object.fromEntries(leaves.map((c) => [c.field, true])))}>All</button>
                <button type="button" className="cp-link" onClick={onReset}>Default</button>
              </div>
            </div>
            {groups.map((g) => {
              const kids = leafColumns(g.children);
              const on = kids.filter((c) => isVisible(c.field, c.hide)).length;
              return (
                <div key={g.groupId} className="cp-group">
                  <button type="button" className={'cp-chip' + (on === kids.length ? ' is-on' : on ? ' is-part' : '')}
                    onClick={() => onVisibility(Object.fromEntries(kids.map((c) => [c.field, on !== kids.length])))}>
                    <span className="cp-check">{on === kids.length ? <Icon name="check" size={11} strokeWidth={3} /> : on ? '–' : ''}</span>{g.headerName}<span className="cp-n">{on}/{kids.length}</span>
                  </button>
                  <div className="cp-kids">
                    {kids.map((c) => (
                      <label key={c.field} className="cp-col"><input type="checkbox" checked={isVisible(c.field, c.hide)} onChange={(e) => onVisibility({ [c.field]: e.target.checked })} />{c.headerName}</label>
                    ))}
                  </div>
                </div>
              );
            })}
            {loose.length > 0 && (
              <div className="cp-group">
                <div className="cp-kids is-flat">
                  {loose.map((c) => (
                    <label key={c.field} className="cp-col"><input type="checkbox" checked={isVisible(c.field, c.hide)} onChange={(e) => onVisibility({ [c.field]: e.target.checked })} />{c.headerName}</label>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Popover>
      )}
      {search && (
        <label className="gt-search">
          <Icon name="search" size={14} />
          <input className="gw-search" value={search.value} onChange={(e) => search.onChange(e.target.value)} placeholder={search.placeholder} aria-label="Search rows" />
          {search.value ? <button type="button" onClick={() => search.onChange('')} aria-label="Clear search"><Icon name="x" size={12} /></button> : <kbd className="kbd">/</kbd>}
        </label>
      )}
    </div>
  );
}

/** Group chips row under the header: one click hides / shows a whole column group. */
export function GroupChips({ defs, visibility, onVisibility }: Pick<ToolsProps, 'defs' | 'visibility' | 'onVisibility'>) {
  const { isVisible, groups } = useCols(defs, visibility);
  if (!groups.length) return null;
  return (
    <div className="gt-groups">
      {groups.map((g, i) => {
        const kids = leafColumns(g.children);
        const on = kids.filter((c) => isVisible(c.field, c.hide)).length;
        return (
          <button key={g.groupId} type="button" className={'gt-group' + (on ? ' is-on' : '')} title={on ? 'Hide group' : 'Show group'}
            onClick={() => onVisibility(Object.fromEntries(kids.map((c) => [c.field, on === 0])))}>
            <span className={'gt-dot gt-dot-' + (i % 4)} /><b>{g.headerName}</b><span className="gt-kids">{kids.map((c) => c.headerName).join(' · ')}</span>
          </button>
        );
      })}
      <span className="gt-hint">Click a group to hide it · Columns to choose values</span>
    </div>
  );
}
