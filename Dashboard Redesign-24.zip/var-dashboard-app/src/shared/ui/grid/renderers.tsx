import type { ICellRendererParams, ITooltipParams } from 'ag-grid-community';
import type { Row } from '@/contracts';
import { formats, isNum } from '../lib/formats';
import { cssVars } from '../controls';

/** Name + row badges from _meta (e.g. "▲ 2.4σ"). */
export function LabelCell(p: ICellRendererParams & { tagField?: string }) {
  const badges = (p.data as Row | undefined)?._meta?.row?.badges ?? [];
  const tag = p.tagField ? (p.data as Row | undefined)?.[p.tagField] : undefined;
  return (
    <span className="lc">
      <span className="lc-text">{String(p.value ?? '')}</span>
      {tag != null && tag !== '' && <span className="lc-tag">{String(tag)}</span>}
      {badges.map((b, i) => <span key={i} className={'lc-badge tone-' + b.tone} title={b.tooltip}>{b.text}</span>)}
    </span>
  );
}

export function TagCell(p: ICellRendererParams) {
  return p.value ? <span className="tag">{String(p.value)}</span> : null;
}

/** Current value + bar + previous-value tick + change chip. */
export function IdCell(p: ICellRendererParams) {
  return <span className="id-cell">{String(p.value ?? '')}</span>;
}

export function SmartCell(p: ICellRendererParams & { previousField?: string; changeField?: string; max?: number; color?: string }) {
  const v = p.value, data = p.data as Row | undefined;
  if (p.node?.rowPinned) return <span className="sc sc-total">{formats.millions(v)}</span>;
  const prev = p.previousField ? data?.[p.previousField] : undefined;
  const chg = p.changeField ? data?.[p.changeField] : undefined;
  const max = p.max || 1;
  const w = isNum(v) ? Math.min(100, (Math.abs(v) / max) * 100) : 0;
  const t = isNum(prev) ? Math.min(100, (Math.abs(prev) / max) * 100) : null;
  const tone = isNum(chg) ? (chg > 0 ? 'negative' : chg < 0 ? 'positive' : 'muted') : 'muted';
  void tone;
  return (
    <span className="sc">
      <span className="sc-bar" style={cssVars(p.color ? { '--pct': w + '%', '--bar': p.color } : { '--pct': w + '%' })} />
      {t !== null && <span className="sc-tick" style={cssVars({ '--tick': t + '%' })} />}
      <span className="sc-val">{formats.millions(v)}</span>
    </span>
  );
}

/** Heatmap cell: tinted data bar filling the cell from the left (width = value / column max), value right-aligned. */
export function HeatCell(p: ICellRendererParams & { max?: number; color?: string }) {
  const v = p.value;
  if (p.node?.rowPinned) return <span className="hc hc-total">{formats.millions(v)}</span>;
  const pct = isNum(v) ? Math.max(0, Math.min(100, (Math.abs(v) / (p.max || 1)) * 100)) : 0;
  return (
    <span className="hc" style={cssVars({ '--pct': pct + '%', '--bar': p.color ?? '#2f62c9' })}>
      <span className="hc-bar" />
      <span className="hc-val">{formats.millions(v)}</span>
    </span>
  );
}

/** Utilisation bar with warn marker. */
export function ThresholdCell(p: ICellRendererParams & { warn?: number; breach?: number }) {
  if (!isNum(p.value)) return null;
  const v = p.value, warn = p.warn ?? 0.8, breach = p.breach ?? 1;
  const tone = v >= breach ? 'breach' : v >= warn ? 'warn' : 'ok';
  return (
    <span className="tc">
      <span className="tc-track"><span className={'tc-fill tc-' + tone} style={cssVars({ '--pct': Math.min(100, v * 100) + '%' })} /><span className="tc-mark" style={cssVars({ '--mark': warn * 100 + '%' })} /></span>
      <span className={'tc-val tc-val-' + tone}>{formats.percent0(v)}</span>
    </span>
  );
}

export function TotalCell(p: ICellRendererParams) {
  const money = Array.isArray(p.colDef?.type) && p.colDef?.type.includes('money');
  return <b className="cell-total">{money ? formats.millions(p.value) : String(p.value ?? '')}</b>;
}

/** Colour swatch + code (FS type). */
export function SwatchCell(p: ICellRendererParams & { colorField?: string }) {
  const c = p.colorField ? (p.data as Row | undefined)?.[p.colorField] : undefined;
  return <span className="sw"><i style={cssVars({ '--c': String(c ?? '#98a2b3') })} /><b>{String(p.value ?? '')}</b></span>;
}

/** Share bar + % (blue). */
export function ShareCell(p: ICellRendererParams) {
  if (!isNum(p.value)) return null;
  return <span className="shc"><span className="shc-track"><span style={cssVars({ '--pct': Math.min(100, p.value * 100 * 2) + '%' })} /></span><span className="shc-val">{formats.percent1(p.value)}</span></span>;
}
export function ShareTotalCell(p: ICellRendererParams) { return <span className="shc-total">{isNum(p.value) ? formats.percent0(p.value) : ''}</span>; }

/** Two-line label: small mono id above the name (limits). */
export function StackCell(p: ICellRendererParams & { subField?: string }) {
  const sub = p.subField ? (p.data as Row | undefined)?.[p.subField] : undefined;
  return <span className="stk">{sub != null && <small>{String(sub)}</small>}<b>{String(p.value ?? '')}</b></span>;
}

export function EmptyCell() { return <span className="tone-muted">—</span>; }

type Section = { label: string; field: string; type?: 'money' | 'percent' | 'change'; pctField?: string };
type ListItem = { code: string; name: string; value: number };
interface TipParams {
  sections?: Section[]; titleField?: string; kicker?: string; tagField?: string; statusField?: string;
  rankField?: string; rankOf?: number; rankLabel?: string; list?: { title: string; field: string }; compare?: string; hint?: string;
}
const LIST_COLORS = ['#5b86f5', '#2bb3a8', '#e0a33a', '#8bc34a'];

/** Rich tooltip card (dark). Everything shown is declared in tooltipComponentParams by services. */
export function DetailTooltip(p: ITooltipParams & TipParams) {
  const data = p.data as Row | undefined;
  if (!data || p.node?.rowPinned) return null;
  const meta = data._meta;
  const tag = p.tagField ? data[p.tagField] : undefined;
  const status = p.statusField && isNum(data[p.statusField]) ? (data[p.statusField] as number) : undefined;
  const statusChip = status === undefined ? null : status >= 1 ? { cls: 'is-breach', text: 'Breach · ' + formats.percent0(status) } : status >= 0.8 ? { cls: 'is-warn', text: 'Warning · ' + formats.percent0(status) } : null;
  const rank = p.rankField && isNum(data[p.rankField]) ? (data[p.rankField] as number) : undefined;
  const items = p.list ? ((data[p.list.field] as ListItem[] | undefined) ?? []) : [];
  const maxItem = Math.max(1, ...items.map((i) => Math.abs(i.value)));
  const notes = meta?.cells ? Object.values(meta.cells).map((c) => c.note).filter(Boolean) : [];
  const label = (s: string) => s.replace('{compare}', p.compare ?? 'previous');
  return (
    <div className="dt">
      <div className="dt-head">
        {(p.kicker || tag) && <span className="dt-kicker"><i />{[p.kicker, tag].filter(Boolean).join(' · ')}</span>}
        <b className="dt-title">{String(data[p.titleField ?? 'label'] ?? '')}</b>
        {(statusChip || rank || meta?.row?.badges?.length) && (
          <div className="dt-chips">
            {statusChip && <span className={'dt-chip ' + statusChip.cls}>{statusChip.text}</span>}
            {rank && <span className="dt-chip is-rank">#{rank} of {p.rankOf} {p.rankLabel}</span>}
            {meta?.row?.badges?.map((bd, i) => <span key={i} className={'dt-chip is-' + bd.tone}>{bd.text}</span>)}
          </div>
        )}
      </div>
      <div className="dt-body">
        {(p.sections ?? []).filter((s) => data[s.field] !== undefined).map((s) => {
          const v = data[s.field];
          const tone = s.type === 'change' && isNum(v) ? (v > 0 ? 'is-up' : v < 0 ? 'is-down' : '') : '';
          const pct = s.pctField && isNum(data[s.pctField]) ? (data[s.pctField] as number) : undefined;
          const text = s.type === 'percent' ? formats.percent1(v) : s.type === 'change' ? formats.fullSigned(v) : formats.full(v);
          return <div key={s.field} className="dt-kv"><span>{label(s.label)}</span><b className={tone}>{text}{pct !== undefined && <> · {formats.percent2(Math.abs(pct))}</>}</b></div>;
        })}
      </div>
      {items.length > 0 && (
        <div className="dt-list">
          <span className="dt-list-title">{p.list!.title}</span>
          {items.map((it, i) => (
            <div key={it.code} className="dt-li">
              <span className="dt-li-name"><i style={cssVars({ '--c': LIST_COLORS[i % LIST_COLORS.length] })} />{it.code} · {it.name}</span>
              <span className="dt-li-bar"><span style={cssVars({ '--pct': (Math.abs(it.value) / maxItem) * 100 + '%', '--c': LIST_COLORS[i % LIST_COLORS.length] })} /></span>
              <b>{formats.millions(it.value)}</b>
            </div>
          ))}
        </div>
      )}
      {notes.length > 0 && <div className="dt-note">{notes.join(' · ')}</div>}
      {p.hint && <div className="dt-foot"><kbd>click</kbd>{p.hint}</div>}
    </div>
  );
}

export const gridComponents = {
  labelCell: LabelCell, tagCell: TagCell, idCell: IdCell, smartCell: SmartCell, heatCell: HeatCell, swatchCell: SwatchCell, shareCell: ShareCell, shareTotalCell: ShareTotalCell, stackCell: StackCell, thresholdCell: ThresholdCell,
  totalCell: TotalCell, emptyCell: EmptyCell, detailTooltip: DetailTooltip,
};
