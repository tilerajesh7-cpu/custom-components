import { devBus } from '@/features/dev-tools/bus';

export const USE_MOCKS = import.meta.env.VITE_USE_MOCKS !== 'false';
const BASE = import.meta.env.VITE_API_BASE ?? '/api';

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

/** Single request function: mocks (dynamic import, not in the prod bundle when disabled) or real services. */
export async function request<T>(path: string, parse: (x: unknown) => T): Promise<T> {
  const t0 = performance.now();
  let status = 0;
  let body: unknown = null;
  try {
    if (USE_MOCKS) {
      const { mockFetch } = await import('@/mocks/mockApi');
      const r = await mockFetch(path);
      status = r.status; body = r.body;
    } else {
      const res = await fetch(BASE + path, { credentials: 'include', headers: { Accept: 'application/json' } });
      status = res.status;
      body = res.status === 204 ? null : await res.json().catch(() => null);
    }
  } catch {
    status = 0;
  }
  if (devBus.enabled) devBus.network({ path, status, ms: Math.round(performance.now() - t0), bytes: body ? JSON.stringify(body).length : 0, at: Date.now() });
  if (status < 200 || status >= 300) throw new ApiError(status, `${status || 'Network error'} ${path}`);
  return parse(body);
}
