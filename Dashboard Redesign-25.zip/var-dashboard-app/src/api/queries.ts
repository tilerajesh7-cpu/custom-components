import { keepPreviousData, useQueries, useQuery, type UseQueryResult } from '@tanstack/react-query';
import { Dashboard, Dataset, LatestBatch, NavItem, type DatasetRef, type SelectionState } from '@/contracts';
import { devBus } from '@/features/dev-tools/bus';
import { request } from './client';

// Full zod validation in dev; trusted cast in production (performance, plan §11).
const check = <T,>(schema: { parse: (x: unknown) => T }) => (x: unknown): T => (import.meta.env.DEV ? schema.parse(x) : (x as T));

export function useDashboard(dashboardId: string) {
  return useQuery({ queryKey: ['dashboard', dashboardId], queryFn: () => request(`/dashboards/${dashboardId}`, check(Dashboard)), staleTime: Infinity });
}

export function useNavigation() {
  return useQuery({ queryKey: ['navigation'], queryFn: () => request('/me/navigation', check(NavItem.array())), staleTime: Infinity });
}

export function useLatestBatch(enabled: boolean, intervalMs: number) {
  return useQuery({
    queryKey: ['batch', 'latest'],
    queryFn: () => request('/batches/latest', check(LatestBatch)),
    refetchInterval: enabled ? intervalMs : false,
    refetchIntervalInBackground: false,
  });
}

/** "$filter.x" | "$selection.w" (required) | "$selection?.w" (optional). Returns null if a required selection is missing. */
export function resolveParams(params: Record<string, string | number>, filters: Record<string, string>, selection: SelectionState) {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(params)) {
    if (typeof v !== 'string') { out[k] = String(v); continue; }
    if (v.startsWith('$filter.')) out[k] = filters[v.slice(8)] ?? '';
    else if (v.startsWith('$selection?.')) { const s = selection[v.slice(12)]?.[0]; if (s) out[k] = s; }
    else if (v.startsWith('$selection.')) { const s = selection[v.slice(11)]?.[0]; if (!s) return null; out[k] = s; }
    else out[k] = v;
  }
  return out;
}

export type DatasetResults = Record<string, UseQueryResult<Dataset>>;

/** One query per dataset → each widget paints as soon as its own data lands. */
export function useDatasets(refs: DatasetRef[] | undefined, filters: Record<string, string>, selection: SelectionState): DatasetResults {
  const list = refs ?? [];
  const results = useQueries({
    queries: list.map((ref) => {
      const params = resolveParams(ref.params, filters, selection);
      const qs = params ? new URLSearchParams(params).toString() : '';
      if (params) devBus.setParams(ref.datasetId, params);
      return {
        queryKey: ['dataset', ref.datasetId, qs],
        queryFn: () => request(`/datasets/${ref.datasetId}?${qs}`, check(Dataset)),
        enabled: params !== null,
        placeholderData: keepPreviousData,
      };
    }),
  });
  const out: DatasetResults = {};
  list.forEach((ref, i) => { out[ref.datasetId] = results[i]; });
  return out;
}
