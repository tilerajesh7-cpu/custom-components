import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { createHashRouter, Navigate, RouterProvider } from 'react-router-dom';
import { store, persistor } from './store';
import { AppShell } from '@/layouts/AppShell';
import DashboardPage from '@/pages/DashboardPage';
import { Toaster } from '@/shared/ui/controls';

const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 5 * 60_000, gcTime: 15 * 60_000, refetchOnWindowFocus: false, retry: 1 } },
});

const router = createHashRouter([
  {
    path: '/',
    element: <AppShell />,
    children: [
      { index: true, element: <Navigate to="/dashboards/dashboard-1" replace /> },
      { path: 'dashboards/:dashboardId', element: <DashboardPage /> },
      { path: '*', element: <Navigate to="/dashboards/dashboard-1" replace /> },
    ],
  },
]);

export function App() {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <QueryClientProvider client={queryClient}>
          <RouterProvider router={router} />
          <Toaster />
        </QueryClientProvider>
      </PersistGate>
    </Provider>
  );
}
