import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { persistReducer, persistStore, FLUSH, PAUSE, PERSIST, PURGE, REGISTER, REHYDRATE } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import { filtersSlice, preferencesSlice, selectionSlice, uiSlice } from '@/features/dashboard/model';
import { savedViewsSlice } from '@/features/saved-views/model';

// Datasets never go into Redux — they live in the TanStack Query cache.
const rootReducer = combineReducers({
  filters: filtersSlice.reducer,
  selection: selectionSlice.reducer,
  ui: uiSlice.reducer,
  preferences: persistReducer({ key: 'preferences', storage, version: 1 }, preferencesSlice.reducer),
  savedViews: persistReducer({ key: 'savedViews', storage, version: 1 }, savedViewsSlice.reducer),
});

export const store = configureStore({
  reducer: rootReducer,
  middleware: (gdm) => gdm({ serializableCheck: { ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER] } }),
});
export const persistor = persistStore(store);
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
