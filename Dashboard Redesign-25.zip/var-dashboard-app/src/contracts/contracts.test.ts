import { describe, expect, it } from 'vitest';
import { Dashboard, Dataset } from './index';
import { buildDashboard } from '@/mocks/dashboard';
import { buildDataset, MOCK_DATASET_IDS } from '@/mocks/datasets';

const params = { asOf: '2026-09-11', compare: 'DoD', region: 'All', variant: '1D', model: 'Both', attr: 'Trading', measure: 'Both', days: '90' };

// Every mock response must satisfy the contract — the same check services run on real responses.
describe('contracts', () => {
  it('dashboard-1 is valid', () => { expect(() => Dashboard.parse(buildDashboard())).not.toThrow(); });
  for (const id of MOCK_DATASET_IDS) {
    it(`${id} is valid`, () => { expect(() => Dataset.parse(buildDataset(id, params, 4812))).not.toThrow(); });
  }
});
