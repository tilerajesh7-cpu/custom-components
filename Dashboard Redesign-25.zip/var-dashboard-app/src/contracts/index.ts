// Response contracts (plan §5–6). zod = source of truth; types are inferred.
import { z } from 'zod';

export const Tone = z.enum(['positive', 'negative', 'warn', 'breach', 'info', 'muted', 'highlight']);
export type Tone = z.infer<typeof Tone>;

export const Condition = z.object({
  op: z.enum(['gt', 'gte', 'lt', 'lte', 'eq', 'neq', 'between', 'in', 'isNull']).optional(),
  value: z.unknown().optional(),
  ref: z.string().optional(),
  scale: z.number().optional(),
  row: z.enum(['pinned', 'group', 'leaf']).optional(),
}).strict();
export type Condition = z.infer<typeof Condition>;

export const StyleRule = z.object({ when: Condition, tone: Tone, emphasis: z.boolean().optional() }).strict();
export const RendererRule = z.object({ when: Condition, renderer: z.string() }).strict();
export type StyleRule = z.infer<typeof StyleRule>;
export type RendererRule = z.infer<typeof RendererRule>;

/** Allowed JSON-safe subset of AG Grid ColDef + our styling keys. */
export interface ColumnContract {
  field: string;
  headerName: string;
  headerTooltip?: string;
  type?: string[];
  pinned?: 'left' | 'right';
  width?: number;
  minWidth?: number;
  flex?: number;
  hide?: boolean;
  sort?: 'asc' | 'desc';
  cellRenderer?: string;
  cellRendererParams?: Record<string, unknown>;
  tooltipComponent?: string;
  tooltipComponentParams?: Record<string, unknown>;
  tooltipField?: string;
  aggFunc?: 'sum' | 'avg' | 'min' | 'max' | 'count';
  styleRules?: StyleRule[];
  rendererRules?: RendererRule[];
}
export interface ColumnGroupContract { groupId: string; headerName: string; headerTooltip?: string; children: ColDefContract[] }
export type ColDefContract = ColumnContract | ColumnGroupContract;

const Column: z.ZodType<ColumnContract> = z.object({
  field: z.string(),
  headerName: z.string(),
  headerTooltip: z.string().optional(),
  type: z.array(z.string()).optional(),
  pinned: z.enum(['left', 'right']).optional(),
  width: z.number().optional(),
  minWidth: z.number().optional(),
  flex: z.number().optional(),
  hide: z.boolean().optional(),
  sort: z.enum(['asc', 'desc']).optional(),
  cellRenderer: z.string().optional(),
  cellRendererParams: z.record(z.unknown()).optional(),
  tooltipComponent: z.string().optional(),
  tooltipComponentParams: z.record(z.unknown()).optional(),
  tooltipField: z.string().optional(),
  aggFunc: z.enum(['sum', 'avg', 'min', 'max', 'count']).optional(),
  styleRules: z.array(StyleRule).optional(),
  rendererRules: z.array(RendererRule).optional(),
}).strict();

export const ColDefContract: z.ZodType<ColDefContract> = z.lazy(() =>
  z.union([
    z.object({ groupId: z.string(), headerName: z.string(), headerTooltip: z.string().optional(), children: z.array(ColDefContract) }).strict(),
    Column,
  ]),
);
export const isGroup = (c: ColDefContract): c is ColumnGroupContract => 'children' in c;
export const leafColumns = (defs: ColDefContract[]): ColumnContract[] =>
  defs.flatMap((d) => (isGroup(d) ? leafColumns(d.children) : [d]));

export const RowMeta = z.object({
  row: z.object({
    tone: Tone.optional(),
    badges: z.array(z.object({ text: z.string(), tone: Tone, tooltip: z.string().optional() })).optional(),
  }).optional(),
  cells: z.record(z.object({ tone: Tone.optional(), flag: z.string().optional(), note: z.string().optional() })).optional(),
}).strict();
export type RowMeta = z.infer<typeof RowMeta>;

export const Row = z.object({ _meta: RowMeta.optional() }).catchall(z.unknown());
export type Row = z.infer<typeof Row>;

export const DatasetMeta = z.object({
  rowCount: z.number().int(),
  batchId: z.number().int(),
  queryId: z.string().optional(),
  ms: z.number().optional(),
  cache: z.enum(['HIT', 'MISS']).optional(),
  lineage: z.array(z.string()).optional(),
  sql: z.string().optional(),            // dev environments only
});

export const GridOptionsContract = z.object({
  rowModel: z.literal('clientSide').optional(),   // Phase 1: client-side row model only
  rowSelection: z.enum(['none', 'single', 'multiple']).optional(),
  sideBar: z.enum(['none', 'columns', 'columnsAndFilters']).optional(),
  statusBar: z.enum(['none', 'aggregations']).optional(),
}).strict();
export type GridOptionsContract = z.infer<typeof GridOptionsContract>;

const Common = {
  datasetId: z.string(),
  version: z.string(),
  asOf: z.string(),
  rowKey: z.string(),
  rowData: z.array(Row),
  meta: DatasetMeta,
};

export const GridDataset = z.object({
  ...Common,
  kind: z.literal('grid'),
  columnDefs: z.array(ColDefContract),
  pinnedBottomRowData: z.array(Row).optional(),
  gridOptions: GridOptionsContract.optional(),
}).strict();

export const SeriesDef = z.object({
  field: z.string(),
  name: z.string(),
  type: z.array(z.string()).optional(),
  palette: z.number().int().min(1).optional(),
  dash: z.boolean().optional(),
  stack: z.string().optional(),
}).strict();

export const SeriesDataset = z.object({ ...Common, kind: z.literal('series'), seriesDefs: z.array(SeriesDef) }).strict();

export const Dataset = z.discriminatedUnion('kind', [GridDataset, SeriesDataset]);
export type GridDataset = z.infer<typeof GridDataset>;
export type SeriesDataset = z.infer<typeof SeriesDataset>;
export type SeriesDef = z.infer<typeof SeriesDef>;
export type Dataset = z.infer<typeof Dataset>;

// ---------- widgets
export const Interactions = z.object({
  /** target = widget whose selection is set (default: this widget) */
  emits: z.array(z.object({ on: z.enum(['rowClick', 'pointClick', 'legendClick']), target: z.string().optional() })).optional(),
  /** field: row field to filter on, '$param' = server param (badge only), '$series' = highlight series */
  listens: z.array(z.object({ from: z.string(), field: z.string() })).optional(),
}).strict();

const Base = {
  widgetId: z.string(),
  title: z.string(),
  subtitle: z.string().optional(),
  interactions: Interactions.optional(),
  actions: z.array(z.string()).optional(),     // export.csv · export.excel · export.copy · export.json · export.png · export.svg
  states: z.object({ empty: z.string().optional() }).optional(),
};

export const GridWidgetConfig = z.object({
  ...Base,
  type: z.literal('grid'),
  datasetId: z.string(),
  presentation: z.object({
    searchNoun: z.string().optional(),
    /** Columns popup quick layouts: which child columns (by header) to show in every group. */
    layouts: z.array(z.object({ label: z.string(), values: z.array(z.string()) })).optional(),
    /** Grid takes the full row (charts wrap below) when more than this many columns are visible. */
    wideAbove: z.number().optional(),
    columnsNote: z.string().optional(),
    height: z.number().optional(),
    cellMode: z.enum(['smart', 'table']).optional(),
    features: z.object({ search: z.boolean().optional(), columnsPanel: z.boolean().optional(), cellModeToggle: z.boolean().optional() }).optional(),
  }).optional(),
}).strict();

export const Encoding = z.object({
  x: z.string(),
  y: z.union([z.array(z.string()), z.object({ fromSeriesDefs: z.literal(true) })]),
  sort: z.enum(['asc', 'desc', 'abs.desc']).optional(),
  limit: z.number().int().optional(),
  reference: z.array(z.object({ field: z.string(), scale: z.number().optional(), label: z.string().optional(), style: z.enum(['line', 'dashed']).optional() })).optional(),
  zones: z.object({ ratioOf: z.string(), steps: z.array(z.tuple([z.number(), z.enum(['warn', 'breach'])])) }).optional(),
}).strict();
export type Encoding = z.infer<typeof Encoding>;

export const ChartWidgetConfig = z.object({
  ...Base,
  type: z.literal('chart'),
  preset: z.enum(['line', 'column', 'column.stacked', 'column.reference', 'bar.diverging']),
  datasetId: z.string(),
  encoding: Encoding,
  options: z.object({ ranges: z.array(z.number().int()).optional(), height: z.number().optional(), stats: z.boolean().optional() }).optional(),
}).strict();

export const KpiWidgetConfig = z.object({
  ...Base,
  type: z.literal('kpi'),
  datasetId: z.string(),
  row: z.enum(['pinnedBottom', 'first']),
  value: z.string(),
  compare: z.string().optional(),
  tone: z.enum(['higherIsWorse', 'higherIsBetter']).optional(),
  spark: z.string().optional(),                 // "<datasetId>:<field>"
  mode: z.enum(['value', 'countAtRisk', 'maxAbs']).optional(),
  format: z.enum(['money', 'moneySigned', 'percent', 'count']).optional(),
  bar: z.boolean().optional(),
  labelField: z.string().optional(),
}).strict();

export const SummaryItem = z.object({
  label: z.string(),
  rule: z.enum(['max', 'min', 'countBadges']),
  datasetId: z.string(),
  field: z.string(),
  labelField: z.string().optional(),
  target: z.string().optional(),
  format: z.enum(['money', 'moneySigned', 'percent', 'count']).optional(),
}).strict();
export type SummaryItem = z.infer<typeof SummaryItem>;

export const SummaryWidgetConfig = z.object({ ...Base, type: z.literal('summary'), items: z.array(SummaryItem) }).strict();

export const WidgetConfig = z.discriminatedUnion('type', [GridWidgetConfig, ChartWidgetConfig, KpiWidgetConfig, SummaryWidgetConfig]);
export type WidgetConfig = z.infer<typeof WidgetConfig>;
export type GridWidgetConfig = z.infer<typeof GridWidgetConfig>;
export type ChartWidgetConfig = z.infer<typeof ChartWidgetConfig>;
export type KpiWidgetConfig = z.infer<typeof KpiWidgetConfig>;
export type SummaryWidgetConfig = z.infer<typeof SummaryWidgetConfig>;

// ---------- dashboard
export const Filter = z.object({
  filterId: z.string(),
  label: z.string(),
  control: z.enum(['date', 'segmented']),
  options: z.array(z.object({ value: z.string(), label: z.string() })).optional(),
  default: z.string(),
  scope: z.enum(['server', 'client']),
  field: z.string().optional(),
}).strict();
export type Filter = z.infer<typeof Filter>;

/** Param values: literal | "$filter.<id>" | "$selection.<widgetId>" (required) | "$selection?.<widgetId>" (optional) */
export const DatasetRef = z.object({
  datasetId: z.string(),
  kind: z.enum(['grid', 'series']),
  params: z.record(z.union([z.string(), z.number()])),
}).strict();
export type DatasetRef = z.infer<typeof DatasetRef>;

export const Layout = z.object({
  type: z.literal('flex'),
  gap: z.number(),
  rows: z.array(z.object({
    items: z.array(z.object({ widgetId: z.string().optional(), stack: z.array(z.string()).optional(), basis: z.number(), grow: z.number(), minW: z.number().optional() }).strict()),
  })),
}).strict();

export const BuiltInView = z.object({ viewId: z.string(), name: z.string(), filters: z.record(z.string()) }).strict();
export type BuiltInView = z.infer<typeof BuiltInView>;

/** Tabs show a subset of layout rows (indexes). */
export const Tab = z.object({ tabId: z.string(), label: z.string(), rows: z.array(z.number().int()) }).strict();
export type Tab = z.infer<typeof Tab>;

/** Attention strip: rows of a dataset at/above a threshold, each pill selects the row in `target`. */
export const Alert = z.object({
  datasetId: z.string(), field: z.string(), labelField: z.string(), warn: z.number(), breach: z.number(), target: z.string(),
}).strict();
export type Alert = z.infer<typeof Alert>;

/** Keyboard behaviour declared by the dashboard. */
export const Hotkeys = z.object({
  cycle: z.record(z.string()).optional(),        // key → filterId to cycle, e.g. { c: 'compareTo', m: 'measure' }
  walk: z.string().optional(),                    // grid widget that J / K move through
  export: z.string().optional(),                  // grid widget that E exports as CSV
}).strict();
export type Hotkeys = z.infer<typeof Hotkeys>;

export const Dashboard = z.object({
  schemaVersion: z.literal('1.0'),
  dashboardId: z.string(),
  version: z.number().int(),
  title: z.string(),
  breadcrumb: z.array(z.string()).optional(),
  filters: z.array(Filter),
  datasets: z.array(DatasetRef),
  widgets: z.array(WidgetConfig),
  layout: Layout,
  views: z.array(BuiltInView).optional(),
  tabs: z.array(Tab).optional(),
  alerts: Alert.optional(),
  hotkeys: Hotkeys.optional(),
}).strict();
export type Dashboard = z.infer<typeof Dashboard>;

export const NavItem = z.object({
  id: z.string(), section: z.string(), label: z.string(), icon: z.string(),
  route: z.string().optional(), disabled: z.boolean().optional(),
  parent: z.string().optional(),                       // nests under another item
  badge: z.object({ text: z.string(), tone: z.enum(['mock', 'soon', 'new']) }).optional(),
}).strict();
export type NavItem = z.infer<typeof NavItem>;

export const LatestBatch = z.object({ batchId: z.number().int(), publishedAt: z.string() });

export type SelectionState = Record<string, string[]>;
export type WidgetStatus = 'loading' | 'refreshing' | 'ready' | 'empty' | 'error' | 'forbidden';
export type WidgetEvent =
  | { kind: 'selection'; widgetId: string; keys: string[] }
  | { kind: 'preferenceChange'; widgetId: string; key: 'columns' | 'cellMode' | 'reset'; value?: unknown };
