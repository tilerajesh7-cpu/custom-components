/** Smooth-scroll a widget into view below the sticky header and flash it. */
export function scrollToWidget(widgetId: string) {
  requestAnimationFrame(() => {
    const el = document.getElementById('w-' + widgetId);
    if (!el) return;
    const header = document.querySelector('.fb-sticky')?.getBoundingClientRect().height ?? 200;
    window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - header - 12, behavior: 'smooth' });
    el.classList.add('wf-flash');
    setTimeout(() => el.classList.remove('wf-flash'), 1200);
  });
}
