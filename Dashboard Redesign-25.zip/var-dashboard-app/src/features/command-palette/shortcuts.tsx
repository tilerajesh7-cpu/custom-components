import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import type { Dashboard, Dataset } from '@/contracts';
import { store } from '@/app/store';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { clearAllSelections, cycleDensity, openInspector, setDevOpen, setFilter, setHelp, setPalette, setSaveOpen, setSelection, toggleSidebar } from '@/features/dashboard/model';
import { useViews } from '@/features/saved-views/SavedViews';
import { devBus } from '@/features/dev-tools/bus';
import { Kbd, Modal, toast } from '@/shared/ui/controls';
import { widgetActions } from '@/shared/ui/widgets';
import { scrollToWidget } from './scroll';

const typing = (e: KeyboardEvent) => {
  const t = e.target as HTMLElement | null;
  return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable || !!t.closest('.ag-cell-edit-wrapper, .ag-cell-focus'));
};

/** Global keyboard shortcuts (behaviour declared in dashboard.hotkeys). Ignored while typing or on a focused grid cell. */
export function useShortcuts(dashboard: Dashboard | undefined, onRefresh: () => void) {
  const dispatch = useAppDispatch();
  const qc = useQueryClient();
  const ui = useAppSelector((s) => s.ui);
  const { all, apply } = useViews(dashboard);
  useEffect(() => {
    const hk = dashboard?.hotkeys ?? {};
    const rowsOf = (widgetId: string) => {
      const w = dashboard?.widgets.find((x) => x.widgetId === widgetId);
      if (!w || !('datasetId' in w)) return undefined;
      const hit = qc.getQueriesData<Dataset>({ queryKey: ['dataset', w.datasetId] }).map(([, d]) => d).filter(Boolean).pop();
      return hit;
    };
    const walk = (dir: 1 | -1) => {
      if (!hk.walk) return;
      const ds = rowsOf(hk.walk); if (!ds?.rowData.length) return;
      const keys = ds.rowData.map((r) => String(r[ds.rowKey]));
      const cur = store.getState().selection.byWidget[hk.walk]?.[0];
      const i = cur ? keys.indexOf(cur) : -1;
      const next = keys[(i + dir + keys.length) % keys.length];
      dispatch(setSelection({ widgetId: hk.walk, keys: [next] }));
      const row = ds.rowData.find((r) => String(r[ds.rowKey]) === next);
      toast(String(row?.label ?? next));
    };
    const cycle = (filterId: string) => {
      const f = dashboard?.filters.find((x) => x.filterId === filterId);
      const opts = f?.options ?? []; if (!f || !opts.length) return;
      const cur = store.getState().filters.values[filterId] ?? f.default;
      const next = opts[(opts.findIndex((o) => o.value === cur) + 1) % opts.length];
      dispatch(setFilter({ id: filterId, value: next.value }));
      toast(`${f.label}: ${next.label}`);
    };
    const onKey = (e: KeyboardEvent) => {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key.toLowerCase() === 'k') { e.preventDefault(); dispatch(setPalette(!ui.paletteOpen)); return; }
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'd' && devBus.enabled) { e.preventDefault(); dispatch(setDevOpen(!ui.devOpen)); return; }
      if (mod || e.altKey || typing(e)) return;
      if (ui.paletteOpen || ui.helpOpen || ui.saveOpen || ui.inspector) return; // modals handle their own keys
      if (e.key === 'Escape') { dispatch(clearAllSelections()); return; }
      if (e.key === '?') { dispatch(setHelp(true)); return; }
      if (e.key === '/') { const el = document.querySelector<HTMLInputElement>('.gw-search'); if (el) { e.preventDefault(); el.focus(); } return; }
      if (e.key === '[') { dispatch(toggleSidebar()); return; }
      const k = e.key.toLowerCase();
      if (hk.cycle?.[k]) { cycle(hk.cycle[k]); return; }
      if (k === 'j') walk(1);
      else if (k === 'k') walk(-1);
      else if (k === 'r') { onRefresh(); toast('Refreshing'); }
      else if (k === 'd') dispatch(cycleDensity());
      else if (k === 's') { e.preventDefault(); dispatch(setSaveOpen(true)); }
      else if (k === 'e' && hk.export) { const fn = widgetActions.get(hk.export)?.current['export.csv']; if (fn) { fn(); toast('CSV downloaded'); scrollToWidget(hk.export); } }
      else if (/^[1-9]$/.test(e.key)) { const v = all[Number(e.key) - 1]; if (v) { apply(v); toast(`View: ${v.name}`); } }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [dispatch, qc, ui, all, apply, onRefresh, dashboard]);
  useEffect(() => { if (!ui.devOpen && ui.inspector) dispatch(openInspector(null)); }, [ui.devOpen, ui.inspector, dispatch]);
}

export function HelpDialog({ dashboard }: { dashboard: Dashboard }) {
  const open = useAppSelector((s) => s.ui.helpOpen);
  const dispatch = useAppDispatch();
  const hk = dashboard.hotkeys ?? {};
  const cycles = Object.entries(hk.cycle ?? {}).map(([key, id]) => {
    const f = dashboard.filters.find((x) => x.filterId === id);
    return [[key.toUpperCase()], `Cycle ${f?.label ?? id} (${(f?.options ?? []).map((o) => o.label).join(' → ')})`] as [string[], string];
  });
  const list: [string[], string][] = [
    [['Ctrl', 'K'], 'Command palette (⌘K on Mac)'],
    [['/'], 'Search the first grid'],
    ...(hk.walk ? [[['J'], 'Next row in the main grid'], [['K'], 'Previous row in the main grid']] as [string[], string][] : []),
    [['1–9'], 'Switch saved view'],
    [['S'], 'Save current view'],
    ...cycles,
    [['D'], 'Cycle density'],
    ...(hk.export ? [[['E'], 'Export main grid (CSV)']] as [string[], string][] : []),
    [['R'], 'Refresh / apply new data'],
    [['['], 'Collapse / expand sidebar'],
    [['Esc'], 'Close dialog · clear cross-filters'],
    [['?'], 'Show shortcuts'],
    [['↑', '↓', '←', '→'], 'Move between grid cells'],
    [['Ctrl', 'C'], 'Copy selected cells'],
  ];
  return (
    <Modal open={open} onClose={() => dispatch(setHelp(false))} title="Keyboard shortcuts" width={480}>
      <div className="help-list">
        {list.map(([keys, label]) => (
          <div key={label} className="help-row"><span>{label}</span><span className="help-keys">{keys.map((k) => <Kbd key={k}>{k}</Kbd>)}</span></div>
        ))}
        {devBus.enabled && <div className="help-row"><span>Dev console (dev only)</span><span className="help-keys"><Kbd>Ctrl</Kbd><Kbd>⇧</Kbd><Kbd>D</Kbd></span></div>}
      </div>
    </Modal>
  );
}
