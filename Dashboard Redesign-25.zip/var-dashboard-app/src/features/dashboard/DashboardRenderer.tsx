import { Fragment, useMemo, type ReactNode } from 'react';
import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { useAppSelector } from '@/app/hooks';
import { cssVars } from '@/shared/ui/controls';
import { WidgetHost } from './WidgetHost';
import { TabBar } from './Sections';
import './dashboard.css';

/**
 * Renders the backend flex layout. Rows not listed in any tab are always shown (brief, KPIs);
 * the tab bar sits before the first tabbed row. `before` injects nodes (e.g. alerts) before a row index.
 */
export function DashboardRenderer({ dashboard, datasets, before }: { dashboard: Dashboard; datasets: DatasetResults; before?: Record<number, ReactNode> }) {
  const tabId = useAppSelector((s) => s.ui.tab);
  const byId = useMemo(() => new Map(dashboard.widgets.map((w) => [w.widgetId, w])), [dashboard.widgets]);
  const tabs = dashboard.tabs ?? [];
  const tab = tabs.find((t) => t.tabId === tabId) ?? tabs[0];
  const tabbed = new Set(tabs.flatMap((t) => t.rows));
  const rows = dashboard.layout.rows.map((row, i) => ({ row, i })).filter(({ i }) => !tabbed.has(i) || !tab || tab.rows.includes(i));
  const firstTabbed = rows.findIndex(({ i }) => tabbed.has(i));
  const host = (id: string) => { const w = byId.get(id); return w ? <WidgetHost key={id} widget={w} dashboard={dashboard} datasets={datasets} /> : null; };
  return (
    <div className="dash">
      {rows.map(({ row, i }, k) => (
        <Fragment key={i}>
          {before?.[i]}
          {k === firstTabbed && <TabBar dashboard={dashboard} />}
          <div className="dash-row">
            {row.items.map((it, j) => (
              <div key={it.widgetId ?? j} className="dash-slot" style={cssVars({ '--grow': it.grow, '--basis': it.basis + 'px', '--min-w': it.minW ? it.minW + 'px' : '0px' })}>
                {it.stack ? it.stack.map(host) : it.widgetId ? host(it.widgetId) : null}
              </div>
            ))}
          </div>
        </Fragment>
      ))}
    </div>
  );
}
