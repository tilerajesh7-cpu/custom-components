import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';

/** Human label for a selected key: looks up the source widget's rows, falls back to the key. */
export function labelFor(dashboard: Dashboard, datasets: DatasetResults, widgetId: string, key: string): string {
  const w = dashboard.widgets.find((x) => x.widgetId === widgetId);
  const dsId = w && 'datasetId' in w ? w.datasetId : undefined;
  const ds = dsId ? datasets[dsId]?.data : undefined;
  const row = ds?.rowData.find((r) => String(r[ds.rowKey]) === key);
  return row && row.label != null ? String(row.label) : key;
}
