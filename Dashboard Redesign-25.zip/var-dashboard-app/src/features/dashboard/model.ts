import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { SelectionState } from '@/contracts';
import type { Density, GridPrefs } from '@/shared/ui/widgets';

/** Global filter values. Defaults come from the dashboard definition. */
export const filtersSlice = createSlice({
  name: 'filters',
  initialState: { values: {} as Record<string, string> },
  reducers: {
    initFilters: (s, a: PayloadAction<Record<string, string>>) => { s.values = { ...a.payload, ...s.values }; },
    setFilter: (s, a: PayloadAction<{ id: string; value: string }>) => { s.values[a.payload.id] = a.payload.value; },
    applyFilters: (s, a: PayloadAction<Record<string, string>>) => { s.values = { ...s.values, ...a.payload }; },
  },
});

/** Cross-filter selections: widgetId → selected keys. */
export const selectionSlice = createSlice({
  name: 'selection',
  initialState: { byWidget: {} as SelectionState },
  reducers: {
    setSelection: (s, a: PayloadAction<{ widgetId: string; keys: string[] }>) => {
      if (a.payload.keys.length) s.byWidget[a.payload.widgetId] = a.payload.keys; else delete s.byWidget[a.payload.widgetId];
    },
    clearSelection: (s, a: PayloadAction<string>) => { delete s.byWidget[a.payload]; },
    clearAllSelections: (s) => { s.byWidget = {}; },
  },
});

const DENSITIES: Density[] = ['compact', 'comfortable', 'spacious'];

/** Persisted user preferences. */
export const preferencesSlice = createSlice({
  name: 'preferences',
  initialState: {
    density: 'compact' as Density,
    sidebarOpen: true,
    grid: {} as Record<string, GridPrefs>,
    live: { mode: 'ask' as 'ask' | 'auto', paused: false },
  },
  reducers: {
    setDensity: (s, a: PayloadAction<Density>) => { s.density = a.payload; },
    cycleDensity: (s) => { s.density = DENSITIES[(DENSITIES.indexOf(s.density) + 1) % DENSITIES.length]; },
    toggleSidebar: (s) => { s.sidebarOpen = !s.sidebarOpen; },
    setGridPref: (s, a: PayloadAction<{ widgetId: string; patch: GridPrefs }>) => {
      const cur = s.grid[a.payload.widgetId] ?? {};
      s.grid[a.payload.widgetId] = { ...cur, ...a.payload.patch, columns: { ...(cur.columns ?? {}), ...(a.payload.patch.columns ?? {}) } };
    },
    resetGridPref: (s, a: PayloadAction<string>) => { delete s.grid[a.payload]; },
    resetAllGridPrefs: (s) => { s.grid = {}; },
    setLiveMode: (s, a: PayloadAction<'ask' | 'auto'>) => { s.live.mode = a.payload; },
    setLivePaused: (s, a: PayloadAction<boolean>) => { s.live.paused = a.payload; },
  },
});

/** Session-only UI state. */
export const uiSlice = createSlice({
  name: 'ui',
  initialState: { paletteOpen: false, helpOpen: false, devOpen: false, saveOpen: false, tab: 'overview', alertDismissed: false, inspector: null as string | null, appliedBatch: null as number | null, appliedAt: null as number | null },
  reducers: {
    setPalette: (s, a: PayloadAction<boolean>) => { s.paletteOpen = a.payload; },
    setHelp: (s, a: PayloadAction<boolean>) => { s.helpOpen = a.payload; },
    setSaveOpen: (s, a: PayloadAction<boolean>) => { s.saveOpen = a.payload; },
    setTab: (s, a: PayloadAction<string>) => { s.tab = a.payload; },
    dismissAlert: (s) => { s.alertDismissed = true; },
    setDevOpen: (s, a: PayloadAction<boolean>) => { s.devOpen = a.payload; },
    openInspector: (s, a: PayloadAction<string | null>) => { s.inspector = a.payload; },
    setAppliedBatch: (s, a: PayloadAction<number>) => { s.appliedBatch = a.payload; s.appliedAt = Date.now(); },
  },
});

export const { initFilters, setFilter, applyFilters } = filtersSlice.actions;
export const { setSelection, clearSelection, clearAllSelections } = selectionSlice.actions;
export const { setDensity, cycleDensity, toggleSidebar, setGridPref, resetGridPref, resetAllGridPrefs, setLiveMode, setLivePaused } = preferencesSlice.actions;
export const { setPalette, setHelp, setSaveOpen, setTab, dismissAlert, setDevOpen, openInspector, setAppliedBatch } = uiSlice.actions;
