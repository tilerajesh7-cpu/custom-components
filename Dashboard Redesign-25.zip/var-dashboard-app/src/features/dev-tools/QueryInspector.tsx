import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { USE_MOCKS } from '@/api/client';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { openInspector } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import { Modal, toast } from '@/shared/ui/controls';
import { copyText } from '@/shared/ui/lib/download';
import { formats } from '@/shared/ui/lib/formats';
import { devBus } from './bus';

/** Per-widget query information (the “DB” icon). Visible only while the dev console is open. */
export function QueryInspector({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const widgetId = useAppSelector((s) => s.ui.inspector);
  const dispatch = useAppDispatch();
  const w = dashboard.widgets.find((x) => x.widgetId === widgetId);
  const dsId = w && 'datasetId' in w ? w.datasetId : undefined;
  const q = dsId ? datasets[dsId] : undefined;
  const ds = q?.data;
  const params = dsId ? devBus.getParams(dsId) ?? {} : {};
  const path = dsId ? `/datasets/${dsId}?${new URLSearchParams(params).toString()}` : '';
  const close = () => dispatch(openInspector(null));
  const copy = async (t: string, label: string) => { if (await copyText(t)) toast(`${label} copied`); };

  return (
    <Modal open={!!w} onClose={close} width={640} title={<span className="modal-title"><Icon name="database" size={15} />Query · {w?.title}</span>}>
      {ds ? (
        <div className="qi">
          <div className="qi-grid">
            {[
              ['Widget', `${w?.widgetId} · ${w?.type}`], ['Dataset', ds.datasetId], ['Query ID', ds.meta.queryId ?? '—'], ['Batch', String(ds.meta.batchId)],
              ['Rows', formats.count(ds.meta.rowCount)], ['Server time', ds.meta.ms != null ? `${ds.meta.ms} ms` : '—'], ['Cache', ds.meta.cache ?? '—'], ['As of', ds.asOf],
              ['Version', ds.version], ['Source', USE_MOCKS ? 'Mock services' : 'Live services'], ['Status', q?.isFetching ? 'Fetching' : q?.isError ? 'Error' : 'Fresh'],
              ['Fetched', q?.dataUpdatedAt ? new Date(q.dataUpdatedAt).toLocaleTimeString() : '—'],
            ].map(([k, v]) => <div key={k} className="qi-kv"><span>{k}</span><b className={k === 'Cache' ? (v === 'HIT' ? 'ok' : 'warn') : ''}>{v}</b></div>)}
          </div>
          <div className="qi-sec"><span>Request</span><button type="button" className="cp-link" onClick={() => copy(path, 'Request')}><Icon name="copy" size={12} /> Copy</button></div>
          <code className="qi-code">GET {path}</code>
          <div className="qi-sec"><span>Parameters</span></div>
          <div className="qi-params">{Object.entries(params).map(([k, v]) => <span key={k} className="qi-param"><em>{k}</em>{v}</span>)}</div>
          {ds.meta.lineage && (<><div className="qi-sec"><span>Lineage</span></div>
            <div className="qi-lineage">{ds.meta.lineage.map((l, i) => <span key={l} className="qi-node">{i > 0 && <Icon name="chevronsRight" size={12} />}<b>{l}</b></span>)}<span className="qi-node"><Icon name="chevronsRight" size={12} /><b>{ds.datasetId}</b></span></div></>)}
          {import.meta.env.DEV && ds.meta.sql && (<><div className="qi-sec"><span>Query (dev only)</span><button type="button" className="cp-link" onClick={() => copy(ds.meta.sql!, 'Query')}><Icon name="copy" size={12} /> Copy</button></div>
            <pre className="qi-sql">{ds.meta.sql}</pre></>)}
        </div>
      ) : <div className="dev-empty">{q?.isError ? 'This request failed — see the Network tab.' : 'No data loaded yet.'}</div>}
    </Modal>
  );
}
