// Dev-only telemetry store (network calls, widget render timings, request params). Invisible to end users.
import { useSyncExternalStore } from 'react';

export interface NetEntry { path: string; status: number; ms: number; bytes: number; at: number }
export interface RenderStat { count: number; last: number; max: number; total: number }

const enabled = import.meta.env.DEV || (typeof localStorage !== 'undefined' && localStorage.getItem('devtools') === '1');

let net: NetEntry[] = [];
let renders: Record<string, RenderStat> = {};
const params: Record<string, Record<string, string>> = {};
const subs = new Set<() => void>();
let version = 0;
let scheduled = false;
const emit = () => {
  if (scheduled) return;
  scheduled = true;
  requestAnimationFrame(() => { scheduled = false; version++; subs.forEach((f) => f()); });
};

export const devBus = {
  enabled,
  network(e: NetEntry) { if (!enabled) return; net = [e, ...net].slice(0, 200); emit(); },
  render(id: string, ms: number) {
    if (!enabled) return;
    const r = renders[id] ?? { count: 0, last: 0, max: 0, total: 0 };
    renders = { ...renders, [id]: { count: r.count + 1, last: ms, max: Math.max(r.max, ms), total: r.total + ms } };
    emit();
  },
  setParams(id: string, p: Record<string, string>) { params[id] = p; },
  getParams(id: string) { return params[id]; },
  get net() { return net; },
  get renders() { return renders; },
  clear() { net = []; renders = {}; emit(); },
  subscribe(f: () => void) { subs.add(f); return () => { subs.delete(f); }; },
  snapshot() { return version; },
};

export function useDevBus() {
  useSyncExternalStore(devBus.subscribe, devBus.snapshot);
  return devBus;
}
