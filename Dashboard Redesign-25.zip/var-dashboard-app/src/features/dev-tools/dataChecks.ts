import { leafColumns, type Dataset } from '@/contracts';
import { isNum } from '@/shared/ui/lib/formats';

export interface Check { datasetId: string; name: string; ok: boolean; detail: string }

/** Automatic data-quality checks on every response (dev console → Data checks). */
export function runChecks(datasets: Record<string, Dataset | undefined>): Check[] {
  const out: Check[] = [];
  const loaded = Object.values(datasets).filter((d): d is Dataset => !!d);
  for (const ds of loaded) {
    const id = ds.datasetId;
    out.push({ datasetId: id, name: 'Row count matches meta', ok: ds.meta.rowCount === ds.rowData.length, detail: `${ds.rowData.length} rows · meta ${ds.meta.rowCount}` });
    const keys = ds.rowData.map((r) => String(r[ds.rowKey]));
    const dup = keys.length - new Set(keys).size;
    out.push({ datasetId: id, name: `Unique row key (${ds.rowKey})`, ok: dup === 0, detail: dup ? `${dup} duplicate keys` : 'All unique' });
    if (ds.kind === 'grid') {
      const fields = leafColumns(ds.columnDefs).map((c) => c.field);
      const missing = ds.rowData.reduce((a, r) => a + fields.filter((f) => r[f] === undefined || r[f] === null).length, 0);
      out.push({ datasetId: id, name: 'Every column has values', ok: missing === 0, detail: missing ? `${missing} empty cells` : `${fields.length} columns complete` });
      const total = ds.pinnedBottomRowData?.[0];
      if (total && ds.rowData.length) {
        const bad = Object.keys(total).filter((f) => isNum(total[f]) && ds.rowData.every((r) => isNum(r[f])) && Math.abs(ds.rowData.reduce((a, r) => a + (r[f] as number), 0) - (total[f] as number)) > 1);
        out.push({ datasetId: id, name: 'Totals row reconciles', ok: bad.length === 0, detail: bad.length ? `Mismatch: ${bad.join(', ')}` : 'Sum of rows = totals' });
      }
    } else {
      const dates = ds.rowData.map((r) => String(r[ds.rowKey]));
      const sorted = dates.every((d, i) => i === 0 || d > dates[i - 1]);
      out.push({ datasetId: id, name: 'Dates ascending, no gaps in order', ok: sorted, detail: sorted ? `${dates[0]} → ${dates[dates.length - 1]}` : 'Out of order' });
    }
  }
  const batches = [...new Set(loaded.map((d) => d.meta.batchId))];
  out.push({ datasetId: 'all', name: 'Same batch on every panel', ok: batches.length <= 1, detail: batches.length > 1 ? `Mixed batches: ${batches.join(', ')}` : `Batch ${batches[0] ?? '—'}` });
  return out;
}
