import { useCallback, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useQueryClient } from '@tanstack/react-query';
import { useLatestBatch } from '@/api/queries';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { setAppliedBatch, setLiveMode, setLivePaused } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import { Popover, SegmentedControl, toast } from '@/shared/ui/controls';
import { formats } from '@/shared/ui/lib/formats';
import './live.css';

const POLL_SEC = 15;
/** Don't swap numbers while the user is reading a tooltip, using a menu or hovering a panel. */
const isInteracting = () => !!document.querySelector('.wf-body:hover, .pop-panel, .ag-popup, .ag-tooltip, .dt, .highcharts-tooltip');

export function useLiveRefresh() {
  const qc = useQueryClient();
  const dispatch = useAppDispatch();
  const { mode, paused } = useAppSelector((s) => s.preferences.live);
  const applied = useAppSelector((s) => s.ui.appliedBatch);
  const appliedAt = useAppSelector((s) => s.ui.appliedAt);
  const [hidden, setHidden] = useState(document.hidden);
  useEffect(() => { const f = () => setHidden(document.hidden); document.addEventListener('visibilitychange', f); return () => document.removeEventListener('visibilitychange', f); }, []);

  const running = !paused && !hidden;
  const latestQ = useLatestBatch(running, POLL_SEC * 1000);
  const latest = latestQ.data?.batchId;

  useEffect(() => { if (latest != null && applied == null) dispatch(setAppliedBatch(latest)); }, [latest, applied, dispatch]);
  const hasNew = latest != null && applied != null && latest > applied;

  const refreshNow = useCallback(() => { void qc.invalidateQueries({ queryKey: ['dataset'] }); }, [qc]);
  const apply = useCallback(() => {
    refreshNow();
    if (latest != null) dispatch(setAppliedBatch(latest));
  }, [refreshNow, latest, dispatch]);

  useEffect(() => {
    if (mode !== 'auto' || !hasNew) return;
    if (!isInteracting()) { apply(); toast('New data applied'); return; }
    const t = setInterval(() => { if (!isInteracting()) { apply(); toast('New data applied'); clearInterval(t); } }, 1000);
    return () => clearInterval(t);
  }, [mode, hasNew, apply]);

  const [left, setLeft] = useState(POLL_SEC);
  useEffect(() => {
    if (!running) return;
    setLeft(POLL_SEC);
    const t = setInterval(() => setLeft((l) => (l <= 1 ? POLL_SEC : l - 1)), 1000);
    return () => clearInterval(t);
  }, [running, latestQ.dataUpdatedAt]);

  return {
    mode, paused, hidden, running, latest, applied, appliedAt, hasNew, left, pollSec: POLL_SEC,
    apply, refreshNow, checkNow: () => void latestQ.refetch(),
    setMode: (m: 'ask' | 'auto') => dispatch(setLiveMode(m)),
    setPaused: (p: boolean) => dispatch(setLivePaused(p)),
  };
}
export type LiveRefresh = ReturnType<typeof useLiveRefresh>;

export function LiveRefreshControl({ live }: { live: LiveRefresh }) {
  const r = 7, c = 2 * Math.PI * r;
  const progress = live.running ? live.left / live.pollSec : 1;
  return (
    <Popover width={290} title="Live data" trigger={
      <span title="Live data · refresh settings" className={'hdr-btn live-btn' + (live.hasNew ? ' has-new' : '') + (live.running ? '' : ' is-paused')}>
        <svg width="18" height="18" viewBox="0 0 18 18" className="live-ring" aria-hidden="true">
          <circle cx="9" cy="9" r={r} className="live-ring-bg" />
          <circle cx="9" cy="9" r={r} className="live-ring-fg" strokeDasharray={c} strokeDashoffset={c * (1 - progress)} />
        </svg>
        <span className="live-text"><b>{live.hasNew ? 'New data ready' : live.paused ? 'Paused' : live.hidden ? 'Idle' : 'Live'}</b><small>{live.hasNew ? `batch #${live.latest} · press R` : live.appliedAt ? `updated ${formats.time(live.appliedAt)}` : 'waiting for data'}</small></span>
      </span>
    }>
      <div className="live-pop">
        <div className="live-row">
          <div><b>Batch #{live.applied ?? '—'}</b><div className="live-sub">{live.appliedAt ? `Updated ${formats.time(live.appliedAt)}` : 'Waiting for first batch'}</div></div>
          <button type="button" className="btn" onClick={live.refreshNow}><Icon name="refresh" size={13} />Refresh</button>
        </div>
        <div className="menu-sep" />
        <div className="menu-title">When new data arrives</div>
        <SegmentedControl tone="light" value={live.mode} onChange={(v) => live.setMode(v as 'ask' | 'auto')} options={[{ value: 'ask', label: 'Ask me first' }, { value: 'auto', label: 'Apply automatically' }]} />
        <p className="live-note">{live.mode === 'auto' ? 'Applied when you are not reading a tooltip or using a menu, so numbers never jump mid-read.' : 'A banner offers the new batch; nothing changes until you apply it.'}</p>
        <div className="menu-sep" />
        <div className="live-row">
          <span className="live-sub">{live.running ? `Checking every ${live.pollSec}s · next in ${live.left}s` : live.hidden ? 'Paused while this tab is hidden' : 'Checking paused'}</span>
          <button type="button" className="btn" onClick={() => live.setPaused(!live.paused)}><Icon name={live.paused ? 'play' : 'pause'} size={12} />{live.paused ? 'Resume' : 'Pause'}</button>
        </div>
      </div>
    </Popover>
  );
}

export function LiveBanner({ live }: { live: LiveRefresh }) {
  const [dismissed, setDismissed] = useState<number | null>(null);
  if (!live.hasNew || live.mode !== 'ask' || dismissed === live.latest) return null;
  return createPortal(
    <div className="live-banner" role="status">
      <span className="live-dot" />
      <b>New risk data</b><span className="live-meta">batch #{live.latest}</span>
      <div className="live-banner-actions">
        <button type="button" className="live-apply" onClick={() => { live.apply(); toast('New data applied'); }}>Apply update <kbd className="kbd">R</kbd></button>
        <button type="button" className="live-later" onClick={() => setDismissed(live.latest ?? null)}>Later</button>
      </div>
    </div>,
    document.body,
  );
}
