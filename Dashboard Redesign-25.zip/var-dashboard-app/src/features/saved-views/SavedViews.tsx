import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import type { Dashboard } from '@/contracts';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { applyFilters, clearAllSelections, setSaveOpen, setSelection } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import { Popover, toast } from '@/shared/ui/controls';
import { copyText } from '@/shared/ui/lib/download';
import { addView, removeView, setDefaultView } from './model';
import './views.css';

export interface ViewItem { viewId: string; name: string; filters: Record<string, string>; selection?: Record<string, string[]>; builtIn: boolean }

const encode = (f: Record<string, string>) => btoa(unescape(encodeURIComponent(JSON.stringify(f))));
const decode = (s: string): Record<string, string> | null => { try { return JSON.parse(decodeURIComponent(escape(atob(s)))); } catch { return null; } };

/** Built-in views (from services) + personal views; full filter sets merged over defaults. */
export function useViews(dashboard: Dashboard | undefined) {
  const dispatch = useAppDispatch();
  const personal = useAppSelector((s) => s.savedViews.views);
  const defaults = useAppSelector((s) => s.savedViews.defaults);
  const filters = useAppSelector((s) => s.filters.values);
  const base = useMemo(() => Object.fromEntries((dashboard?.filters ?? []).filter((f) => f.control !== 'date').map((f) => [f.filterId, f.default])), [dashboard]);

  const all: ViewItem[] = useMemo(() => [
    ...(dashboard?.views ?? []).map((v) => ({ viewId: v.viewId, name: v.name, filters: { ...base, ...v.filters }, builtIn: true })),
    ...personal.filter((v) => v.dashboardId === dashboard?.dashboardId).map((v) => ({ viewId: v.viewId, name: v.name, filters: { ...base, ...v.filters }, selection: v.selection, builtIn: false })),
  ], [dashboard, personal, base]);

  const active = all.find((v) => Object.keys(base).every((k) => v.filters[k] === filters[k]));
  const apply = useCallback((v: ViewItem) => {
    dispatch(applyFilters(v.filters)); dispatch(clearAllSelections());
    Object.entries(v.selection ?? {}).forEach(([widgetId, keys]) => dispatch(setSelection({ widgetId, keys })));
  }, [dispatch]);
  const defaultId = dashboard ? defaults[dashboard.dashboardId] : undefined;
  const current = useMemo(() => Object.fromEntries(Object.keys(base).map((k) => [k, filters[k]])), [base, filters]);
  return { all, active, apply, defaultId, current };
}

/** On first load: ?view=<encoded> from a shared link wins, else the user's default view. */
export function useInitialView(dashboard: Dashboard | undefined, ready: boolean) {
  const { all, apply, defaultId } = useViews(dashboard);
  const [params, setParams] = useSearchParams();
  const done = useRef(false);
  const dispatch = useAppDispatch();
  useEffect(() => {
    if (!dashboard || !ready || done.current) return;
    done.current = true;
    const shared = params.get('view');
    if (shared) {
      const f = decode(shared);
      if (f) { dispatch(applyFilters(f)); toast('Shared view applied'); }
      params.delete('view'); setParams(params, { replace: true });
      return;
    }
    const def = all.find((v) => v.viewId === defaultId);
    if (def) apply(def);
  }, [dashboard, ready, all, apply, defaultId, params, setParams, dispatch]);
}

export function SavedViewsMenu({ dashboard }: { dashboard: Dashboard }) {
  const dispatch = useAppDispatch();
  const { all, active, apply, defaultId, current } = useViews(dashboard);
  const [name, setName] = useState('');

  const save = () => {
    const n = name.trim(); if (!n) return;
    dispatch(addView({ viewId: 'u-' + Date.now().toString(36), dashboardId: dashboard.dashboardId, name: n, filters: current, createdAt: Date.now() }));
    setName(''); toast(`View “${n}” saved`);
  };
  const share = async () => {
    const url = `${location.origin}${location.pathname}#/dashboards/${dashboard.dashboardId}?view=${encode(current)}`;
    if (await copyText(url)) toast('Link copied');
  };

  return (
    <Popover width={320} title="Saved views" trigger={
      <span className="vb-more" title="Manage views"><Icon name="sliders" size={13} />{all.length}</span>
    }>
      {(close) => (
        <div className="sv">
          <div className="menu-title">Views</div>
          {all.map((v, i) => (
            <div key={v.viewId} className={'sv-item' + (active?.viewId === v.viewId ? ' is-active' : '')}>
              <button type="button" className="sv-apply" onClick={() => { apply(v); close(); }}>
                <span className="sv-num">{i < 9 ? i + 1 : ''}</span>
                <span className="sv-label">{v.name}</span>
                {v.builtIn && <span className="sv-tag">Built-in</span>}
              </button>
              <button type="button" className={'sv-star' + (defaultId === v.viewId ? ' is-on' : '')} title={defaultId === v.viewId ? 'Default view (click to unset)' : 'Open this view by default'}
                onClick={() => dispatch(setDefaultView({ dashboardId: dashboard.dashboardId, viewId: defaultId === v.viewId ? null : v.viewId }))}>
                <Icon name="star" size={14} fill={defaultId === v.viewId ? 'currentColor' : 'none'} />
              </button>
              {!v.builtIn && <button type="button" className="sv-del" title="Delete view" onClick={() => dispatch(removeView(v.viewId))}><Icon name="trash" size={14} /></button>}
            </div>
          ))}
          <div className="menu-sep" />
          <form className="sv-save" onSubmit={(e) => { e.preventDefault(); save(); }}>
            <input className="input" placeholder="Name this view…" value={name} onChange={(e) => setName(e.target.value)} aria-label="View name" />
            <button type="submit" className="btn btn-primary" disabled={!name.trim()}>Save</button>
          </form>
          <button type="button" className="menu-item" onClick={() => { void share(); close(); }}><Icon name="link" size={14} />Copy link to this view</button>
          <div className="sv-hint">Press <kbd className="kbd">1</kbd>–<kbd className="kbd">9</kbd> to switch views</div>
        </div>
      )}
    </Popover>
  );
}

/** Anchored "Save current view" panel (prototype): name · what gets saved · include cross-filters · open by default. */
function SavePanel({ dashboard, labelFor, onClose }: { dashboard: Dashboard; labelFor: (widgetId: string, key: string) => string; onClose: () => void }) {
  const dispatch = useAppDispatch();
  const { current, all } = useViews(dashboard);
  const selection = useAppSelector((st) => st.selection.byWidget);
  const [name, setName] = useState('');
  const [withSel, setWithSel] = useState(Object.keys(selection).length > 0);
  const [asDefault, setAsDefault] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const down = (e: MouseEvent) => { if (ref.current && !ref.current.parentElement?.contains(e.target as Node)) onClose(); };
    document.addEventListener('mousedown', down);
    return () => document.removeEventListener('mousedown', down);
  }, [onClose]);
  const selText = Object.entries(selection).map(([w, keys]) => keys.map((k) => labelFor(w, k)).join(', ')).join(' · ');
  const facts = dashboard.filters.filter((f) => f.control !== 'date').map((f) => ({ k: f.label, v: f.options?.find((o) => o.value === current[f.filterId])?.label ?? current[f.filterId] }));
  const save = () => {
    const n = name.trim(); if (!n) return;
    const viewId = 'u-' + Date.now().toString(36);
    dispatch(addView({ viewId, dashboardId: dashboard.dashboardId, name: n, filters: current, selection: withSel ? selection : undefined, createdAt: Date.now() }));
    if (asDefault) dispatch(setDefaultView({ dashboardId: dashboard.dashboardId, viewId }));
    toast(`View “${n}” saved · press ${Math.min(all.length + 1, 9)}`); onClose();
  };
  return (
    <div className="svp" ref={ref} role="dialog" aria-label="Save current view">
      <div className="svp-head"><b>Save current view</b><kbd className="kbd">S</kbd></div>
      <input className="svp-input" autoFocus value={name} placeholder="Name it, e.g. EMEA morning check" aria-label="View name"
        onChange={(e) => setName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') save(); if (e.key === 'Escape') onClose(); }} />
      <div className="svp-sec">
        <span className="svp-label">What gets saved</span>
        <div className="svp-facts">{facts.map((f) => <span key={f.k} className="svp-fact">{f.k} <b>{f.v}</b></span>)}</div>
      </div>
      <label className={'svp-toggle' + (selText ? '' : ' is-disabled')}>
        <span><b>Include cross-filters</b><small>{selText || 'none active'}</small></span>
        <input type="checkbox" role="switch" checked={withSel && !!selText} disabled={!selText} onChange={(e) => setWithSel(e.target.checked)} /><i />
      </label>
      <label className="svp-toggle">
        <span><b>Open by default</b><small>Load this view every time you open the dashboard</small></span>
        <input type="checkbox" role="switch" checked={asDefault} onChange={(e) => setAsDefault(e.target.checked)} /><i />
      </label>
      <div className="svp-actions">
        <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button type="button" className="btn btn-primary" disabled={!name.trim()} onClick={save}>Save view</button>
      </div>
      <p className="svp-foot">Saved to your profile on this browser · press 1–9 to switch views</p>
    </div>
  );
}

/** Views row inside the navy filter bar: one click per view, Save (anchored panel), and the manage menu. */
export function ViewsBar({ dashboard, labelFor }: { dashboard: Dashboard; labelFor: (widgetId: string, key: string) => string }) {
  const dispatch = useAppDispatch();
  const open = useAppSelector((st) => st.ui.saveOpen);
  const { all, active, apply } = useViews(dashboard);
  const close = useCallback(() => dispatch(setSaveOpen(false)), [dispatch]);
  return (
    <div className="vb">
      <span className="seg-label vb-label"><Icon name="bookmark" size={12} />Views</span>
      {all.slice(0, 6).map((v) => (
        <button key={v.viewId} type="button" className={'vb-item' + (active?.viewId === v.viewId ? ' is-on' : '')} onClick={() => apply(v)}>{v.name}</button>
      ))}
      <div className="vb-save-wrap">
        <button type="button" className={'vb-save' + (open ? ' is-open' : '')} onClick={() => dispatch(setSaveOpen(!open))} title="Save current view (S)" aria-expanded={open}><Icon name="bookmark" size={12} />Save</button>
        {open && <SavePanel dashboard={dashboard} labelFor={labelFor} onClose={close} />}
      </div>
      <SavedViewsMenu dashboard={dashboard} />
    </div>
  );
}

export function copyViewLink(dashboardId: string, filters: Record<string, string>) {
  return copyText(`${location.origin}${location.pathname}#/dashboards/${dashboardId}?view=${encode(filters)}`);
}
