import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

export interface SavedView { viewId: string; dashboardId: string; name: string; filters: Record<string, string>; selection?: Record<string, string[]>; createdAt: number }

/** Personal saved views + default view per dashboard (persisted). */
export const savedViewsSlice = createSlice({
  name: 'savedViews',
  initialState: { views: [] as SavedView[], defaults: {} as Record<string, string> },
  reducers: {
    addView: (s, a: PayloadAction<SavedView>) => { s.views.push(a.payload); },
    removeView: (s, a: PayloadAction<string>) => {
      s.views = s.views.filter((v) => v.viewId !== a.payload);
      for (const k of Object.keys(s.defaults)) if (s.defaults[k] === a.payload) delete s.defaults[k];
    },
    setDefaultView: (s, a: PayloadAction<{ dashboardId: string; viewId: string | null }>) => {
      if (a.payload.viewId) s.defaults[a.payload.dashboardId] = a.payload.viewId; else delete s.defaults[a.payload.dashboardId];
    },
  },
});
export const { addView, removeView, setDefaultView } = savedViewsSlice.actions;
