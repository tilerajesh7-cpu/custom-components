import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { resetAllGridPrefs, setDensity, setHelp } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import { Popover, toast } from '@/shared/ui/controls';
import type { Density } from '@/shared/ui/widgets';
import './settings.css';

const OPTIONS: { value: Density; label: string; lines: number }[] = [
  { value: 'compact', label: 'Compact', lines: 4 },
  { value: 'comfortable', label: 'Comfortable', lines: 3 },
  { value: 'spacious', label: 'Spacious', lines: 2 },
];

/** Gear menu: whole-screen density cards · shortcuts · reset grid layouts. */
export function DisplaySettings() {
  const dispatch = useAppDispatch();
  const density = useAppSelector((s) => s.preferences.density);
  return (
    <Popover width={330} trigger={<span className="hdr-btn is-icon" title="Display settings (D)"><Icon name="settings" size={16} /></span>}>
      {(close) => (
        <div className="ds">
          <div className="ds-head"><b>Display</b><kbd className="kbd">D</kbd></div>
          <div className="ds-label">Density · whole screen</div>
          <div className="ds-cards" role="radiogroup" aria-label="Density">
            {OPTIONS.map((o) => (
              <button key={o.value} type="button" role="radio" aria-checked={density === o.value} className={'ds-card' + (density === o.value ? ' is-on' : '')} onClick={() => dispatch(setDensity(o.value))}>
                <span className={'ds-lines l' + o.lines}>{Array.from({ length: o.lines }, (_, i) => <i key={i} />)}</span>
                {o.label}
              </button>
            ))}
          </div>
          <p className="ds-note">Row height, card padding and spacing adapt across every grid and chart.</p>
          <div className="ds-sep" />
          <button type="button" className="ds-row" onClick={() => { close(); dispatch(setHelp(true)); }}>
            <Icon name="keyboard" size={15} /><span>Keyboard shortcuts</span><kbd className="kbd">?</kbd>
          </button>
          <button type="button" className="ds-row" onClick={() => { dispatch(resetAllGridPrefs()); toast('Grid layouts reset'); }}>
            <Icon name="columns" size={15} /><span>Reset grid columns</span>
          </button>
        </div>
      )}
    </Popover>
  );
}
