import { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import type { NavItem } from '@/contracts';
import { useNavigation } from '@/api/queries';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { toggleSidebar } from '@/features/dashboard/model';
import { PORTAL } from '@/mocks/dashboard';
import { Icon } from '@/shared/ui/icons';
import { TooltipLayer } from '@/shared/ui/controls';
import './app-shell.css';

const Badge = ({ b }: { b?: NavItem['badge'] }) => (b ? <span className={'side-badge is-' + b.tone}>{b.text}</span> : null);

/** Navy sidebar: portal header, sections, nested tree (parent → children) from services. */
export function AppShell() {
  const open = useAppSelector((s) => s.preferences.sidebarOpen);
  const dispatch = useAppDispatch();
  const nav = useNavigation().data ?? [];
  const { pathname } = useLocation();
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const sections = [...new Set(nav.map((n) => n.section))];
  const kids = (id?: string) => nav.filter((n) => n.parent === id);
  const containsActive = (n: NavItem): boolean => (n.route ? pathname.startsWith(n.route) : false) || kids(n.id).some(containsActive);

  const renderItem = (n: NavItem, depth: number) => {
    const children = kids(n.id);
    const isOpen = !collapsed[n.id];
    const onPath = containsActive(n);
    const cls = 'side-item depth-' + depth + (n.disabled ? ' is-disabled' : '') + (onPath && depth === 0 ? ' is-root-active' : '');
    const inner = (
      <>
        {depth === 0 ? <span className="side-ico"><Icon name={n.icon} size={15} /></span> : <span className="side-dot" />}
        {open && <span className="side-label">{n.label}</span>}
        {open && <Badge b={n.badge} />}
        {open && children.length > 0 && <Icon name="chevronDown" size={14} className={'side-caret' + (isOpen ? '' : ' is-closed')} />}
      </>
    );
    return (
      <div key={n.id} className="side-node">
        {children.length > 0 ? (
          <button type="button" className={cls} title={n.label} aria-expanded={isOpen} onClick={() => setCollapsed((c) => ({ ...c, [n.id]: isOpen }))}>{inner}</button>
        ) : n.route && !n.disabled ? (
          <NavLink to={n.route} title={n.label} className={({ isActive }) => cls + (isActive ? ' is-active' : '')}>{inner}</NavLink>
        ) : (
          <span className={cls} title={n.label + ' · not available yet'}>{inner}</span>
        )}
        {children.length > 0 && isOpen && open && <div className="side-children">{children.map((c) => renderItem(c, depth + 1))}</div>}
      </div>
    );
  };

  return (
    <div className="shell">
      <aside className={'side' + (open ? '' : ' is-collapsed')}>
        <div className="side-brand">
          {open ? (
            <>
              <span className="side-portal">{PORTAL.name}</span>
              <span className="side-user" title="Signed in as">{PORTAL.userId}</span>
            </>
          ) : <span className="side-logo">RP</span>}
        </div>
        <nav className="side-nav" aria-label="Main">
          {sections.map((sec) => (
            <div key={sec} className="side-sec">
              {open && <div className="side-sec-title">{sec}</div>}
              {nav.filter((n) => n.section === sec && !n.parent).map((n) => renderItem(n, 0))}
            </div>
          ))}
        </nav>
        <button type="button" className="side-toggle" onClick={() => dispatch(toggleSidebar())} aria-label={open ? 'Collapse sidebar' : 'Expand sidebar'}>
          <Icon name={open ? 'chevronsLeft' : 'chevronsRight'} size={15} />{open && 'Collapse sidebar'}
        </button>
      </aside>
      <main className="content"><Outlet /></main>
      <TooltipLayer />
    </div>
  );
}
