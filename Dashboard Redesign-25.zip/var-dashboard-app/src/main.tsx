import React from 'react';
import ReactDOM from 'react-dom/client';
// Fonts are bundled locally (no external links).
import '@fontsource/plus-jakarta-sans/400.css';
import '@fontsource/plus-jakarta-sans/500.css';
import '@fontsource/plus-jakarta-sans/600.css';
import '@fontsource/plus-jakarta-sans/700.css';
import '@fontsource/ibm-plex-mono/400.css';
import '@fontsource/ibm-plex-mono/500.css';
import '@fontsource/ibm-plex-mono/600.css';
import '@/theme/tokens.css';
import '@/app/global.css';
import { setupAgGrid } from '@/shared/ui/grid';
import { applyHighchartsTheme } from '@/theme/highchartsTheme';
import '@/shared/ui/widgets/registerAll';
import { App } from '@/app/App';

setupAgGrid(import.meta.env.VITE_AG_GRID_LICENSE);
applyHighchartsTheme();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
