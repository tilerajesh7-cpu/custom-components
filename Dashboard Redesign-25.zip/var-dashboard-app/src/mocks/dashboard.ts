// Mock dashboard definition + navigation — same shape services will return.
import type { Dashboard, NavItem } from '@/contracts';

const seg = (filterId: string, label: string, def: string, opts: (string | [string, string])[]) => ({
  filterId, label, control: 'segmented' as const, default: def, scope: 'server' as const,
  options: opts.map((o) => (Array.isArray(o) ? { value: o[0], label: o[1] } : { value: o, label: o })),
});

const EXPORT_GRID = ['export.excel', 'export.csv', 'export.copy', 'export.json'];
const EXPORT_CHART = ['export.png', 'export.svg', 'export.csv'];

export function buildDashboard(): Dashboard {
  const P = {
    asOf: '$filter.asOfDate', compare: '$filter.compareTo', region: '$filter.region', variant: '$filter.variant',
    model: '$filter.model', attr: '$filter.attr', measure: '$filter.measure',
  };
  const desk = '$selection?.widget-3';
  return {
    schemaVersion: '1.0', dashboardId: 'dashboard-1', version: 1, title: 'VaR Summary', breadcrumb: ['Daily Risk', 'Equities'],
    filters: [
      { filterId: 'asOfDate', label: 'COB', control: 'date', default: '2026-09-11', scope: 'server' },
      seg('compareTo', 'Compare', 'DoD', ['DoD', 'WoW', 'MoM']),
      seg('region', 'Region', 'All', ['All', 'NA', 'EMEA', 'APAC', 'Latam', 'Global']),
      seg('variant', 'Horizon', '1D', ['1D', '10D']),
      seg('model', 'Model', 'MC', [['MC', 'Monte Carlo'], ['Hist', 'Historical'], ['Both', 'MC + Hist']]),
      seg('attr', 'Attribute', 'Trading', ['Trading', 'Economic', 'Regulatory A', 'Regulatory B', 'Trading & Credit']),
      seg('measure', 'Measure', 'Both', [['VaR', 'VaR'], ['SVaR', 'SVaR'], ['Both', 'Both']]),
    ],
    datasets: [
      { datasetId: 'dataset-1', kind: 'grid', params: P },
      { datasetId: 'dataset-2', kind: 'series', params: { ...P, days: 90, deskId: desk } },
      { datasetId: 'dataset-3', kind: 'grid', params: { ...P, deskId: desk } },
      { datasetId: 'dataset-4', kind: 'series', params: { ...P, days: 90, deskId: desk } },
      { datasetId: 'dataset-5', kind: 'grid', params: { asOf: '$filter.asOfDate' } },
      { datasetId: 'dataset-6', kind: 'series', params: { asOf: '$filter.asOfDate', limitId: '$selection?.widget-8' } },
    ],
    widgets: [
      { widgetId: 'kpi-var', type: 'kpi', title: 'Total VaR', subtitle: 'vs previous COB · $MM', datasetId: 'dataset-1', row: 'pinnedBottom', value: 'varCob', compare: 'varPcob', tone: 'higherIsWorse', spark: 'dataset-2:var' },
      { widgetId: 'kpi-svar', type: 'kpi', title: 'Total SVaR', subtitle: 'vs previous COB · $MM', datasetId: 'dataset-1', row: 'pinnedBottom', value: 'svarCob', compare: 'svarPcob', tone: 'higherIsWorse', spark: 'dataset-2:svar' },
      { widgetId: 'kpi-limit', type: 'kpi', title: 'VaR limit used', subtitle: 'all desks in scope', datasetId: 'dataset-1', row: 'pinnedBottom', value: 'limitUse', format: 'percent', bar: true },
      { widgetId: 'kpi-risk', type: 'kpi', title: 'Desk limits at risk', datasetId: 'dataset-1', row: 'first', value: 'limitUse', mode: 'countAtRisk', format: 'count' },
      { widgetId: 'kpi-mover', type: 'kpi', title: 'Largest VaR mover', datasetId: 'dataset-1', row: 'first', value: 'varD', mode: 'maxAbs', labelField: 'short', format: 'moneySigned' },
      { widgetId: 'widget-10', type: 'summary', title: 'Daily brief', subtitle: 'what moved today · click an item to focus it', items: [
        { label: 'Largest VaR increase', rule: 'max', datasetId: 'dataset-1', field: 'varD', labelField: 'label', target: 'widget-3', format: 'moneySigned' },
        { label: 'Largest VaR decrease', rule: 'min', datasetId: 'dataset-1', field: 'varD', labelField: 'label', target: 'widget-3', format: 'moneySigned' },
        { label: 'Highest limit utilisation', rule: 'max', datasetId: 'dataset-5', field: 'ratio', labelField: 'label', target: 'widget-8', format: 'percent' },
        { label: 'Unusual moves (≥ 2σ)', rule: 'countBadges', datasetId: 'dataset-1', field: 'short', format: 'count' },
      ] },
      { widgetId: 'widget-3', type: 'grid', title: 'Standalone VaR / SVaR by desk', subtitle: '$MM · {filter.variant} · {filter.model} · {filter.attr} · click a desk to filter', datasetId: 'dataset-1',
        interactions: { emits: [{ on: 'rowClick' }] }, actions: EXPORT_GRID,
        presentation: { height: 520, cellMode: 'table', searchNoun: 'desks', wideAbove: 6, columnsNote: 'Applies to the desk grid',
          layouts: [{ label: 'Essentials', values: ['COB', 'Δ'] }, { label: 'Full', values: ['*'] }, { label: 'Analyst', values: ['COB', 'Δ', 'Δ%'] }, { label: 'COB only', values: ['COB'] }],
          features: { search: true, columnsPanel: true } } },
      { widgetId: 'widget-4', type: 'chart', title: 'VaR trend', subtitle: '$MM · business days · MC solid, Hist dashed', preset: 'line', datasetId: 'dataset-2',
        interactions: { listens: [{ from: 'widget-3', field: '$param' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { ranges: [30, 60, 90], height: 250 } },
      { widgetId: 'widget-5', type: 'chart', title: 'What moved', subtitle: 'largest VaR changes vs {filter.compareTo} · click to focus', preset: 'bar.diverging', datasetId: 'dataset-1',
        interactions: { emits: [{ on: 'pointClick', target: 'widget-3' }] }, actions: EXPORT_CHART,
        encoding: { x: 'short', y: ['varD'], sort: 'abs.desc', limit: 7 }, options: { height: 230 } },
      { widgetId: 'widget-6', type: 'grid', title: 'Component VaR / SVaR by FS type', subtitle: '$MM · {filter.model} · click a row to filter', datasetId: 'dataset-3',
        interactions: { emits: [{ on: 'rowClick', target: 'widget-7' }], listens: [{ from: 'widget-3', field: '$param' }] }, actions: EXPORT_GRID,
        presentation: { height: 420, cellMode: 'table', searchNoun: 'FS types', wideAbove: 6, columnsNote: 'Applies to the FS type grid', features: { search: true, columnsPanel: true } } },
      { widgetId: 'widget-7', type: 'chart', title: 'Component VaR over time', subtitle: 'daily · stacked by FS type · click the legend to filter', preset: 'column.stacked', datasetId: 'dataset-4',
        interactions: { emits: [{ on: 'legendClick' }], listens: [{ from: 'widget-3', field: '$param' }, { from: 'widget-7', field: '$series' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { ranges: [30, 60, 90], height: 400 } },
      { widgetId: 'widget-8', type: 'grid', title: 'VaR limits', subtitle: 'sorted by utilisation · click to chart', datasetId: 'dataset-5',
        interactions: { emits: [{ on: 'rowClick' }] }, actions: EXPORT_GRID, presentation: { height: 420, searchNoun: 'limits', features: { search: true, columnsPanel: true } } },
      { widgetId: 'widget-9', type: 'chart', title: 'Exposure vs limit', subtitle: '90 business days · showing highest utilisation until you pick a limit', preset: 'column.reference', datasetId: 'dataset-6',
        interactions: { listens: [{ from: 'widget-8', field: '$param' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: ['value'], reference: [{ field: 'threshold', label: 'Limit' }, { field: 'threshold', scale: 0.8, style: 'dashed', label: '80% of limit' }], zones: { ratioOf: 'threshold', steps: [[0.8, 'warn'], [1, 'breach']] } },
        options: { height: 290, stats: true } },
    ],
    layout: { type: 'flex', gap: 16, rows: [
      { items: [{ widgetId: 'widget-10', basis: 600, grow: 1 }] },
      { items: [
        { widgetId: 'kpi-var', basis: 200, grow: 1 }, { widgetId: 'kpi-svar', basis: 200, grow: 1 }, { widgetId: 'kpi-limit', basis: 200, grow: 1 },
        { widgetId: 'kpi-risk', basis: 200, grow: 1 }, { widgetId: 'kpi-mover', basis: 200, grow: 1 },
      ] },
      { items: [{ widgetId: 'widget-3', basis: 640, grow: 7, minW: 460 }, { stack: ['widget-4', 'widget-5'], basis: 380, grow: 5, minW: 320 }] },
      { items: [{ widgetId: 'widget-6', basis: 640, grow: 7, minW: 460 }, { widgetId: 'widget-7', basis: 380, grow: 5, minW: 320 }] },
      { items: [{ widgetId: 'widget-8', basis: 640, grow: 7, minW: 460 }, { widgetId: 'widget-9', basis: 380, grow: 5, minW: 320 }] },
    ] },
    views: [
      { viewId: 'v-morning', name: 'Morning check', filters: { compareTo: 'DoD', variant: '1D', model: 'MC', attr: 'Trading', measure: 'Both', region: 'All' } },
      { viewId: 'v-weekly', name: 'Weekly review', filters: { compareTo: 'WoW', variant: '1D', model: 'MC', attr: 'Trading', measure: 'VaR', region: 'All' } },
      { viewId: 'v-reg', name: 'Regulatory', filters: { compareTo: 'MoM', variant: '10D', model: 'Hist', attr: 'Regulatory B', measure: 'SVaR', region: 'All' } },
    ],
    tabs: [
      { tabId: 'overview', label: 'Overview', rows: [2, 3, 4] },
      { tabId: 'desks', label: 'Desks', rows: [2] },
      { tabId: 'fs', label: 'FS Type', rows: [3] },
      { tabId: 'limits', label: 'Limits', rows: [4] },
    ],
    alerts: { datasetId: 'dataset-1', field: 'limitUse', labelField: 'short', warn: 0.8, breach: 1, target: 'widget-3' },
    hotkeys: { cycle: { c: 'compareTo', m: 'measure' }, walk: 'widget-3', export: 'widget-3' },
  };
}

export const NAVIGATION: NavItem[] = [
  { id: 'nav-daily', section: 'Risk management', label: 'Daily Risk', icon: 'layers' },
  { id: 'nav-eq', section: 'Risk management', label: 'Equities', icon: 'trendUp', parent: 'nav-daily' },
  { id: 'nav-var', section: 'Risk management', label: 'VaR Summary', icon: 'dashboard', parent: 'nav-eq', route: '/dashboards/dashboard-1', badge: { text: 'Mock 1', tone: 'mock' } },
  { id: 'nav-var2', section: 'Risk management', label: 'VaR Summary', icon: 'dashboard', parent: 'nav-eq', disabled: true, badge: { text: 'Mock 2', tone: 'mock' } },
  { id: 'nav-fs', section: 'Risk management', label: 'FS Summary', icon: 'pie', parent: 'nav-eq', disabled: true, badge: { text: 'Soon', tone: 'soon' } },
  { id: 'nav-admin', section: 'Administration', label: 'Admin', icon: 'sliders', disabled: true },
];

export const PORTAL = { name: 'Risk Portal', userId: 'USER-001' };
