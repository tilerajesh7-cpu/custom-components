// In-app mock services. No service worker, no network. Used when VITE_USE_MOCKS !== 'false'.
import { buildDashboard, NAVIGATION } from './dashboard';
import { buildDataset } from './datasets';

export interface MockConfig {
  latencyMs: number;
  failDataset: string;       // '' | 'all' | dataset id
  emptyDataset: string;
  forbiddenDataset: string;
  autoBatchSec: number;      // 0 = off; new batch published every N seconds
}
const KEY = 'mock.config';
const DEFAULTS: MockConfig = { latencyMs: 350, failDataset: '', emptyDataset: '', forbiddenDataset: '', autoBatchSec: 120 };

function load(): MockConfig {
  try { return { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch { return { ...DEFAULTS }; }
}
let config = load();
export const getMockConfig = () => config;
export function setMockConfig(patch: Partial<MockConfig>) { config = { ...config, ...patch }; localStorage.setItem(KEY, JSON.stringify(config)); }
export function resetMockConfig() { config = { ...DEFAULTS }; localStorage.removeItem(KEY); }

let batch = 4812;
let publishedAt = new Date().toISOString();
let sinceLast = 0;
export function publishBatch() { batch += 1; publishedAt = new Date().toISOString(); sinceLast = 0; return batch; }
setInterval(() => { sinceLast += 1; if (config.autoBatchSec > 0 && sinceLast >= config.autoBatchSec) publishBatch(); }, 1000);

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function mockFetch(path: string): Promise<{ status: number; body: unknown }> {
  const url = new URL(path, 'http://mock.local');
  const parts = url.pathname.split('/').filter(Boolean);
  const params = Object.fromEntries(url.searchParams);

  if (parts[0] === 'dashboards') { await wait(120); return { status: 200, body: buildDashboard() }; }
  if (parts[0] === 'me' && parts[1] === 'navigation') { await wait(60); return { status: 200, body: NAVIGATION }; }
  if (parts[0] === 'batches') { await wait(40); return { status: 200, body: { batchId: batch, publishedAt } }; }
  if (parts[0] === 'datasets' && parts[1]) {
    const id = parts[1];
    const ms = Math.round(config.latencyMs * (0.6 + Math.random() * 0.8));
    await wait(ms);
    if (config.failDataset === id || config.failDataset === 'all') return { status: 503, body: { error: 'Service unavailable (simulated)' } };
    if (config.forbiddenDataset === id) return { status: 403, body: { error: 'Forbidden (simulated)' } };
    try {
      const ds = buildDataset(id, params, batch);
      ds.meta.ms = ms;
      if (config.emptyDataset === id) {
        ds.rowData = [];
        ds.meta.rowCount = 0;
        if (ds.kind === 'grid') ds.pinnedBottomRowData = [];
      }
      return { status: 200, body: ds };
    } catch {
      return { status: 404, body: { error: 'Unknown dataset' } };
    }
  }
  return { status: 404, body: { error: 'Not found' } };
}
