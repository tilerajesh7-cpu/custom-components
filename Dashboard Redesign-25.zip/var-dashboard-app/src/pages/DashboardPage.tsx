import { useCallback, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useDashboard, useDatasets } from '@/api/queries';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { initFilters, setPalette } from '@/features/dashboard/model';
import { DashboardRenderer } from '@/features/dashboard/DashboardRenderer';
import { FilterBar } from '@/features/dashboard/FilterBar';
import { labelFor } from '@/features/dashboard/labels';
import { ViewsBar, copyViewLink, useInitialView, useViews } from '@/features/saved-views/SavedViews';
import { AttentionStrip } from '@/features/dashboard/Sections';
import { LiveBanner, LiveRefreshControl, useLiveRefresh } from '@/features/live-refresh/LiveRefresh';
import { DisplaySettings } from '@/features/settings/DisplaySettings';
import { CommandPalette } from '@/features/command-palette/CommandPalette';
import { HelpDialog, useShortcuts } from '@/features/command-palette/shortcuts';
import { DevConsole } from '@/features/dev-tools/DevConsole';
import { QueryInspector } from '@/features/dev-tools/QueryInspector';
import { devBus } from '@/features/dev-tools/bus';
import { WidgetFrame, widgetActions } from '@/shared/ui/widgets';
import { Icon } from '@/shared/ui/icons';
import { toast } from '@/shared/ui/controls';

/** Route /#/dashboards/:dashboardId — everything on screen comes from the dashboard definition. */
export default function DashboardPage() {
  const { dashboardId = 'dashboard-1' } = useParams();
  const dispatch = useAppDispatch();
  const dash = useDashboard(dashboardId);
  const filters = useAppSelector((s) => s.filters.values);
  const selection = useAppSelector((s) => s.selection.byWidget);
  const density = useAppSelector((s) => s.preferences.density);

  useEffect(() => {
    if (dash.data) dispatch(initFilters(Object.fromEntries(dash.data.filters.map((f) => [f.filterId, f.default]))));
  }, [dash.data, dispatch]);

  const ready = !!dash.data && dash.data.filters.every((f) => f.filterId in filters);
  useInitialView(dash.data, ready);
  const datasets = useDatasets(ready ? dash.data!.datasets : undefined, filters, selection);
  const live = useLiveRefresh();
  const refresh = useCallback(() => live.apply(), [live]);
  useShortcuts(dash.data, refresh);
  const { current } = useViews(dash.data);

  useEffect(() => { document.documentElement.dataset.density = density; }, [density]);

  if (dash.isError) {
    return <div className="page-state"><WidgetFrame title="Dashboard" status="error" onRetry={() => void dash.refetch()}><span /></WidgetFrame></div>;
  }
  if (!dash.data) {
    return <div className="page-state page-loading"><div className="page-loading-card"><WidgetFrame status="loading"><span /></WidgetFrame></div></div>;
  }
  const d = dash.data;
  return (
    <div data-density={density}>
      <FilterBar
        dashboard={d}
        labelFor={(wid, key) => labelFor(d, datasets, wid, key)}
        views={<ViewsBar dashboard={d} labelFor={(wid, key) => labelFor(d, datasets, wid, key)} />}
        banner={<LiveBanner live={live} />}
        actions={
          <>
            <LiveRefreshControl live={live} />
            <button type="button" className="hdr-btn is-icon" onClick={() => dispatch(setPalette(true))} title="Search (Ctrl K)"><Icon name="search" size={16} /></button>
            <DisplaySettings />
            <button type="button" className="hdr-btn is-icon" title="Copy link to this view" onClick={() => { void copyViewLink(d.dashboardId, current).then((ok) => ok && toast('Link copied')); }}><Icon name="link" size={16} /></button>
            <button type="button" className="hdr-btn is-icon is-primary" title="Export main grid (Excel)" onClick={() => { const fn = widgetActions.get(d.hotkeys?.export ?? '')?.current['export.excel']; if (fn) { fn(); toast('Excel downloaded'); } }}><Icon name="download" size={16} /></button>
          </>
        }
      />
      <DashboardRenderer dashboard={d} datasets={datasets} before={{ 1: <AttentionStrip dashboard={d} datasets={datasets} /> }} />
      <CommandPalette dashboard={d} onRefresh={refresh} />
      <HelpDialog dashboard={d} />
      {devBus.enabled && <DevConsole dashboard={d} datasets={datasets} />}
      {devBus.enabled && <QueryInspector dashboard={d} datasets={datasets} />}
    </div>
  );
}
