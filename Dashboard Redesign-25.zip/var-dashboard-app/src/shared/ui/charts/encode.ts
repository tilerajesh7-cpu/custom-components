import type { SeriesOptionsType, XAxisOptions } from 'highcharts';
import type { Dataset, Encoding, Row } from '@/contracts';
import { isNum } from '../lib/formats';
import { SERIES_PALETTE } from '@/theme/highchartsTheme';

const ts = (v: unknown) => (typeof v === 'string' ? Date.parse(v.slice(0, 10) + 'T00:00:00Z') : Number(v));

/** The only chart "transformation": map row fields to series by name. */
export function encode(ds: Dataset, enc: Encoding, input: Row[], opts: { range?: number; highlight?: string[]; focus?: string[] } = {}): { series: SeriesOptionsType[]; xAxis?: XAxisOptions } {
  const hl = opts.highlight?.length ? opts.highlight : undefined;
  const yDefs = Array.isArray(enc.y)
    ? enc.y.map((f, i) => ({ field: f, name: ds.kind === 'series' ? ds.seriesDefs.find((s) => s.field === f)?.name ?? f : f, palette: i + 1, dash: false, stack: undefined as string | undefined }))
    : ds.kind === 'series' ? ds.seriesDefs.map((s, i) => ({ field: s.field, name: s.name, palette: s.palette ?? i + 1, dash: !!s.dash, stack: s.stack })) : [];

  if (ds.kind !== 'series') {
    // Category chart from grid rows (e.g. top changes)
    const f = yDefs[0]?.field ?? '';
    const val = (r: Row) => (isNum(r[f]) ? (r[f] as number) : 0);
    let rows = [...input];
    if (enc.sort) rows.sort((a, b) => (enc.sort === 'asc' ? val(a) - val(b) : enc.sort === 'abs.desc' ? Math.abs(val(b)) - Math.abs(val(a)) : val(b) - val(a)));
    if (enc.limit) rows = rows.slice(0, enc.limit);
    const focus = opts.focus?.length ? opts.focus : undefined;
    const at = focus ? rows.findIndex((r) => focus.includes(String(r[ds.rowKey]))) : -1;
    return {
      xAxis: {
        categories: rows.map((r) => String(r[enc.x] ?? '')),
        plotBands: at >= 0 ? [{ from: at - 0.5, to: at + 0.5, color: 'rgba(47,95,214,.10)' }] : [],
        labels: { formatter(this: { pos: number; value: string | number }) { return this.pos === at ? `<b style="color:#14224a">${this.value}</b>` : String(this.value); } },
      } as XAxisOptions,
      series: yDefs.map((y) => ({
        type: undefined as never, id: y.field, name: y.name,
        dataLabels: { enabled: true, inside: false, crop: false, overflow: 'allow', style: { fontFamily: "'IBM Plex Mono', monospace", fontSize: '11px', fontWeight: '600', textOutline: 'none', color: '#344054' },
          formatter(this: { y?: number | null }) { const v = this.y ?? 0; return (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v / 1e6).toFixed(2); } },
        data: rows.map((r, i) => ({
          y: isNum(r[y.field]) ? (r[y.field] as number) : null,
          custom: { key: String(r[ds.rowKey]) },
          opacity: at >= 0 && i !== at ? 0.4 : 1,
          borderColor: i === at ? '#14224a' : undefined, borderWidth: i === at ? 1 : 0,
        })),
      }) as SeriesOptionsType),
    };
  }

  const rows = opts.range ? input.slice(-opts.range) : input;
  const colors = enc.zones ? zoneColors(enc, rows, yDefs[0]?.field ?? '') : [];
  const series: SeriesOptionsType[] = yDefs.map((y) => ({
    type: undefined as never, id: y.field, name: y.name, stack: y.stack,
    color: SERIES_PALETTE[(y.palette - 1) % SERIES_PALETTE.length],
    dashStyle: y.dash ? 'ShortDash' : 'Solid',
    opacity: hl && !hl.includes(y.name) ? 0.22 : 1,
    data: rows.map((r, i) => {
      const v = isNum(r[y.field]) ? (r[y.field] as number) : null;
      return colors[i] ? { x: ts(r[enc.x]), y: v, color: colors[i] } : [ts(r[enc.x]), v];
    }),
  }) as SeriesOptionsType);

  for (const ref of enc.reference ?? []) {
    const dashed = ref.style === 'dashed';
    series.push({
      type: 'line', name: ref.label ?? ref.field, color: dashed ? '#d08a0e' : '#101828', dashStyle: dashed ? 'Dash' : 'Solid',
      lineWidth: dashed ? 1.5 : 2, step: 'left', marker: { enabled: false },
      data: rows.map((r) => [ts(r[enc.x]), isNum(r[ref.field]) ? (r[ref.field] as number) * (ref.scale ?? 1) : null]),
    } as SeriesOptionsType);
  }
  return { series };
}

/** Colour points by ratio to a varying reference field (warn / breach). */
function zoneColors(enc: Encoding, rows: Row[], yField: string): (string | undefined)[] {
  const z = enc.zones!;
  return rows.map((r) => {
    const v = r[yField], ref = r[z.ratioOf];
    if (!isNum(v) || !isNum(ref) || ref === 0) return undefined;
    const hit = [...z.steps].sort((a, b) => b[0] - a[0]).find(([t]) => v / ref >= t);
    return hit ? (hit[1] === 'breach' ? '#c2392f' : '#e0a33a') : '#7fa2fb';
  });
}
