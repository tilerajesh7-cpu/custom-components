import type { Options } from 'highcharts';
import { formats } from '../lib/formats';

const moneyAxis = { labels: { formatter(this: { value: number | string }) { return formats.millions(Number(this.value)); } } };

/** Presets hold the full look; widget config adds only encoding. */
export const presets: Record<string, Options> = {
  line: {
    chart: { type: 'line' },
    xAxis: { type: 'datetime', crosshair: { color: '#98a2b3', dashStyle: 'ShortDash', width: 1 } },
    yAxis: moneyAxis,
    tooltip: { shared: true },
    legend: { enabled: true, align: 'left', verticalAlign: 'top', itemStyle: { fontSize: '11.5px', fontWeight: '500', color: '#475467' } },
    plotOptions: { line: { lineWidth: 2.25 } },
  },
  column: {
    chart: { type: 'column' },
    xAxis: { type: 'category' },
    yAxis: moneyAxis,
    plotOptions: { column: { borderRadius: 3, borderWidth: 0, pointPadding: 0.08, groupPadding: 0.1 } },
  },
  'column.stacked': {
    chart: { type: 'column' },
    xAxis: { type: 'datetime', crosshair: { color: 'rgba(47,95,214,.08)' } },
    yAxis: { ...moneyAxis, reversedStacks: false },
    tooltip: { shared: true },
    legend: { enabled: true, align: 'left', verticalAlign: 'top', itemStyle: { fontSize: '11.5px', fontWeight: '500', color: '#475467' }, itemHoverStyle: { color: '#101828' } },
    plotOptions: { column: { stacking: 'normal', borderWidth: 0, pointPadding: 0.04, groupPadding: 0.04 } },
  },
  'column.reference': {
    chart: { type: 'column' },
    xAxis: { type: 'datetime' },
    yAxis: moneyAxis,
    tooltip: { shared: true },
    legend: { enabled: true, align: 'left', verticalAlign: 'top', itemStyle: { fontSize: '11.5px', fontWeight: '500', color: '#475467' } },
    plotOptions: { column: { borderWidth: 0, pointPadding: 0.05, groupPadding: 0.04, borderRadius: 2 } },
  },
  'bar.diverging': {
    chart: { type: 'bar' },
    xAxis: { type: 'category', labels: { style: { fontSize: '12px', color: '#344054' } } },
    yAxis: { ...moneyAxis, plotLines: [{ value: 0, color: '#cfd4dc', width: 1 }] },
    plotOptions: { bar: { borderRadius: 4, borderWidth: 0, negativeColor: '#16895a', color: '#c2392f', cursor: 'pointer' } },
  },
};
