import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { cssVars } from './index';
import './tooltip.css';

/**
 * One tooltip style for the whole app. Any element with `title` (or `data-tip`) gets the navy bubble
 * instead of the browser's native tooltip. AG Grid and Highcharts tooltips are themed to match.
 */
export function TooltipLayer() {
  const [tip, setTip] = useState<{ text: string; x: number; y: number; below: boolean } | null>(null);
  const timer = useRef<number | undefined>(undefined);
  useEffect(() => {
    let current: HTMLElement | null = null;
    const hide = () => { window.clearTimeout(timer.current); current = null; setTip(null); };
    const over = (e: MouseEvent) => {
      const el = (e.target as HTMLElement | null)?.closest<HTMLElement>('[title], [data-tip]');
      if (!el || el === current || el.closest('.highcharts-container')) return;
      const t = el.getAttribute('title');
      if (t) { el.setAttribute('data-tip', t); el.removeAttribute('title'); if (!el.getAttribute('aria-label')) el.setAttribute('aria-label', t); }
      const text = el.getAttribute('data-tip');
      if (!text) return;
      current = el;
      window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => {
        const r = el.getBoundingClientRect();
        const below = r.top < 56;
        setTip({ text, x: Math.min(Math.max(r.left + r.width / 2, 90), window.innerWidth - 90), y: below ? r.bottom + 8 : r.top - 8, below });
      }, 600);
    };
    const out = (e: MouseEvent) => { if (current && !current.contains(e.relatedTarget as Node)) hide(); };
    document.addEventListener('mouseover', over);
    document.addEventListener('mouseout', out);
    document.addEventListener('mousedown', hide, true);
    window.addEventListener('scroll', hide, true);
    return () => { document.removeEventListener('mouseover', over); document.removeEventListener('mouseout', out); document.removeEventListener('mousedown', hide, true); window.removeEventListener('scroll', hide, true); };
  }, []);
  if (!tip) return null;
  return createPortal(
    <div className={'tip' + (tip.below ? ' is-below' : '')} role="tooltip" style={cssVars({ '--x': tip.x + 'px', '--y': tip.y + 'px' })}>{tip.text}</div>,
    document.body,
  );
}
