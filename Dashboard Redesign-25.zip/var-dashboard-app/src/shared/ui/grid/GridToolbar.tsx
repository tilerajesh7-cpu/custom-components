import { useMemo } from 'react';
import { isGroup, leafColumns, type ColDefContract } from '@/contracts';
import { Icon } from '../icons';
import { Popover, SegmentedControl, cssVars } from '../controls';

interface ToolsProps {
  defs: ColDefContract[];
  visibility: Record<string, boolean>;
  onVisibility: (patch: Record<string, boolean>) => void;
  onReset: () => void;
  search?: { value: string; onChange: (v: string) => void; placeholder: string };
  cellMode?: { value: 'smart' | 'table'; onChange: (v: 'smart' | 'table') => void };
  showColumns: boolean;
  layouts?: { label: string; values: string[] }[];
  note?: string;
}

const useCols = (defs: ColDefContract[], visibility: Record<string, boolean>) => {
  const leaves = useMemo(() => leafColumns(defs).filter((c) => !c.pinned), [defs]);
  const isVisible = (field: string, hide?: boolean) => visibility[field] ?? !hide;
  return { leaves, isVisible, groups: defs.filter(isGroup), loose: defs.filter((d) => !isGroup(d) && !d.pinned) as ReturnType<typeof leafColumns> };
};

/** Header tools (rendered into the card header): Smart | Table · Columns · Search. */
export function GridTools({ defs, visibility, onVisibility, onReset, search, cellMode, showColumns, layouts, note }: ToolsProps) {
  const { leaves, isVisible } = useCols(defs, visibility);
  const visibleCount = leaves.filter((c) => isVisible(c.field, c.hide)).length;
  return (
    <div className="gt-tools">
      {cellMode && (
        <div className="gt-mode">
          <SegmentedControl tone="light" size="sm" value={cellMode.value} onChange={(v) => cellMode.onChange(v as 'smart' | 'table')}
            options={[{ value: 'smart', label: 'Smart' }, { value: 'table', label: 'Table' }]} />
        </div>
      )}
      {showColumns && (
        <Popover width={440} trigger={<span className="gt-btn" title="Choose columns"><Icon name="columns" size={14} />Columns <b className="gt-count">{visibleCount} of {leaves.length}</b></span>}>
          <ColumnsMatrix defs={defs} visibility={visibility} onVisibility={onVisibility} onReset={onReset} layouts={layouts} note={note} />
        </Popover>
      )}
      {search && (
        <label className="gt-search">
          <Icon name="search" size={14} />
          <input className="gw-search" value={search.value} onChange={(e) => search.onChange(e.target.value)} placeholder={search.placeholder} aria-label="Search rows" />
          {search.value ? <button type="button" onClick={() => search.onChange('')} aria-label="Clear search"><Icon name="x" size={12} /></button> : <kbd className="kbd">/</kbd>}
        </label>
      )}
    </div>
  );
}

/** Group chips row under the header: one click hides / shows a whole column group. */
export function GroupChips({ defs, visibility, onVisibility }: Pick<ToolsProps, 'defs' | 'visibility' | 'onVisibility'>) {
  const { isVisible, groups } = useCols(defs, visibility);
  if (!groups.length) return null;
  return (
    <div className="gt-groups">
      {groups.map((g, i) => {
        const kids = leafColumns(g.children);
        const on = kids.filter((c) => isVisible(c.field, c.hide)).length;
        return (
          <button key={g.groupId} type="button" className={'gt-group' + (on ? ' is-on' : '')} title={on ? 'Hide group' : 'Show group'}
            onClick={() => onVisibility(Object.fromEntries(kids.map((c) => [c.field, on === 0])))}>
            <span className={'gt-dot gt-dot-' + (i % 4)} /><b>{g.headerName}</b><span className="gt-kids">{kids.map((c) => c.headerName).join(' · ')}</span>
          </button>
        );
      })}
      <span className="gt-hint">Click a group to hide it · Columns to choose values</span>
    </div>
  );
}

const DEFAULT_LAYOUTS = [
  { label: 'Essentials', values: ['COB', 'Δ'] },
  { label: 'Full', values: ['*'] },
  { label: 'Analyst', values: ['COB', 'Δ', 'Δ%'] },
  { label: 'COB only', values: ['COB'] },
];

/** Columns popup: quick layouts + group × value matrix + show toggle per group + other columns. */
function ColumnsMatrix({ defs, visibility, onVisibility, onReset, layouts, note }: Pick<ToolsProps, 'defs' | 'visibility' | 'onVisibility' | 'onReset' | 'layouts' | 'note'>) {
  const { leaves, isVisible, groups, loose } = useCols(defs, visibility);
  const valueNames = [...new Set(groups.flatMap((g) => leafColumns(g.children).map((c) => c.headerName)))];
  const cell = (gi: number, name: string) => leafColumns(groups[gi].children).find((c) => c.headerName === name);
  const visibleCount = leaves.filter((c) => isVisible(c.field, c.hide)).length;
  const groupsOn = groups.filter((g) => leafColumns(g.children).some((c) => isVisible(c.field, c.hide))).length;
  const list = (layouts?.length ? layouts : DEFAULT_LAYOUTS).map((l) => ({ ...l, values: l.values.includes('*') ? valueNames : l.values.filter((v) => valueNames.includes(v)) }));
  const activeLayout = list.find((l) => groups.every((g) => leafColumns(g.children).every((c) => isVisible(c.field, c.hide) === l.values.includes(c.headerName))));
  const applyLayout = (values: string[]) => onVisibility(Object.fromEntries(groups.flatMap((g) => leafColumns(g.children).map((c) => [c.field, values.includes(c.headerName)]))));
  return (
    <div className="cm">
      <div className="cm-head">
        <div><b>Columns</b>{note && <small>{note}</small>}</div>
        <button type="button" className="cp-link" onClick={onReset}>Reset</button>
      </div>
      {groups.length > 0 && (
        <>
          <div className="cm-label">Quick layouts</div>
          <div className="cm-layouts" role="radiogroup" aria-label="Quick layouts">
            {list.map((l) => (
              <button key={l.label} type="button" role="radio" aria-checked={activeLayout === l} className={'cm-layout' + (activeLayout === l ? ' is-on' : '')} onClick={() => applyLayout(l.values)}>
                <b>{l.label}</b><small>{l.values.join(' · ')}</small>
              </button>
            ))}
          </div>
          <div className="cm-grid" style={cssVars({ '--n': valueNames.length })}>
            <span className="cm-th cm-th-first">Group</span>
            {valueNames.map((v) => <span key={v} className="cm-th">{v}</span>)}
            <span className="cm-th">Show</span>
            {groups.map((g, gi) => {
              const kids = leafColumns(g.children);
              const on = kids.filter((c) => isVisible(c.field, c.hide)).length;
              return (
                <div key={g.groupId} className="cm-row">
                  <span className="cm-group"><i className={'gt-dot gt-dot-' + (gi % 4)} />{g.headerName}</span>
                  {valueNames.map((v) => {
                    const c = cell(gi, v);
                    return c ? (
                      <label key={v} className={'cm-check tone-' + (gi % 4)} title={`${g.headerName} · ${v}`}>
                        <input type="checkbox" checked={isVisible(c.field, c.hide)} onChange={(e) => onVisibility({ [c.field]: e.target.checked })} />
                        <span><Icon name="check" size={12} strokeWidth={3} /></span>
                      </label>
                    ) : <span key={v} />;
                  })}
                  <label className="cm-switch" title={on ? 'Hide group' : 'Show group'}>
                    <input type="checkbox" role="switch" checked={on > 0} onChange={(e) => onVisibility(Object.fromEntries(kids.map((c) => [c.field, e.target.checked])))} /><i />
                  </label>
                </div>
              );
            })}
          </div>
        </>
      )}
      {loose.length > 0 && (
        <>
          <div className="cm-label">Other columns</div>
          <div className="cm-other">
            {loose.map((c) => (
              <button key={c.field} type="button" className={'cm-chip' + (isVisible(c.field, c.hide) ? ' is-on' : '')} onClick={() => onVisibility({ [c.field]: !isVisible(c.field, c.hide) })}>
                {isVisible(c.field, c.hide) && <Icon name="check" size={11} strokeWidth={3} />}{c.headerName}
              </button>
            ))}
          </div>
        </>
      )}
      <div className="cm-foot"><span>{visibleCount} of {leaves.length} columns{groups.length ? ` · ${groupsOn} of ${groups.length} groups` : ''}</span><span>Saved with your views</span></div>
    </div>
  );
}
