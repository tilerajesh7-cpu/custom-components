import type { ColTypeDef, ITooltipParams, ValueFormatterParams } from 'ag-grid-community';
import { formats } from '../lib/formats';

const fmt = (f: (v: unknown) => string) => (p: ValueFormatterParams) => f(p.value);

/** Column-type registry. Services reference these by name in `type`. */
export const columnTypes: Record<string, ColTypeDef> = {
  text: { cellDataType: 'text' },
  tag: { cellDataType: 'text', cellClass: 'cell-tag', cellRenderer: 'tagCell' },
  date: { cellDataType: 'dateString', valueFormatter: fmt(formats.date) },
  money: {
    cellDataType: 'number', cellClass: 'cell-num', headerClass: 'ag-right-aligned-header', filter: 'agNumberColumnFilter',
    valueFormatter: fmt(formats.millions),
    tooltipValueGetter: (p: ITooltipParams) => formats.full(p.value),   // normal tooltip: exact value
  },
  change: { valueFormatter: fmt(formats.millionsSigned), tooltipValueGetter: (p: ITooltipParams) => formats.fullSigned(p.value) },
  percent: { cellDataType: 'number', cellClass: 'cell-num', headerClass: 'ag-right-aligned-header', valueFormatter: fmt(formats.percent1) },
  threshold: { cellRenderer: 'thresholdCell' },
};

/** Default tone rules carried by a type so services don't repeat them. `change`: higher is worse. */
export const typeDefaultRules: Record<string, { op: 'gt' | 'lt'; value: number; tone: 'negative' | 'positive' }[]> = {
  change: [{ op: 'gt', value: 0, tone: 'negative' }, { op: 'lt', value: 0, tone: 'positive' }],
};

/** Tones → Excel styles, so exports keep the colours. */
export const excelStyles = [
  { id: 'cell-num', numberFormat: { format: '#,##0' }, alignment: { horizontal: 'Right' as const } },
  { id: 'tone-positive', font: { color: '#137A50' } },
  { id: 'tone-negative', font: { color: '#B0322A' } },
  { id: 'tone-warn', font: { color: '#8A5A06' }, interior: { color: '#FFF4E2', pattern: 'Solid' as const } },
  { id: 'tone-breach', font: { color: '#FFFFFF', bold: true }, interior: { color: '#C2392F', pattern: 'Solid' as const } },
  { id: 'tone-info', font: { color: '#1D4596' }, interior: { color: '#EEF3FD', pattern: 'Solid' as const } },
  { id: 'tone-emphasis', font: { bold: true } },
  { id: 'header', font: { bold: true, color: '#475467' }, interior: { color: '#F5F7FB', pattern: 'Solid' as const } },
];
