import { ModuleRegistry } from 'ag-grid-community';
import { AllEnterpriseModule, LicenseManager } from 'ag-grid-enterprise';

/** Call once at start. Later: register only used modules to trim the bundle. */
export function setupAgGrid(licenseKey: string | undefined) {
  ModuleRegistry.registerModules([AllEnterpriseModule]);
  if (licenseKey) LicenseManager.setLicenseKey(licenseKey);
}

export { GridWidget } from './GridWidget';
export { resolveColumnDefs } from './resolveColumnDefs';
export { buildGridOptions } from './buildGridOptions';
export { columnTypes } from './columnTypes';
