import type { CellClassParams, ColDef, ColGroupDef, ICellRendererParams } from 'ag-grid-community';
import { isGroup, type ColDefContract, type ColumnContract, type Row } from '@/contracts';
import { compileCondition } from '../lib/rules';
import { typeDefaultRules } from './columnTypes';

const TONES = ['positive', 'negative', 'warn', 'breach', 'info', 'muted', 'highlight'];
const ctxOf = (p: CellClassParams | ICellRendererParams) => ({
  value: p.value, data: p.data as Row | undefined, rowPinned: !!p.node?.rowPinned, group: !!p.node?.group,
});

/** Type defaults + styleRules + per-cell _meta → cellClassRules (compiled once per column version). */
function buildClassRules(c: ColumnContract): ColDef['cellClassRules'] {
  const rules: Record<string, (p: CellClassParams) => boolean> = {};
  const add = (cls: string, fn: (p: CellClassParams) => boolean) => {
    const prev = rules[cls];
    rules[cls] = prev ? (p) => prev(p) || fn(p) : fn;
  };
  for (const t of c.type ?? []) for (const r of typeDefaultRules[t] ?? []) {
    const test = compileCondition({ op: r.op, value: r.value });
    add('tone-' + r.tone, (p) => test(ctxOf(p)));
  }
  for (const r of c.styleRules ?? []) {
    const test = compileCondition(r.when);
    add('tone-' + r.tone, (p) => test(ctxOf(p)));
    if (r.emphasis) add('tone-emphasis', (p) => test(ctxOf(p)));
  }
  for (const tone of TONES) add('tone-' + tone, (p) => (p.data as Row | undefined)?._meta?.cells?.[c.field]?.tone === tone);
  return rules;
}

function buildRendererSelector(c: ColumnContract, fallback: string | undefined): ColDef['cellRendererSelector'] {
  if (!c.rendererRules?.length) return undefined;
  const compiled = c.rendererRules.map((r) => ({ test: compileCondition(r.when), renderer: r.renderer }));
  return (p) => {
    const hit = compiled.find((r) => r.test(ctxOf(p)));
    return hit ? { component: hit.renderer } : fallback ? { component: fallback } : undefined;
  };
}

/** Contract columns → AG Grid ColDefs. Data is untouched; only our keys are compiled. */
export function resolveColumnDefs(defs: ColDefContract[], opts: { cellMode?: 'smart' | 'table'; visibility?: Record<string, boolean> } = {}): (ColDef | ColGroupDef)[] {
  return defs.map((d): ColDef | ColGroupDef => {
    if (isGroup(d)) return { groupId: d.groupId, headerName: d.headerName, headerTooltip: d.headerTooltip, children: resolveColumnDefs(d.children, opts) };
    const { styleRules: _s, rendererRules: _r, cellRenderer, hide, ...rest } = d;
    const renderer = cellRenderer === 'smartCell' && opts.cellMode === 'table' ? 'heatCell' : cellRenderer;
    const vis = opts.visibility?.[d.field];
    return {
      ...rest,
      colId: d.field,
      ...(d.pinned ? { suppressSizeToFit: true, lockPinned: true } : {}),
      hide: vis === undefined ? hide : !vis,
      cellRenderer: renderer,
      cellClassRules: buildClassRules(d),
      cellRendererSelector: buildRendererSelector(d, renderer),
    };
  });
}
