const n2 = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const n1 = new Intl.NumberFormat('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const n0 = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });

export const isNum = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

/** Values arrive in base units; round only when formatting. */
export const formats = {
  millions: (v: unknown) => (isNum(v) ? n2.format(v / 1e6) : ''),
  millionsSigned: (v: unknown) => (isNum(v) ? (v > 0 ? '+' : v < 0 ? '−' : '') + n2.format(Math.abs(v) / 1e6) : ''),
  full: (v: unknown) => (isNum(v) ? (v < 0 ? '−$' : '$') + n0.format(Math.abs(v)) : ''),
  fullSigned: (v: unknown) => (isNum(v) ? (v > 0 ? '+$' : v < 0 ? '−$' : '$') + n0.format(Math.abs(v)) : ''),
  percent0: (v: unknown) => (isNum(v) ? n0.format(v * 100) + '%' : ''),
  percent1: (v: unknown) => (isNum(v) ? n1.format(v * 100) + '%' : ''),
  percent2: (v: unknown) => (isNum(v) ? (v * 100).toFixed(2) + '%' : ''),
  count: (v: unknown) => (isNum(v) ? n0.format(v) : ''),
  date: (v: unknown) => (typeof v === 'string' ? new Date(v.slice(0, 10) + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : ''),
  time: (v: number | string) => new Date(v).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
};
