import type { Condition, Row } from '@/contracts';
import { isNum } from './formats';

export interface RuleContext { value: unknown; data: Row | undefined; rowPinned?: boolean; group?: boolean }

/** Compile a declarative condition once into a fast predicate. No eval, no expressions. */
export function compileCondition(c: Condition): (ctx: RuleContext) => boolean {
  const { op, value, ref, scale = 1, row } = c;
  const rowCheck =
    row === 'pinned' ? (x: RuleContext) => !!x.rowPinned
    : row === 'group' ? (x: RuleContext) => !!x.group
    : row === 'leaf' ? (x: RuleContext) => !x.rowPinned && !x.group
    : () => true;
  if (!op) return rowCheck;
  const operand = (x: RuleContext): unknown => {
    const base = ref ? x.data?.[ref] : value;
    return isNum(base) ? base * scale : base;
  };
  const tests: Record<string, (v: unknown, o: unknown) => boolean> = {
    gt: (v, o) => isNum(v) && isNum(o) && v > o,
    gte: (v, o) => isNum(v) && isNum(o) && v >= o,
    lt: (v, o) => isNum(v) && isNum(o) && v < o,
    lte: (v, o) => isNum(v) && isNum(o) && v <= o,
    eq: (v, o) => v === o,
    neq: (v, o) => v !== o,
    between: (v, o) => isNum(v) && Array.isArray(o) && v >= Number(o[0]) && v <= Number(o[1]),
    in: (v, o) => Array.isArray(o) && o.includes(v),
    isNull: (v) => v === null || v === undefined || v === '',
  };
  const test = tests[op];
  return (x) => rowCheck(x) && test(x.value, operand(x));
}
