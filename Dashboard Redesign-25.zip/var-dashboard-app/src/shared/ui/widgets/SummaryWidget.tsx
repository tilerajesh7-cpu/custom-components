import type { Row, SummaryItem, SummaryWidgetConfig } from '@/contracts';
import { formats, isNum } from '../lib/formats';
import { Icon } from '../icons';
import type { WidgetProps } from './registry';

interface Computed { item: SummaryItem; main: string; value: string; key?: string; tone: string; icon: string }

function compute(item: SummaryItem, rows: Row[], rowKey: string): Computed | null {
  const fmt = formats[item.format === 'moneySigned' ? 'millionsSigned' : item.format === 'percent' ? 'percent1' : item.format === 'count' ? 'count' : 'millions'];
  if (item.rule === 'countBadges') {
    const hits = rows.filter((r) => r._meta?.row?.badges?.length);
    return { item, main: hits.length ? hits.slice(0, 3).map((r) => String(r[item.field] ?? '')).join(', ') : 'None today', value: `${hits.length} flagged`, tone: hits.length ? 'warn' : 'info', icon: 'sparkles' };
  }
  const nums = rows.filter((r) => isNum(r[item.field]));
  if (!nums.length) return null;
  const pick = nums.reduce((a, b) => (item.rule === 'max' ? ((b[item.field] as number) > (a[item.field] as number) ? b : a) : ((b[item.field] as number) < (a[item.field] as number) ? b : a)));
  const v = pick[item.field] as number;
  const tone = item.format === 'percent' ? (v >= 1 ? 'negative' : v >= 0.8 ? 'warn' : 'info') : v > 0 ? 'negative' : v < 0 ? 'positive' : 'info';
  const icon = item.format === 'percent' ? 'gauge' : v >= 0 ? 'trendUp' : 'trendDown';
  return { item, main: String(pick[item.labelField ?? 'label'] ?? ''), value: fmt(v), key: String(pick[rowKey]), tone, icon };
}

/** “Daily brief”: rules computed from rows already on screen; each item applies a cross-filter. */
export function SummaryWidget({ config, related, onEvent }: WidgetProps<SummaryWidgetConfig>) {
  const list = config.items
    .map((it) => { const ds = related[it.datasetId]; return ds ? compute(it, ds.rowData, ds.rowKey) : null; })
    .filter((x): x is Computed => !!x);
  return (
    <div className="brief">
      {list.map((c, i) => {
        const link = !!(c.item.target && c.key);
        return (
          <button key={i} type="button" className={'brief-item' + (link ? ' is-link' : '')} disabled={!link}
            onClick={() => link && onEvent({ kind: 'selection', widgetId: c.item.target!, keys: [c.key!] })}>
            <span className={'brief-ico tone-' + c.tone}><Icon name={c.icon} size={15} /></span>
            <span className="brief-text">
              <span className="brief-label">{c.item.label}</span>
              <span className="brief-main" title={c.main}>{c.main}</span>
              <span className={'brief-value tone-' + (c.tone === 'info' ? 'muted' : c.tone)}>{c.value}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}
