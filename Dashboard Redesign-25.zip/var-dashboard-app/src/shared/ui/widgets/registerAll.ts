import { registerWidgetType } from './registry';
import { KpiWidget } from './KpiWidget';
import { SummaryWidget } from './SummaryWidget';
import { GridWidget } from '../grid/GridWidget';
import { ChartWidget } from '../charts/ChartWidget';

// type → component. Adding a widget type = one line here + a component.
registerWidgetType('grid', GridWidget);
registerWidgetType('chart', ChartWidget);
registerWidgetType('kpi', KpiWidget);
registerWidgetType('summary', SummaryWidget);
