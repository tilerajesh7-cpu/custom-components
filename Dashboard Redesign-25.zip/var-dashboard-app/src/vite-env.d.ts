/// <reference types="vite/client" />
interface ImportMetaEnv {
  readonly VITE_AG_GRID_LICENSE?: string;
  readonly VITE_USE_MOCKS?: string;
  readonly VITE_API_BASE?: string;
}
interface ImportMeta { readonly env: ImportMetaEnv }
