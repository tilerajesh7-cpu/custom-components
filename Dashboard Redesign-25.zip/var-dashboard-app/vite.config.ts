import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  server: { port: 4000 },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor-aggrid': ['ag-grid-community', 'ag-grid-enterprise', 'ag-grid-react'],
          'vendor-highcharts': ['highcharts', 'highcharts-react-official'],
        },
      },
    },
  },
  test: { environment: 'node' },
} as never);
