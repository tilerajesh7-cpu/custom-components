# Dashboard app — Phase 1 (React + AG Grid Enterprise + Highcharts)

A single React app you can copy into your branch as-is. Everything runs locally: mock services, fonts and icons are all inside the project, with no CDN or external links at runtime.

## Run
```bash
npm install
cp .env.example .env.local     # add VITE_AG_GRID_LICENSE
npm run dev                    # http://localhost:4000/#/dashboards/dashboard-1
npm test                       # contract tests: every mock response is validated against the contracts
npm run build
```
- `VITE_USE_MOCKS=true` (default) serves all data from `src/mocks`. Set it to `false` to call real services at `VITE_API_BASE`.
- Fonts (Plus Jakarta Sans + IBM Plex Mono, same as the prototype) come from the `@fontsource/*` npm packages. If your registry doesn't have them, remove the imports in `src/main.tsx` and the system fallback is used.

## Structure
```
src/
  main.tsx                 AG Grid licence, Highcharts theme, widget registration
  app/                     App (providers, hash router), store (RTK + redux-persist), hooks, global.css
  contracts/               zod schemas = the response contracts (dashboard, widgets, datasets, navigation, batches)
  api/                     client.ts (mock or real, one switch) · queries.ts (TanStack Query hooks, param binding)
  theme/                   tokens.css · agGridTheme.ts · highchartsTheme.ts
  shared/ui/               ← reusable component library (no app state, no fetching)
    widgets/               WidgetFrame (states + spinner), registry, KPI, Daily brief, Export menu
    grid/                  GridWidget, toolbar + columns manager, column types, style/renderer rules, cell renderers, rich tooltip
    charts/                ChartWidget, presets, encoding → series
    controls/              Segmented, Popover, Modal, IconButton, Toast, Kbd
    lib/                   formats, rule compiler, download/copy
    icons.tsx              local icon set
  features/
    dashboard/             model (filters, selection, preferences, ui), WidgetHost, DashboardRenderer, FilterBar
    saved-views/           built-in + personal views, default ★, share link, 1–9
    live-refresh/          batch polling, countdown ring, ask-first banner / auto-apply, pause
    settings/              gear → density, reset grid layouts
    command-palette/       Ctrl/⌘K palette, keyboard shortcuts, help dialog
    dev-tools/             dev console (network, renders, data checks, simulate, state), query inspector (DB icon)
  layouts/AppShell.tsx     navy sidebar (navigation from services)
  pages/DashboardPage.tsx  route /#/dashboards/:dashboardId
  mocks/                   seed · dashboard + navigation · 6 dataset builders · mockApi (latency, errors, batches)
```
Rules:
- Only `shared/ui/grid` imports AG Grid, and only `shared/ui/charts` imports Highcharts.
- Widgets receive props and emit events. They never fetch data or read the store.
- Datasets live in the TanStack Query cache, never in Redux.

## Feature checklist (matches the HTML prototype)
- Sticky header, navy one-click filter bar, as-of date, cross-filter strip with chips and "Clear all".
- KPI tiles with sparklines. A Daily brief whose items cross-filter the grids when clicked.
- Summary grid:
  - column groups per model × measure;
  - Smart/Table cell toggle;
  - columns manager (group chips + per-column toggles);
  - search (`/` shortcut);
  - σ badges and a pinned totals row;
  - utilisation bars;
  - exact-value tooltip, plus a rich tooltip on names;
  - flashing cells when a new batch arrives.
- Trend chart with a 30/60/90-day range. Top changes (click a bar to filter). Stacked breakdown (click the legend to filter the breakdown grid). Thresholds grid linked to the exposure-vs-threshold chart, with stat tiles and zone colours.
- Spinner, empty, error-and-retry and no-access states for each widget.
- Export menu per widget:
  - grids: Excel (keeps the colours), CSV, copy for Excel, JSON;
  - charts: PNG, SVG, CSV.
- Saved views: built-in and personal, set a default, copy a share link, `1`–`9` to switch.
- Live data: checks for new batches every 15 s, countdown ring, "Ask me first" banner or automatic apply (waits while you read a tooltip), pause, and it stops checking while the tab is hidden.
- Density (gear or `D`), command palette (Ctrl/⌘K), shortcuts help (`?`).
- Developer tools (dev builds, or `localStorage.devtools = '1'`), hidden from end users:
  - dev console: network, render timings, data checks, simulation of latency, failures, empty data, no access and new batches, and a state view;
  - DB icon on each widget opens the query inspector: IDs, timing, cache, parameters, lineage, and the SQL (dev only);
  - closing the console reloads the page so the DB icons disappear.

## Handing contracts to services
`src/contracts/index.ts` defines every response. The builders in `src/mocks/*` show one valid example of each. Services should return the same shapes: AG Grid-ready `rowData`, `columnDefs` (the allowed subset), `pinnedBottomRowData`, `gridOptions` and `_meta` on each row. Styling is sent as tones only, never colours.

## Status
The code was written without being installed or compiled here. On the first `npm install`, run `npm run typecheck` and fix any small API-name differences for the exact AG Grid 33+ and Highcharts 12 versions you pin.

## Page export (PDF)
Header **Export** button → *Page as PDF* (one long page, exactly as on screen, in colour, including everything below the fold) or *Page as PDF · A4* (same image split into A4 pages). Also in the command palette.
Uses `html-to-image` + `jspdf`, loaded only when you export. The page is captured as an image, so text in the PDF is not selectable. If your registry doesn't have these packages, use the browser's Print → Save as PDF instead.
