import { useState } from 'react';
import type { Dashboard } from '@/contracts';
import { useAppSelector } from '@/app/hooks';
import { Popover, toast } from '@/shared/ui/controls';
import { Icon } from '@/shared/ui/icons';
import { widgetActions } from '@/shared/ui/widgets';
import { exportPagePdf, type PdfLayout } from './exportPagePdf';
import './export-page.css';

/** Top-level export: whole page as PDF (as on screen) · A4 pages · main grid to Excel. */
export function PageExportMenu({ dashboard }: { dashboard: Dashboard }) {
  const [busy, setBusy] = useState(false);
  const dateFilter = dashboard.filters.find((f) => f.control === 'date');
  const asOf = useAppSelector((s) => (dateFilter ? s.filters.values[dateFilter.filterId] ?? dateFilter.default : ''));
  const mainGrid = dashboard.hotkeys?.export;

  const pdf = async (layout: PdfLayout) => {
    if (busy) return;
    setBusy(true);
    toast('Preparing PDF…');
    try {
      await exportPagePdf({ layout, title: `${dashboard.title} · ${asOf}`, fileName: `${dashboard.title.replace(/\s+/g, '-')}-${asOf || 'export'}` });
      toast('PDF downloaded');
    } catch (e) {
      console.error(e);
      toast('Couldn’t create the PDF');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Popover width={290} title="Export" trigger={
      <span className={'hdr-btn is-icon is-primary' + (busy ? ' is-busy' : '')} title="Export page">
        {busy ? <span className="pe-spin" aria-hidden="true" /> : <Icon name="download" size={16} />}
      </span>
    }>
      {(close) => (
        <div className="pe">
          <button type="button" className="menu-item" disabled={busy} onClick={() => { close(); void pdf('single'); }}>
            <Icon name="download" size={14} />
            <span className="menu-item-text">Page as PDF<span className="menu-item-sub">Whole page, as on screen · one long page</span></span>
          </button>
          <button type="button" className="menu-item" disabled={busy} onClick={() => { close(); void pdf('a4'); }}>
            <Icon name="download" size={14} />
            <span className="menu-item-text">Page as PDF · A4<span className="menu-item-sub">Same view split into printable pages</span></span>
          </button>
          {mainGrid && (
            <>
              <div className="menu-sep" />
              <button type="button" className="menu-item" onClick={() => { close(); const fn = widgetActions.get(mainGrid)?.current['export.excel']; if (fn) { fn(); toast('Excel downloaded'); } }}>
                <Icon name="columns" size={14} />
                <span className="menu-item-text">Main grid · Excel<span className="menu-item-sub">With colours and number formats</span></span>
              </button>
            </>
          )}
        </div>
      )}
    </Popover>
  );
}
