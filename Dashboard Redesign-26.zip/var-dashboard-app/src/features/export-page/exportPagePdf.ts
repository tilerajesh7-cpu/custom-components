/**
 * Whole-page PDF export — exactly what is on screen, in colour, including everything below the fold.
 * Renders the app shell to a canvas (html-to-image), then writes it into a PDF (jsPDF).
 * Both libraries are loaded on demand, so they add nothing to the initial bundle.
 */
export type PdfLayout = 'single' | 'a4';

const SKIP = '.tip, .live-banner, .pop-panel, .toast, .toasts, [data-no-export]';
const MAX_CANVAS = 16000;           // safe canvas edge across browsers
const MAX_PDF_PT = 14400;           // PDF page size limit (200 in)

const nextFrame = () => new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r())));

export async function exportPagePdf({ fileName, title, layout = 'single' }: { fileName: string; title: string; layout?: PdfLayout }) {
  const root = document.querySelector<HTMLElement>('.shell');
  if (!root) throw new Error('Nothing to export');
  const [{ toCanvas }, { jsPDF }] = await Promise.all([import('html-to-image'), import('jspdf')]);

  const scrollY = window.scrollY;
  const html = document.documentElement;
  html.classList.add('is-capturing');
  window.scrollTo(0, 0);
  try {
    await document.fonts.ready;
    await nextFrame();
    const width = root.scrollWidth;
    const height = root.scrollHeight;
    const pixelRatio = Math.max(1, Math.min(2, MAX_CANVAS / height, MAX_CANVAS / width));
    const canvas = await toCanvas(root, {
      width, height, pixelRatio, cacheBust: true,
      backgroundColor: '#f1f4fa',
      filter: (n) => !(n instanceof Element && n.matches(SKIP)),
    });

    const pt = 0.75;                                  // CSS px → PDF pt
    const W = width * pt;
    const H = height * pt;
    const single = layout === 'single' && H <= MAX_PDF_PT;
    const pdf = single
      ? new jsPDF({ unit: 'pt', format: [W, H], orientation: W > H ? 'landscape' : 'portrait', compress: true })
      : new jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait', compress: true });
    pdf.setProperties({ title, subject: title, creator: 'Risk Portal' });

    if (single) {
      pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, W, H, undefined, 'FAST');
    } else {
      // Fit page width, slice the tall canvas into A4 pages.
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const sliceH = Math.floor((pageH / pageW) * canvas.width);
      const slice = document.createElement('canvas');
      slice.width = canvas.width;
      const ctx = slice.getContext('2d')!;
      for (let y = 0, i = 0; y < canvas.height; y += sliceH, i++) {
        const h = Math.min(sliceH, canvas.height - y);
        slice.height = h;
        ctx.fillStyle = '#f1f4fa';
        ctx.fillRect(0, 0, slice.width, h);
        ctx.drawImage(canvas, 0, y, canvas.width, h, 0, 0, canvas.width, h);
        if (i > 0) pdf.addPage();
        pdf.addImage(slice.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, pageW, (h / canvas.width) * pageW, undefined, 'FAST');
      }
    }
    pdf.save(fileName.endsWith('.pdf') ? fileName : fileName + '.pdf');
  } finally {
    html.classList.remove('is-capturing');
    window.scrollTo(0, scrollY);
  }
}
