import type { ReactNode } from 'react';
import type { Dashboard } from '@/contracts';
import { SegmentedControl } from '@/shared/ui/controls';
import { Icon } from '@/shared/ui/icons';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { clearAllSelections, clearSelection, setFilter } from './model';
import './filter-bar.css';

const HEADER_FILTER = 'compareTo';
const SECOND_ROW = new Set(['measure']);

/** Panels that react to the given selections (for the "→ …" hint). */
function affected(d: Dashboard, from: string[]) {
  return d.widgets.filter((w) => !from.includes(w.widgetId) && w.interactions?.listens?.some((l) => from.includes(l.from))).map((w) => w.title).join(', ') || 'related panels';
}

/** Compared-to date shown next to the COB date. */
function comparedDate(asOf: string, cmp: string) {
  const d = new Date(asOf + 'T00:00:00Z');
  if (Number.isNaN(d.getTime())) return '';
  if (cmp === 'WoW') d.setUTCDate(d.getUTCDate() - 7);
  else if (cmp === 'MoM') d.setUTCMonth(d.getUTCMonth() - 1);
  else do { d.setUTCDate(d.getUTCDate() - 1); } while (d.getUTCDay() === 0 || d.getUTCDay() === 6);
  return d.toISOString().slice(0, 10);
}

/** Sticky top: title + date cards + compare + actions · navy two-row filter bar (+ views) · cross-filter strip. */
export function FilterBar({ dashboard, actions, banner, views, labelFor }: {
  dashboard: Dashboard; actions?: ReactNode; banner?: ReactNode; views?: ReactNode; labelFor: (widgetId: string, key: string) => string;
}) {
  const dispatch = useAppDispatch();
  const values = useAppSelector((s) => s.filters.values);
  const selection = useAppSelector((s) => s.selection.byWidget);
  const chips = Object.entries(selection);
  const date = dashboard.filters.find((f) => f.control === 'date');
  const compare = dashboard.filters.find((f) => f.filterId === HEADER_FILTER);
  const segmented = dashboard.filters.filter((f) => f.control === 'segmented' && f !== compare);
  const row1 = segmented.filter((f) => !SECOND_ROW.has(f.filterId));
  const row2 = segmented.filter((f) => SECOND_ROW.has(f.filterId));
  const asOf = date ? values[date.filterId] ?? date.default : '';
  const seg = (f: (typeof segmented)[number]) => (
    <SegmentedControl key={f.filterId} label={f.label} value={values[f.filterId] ?? f.default} options={f.options ?? []} onChange={(v) => dispatch(setFilter({ id: f.filterId, value: v }))} />
  );

  return (
    <div className="fb-sticky">
      <header className="fb-head">
        <div className="fb-titles">
          {dashboard.breadcrumb && <div className="fb-crumb">{dashboard.breadcrumb.map((b) => <span key={b}>{b}</span>)}</div>}
          <h1 className="fb-title">{dashboard.title}</h1>
        </div>
        <div className="fb-right">
          {date && (
            <label className="fb-card">
              <Icon name="history" size={15} />
              <span className="fb-card-text"><small>As of</small>
                <input type="date" value={asOf} onChange={(e) => e.target.value && dispatch(setFilter({ id: date.filterId, value: e.target.value }))} />
              </span>
            </label>
          )}
          {date && compare && (
            <div className="fb-card">
              <Icon name="refresh" size={15} />
              <span className="fb-card-text"><small>Compared to</small><b>{comparedDate(asOf, values[compare.filterId] ?? compare.default)}</b></span>
            </div>
          )}
          {compare && (
            <div className="hdr-seg">
              <SegmentedControl tone="light" value={values[compare.filterId] ?? compare.default} options={compare.options ?? []} onChange={(v) => dispatch(setFilter({ id: compare.filterId, value: v }))} />
            </div>
          )}
          <div className="fb-actions">{actions}</div>
        </div>
      </header>
      <div className="fb-bar">
        <div className="fb-bar-row">{row1.map(seg)}</div>
        <div className="fb-bar-row">{row2.map(seg)}{views}</div>
      </div>
      <div className="fb-cross">
        <span className="fb-cross-label"><Icon name="filter" size={12} />Cross-filters<b>{chips.length}</b></span>
        {chips.length === 0 && <span className="fb-cross-hint">Click a row, bar or legend to filter related panels</span>}
        {chips.map(([wid, keys]) => (
          <span key={wid} className="fb-chip">
            <span className="fb-chip-kind">{dashboard.widgets.find((w) => w.widgetId === wid)?.title ?? wid}</span>
            <b>{keys.map((k) => labelFor(wid, k)).join(', ')}</b>
            <button type="button" aria-label="Remove filter" onClick={() => dispatch(clearSelection(wid))}><Icon name="x" size={11} strokeWidth={2.4} /></button>
          </span>
        ))}
        {chips.length > 0 && <span className="fb-applies">→ {affected(dashboard, chips.map(([w]) => w))}</span>}
        {chips.length > 0 && <button type="button" className="fb-clear" onClick={() => dispatch(clearAllSelections())}>Clear all <kbd className="kbd">Esc</kbd></button>}
      </div>
      {banner}
    </div>
  );
}
