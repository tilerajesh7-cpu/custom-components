// Mock dataset builders — responses follow src/contracts (AG Grid-ready rows + columnDefs).
import type { ColDefContract, Dataset, Row } from '@/contracts';
import { ATTR_FACTOR, COMPARE_OFFSET, ENTITIES, ENTITY, FS, FS_NAMES, FS_BASE, HORIZON_FACTOR, LIMITS, MEASURES, MODELS, businessDays, history } from './seed';

export type Params = Record<string, string>;
const N = 250;
const ASOF = (p: Params) => (p.asOf || '2026-09-11') + 'T11:41:00-04:00';
type Model = (typeof MODELS)[number];
type Measure = (typeof MEASURES)[number];
interface Group { key: string; label: string; model: Model; measure: Measure }

const FS_COLORS = ['#2f62c9', '#3a8a5c', '#c2392f', '#4a90c9', '#6a4bd6', '#d0782a', '#5a8a3a', '#2f4f8a', '#b7780a', '#d0782a', '#7fa2fb', '#12918a', '#8a5a06', '#6a7fb0', '#9b59b6', '#5cc9bf'];
export const GROUP_COLOR: Record<string, string> = { MC_var: '#2f62c9', Hist_var: '#6a4bd6', MC_svar: '#12918a', Hist_svar: '#b7780a' };

function groupsFor(p: Params): Group[] {
  const models = !p.model || p.model === 'Both' ? MODELS : MODELS.filter((m) => m.id === p.model);
  const measures = !p.measure || p.measure === 'Both' ? MEASURES : MEASURES.filter((m) => m.id === p.measure.toLowerCase());
  const out: Group[] = [];
  for (const me of measures) for (const mo of models) out.push({ key: `${mo.id}_${me.id}`, label: `${mo.label} ${me.label}`, model: mo, measure: me });
  return out;
}
const primaryModel = (p: Params) => MODELS.find((m) => m.id === p.model) ?? MODELS[0];

function entitiesInScope(p: Params, useEntity: boolean) {
  return ENTITIES.map((d, i) => ({ d, i })).filter(({ d }) =>
    (!p.region || p.region === 'All' || d.region === p.region) && (!useEntity || !p.entityId || d.id === p.entityId));
}

/** Each new batch nudges ~half the entities so deltas and row flash have something to show. */
const nudge = (i: number, batch: number) => {
  if (batch <= 4812) return 1;
  const h = (i * 2654435761 + batch * 40503) >>> 0;
  return h % 2 ? 1 + ((h % 100) / 100 - 0.48) * 0.06 : 1;
};

const cache = new Map<string, number[]>();
function series(i: number, model: Model, measure: 'var' | 'svar', p: Params, batch: number) {
  const k = [i, model.id, measure, p.variant, p.attr, batch].join('|');
  const hit = cache.get(k); if (hit) return hit;
  const f = model.factor * (HORIZON_FACTOR[p.variant || '1D'] ?? 1) * (ATTR_FACTOR[p.attr || 'Trading'] ?? 1);
  const d = ENTITIES[i];
  const s = history(i * 97 + (measure === 'svar' ? 13 : 0) + (model.id === 'Hist' ? 29 : 0), d.cob[measure] * f * nudge(i, batch), d.pcob[measure] * f, N);
  cache.set(k, s); return s;
}

const LINEAGE: Record<string, string[]> = {
  'dataset-1': ['risk_engine.var_run', 'mart.var_by_entity', 'api.entity_var'],
  'dataset-2': ['risk_engine.var_run', 'mart.var_history', 'api.var_trend'],
  'dataset-3': ['risk_engine.component_var', 'mart.var_by_fs', 'api.fs_var'],
  'dataset-4': ['risk_engine.component_var', 'mart.var_fs_history', 'api.fs_trend'],
  'dataset-5': ['ref.limit_master', 'mart.var_by_entity', 'api.limit_utilisation'],
  'dataset-6': ['ref.limit_master', 'mart.limit_history', 'api.limit_history'],
};
function meta(id: string, rows: number, batch: number, p: Params) {
  const src = LINEAGE[id]?.[1] ?? id;
  const where = Object.entries(p).filter(([, v]) => v).map(([k]) => `${k} = :${k}`).join('\n  AND ');
  return {
    rowCount: rows, batchId: batch, queryId: `q-${id.split('-')[1]}-${batch.toString(16)}`,
    cache: (batch + rows) % 3 ? ('HIT' as const) : ('MISS' as const), lineage: LINEAGE[id],
    sql: `SELECT *\nFROM ${src}\nWHERE batch_id = ${batch}${where ? '\n  AND ' + where : ''}`,
  };
}
const money = (field: string, headerName: string, extra: Partial<ColDefContract> = {}) => ({ field, headerName, type: ['money'], ...extra }) as ColDefContract;
function sd(xs: number[]) {
  const d = xs.slice(1).map((x, i) => x - xs[i]);
  const m = d.reduce((a, b) => a + b, 0) / d.length;
  return Math.sqrt(d.reduce((a, b) => a + (b - m) ** 2, 0) / d.length) || 1;
}
const groupCols = (g: Group, max: number, compact: boolean): ColDefContract => ({
  groupId: g.key, headerName: g.label, headerTooltip: `${g.model.long} ${g.measure.label}`,
  children: [
    money(`${g.key}_cob`, 'COB', { cellRenderer: 'smartCell', minWidth: 84, cellRendererParams: { previousField: `${g.key}_pcob`, changeField: `${g.key}_d`, max, color: GROUP_COLOR[g.key] } }),
    money(`${g.key}_pcob`, 'PCOB', { hide: compact }),
    money(`${g.key}_d`, 'Δ', { type: ['money', 'change'], hide: compact }),
    { field: `${g.key}_dp`, headerName: 'Δ%', type: ['percentChange'], hide: true, minWidth: 72 },
  ],
});
const sum = (rows: Row[], f: string) => rows.reduce((a, r) => a + ((r[f] as number) || 0), 0);

// dataset-1 · Standalone VaR / SVaR by entity
function dataset1(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), off = COMPARE_OFFSET[p.compare || 'DoD'] ?? 1, pm = primaryModel(p);
  const f = (HORIZON_FACTOR[p.variant || '1D'] ?? 1) * (ATTR_FACTOR[p.attr || 'Trading'] ?? 1);
  const maxBy: Record<string, number> = {};
  const rows: Row[] = entitiesInScope(p, false).map(({ d, i }) => {
    const r: Row = { id: d.id, label: d.name, short: d.short, region: d.region, limit: Math.round(d.limit * f) };
    for (const g of groups) {
      const s = series(i, g.model, g.measure.id as 'var' | 'svar', p, batch), cob = Math.round(s[N - 1]), pcob = Math.round(s[N - 1 - off]);
      Object.assign(r, { [`${g.key}_cob`]: cob, [`${g.key}_pcob`]: pcob, [`${g.key}_d`]: cob - pcob, [`${g.key}_dp`]: pcob ? (cob - pcob) / pcob : 0 });
      maxBy[g.key] = Math.max(maxBy[g.key] ?? 0, cob);
    }
    for (const m of ['var', 'svar'] as const) {
      const s = series(i, pm, m, p, batch);
      r[m + 'Cob'] = Math.round(s[N - 1]); r[m + 'Pcob'] = Math.round(s[N - 1 - off]); r[m + 'D'] = (r[m + 'Cob'] as number) - (r[m + 'Pcob'] as number);
      if (m === 'var') {
        const z = (s[N - 1] - s[N - 1 - off]) / (sd(s.slice(-61)) * Math.sqrt(off));
        if (Math.abs(z) >= 2) r._meta = { row: { badges: [{ text: (z > 0 ? '▲ ' : '▼ ') + Math.abs(z).toFixed(1) + 'σ', tone: z > 0 ? 'negative' : 'positive', tooltip: 'Unusual move vs typical daily change' }] } };
      }
    }
    r.limitUse = (r.varCob as number) / (r.limit as number);
    r.varDp = r.varPcob ? (r.varD as number) / (r.varPcob as number) : 0;
    r.svarDp = r.svarPcob ? (r.svarD as number) / (r.svarPcob as number) : 0;
    const sh = share(i, 0);
    r.topFs = FS.map((code, j) => ({ code, name: FS_NAMES[code] ?? code, value: Math.round((r.varCob as number) * sh[j]) }))
      .sort((a, b) => b.value - a.value).slice(0, 4);
    return r;
  });
  const totalVar = sum(rows, 'varCob') || 1;
  [...rows].sort((a, b) => (b.varCob as number) - (a.varCob as number)).forEach((r, k) => { r.rank = k + 1; r.varShare = (r.varCob as number) / totalVar; });
  const total: Row = { id: 'total', label: 'Total' };
  for (const g of groups) {
    for (const k of ['cob', 'pcob', 'd']) total[`${g.key}_${k}`] = sum(rows, `${g.key}_${k}`);
    total[`${g.key}_dp`] = total[`${g.key}_pcob`] ? (total[`${g.key}_d`] as number) / (total[`${g.key}_pcob`] as number) : 0;
  }
  for (const k of ['varCob', 'varPcob', 'varD', 'svarCob', 'svarPcob', 'svarD', 'limit']) total[k] = sum(rows, k);
  total.limitUse = total.limit ? (total.varCob as number) / (total.limit as number) : 0;
  const compact = groups.length > 2;
  const columnDefs: ColDefContract[] = [
    {
      field: 'label', headerName: ENTITY.one, pinned: 'left', width: 230, minWidth: 210, type: ['text'], cellRenderer: 'labelCell', cellRendererParams: { tagField: 'region' }, tooltipField: 'label', tooltipComponent: 'detailTooltip',
      tooltipComponentParams: {
        kicker: ENTITY.one, tagField: 'region', statusField: 'limitUse', rankField: 'rank', rankOf: rows.length, rankLabel: 'by VaR',
        sections: [{ label: 'VaR COB', field: 'varCob' }, { label: 'VaR vs {compare}', field: 'varD', type: 'change', pctField: 'varDp' }, { label: 'SVaR COB', field: 'svarCob' }, { label: 'SVaR vs {compare}', field: 'svarD', type: 'change', pctField: 'svarDp' }, { label: 'Share of total VaR', field: 'varShare', type: 'percent' }],
        list: { title: 'Top FS contributors · $MM', field: 'topFs' },
        compare: p.compare || 'DoD',
        hint: `to cross-filter · J / K to step ${ENTITY.many}`,
      },
      rendererRules: [{ when: { row: 'pinned' }, renderer: 'totalCell' }],
    },
    ...groups.map((g) => groupCols(g, maxBy[g.key] || 1, compact)),
    { field: 'limit', headerName: 'VaR limit', type: ['money'], hide: true },
    { field: 'limitUse', headerName: 'Limit use', type: ['percent', 'threshold'], minWidth: 110, cellRendererParams: { warn: 0.8, breach: 1 },
      styleRules: [{ when: { op: 'gte', value: 1 }, tone: 'breach', emphasis: true }] },
  ];
  return {
    datasetId: 'dataset-1', kind: 'grid', version: `b${batch}-1`, asOf: ASOF(p), rowKey: 'id', columnDefs, rowData: rows, pinnedBottomRowData: [total],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'single', statusBar: 'aggregations' }, meta: meta('dataset-1', rows.length, batch, p),
  };
}

// dataset-2 · VaR trend (per group) + primary VaR/SVaR totals for KPI sparklines
function dataset2(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), days = Number(p.days || 90), dates = businessDays(p.asOf || '2026-09-11', days), pm = primaryModel(p);
  const entities = entitiesInScope(p, true);
  const agg = (model: Model, m: 'var' | 'svar') => { const acc = new Array(N).fill(0); entities.forEach(({ i }) => series(i, model, m, p, batch).forEach((v, k) => { acc[k] += v; })); return acc.slice(-days); };
  const g = groups.map((x) => agg(x.model, x.measure.id as 'var' | 'svar'));
  const kv = agg(pm, 'var'), ks = agg(pm, 'svar');
  return {
    datasetId: 'dataset-2', kind: 'series', version: `b${batch}-2`, asOf: ASOF(p), rowKey: 'date',
    seriesDefs: groups.map((x) => ({ field: x.key, name: x.label, type: ['money'], palette: { MC_var: 1, Hist_var: 6, MC_svar: 3, Hist_svar: 5 }[x.key] ?? 1, dash: x.model.id === 'Hist' })),
    rowData: dates.map((d, k) => ({ date: d, ...Object.fromEntries(groups.map((x, j) => [x.key, Math.round(g[j][k])])), var: Math.round(kv[k]), svar: Math.round(ks[k]) })),
    meta: meta('dataset-2', days, batch, p),
  };
}

const share = (entityIdx: number, phase: number) => {
  const a = FS_BASE.map((b, j) => b * (1 + 0.45 * Math.sin(j * 1.3 + entityIdx * 0.7 + phase)));
  const t = a.reduce((x, y) => x + y, 0);
  return a.map((x) => x / t);
};

// dataset-3 · Component VaR / SVaR by FS type
function dataset3(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), off = COMPARE_OFFSET[p.compare || 'DoD'] ?? 1, entities = entitiesInScope(p, true);
  const rows: Row[] = FS.map((code, j) => {
    const r: Row = { id: code, label: code, name: FS_NAMES[code] ?? code, color: FS_COLORS[j % FS_COLORS.length] };
    for (const g of groups) {
      const m = g.measure.id as 'var' | 'svar', ph = m === 'svar' ? 2 : 0;
      let cob = 0, pcob = 0;
      entities.forEach(({ i }) => { const s = series(i, g.model, m, p, batch); cob += s[N - 1] * share(i, ph)[j]; pcob += s[N - 1 - off] * share(i, ph + 0.5)[j]; });
      Object.assign(r, { [`${g.key}_cob`]: Math.round(cob), [`${g.key}_pcob`]: Math.round(pcob), [`${g.key}_d`]: Math.round(cob) - Math.round(pcob), [`${g.key}_dp`]: pcob ? (cob - pcob) / Math.abs(pcob) : 0 });
    }
    return r;
  });
  const k0 = groups[0].key, t1 = sum(rows, `${k0}_cob`) || 1;
  rows.forEach((r) => { r.share = (r[`${k0}_cob`] as number) / t1; });
  rows.sort((a, b) => (b[`${k0}_cob`] as number) - (a[`${k0}_cob`] as number));
  const total: Row = { id: 'total', label: 'Total' };
  for (const g of groups) for (const k of ['cob', 'pcob', 'd']) total[`${g.key}_${k}`] = sum(rows, `${g.key}_${k}`);
  total.share = 1;
  const compact = groups.length > 2;
  return {
    datasetId: 'dataset-3', kind: 'grid', version: `b${batch}-3`, asOf: ASOF(p), rowKey: 'id', rowData: rows, pinnedBottomRowData: [total],
    columnDefs: [
      { field: 'label', headerName: 'FS type', pinned: 'left', width: 120, minWidth: 100, type: ['text'], cellRenderer: 'swatchCell', cellRendererParams: { colorField: 'color' }, tooltipField: 'name', rendererRules: [{ when: { row: 'pinned' }, renderer: 'totalCell' }] },
      ...groups.map((g) => {
        const gc = groupCols(g, Math.max(1, ...rows.map((r) => r[`${g.key}_cob`] as number)), true) as { groupId: string; headerName: string; children: ColDefContract[] };
        if (!compact) gc.children = gc.children.map((c) => ('field' in c && c.field.endsWith('_d') ? { ...c, hide: false } : c));
        return gc as ColDefContract;
      }),
      { field: 'share', headerName: 'Share of VaR', type: ['percent'], minWidth: 130, cellRenderer: 'shareCell', rendererRules: [{ when: { row: 'pinned' }, renderer: 'shareTotalCell' }] },
    ],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'single' },
    meta: meta('dataset-3', rows.length, batch, p),
  };
}

// dataset-4 · Component VaR over time (top 6 FS types + Other)
function dataset4(p: Params, batch: number): Dataset {
  const g = groupsFor(p)[0], m = g.measure.id as 'var' | 'svar', days = Number(p.days || 90), dates = businessDays(p.asOf || '2026-09-11', days);
  const entities = entitiesInScope(p, true);
  const top = FS.slice(0, 6);
  const rows = dates.map((d, k) => {
    const idx = N - days + k; const r: Row = { date: d }; let tot = 0;
    entities.forEach(({ i }) => { tot += series(i, g.model, m, p, batch)[idx]; });
    let used = 0;
    top.forEach((code, j) => { const v = tot * FS_BASE[j] * (1 + 0.14 * Math.sin(k / 4.3 + j * 1.7)); r[code] = Math.round(v); used += v; });
    r.Other = Math.round(tot - used);
    return r;
  });
  return {
    datasetId: 'dataset-4', kind: 'series', version: `b${batch}-4`, asOf: ASOF(p), rowKey: 'date', rowData: rows,
    seriesDefs: [...top.map((c, j) => ({ field: c, name: c, type: ['money'], palette: j + 1, stack: 's' })), { field: 'Other', name: 'Other', type: ['money'], palette: 8, stack: 's' }],
    meta: meta('dataset-4', days, batch, p),
  };
}

function limitExposure(l: (typeof LIMITS)[number], p: Params, batch: number) {
  const [, , , entity, kind] = l;
  const idx = entity === null ? ENTITIES.map((_, i) => i) : [entity];
  const acc = new Array(N).fill(0);
  idx.forEach((i) => series(i, MODELS[0], kind, { ...p, variant: '1D', attr: 'Trading' }, batch).forEach((v, k) => { acc[k] += v; }));
  return acc;
}

// dataset-5 · VaR limits
function dataset5(p: Params, batch: number): Dataset {
  const rows: Row[] = LIMITS.map((l) => {
    const s = limitExposure(l, p, batch), limit = l[5] * 1e6, exposure = Math.round(s[N - 1]), previous = Math.round(s[N - 2]);
    return { id: l[0], label: l[1], unit: l[2], kind: l[4] === 'var' ? 'VaR' : 'SVaR', limit, exposure, previous, change: exposure - previous, ratio: exposure / limit, headroom: limit - exposure };
  }).sort((a, b) => (b.ratio as number) - (a.ratio as number));
  const breaches = rows.filter((r) => (r.ratio as number) >= 1).length, warn = rows.filter((r) => (r.ratio as number) >= 0.8).length;
  const total: Row = { id: 'total', label: `${warn} at risk · ${breaches} in breach`, limit: sum(rows, 'limit'), exposure: sum(rows, 'exposure'), previous: sum(rows, 'previous'), change: sum(rows, 'change') };
  return {
    datasetId: 'dataset-5', kind: 'grid', version: `b${batch}-5`, asOf: ASOF(p), rowKey: 'id', rowData: rows, pinnedBottomRowData: [total],
    columnDefs: [
      { field: 'label', headerName: 'Limit', pinned: 'left', width: 220, minWidth: 170, type: ['text'], cellRenderer: 'stackCell', cellRendererParams: { subField: 'id' }, rendererRules: [{ when: { row: 'pinned' }, renderer: 'totalCell' }] },
      { field: 'unit', headerName: 'Tier', minWidth: 150, type: ['text'] },
      { field: 'kind', headerName: 'Type', type: ['tag'], minWidth: 70, hide: true },
      money('limit', 'Threshold', { cellRendererParams: {}, minWidth: 90 }),
      money('exposure', 'Exposure', { minWidth: 90 }),
      { field: 'ratio', headerName: 'Utilisation', type: ['percent', 'threshold'], minWidth: 170, cellRendererParams: { warn: 0.8, breach: 1 } },
      money('change', '1D Δ', { type: ['money', 'change'] }),
    ],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'single' }, meta: meta('dataset-5', rows.length, batch, p),
  };
}

// dataset-6 · Exposure vs limit for one limit (default: highest utilisation)
function dataset6(p: Params, batch: number): Dataset {
  const ranked = [...LIMITS].sort((a, b) => { const u = (l: typeof a) => limitExposure(l, p, batch)[N - 1] / (l[5] * 1e6); return u(b) - u(a); });
  const l = LIMITS.find((x) => x[0] === p.limitId) ?? ranked[0];
  const limit = l[5] * 1e6, s = limitExposure(l, p, batch).slice(-90), dates = businessDays(p.asOf || '2026-09-11', 90);
  return {
    datasetId: 'dataset-6', kind: 'series', version: `b${batch}-6-${l[0]}`, asOf: ASOF(p), rowKey: 'date',
    seriesDefs: [{ field: 'value', name: `${l[0]} · ${l[1]}`, type: ['money'], palette: 1 }],
    rowData: dates.map((d, k) => ({ date: d, value: Math.round(s[k]), threshold: k < 45 ? Math.round(limit * 0.9) : limit })),
    meta: meta('dataset-6', 90, batch, { ...p, limitId: l[0] }),
  };
}

const BUILDERS: Record<string, (p: Params, b: number) => Dataset> = {
  'dataset-1': dataset1, 'dataset-2': dataset2, 'dataset-3': dataset3, 'dataset-4': dataset4, 'dataset-5': dataset5, 'dataset-6': dataset6,
};
export const MOCK_DATASET_IDS = Object.keys(BUILDERS);

export function buildDataset(id: string, params: Params, batch: number): Dataset {
  const b = BUILDERS[id];
  if (!b) throw new Error('Unknown dataset ' + id);
  if (cache.size > 4000) cache.clear();
  return b(params, batch);
}
