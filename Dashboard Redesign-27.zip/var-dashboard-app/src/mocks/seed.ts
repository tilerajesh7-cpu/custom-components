// Seeded mock world — same entities, FS types and limits as the finalised prototype. Names are generic placeholders.
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** [name, region, VaR COB, VaR PCOB, SVaR COB, SVaR PCOB, VaR limit] in $MM */
/** Display vocabulary for the primary grid — real services send their own labels. */
export const ENTITY = { one: 'Entity', many: 'entities' };

const ENTITY_ROWS: [string, string, number, number, number, number, number][] = [
  ['Entity 01', 'NA', 52.40, 49.10, 68.10, 66.40, 62],
  ['Entity 02', 'NA', 29.85, 27.60, 41.32, 39.87, 40],
  ['Entity 03', 'EMEA', 24.73, 18.53, 29.00, 26.60, 35],
  ['Entity 04', 'EMEA', 11.40, 5.05, 28.25, 11.20, 10],
  ['Entity 05', 'Global', 6.90, 7.92, 9.39, 9.33, 12],
  ['Entity 06', 'NA', 6.18, 8.03, 6.95, 10.37, 12],
  ['Entity 07', 'Global', 6.07, 5.81, 4.31, 4.29, 9],
  ['Entity 08', 'EMEA', 3.87, 3.96, 3.49, 3.59, 6],
  ['Entity 09', 'APAC', 3.41, 11.85, 3.10, 14.11, 15],
  ['Entity 10', 'APAC', 2.59, 2.62, 3.42, 3.28, 5],
  ['Entity 11', 'Latam', 1.02, 1.01, 1.17, 1.00, 3],
  ['Entity 12', 'Latam', 0.60, 0.62, 0.84, 0.96, 2],
  ['Entity 13', 'Global', 0.42, 0.44, 2.19, 2.38, 2],
  ['Entity 14', 'Global', 0.09, 1.46, 0.17, 2.39, 3],
  ['Entity 15', 'Global', 0.03, 0.03, 0.01, 0.01, 1],
  ['Entity 16', 'Global', 0.01, 0.01, 0.01, 0.01, 1],
];
export const short = (n: string) => n.replace('Entity ', 'E');

export const ENTITIES = ENTITY_ROWS.map(([name, region, vc, vp, sc, sp, limit], i) => ({
  id: 'E' + String(i + 1).padStart(2, '0'), name, short: short(name), region,
  cob: { var: vc * 1e6, svar: sc * 1e6 }, pcob: { var: vp * 1e6, svar: sp * 1e6 }, limit: limit * 1e6,
}));

export const MODELS = [{ id: 'MC', label: 'MC', long: 'Monte Carlo', factor: 1 }, { id: 'Hist', label: 'Hist', long: 'Historical', factor: 0.91 }];
export const MEASURES = [{ id: 'var', label: 'VaR' }, { id: 'svar', label: 'SVaR' }];

export const FS = ['EQDV', 'EQDL', 'IRVG', 'BCSY', 'ISDL', 'IDIO', 'BCID', 'CMDL', 'DTID', 'ECVG', 'FXVG', 'IRDL', 'CMVG', 'FXRR', 'FXST', 'FXDL'];
export const FS_NAMES: Record<string, string> = {
  EQDV: 'Equity vega', EQDL: 'Equity delta', IRVG: 'Interest-rate vega', BCSY: 'Basis · credit sys', ISDL: 'Inflation delta', IDIO: 'Idiosyncratic',
  BCID: 'Basis · credit idio', CMDL: 'Commodity delta', DTID: 'Default idio', ECVG: 'Equity corr vega', FXVG: 'FX vega', IRDL: 'Interest-rate delta',
  CMVG: 'Commodity vega', FXRR: 'FX risk reversal', FXST: 'FX spot', FXDL: 'FX delta',
};
export const FS_BASE = [0.40, 0.19, 0.08, 0.07, 0.06, 0.05, 0.04, 0.03, 0.025, 0.02, 0.015, 0.012, 0.006, 0.004, 0.002, -0.012];

/** [id, name, owner, entity index | null (all entities), kind, limit $MM] */
export const LIMITS: [string, string, string, number | null, 'var' | 'svar', number][] = [
  ['LIM-1870', 'Deriv - NAM VaR', 'Business Unit - Americas', 0, 'var', 62],
  ['LIM-1355', 'Fin - EMEA VaR', 'Business Unit - Europe', 3, 'var', 10],
  ['LIM-1875', 'Fin - NAM VaR', 'Business Unit - Americas', 1, 'var', 40],
  ['LIM-9663', 'SVaR - Global', 'Division', null, 'svar', 250],
  ['LIM-1360', 'Deriv - EMEA VaR', 'Business Unit - Europe', 2, 'var', 35],
  ['LIM-2050', 'Cash - APAC VaR', 'Business Unit - Asia', 9, 'var', 5],
  ['LIM-6032', 'Structured - VaR', 'Business Unit - Global', 4, 'var', 27],
  ['LIM-8345', 'Convertibles - Stressed VaR', 'Business Unit - Global', 6, 'svar', 20],
  ['LIM-1873', 'Cash - NAM VaR', 'Business Unit - Americas', 5, 'var', 35],
  ['LIM-2045', 'Deriv - Stressed VaR', 'Business Unit - Asia', 8, 'svar', 18],
  ['LIM-1878', 'Fin - LATAM VaR', 'Business Unit - Americas', 10, 'var', 8],
  ['LIM-1357', 'Cash - SVaR', 'Business Unit - Europe', 7, 'svar', 32],
  ['LIM-1872', 'Fin - LATAM Stress', 'Business Unit - Americas', 10, 'svar', 14],
  ['LIM-1206', 'Cash - NAM Stress', 'Business Unit - Americas', 5, 'svar', 90],
  ['LIM-1877', 'Deriv - LATAM VaR', 'Business Unit - Americas', 11, 'var', 10],
];

export function businessDays(asOf: string, n: number): string[] {
  const out: string[] = [];
  let d = new Date(asOf + 'T00:00:00Z');
  while (out.length < n) {
    const w = d.getUTCDay();
    if (w && w < 6) out.unshift(d.toISOString().slice(0, 10));
    d = new Date(d.getTime() - 864e5);
  }
  return out;
}

/** Seeded walk of n points: ends at `end`, point n-2 equals `prev` (the DoD PCOB). */
export function history(seed: number, end: number, prev: number, n = 250): number[] {
  const r = rng(seed);
  const raw: number[] = [1];
  for (let i = 1; i < n; i++) raw.push(raw[i - 1] * (1 + (r() - 0.5) * 0.05 + 0.012 * Math.sin(i / 9 + seed)));
  const scale = prev / raw[n - 2];
  const out = raw.map((x) => x * scale);
  out[n - 1] = end;
  return out;
}

export const COMPARE_OFFSET: Record<string, number> = { DoD: 1, WoW: 5, MoM: 21 };
export const HORIZON_FACTOR: Record<string, number> = { '1D': 1, '10D': Math.sqrt(10) };
export const ATTR_FACTOR: Record<string, number> = { Trading: 1, Economic: 1.07, 'Regulatory A': 0.94, 'Regulatory B': 1.12, 'Trading & Credit': 1.18 };
