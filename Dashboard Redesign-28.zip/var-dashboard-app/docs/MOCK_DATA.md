# Mock data — what it is and how to hand it to services

## Where the mock lives
| File | What it is |
|---|---|
| `src/mocks/dashboard.ts` | **Dashboard definition** (`GET /dashboards/{id}`) + sidebar (`GET /me/navigation`): filters, datasets + bindings, widgets, layout, tabs, alerts. |
| `src/mocks/datasets.ts` | **Grid and chart data** (`GET /datasets/{id}`). One function per dataset: |
| | • `dataset1` — **primary grid** (VaR / SVaR per row) · `dataset3` — **FS type grid** · `dataset5` — **limits grid** |
| | • `dataset2` trend · `dataset4` FS over time · `dataset6` exposure vs limit (charts) |
| `src/mocks/seed.ts` | Seeded numbers (primary-grid rows, FS types, limits, 250-day history). Row names like “Derivatives Desk A” are **data** — another app sends different rows and columns; no code changes. Same seed → same numbers. |
| `src/mocks/mockApi.ts` | The fake server: routes a URL to the builders above, adds latency / errors. |
| `src/mocks/servicesPack.ts` | Builds the **services pack** (below). |

A grid response is **generated**, not a static JSON file: `dataset1(params)` returns `{ columnDefs, rowData, pinnedBottomRowData, gridOptions, meta }` for whatever filters the user picked.

## How to give it to the services team
1. `npm run dev` → open the dashboard.
2. Open the dev console: **Ctrl + Shift + D** → tab **Simulate**.
3. Click **Download services pack (JSON)** — one file with every endpoint — or **One file per endpoint**.

The pack contains, for each call: `method`, `url` (with real query string), `params`, `purpose`, and the **exact response body** the UI expects, plus *drilldown* variants (`rowId`, `limitId`) and the error codes (403 / 404 / 503 / empty).

Tell services: *“Return exactly this shape at these URLs. Field names, types and nesting must match; values are yours.”*
The zod schemas in `src/contracts/index.ts` are the formal definition — the UI validates every response against them in development.
