import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { formats, isNum } from '@/shared/ui/lib/formats';
import { Icon } from '@/shared/ui/icons';
import { cssVars } from '@/shared/ui/controls';
import { dismissAlert, setSelection, setTab } from './model';
import { scrollToWidget } from '@/features/command-palette/scroll';

/** Tab bar from dashboard.tabs. */
export function TabBar({ dashboard }: { dashboard: Dashboard }) {
  const dispatch = useAppDispatch();
  const current = useAppSelector((s) => s.ui.tab);
  if (!dashboard.tabs?.length) return null;
  const active = dashboard.tabs.find((t) => t.tabId === current) ? current : dashboard.tabs[0].tabId;
  return (
    <div className="tabs" role="tablist" aria-label="Sections">
      {dashboard.tabs.map((t) => (
        <button key={t.tabId} type="button" role="tab" aria-selected={t.tabId === active} className={'tab' + (t.tabId === active ? ' is-on' : '')} onClick={() => dispatch(setTab(t.tabId))}>{t.label}</button>
      ))}
    </div>
  );
}

/**
 * Attention panel: every row at/above `warn` with a plain-language explanation —
 * status, name + id, exposure vs threshold, utilization, amount over / headroom, 1D change.
 * Clicking an item selects the row in the target grid and scrolls to it.
 */
export function AttentionStrip({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const dispatch = useAppDispatch();
  const dismissed = useAppSelector((s) => s.ui.alertDismissed);
  const selected = useAppSelector((s) => (dashboard.alerts ? s.selection.byWidget[dashboard.alerts.target] : undefined));
  const cfg = dashboard.alerts;
  const ds = cfg ? datasets[cfg.datasetId]?.data : undefined;
  if (!cfg || !ds || dismissed) return null;
  const hits = ds.rowData.filter((r) => isNum(r[cfg.field]) && (r[cfg.field] as number) >= cfg.warn).sort((a, b) => (b[cfg.field] as number) - (a[cfg.field] as number));
  if (!hits.length) return null;
  const noun = cfg.noun ?? 'limit';
  const breach = hits.filter((r) => (r[cfg.field] as number) >= cfg.breach).length;
  const warn = hits.length - breach;
  const num = (r: Record<string, unknown>, f?: string) => (f && isNum(r[f]) ? (r[f] as number) : undefined);
  return (
    <section className="att" role="status" aria-live="polite">
      <header className="att-head">
        <span className={'att-icon' + (breach ? ' is-breach' : '')}><Icon name="alert" size={16} /></span>
        <div className="att-titles">
          <b>{hits.length} {noun}{hits.length === 1 ? '' : 's'} need{hits.length === 1 ? 's' : ''} attention</b>
          <span>
            {breach > 0 && <><em className="att-tag is-breach">{breach} in breach</em> exposure is above the threshold</>}
            {breach > 0 && warn > 0 && ' · '}
            {warn > 0 && <><em className="att-tag is-warn">{warn} warning</em> utilization at or above {formats.percent0(cfg.warn)}</>}
            {' · as of ' + ds.asOf.slice(0, 10)}
          </span>
        </div>
        <button type="button" className="att-close" onClick={() => dispatch(dismissAlert())} title="Hide until next load"><Icon name="x" size={14} /></button>
      </header>
      <div className="att-list">
        {hits.map((r) => {
          const key = String(r[ds.rowKey]), u = r[cfg.field] as number, on = selected?.includes(key), isBreach = u >= cfg.breach;
          const exp = num(r, cfg.valueField), lim = num(r, cfg.limitField), chg = num(r, cfg.changeField);
          const gap = exp !== undefined && lim !== undefined ? exp - lim : undefined;
          return (
            <button key={key} type="button" className={'att-item ' + (isBreach ? 'is-breach' : 'is-warn') + (on ? ' is-on' : '')}
              onClick={() => { dispatch(setSelection({ widgetId: cfg.target, keys: on ? [] : [key] })); scrollToWidget(cfg.target); }}
              title={on ? 'Click to clear the selection' : 'Click to show this limit in the grid and chart'}>
              <span className="att-row1">
                <em className={'att-tag ' + (isBreach ? 'is-breach' : 'is-warn')}>{isBreach ? 'Breach' : 'Warning'}</em>
                <b className="att-name">{String(r[cfg.labelField] ?? key)}</b>
                {cfg.idField && <span className="att-id">{String(r[cfg.idField] ?? '')}</span>}
                <b className="att-pct">{formats.percent1(u)}</b>
              </span>
              <span className="att-meter"><span style={cssVars({ '--pct': Math.min(100, u * 100) + '%' })} /><i style={cssVars({ '--mark': Math.min(100, cfg.warn * 100) + '%' })} /></span>
              <span className="att-row2">
                {exp !== undefined && lim !== undefined && <span>Exposure <b>{formats.millions(exp)}</b> of <b>{formats.millions(lim)}</b> threshold ($MM)</span>}
                {gap !== undefined && <span className={gap > 0 ? 'tone-negative' : ''}>{gap > 0 ? 'Over by ' : 'Headroom '}<b>{formats.millions(Math.abs(gap))}</b></span>}
                {chg !== undefined && <span>1D <b className={chg > 0 ? 'tone-negative' : chg < 0 ? 'tone-positive' : ''}>{formats.millionsSigned(chg)}</b></span>}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
