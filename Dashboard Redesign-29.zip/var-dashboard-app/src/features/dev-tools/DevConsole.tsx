import { useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { USE_MOCKS } from '@/api/client';
import { downloadText } from '@/shared/ui/lib/download';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { setDevOpen } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import { IconButton, cssVars } from '@/shared/ui/controls';
import { useDevBus } from './bus';
import { runChecks } from './dataChecks';
import './dev.css';

type Tab = 'network' | 'renders' | 'checks' | 'simulate' | 'state';
type MockApi = typeof import('@/mocks/mockApi');

/** Developer console (dev builds or localStorage.devtools = '1'). Not shipped to end users. */
export function DevConsole({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const open = useAppSelector((s) => s.ui.devOpen);
  const state = useAppSelector((s) => s);
  const dispatch = useAppDispatch();
  const bus = useDevBus();
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>('network');
  const [min, setMin] = useState(() => sessionStorage.getItem('dev.min') === '1');
  const toggleMin = () => setMin((m) => { sessionStorage.setItem('dev.min', m ? '0' : '1'); return !m; });
  const [mock, setMock] = useState<MockApi | null>(null);
  const [, force] = useState(0);
  useEffect(() => { if (USE_MOCKS && open) void import('@/mocks/mockApi').then(setMock); }, [open]);

  const data = useMemo(() => Object.fromEntries(Object.entries(datasets).map(([k, v]) => [k, v.data])), [datasets]);
  const checks = useMemo(() => runChecks(data), [data]);
  const failed = checks.filter((c) => !c.ok).length;

  if (!open) {
    return <button type="button" className="dev-pill" onClick={() => dispatch(setDevOpen(true))} title="Open dev console (Ctrl+Shift+D)"><Icon name="terminal" size={13} />DEV{failed > 0 && <b>{failed}</b>}</button>;
  }

  // Closing reloads the page so every dev-only affordance (DB icons, profiler) is gone.
  const close = () => { dispatch(setDevOpen(false)); setTimeout(() => window.location.reload(), 30); };
  const cfg = mock?.getMockConfig();
  const setCfg = (p: Partial<NonNullable<typeof cfg>>) => { mock?.setMockConfig(p); force((n) => n + 1); };
  const ids = dashboard.datasets.map((d) => d.datasetId);
  const renders = Object.entries(bus.renders).sort((a, b) => b[1].max - a[1].max);
  const byWidget = (id: string) => dashboard.widgets.find((w) => w.widgetId === id)?.title ?? id;

  return (
    <div className={'dev' + (min ? ' is-min' : '')} role="region" aria-label="Developer console">
      <header className="dev-head">
        <span className="dev-title"><Icon name="terminal" size={14} />Dev console</span>
        <span className="dev-env">{USE_MOCKS ? 'Mock services' : 'Live services'}</span>
        <span className="dev-env">Batch {state.ui.appliedBatch ?? '—'}</span>
        <nav className="dev-tabs">
          {(['network', 'renders', 'checks', 'simulate', 'state'] as Tab[]).map((t) => (
            <button key={t} type="button" className={tab === t ? 'is-on' : ''} onClick={() => setTab(t)}>
              {t === 'checks' ? 'Data checks' : t[0].toUpperCase() + t.slice(1)}
              {t === 'checks' && <b className={failed ? 'bad' : 'ok'}>{failed || '✓'}</b>}
              {t === 'network' && <b>{bus.net.length}</b>}
            </button>
          ))}
        </nav>
        <span className="dev-hint">Click <Icon name="database" size={12} /> on a panel for its query</span>
        <IconButton icon="trash" title="Clear logs" onClick={() => bus.clear()} />
        <IconButton icon={min ? 'maximize' : 'minimize'} title={min ? 'Expand console' : 'Minimise — DB icons stay active'} onClick={toggleMin} />
        <IconButton icon="x" title="Close (reloads the page)" onClick={close} />
      </header>
      {!min && <div className="dev-body">
        {tab === 'network' && (
          <table className="dev-table">
            <thead><tr><th>Time</th><th>Request</th><th>Status</th><th className="r">ms</th><th className="r">Size</th></tr></thead>
            <tbody>
              {bus.net.map((n, i) => (
                <tr key={i}>
                  <td className="mono">{new Date(n.at).toLocaleTimeString()}</td>
                  <td className="mono path" title={n.path}>{n.path}</td>
                  <td><span className={'dev-status ' + (n.status >= 200 && n.status < 300 ? 'ok' : 'bad')}>{n.status || 'ERR'}</span></td>
                  <td className={'mono r' + (n.ms > 800 ? ' slow' : '')}>{n.ms}</td>
                  <td className="mono r">{(n.bytes / 1024).toFixed(1)} KB</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {tab === 'renders' && (
          <table className="dev-table">
            <thead><tr><th>Widget</th><th className="r">Renders</th><th className="r">Last ms</th><th className="r">Avg ms</th><th className="r">Max ms</th><th>Budget (16 ms)</th></tr></thead>
            <tbody>
              {renders.map(([id, r]) => (
                <tr key={id}>
                  <td>{byWidget(id)} <span className="mono muted">{id}</span></td>
                  <td className="mono r">{r.count}</td>
                  <td className="mono r">{r.last.toFixed(1)}</td>
                  <td className="mono r">{(r.total / r.count).toFixed(1)}</td>
                  <td className={'mono r' + (r.max > 16 ? ' slow' : '')}>{r.max.toFixed(1)}</td>
                  <td><span className="dev-bar"><span style={cssVars({ '--pct': Math.min(100, (r.max / 32) * 100) + '%' })} className={r.max > 16 ? 'bad' : ''} /></span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {tab === 'checks' && (
          <table className="dev-table">
            <thead><tr><th>Dataset</th><th>Check</th><th>Result</th><th>Detail</th></tr></thead>
            <tbody>
              {checks.map((c, i) => (
                <tr key={i}>
                  <td className="mono">{c.datasetId}</td><td>{c.name}</td>
                  <td><span className={'dev-status ' + (c.ok ? 'ok' : 'bad')}>{c.ok ? 'Pass' : 'Fail'}</span></td>
                  <td className="muted">{c.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {tab === 'simulate' && (
          !USE_MOCKS || !cfg ? <div className="dev-empty">Simulation is available with mock services (VITE_USE_MOCKS=true).</div> : (
            <div className="dev-sim">
              <label>Latency <b className="mono">{cfg.latencyMs} ms</b>
                <input type="range" min={0} max={3000} step={50} value={cfg.latencyMs} onChange={(e) => setCfg({ latencyMs: Number(e.target.value) })} />
              </label>
              <label>Fail dataset
                <select value={cfg.failDataset} onChange={(e) => setCfg({ failDataset: e.target.value })}><option value="">None</option><option value="all">All datasets</option>{ids.map((id) => <option key={id}>{id}</option>)}</select>
              </label>
              <label>Empty dataset
                <select value={cfg.emptyDataset} onChange={(e) => setCfg({ emptyDataset: e.target.value })}><option value="">None</option>{ids.map((id) => <option key={id}>{id}</option>)}</select>
              </label>
              <label>No access (403)
                <select value={cfg.forbiddenDataset} onChange={(e) => setCfg({ forbiddenDataset: e.target.value })}><option value="">None</option>{ids.map((id) => <option key={id}>{id}</option>)}</select>
              </label>
              <label>Publish a batch every
                <select value={cfg.autoBatchSec} onChange={(e) => setCfg({ autoBatchSec: Number(e.target.value) })}>{[0, 30, 60, 120, 300].map((s) => <option key={s} value={s}>{s ? `${s} s` : 'Off'}</option>)}</select>
              </label>
              <div className="dev-sim-actions">
                <button type="button" className="btn btn-primary" onClick={() => { void qc.invalidateQueries({ queryKey: ['dataset'] }); }}><Icon name="refresh" size={13} />Refetch all</button>
                <button type="button" className="btn" onClick={() => { mock?.publishBatch(); void qc.invalidateQueries({ queryKey: ['batch'] }); }}>Publish new batch now</button>
                <button type="button" className="btn" onClick={() => { mock?.resetMockConfig(); force((n) => n + 1); void qc.invalidateQueries({ queryKey: ['dataset'] }); }}>Reset</button>
              </div>
              <div className="dev-pack">
                <div><b>Services pack</b><small>Every endpoint the UI calls — request URL + exact mock response. Hand this to the services team.</small></div>
                <div className="dev-sim-actions">
                  <button type="button" className="btn btn-primary" onClick={() => { void import('@/mocks/servicesPack').then(({ buildServicesPack }) => downloadText('services-pack.json', JSON.stringify(buildServicesPack(), null, 2), 'application/json')); }}><Icon name="download" size={13} />Download services pack (JSON)</button>
                  <button type="button" className="btn" onClick={() => { void import('@/mocks/servicesPack').then(({ servicesPackFiles }) => { const { files } = servicesPackFiles(); Object.entries(files).forEach(([n, t], i) => setTimeout(() => downloadText(n, t, 'application/json'), i * 250)); }); }}>One file per endpoint</button>
                </div>
              </div>
            </div>
          )
        )}
        {tab === 'state' && (
          <pre className="dev-pre">{JSON.stringify({ filters: state.filters.values, selection: state.selection.byWidget, preferences: state.preferences, savedViews: state.savedViews, ui: state.ui }, null, 2)}</pre>
        )}
      </div>}
    </div>
  );
}
