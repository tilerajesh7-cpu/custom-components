import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { USE_MOCKS } from '@/api/client';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { openInspector } from '@/features/dashboard/model';
import { Icon } from '@/shared/ui/icons';
import { toast } from '@/shared/ui/controls';
import { copyText, downloadText } from '@/shared/ui/lib/download';
import { formats } from '@/shared/ui/lib/formats';
import { devBus } from './bus';
import './query-inspector.css';

type Tab = 'sql' | 'params' | 'response' | 'lineage';
const KW = /^(SELECT|FROM|JOIN|LEFT|RIGHT|INNER|OUTER|ON|WHERE|AND|OR|NOT|IN|IS|NULL|AS|GROUP|ORDER|BY|DESC|ASC|BETWEEN|LIMIT|HAVING|UNION|ALL|CASE|WHEN|THEN|ELSE|END|DISTINCT|WITH)$/i;
const FN = /^(SUM|MAX|MIN|AVG|COUNT|COALESCE|prior_cob|business_days_back)$/i;

/** Tiny SQL highlighter: comments · keywords · functions · :params · strings · numbers. */
function highlight(line: string): ReactNode[] {
  if (/^\s*--/.test(line)) return [<span key="c" className="sq-c">{line}</span>];
  return line.split(/(\s+|'[^']*'|:[A-Za-z_]\w*|[(),;=<>*]|\b\d+(?:\.\d+)?\b)/).filter(Boolean).map((t, i) =>
    t.startsWith("'") ? <span key={i} className="sq-s">{t}</span>
      : t.startsWith(':') ? <span key={i} className="sq-p">{t}</span>
      : KW.test(t) ? <span key={i} className="sq-k">{t}</span>
      : FN.test(t) ? <span key={i} className="sq-f">{t}</span>
      : /^\d/.test(t) ? <span key={i} className="sq-n">{t}</span>
      : <span key={i}>{t}</span>);
}

/** Replace :params with their literal values (for copy / download). Unset optional ids become NULL. */
const bind = (sql: string, p: Record<string, string>) =>
  sql.replace(/:([A-Za-z_]\w*)/g, (m, k: string) => {
    if (!(k in p)) return k === 'rowId' || k === 'limitId' ? 'NULL' : m;
    const v = p[k];
    if (v === '') return 'NULL';
    return /^-?\d+(\.\d+)?$/.test(v) ? v : `'${v.replace(/'/g, "''")}'`;
  });
const etTime = (t: number) => new Date(t).toLocaleTimeString('en-US', { timeZone: 'America/New_York', hour12: false }) + ' ET';

/** Per-widget query inspector (the DB icon). Dev console only. Reads the cached dataset — no extra API call. */
export function QueryInspector({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const widgetId = useAppSelector((s) => s.ui.inspector);
  const dispatch = useAppDispatch();
  const [tab, setTab] = useState<Tab>('sql');
  const w = dashboard.widgets.find((x) => x.widgetId === widgetId);
  const dsId = w && 'datasetId' in w ? w.datasetId : undefined;
  const q = dsId ? datasets[dsId] : undefined;
  const ds = q?.data;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const params = useMemo(() => (dsId ? devBus.getParams(dsId) ?? {} : {}), [dsId, q?.dataUpdatedAt]);
  const kb = useMemo(() => (ds ? new Blob([JSON.stringify(ds)]).size / 1024 : 0), [ds]);
  const close = () => dispatch(openInspector(null));
  useEffect(() => { setTab('sql'); }, [widgetId]);
  useEffect(() => {
    if (!widgetId) return;
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') dispatch(openInspector(null)); };
    document.addEventListener('keydown', k);
    return () => document.removeEventListener('keydown', k);
  }, [widgetId, dispatch]);
  if (!w) return null;

  const apiBase = (import.meta.env.VITE_API_BASE as string | undefined) ?? '/api';
  const path = dsId ? `/datasets/${dsId}?${new URLSearchParams(params).toString()}` : '';
  const url = `${location.origin}${apiBase}${path}`;
  const net = devBus.net.find((n) => n.path.includes(`/datasets/${dsId}`));
  const sql = ds?.meta.sql ?? '';
  const copy = async (t: string, label: string) => { if (await copyText(t)) toast(`${label} copied`); };
  const curl = `curl -s '${url}' \\\n  -H 'Accept: application/json'`;
  const header = [`-- Widget   : ${w.title} (${w.widgetId})`, `-- Dataset  : ${dsId}`, `-- Request  : GET ${apiBase}${path}`,
    `-- Batch    : ${ds?.meta.batchId ?? '—'} · as of ${ds?.asOf ?? '—'}`, `-- Query ID : ${ds?.meta.queryId ?? '—'}`, ''].join('\n');
  const downloadSql = () => { downloadText(`${w.widgetId}-${dsId}.sql`, header + bind(sql, params) + '\n', 'text/plain'); toast('Query downloaded'); };
  const downloadJson = () => {
    downloadText(`${w.widgetId}-${dsId}-query.json`, JSON.stringify({
      widget: { id: w.widgetId, type: w.type, title: w.title }, request: { method: 'GET', url: apiBase + path, params },
      meta: ds?.meta, sql, sqlBound: bind(sql, params), fetchedAt: q?.dataUpdatedAt ? new Date(q.dataUpdatedAt).toISOString() : null,
    }, null, 2), 'application/json');
    toast('Query JSON downloaded');
  };
  const status = q?.isError ? String((q.error as { status?: number } | null)?.status ?? 'ERR') : '200 OK';
  const plan = ds?.meta.plan;
  const lines = (sql || '-- No SQL returned for this dataset (hidden in production).').split('\n');
  const preview = ds ? {
    datasetId: ds.datasetId, kind: ds.kind, rowKey: ds.rowKey, version: ds.version, asOf: ds.asOf, rowCount: ds.meta.rowCount,
    ...(ds.kind === 'grid' ? { columns: ds.columnDefs.length } : { seriesDefs: ds.seriesDefs.map((s) => s.field) }),
    rowData: ds.rowData.slice(0, 3), '…': `${Math.max(0, ds.rowData.length - 3)} more rows`,
  } : null;
  const planRows: [string, string | undefined][] = plan ? [
    ['Source object', plan.sourceObject], ['Access path', plan.accessPath],
    ['Rows scanned', plan.rowsScanned != null ? formats.count(plan.rowsScanned) : undefined],
    ['Server time', plan.serverMs != null ? `${plan.serverMs} ms${net ? ` (+${Math.max(0, net.ms - plan.serverMs)} ms network)` : ''}` : undefined],
    ['Cache', plan.cache],
  ] : [];

  return createPortal(
    <aside className="qx" role="dialog" aria-label={`Query inspector · ${w.title}`}>
      <header className="qx-head">
        <span className="qx-tile"><Icon name="database" size={20} /></span>
        <div className="qx-titles">
          <span className="qx-kicker">Query inspector · {w.widgetId}</span>
          <b className="qx-title">{w.title}</b>
          <code className="qx-path" title={apiBase + path}><em>GET</em>{apiBase}{path}</code>
        </div>
        <div className="qx-head-actions">
          <button type="button" className="qx-icon" title="Download query (.sql)" onClick={downloadSql}><Icon name="download" size={15} /></button>
          <button type="button" className="qx-icon" title="Close (Esc)" onClick={close}><Icon name="x" size={15} /></button>
        </div>
      </header>
      {ds ? (
        <>
          <div className="qx-chips">
            <span className={'qx-chip ' + (q?.isError ? 'is-bad' : 'is-ok')}>{status}</span>
            <span className="qx-chip">{net?.ms ?? ds.meta.ms ?? '—'} ms</span>
            <span className={'qx-chip ' + (ds.meta.cache === 'HIT' ? 'is-info' : 'is-warn')}>cache {ds.meta.cache ?? '—'}</span>
            <span className="qx-chip">{formats.count(ds.meta.rowCount)} rows</span>
            <span className="qx-chip">{kb.toFixed(1)} KB</span>
            <span className="qx-chip is-src">{ds.meta.source ?? (USE_MOCKS ? 'Mock services' : 'Live services')}</span>
          </div>
          <nav className="qx-tabs" role="tablist">
            {([['sql', 'SQL'], ['params', `Params · ${Object.keys(params).length}`], ['response', 'Response'], ['lineage', 'Lineage']] as [Tab, string][]).map(([t, l]) => (
              <button key={t} type="button" role="tab" aria-selected={tab === t} className={tab === t ? 'is-on' : ''} onClick={() => setTab(t)}>{l}</button>
            ))}
          </nav>
          <div className="qx-body">
            {tab === 'sql' && (
              <>
                <pre className="qx-code">{lines.map((l, i) => <div key={i} className="qx-line"><span className="qx-ln">{i + 1}</span><span>{highlight(l)}</span></div>)}</pre>
                <div className="qx-actions">
                  <button type="button" onClick={() => copy(sql, 'SQL')}><Icon name="copy" size={13} />Copy SQL</button>
                  <button type="button" onClick={() => copy(bind(sql, params), 'SQL with values')}><Icon name="copy" size={13} />Copy with values bound</button>
                  <button type="button" onClick={() => copy(curl, 'cURL')}><Icon name="code" size={13} />Copy cURL</button>
                  <button type="button" className="is-primary" onClick={downloadSql}><Icon name="download" size={13} />Download .sql</button>
                  <button type="button" onClick={downloadJson}><Icon name="download" size={13} />JSON</button>
                </div>
                {planRows.length > 0 && (
                  <div className="qx-plan">
                    <span className="qx-label">Execution plan</span>
                    {planRows.filter(([, v]) => v != null).map(([k, v]) => <div key={k} className="qx-kv"><span>{k}</span><b>{v}</b></div>)}
                  </div>
                )}
              </>
            )}
            {tab === 'params' && (
              <table className="qx-table">
                <thead><tr><th>Param</th><th>Value</th><th>Bound as</th></tr></thead>
                <tbody>{Object.entries(params).map(([k, v]) => <tr key={k}><td>{k}</td><td className="v">{v || <em>null</em>}</td><td className="p">:{k}</td></tr>)}</tbody>
              </table>
            )}
            {tab === 'response' && (
              <>
                <pre className="qx-json">{JSON.stringify(preview, null, 2)}</pre>
                <div className="qx-actions"><button type="button" onClick={() => copy(JSON.stringify(ds, null, 2), 'Response')}><Icon name="copy" size={13} />Copy full response</button></div>
              </>
            )}
            {tab === 'lineage' && (
              <div className="qx-lineage">
                {[...(ds.meta.lineage ?? []), ds.datasetId, w.widgetId].map((n, i, a) => (
                  <div key={n + i} className="qx-node"><span className="qx-dot" /><b>{n}</b><small>{i === a.length - 1 ? 'widget' : i === a.length - 2 ? 'dataset' : i === 0 ? 'source' : 'transform'}</small></div>
                ))}
              </div>
            )}
          </div>
          <footer className="qx-foot"><span>{ds.meta.requestId ?? ds.meta.queryId}</span><span>fetched {q?.dataUpdatedAt ? etTime(q.dataUpdatedAt) : '—'}</span></footer>
        </>
      ) : <div className="qx-empty">{q?.isError ? 'This request failed — see the Network tab.' : 'No data loaded yet.'}</div>}
    </aside>,
    document.body,
  );
}
