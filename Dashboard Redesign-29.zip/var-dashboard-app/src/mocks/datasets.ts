// Mock dataset builders — responses follow src/contracts (AG Grid-ready rows + columnDefs).
import type { ColDefContract, Dataset, Row } from '@/contracts';
import { ATTR_FACTOR, COMPARE_OFFSET, FILTER_META, GRID_META, PRIMARY_ROWS, PRIMARY_GRID_LABELS, FS, FS_NAMES, FS_BASE, HORIZON_FACTOR, LIMITS, MEASURES, MODELS, businessDays, history } from './seed';

export type Params = Record<string, string>;
const N = 250;
const ASOF = (p: Params) => (p.asOf || '2026-09-11') + 'T11:41:00-04:00';
type Model = (typeof MODELS)[number];
type Measure = (typeof MEASURES)[number];
interface Group { key: string; label: string; model: Model; measure: Measure }

const FS_COLORS = ['#2f62c9', '#3a8a5c', '#c2392f', '#4a90c9', '#6a4bd6', '#d0782a', '#5a8a3a', '#2f4f8a', '#b7780a', '#d0782a', '#7fa2fb', '#12918a', '#8a5a06', '#6a7fb0', '#9b59b6', '#5cc9bf'];
export const GROUP_COLOR: Record<string, string> = { MC_var: '#2f62c9', Hist_var: '#6a4bd6', MC_svar: '#12918a', Hist_svar: '#b7780a' };

function groupsFor(p: Params): Group[] {
  const models = !p.model || p.model === 'Both' ? MODELS : MODELS.filter((m) => m.id === p.model);
  const measures = !p.measure || p.measure === 'Both' ? MEASURES : MEASURES.filter((m) => m.id === p.measure.toLowerCase());
  const out: Group[] = [];
  for (const me of measures) for (const mo of models) out.push({ key: `${mo.id}_${me.id}`, label: `${mo.label} ${me.label}`, model: mo, measure: me });
  return out;
}
/** Business days between PCOB and COB (Custom compare) or the preset offset (DoD / WoW / MoM). */
function offsetFor(p: Params) {
  if (p.compare !== 'Custom' || !p.pcob || !p.asOf) return COMPARE_OFFSET[p.compare || 'DoD'] ?? 1;
  let n = 0; const end = new Date(p.pcob + 'T00:00:00Z'); const cur = new Date(p.asOf + 'T00:00:00Z');
  while (cur > end && n < 240) { cur.setUTCDate(cur.getUTCDate() - 1); const w = cur.getUTCDay(); if (w && w < 6) n++; }
  return Math.max(1, n);
}
const primaryModel = (p: Params) => MODELS.find((m) => m.id === p.model) ?? MODELS[0];

function rowsInScope(p: Params, bySelection: boolean) {
  return PRIMARY_ROWS.map((d, i) => ({ d, i })).filter(({ d }) =>
    (!p.region || p.region === 'All' || d.region === p.region) && (!bySelection || !p.rowId || d.id === p.rowId));
}

/** Each new batch nudges ~half the rows so deltas and row flash have something to show. */
const nudge = (i: number, batch: number) => {
  if (batch <= 4812) return 1;
  const h = (i * 2654435761 + batch * 40503) >>> 0;
  return h % 2 ? 1 + ((h % 100) / 100 - 0.48) * 0.06 : 1;
};

const cache = new Map<string, number[]>();
function series(i: number, model: Model, measure: 'var' | 'svar', p: Params, batch: number) {
  const k = [i, model.id, measure, p.variant, p.attr, batch].join('|');
  const hit = cache.get(k); if (hit) return hit;
  const f = model.factor * (HORIZON_FACTOR[p.variant || '1D'] ?? 1) * (ATTR_FACTOR[p.attr || 'Trading'] ?? 1);
  const d = PRIMARY_ROWS[i];
  const s = history(i * 97 + (measure === 'svar' ? 13 : 0) + (model.id === 'Hist' ? 29 : 0), d.cob[measure] * f * nudge(i, batch), d.pcob[measure] * f, N);
  cache.set(k, s); return s;
}

const LINEAGE: Record<string, string[]> = {
  'dataset-1': ['risk_engine.var_run', 'mart.var_summary', 'api.var_summary'],
  'dataset-2': ['risk_engine.var_run', 'mart.var_history', 'api.var_trend'],
  'dataset-3': ['risk_engine.component_var', 'mart.var_by_fs', 'api.fs_var'],
  'dataset-4': ['risk_engine.component_var', 'mart.var_fs_history', 'api.fs_trend'],
  'dataset-5': ['ref.limit_master', 'mart.var_summary', 'api.limit_utilisation'],
  'dataset-6': ['ref.limit_master', 'mart.limit_history', 'api.limit_history'],
};
const SQL: Record<string, string> = {
  "dataset-1": "-- Standalone VaR / SVaR per row of the primary grid\nSELECT h.row_id, h.row_name, h.region,\n       SUM(c.var_amt)  AS var_cob,  SUM(p.var_amt)  AS var_pcob,\n       SUM(c.svar_amt) AS svar_cob, SUM(p.svar_amt) AS svar_pcob,\n       MAX(l.limit_amt) AS var_limit\nFROM risk.var_daily c\nJOIN ref.hierarchy h ON h.row_id = c.row_id\nLEFT JOIN risk.var_daily p\n       ON p.row_id = c.row_id AND p.cob_date = prior_cob(:asOf, :compare)\nLEFT JOIN ref.limit_master l ON l.row_id = c.row_id\nWHERE c.cob_date = :asOf AND c.horizon = :variant\n  AND c.model = :model AND c.attribution = :attr\n  AND (:region = 'All' OR h.region = :region)\nGROUP BY h.row_id, h.row_name, h.region\nORDER BY var_cob DESC;",
  "dataset-2": "-- VaR / SVaR trend (business days)\nSELECT c.cob_date, SUM(c.var_amt) AS var, SUM(c.svar_amt) AS svar\nFROM risk.var_daily c\nJOIN ref.hierarchy h ON h.row_id = c.row_id\nWHERE c.cob_date > business_days_back(:asOf, :days)\n  AND c.horizon = :variant AND c.model = :model\n  AND c.attribution = :attr\n  AND (:region = 'All' OR h.region = :region)\n  AND (:rowId IS NULL OR c.row_id = :rowId)\nGROUP BY c.cob_date\nORDER BY c.cob_date;",
  "dataset-3": "-- Euler allocation of VaR to risk-factor (FS) types\nSELECT c.fs_type,\n       SUM(c.cvar_amt)  AS var_cob,  SUM(p.cvar_amt)  AS var_pcob,\n       SUM(c.csvar_amt) AS svar_cob, SUM(p.csvar_amt) AS svar_pcob\nFROM risk.var_component_daily c\nJOIN ref.hierarchy h ON h.row_id = c.row_id\nLEFT JOIN risk.var_component_daily p\n       ON p.row_id = c.row_id AND p.fs_type = c.fs_type AND p.cob_date = prior_cob(:asOf, :compare)\nWHERE c.cob_date = :asOf AND c.horizon = :variant\n  AND c.model = :model AND c.attribution = :attr\n  AND (:rowId IS NULL OR c.row_id = :rowId)\nGROUP BY c.fs_type\nORDER BY var_cob DESC;",
  "dataset-4": "-- Component VaR over time, top FS types + other\nSELECT c.cob_date, c.fs_type, SUM(c.cvar_amt) AS cvar\nFROM risk.var_component_daily c\nWHERE c.cob_date > business_days_back(:asOf, :days)\n  AND c.horizon = :variant AND c.model = :model\n  AND (:rowId IS NULL OR c.row_id = :rowId)\nGROUP BY c.cob_date, c.fs_type\nORDER BY c.cob_date;",
  "dataset-5": "-- Limit utilisation on the COB date\nSELECT l.limit_id, l.limit_name, l.tier, l.limit_amt,\n       e.exposure_amt, e.exposure_amt / l.limit_amt AS utilisation,\n       e.exposure_amt - e.prev_exposure_amt AS change_1d\nFROM ref.limit_master l\nJOIN risk.limit_exposure_daily e ON e.limit_id = l.limit_id\nWHERE e.cob_date = :asOf\nORDER BY utilisation DESC;",
  "dataset-6": "-- Exposure vs limit history for one limit\nSELECT e.cob_date, e.exposure_amt, l.limit_amt\nFROM risk.limit_exposure_daily e\nJOIN ref.limit_master_hist l\n     ON l.limit_id = e.limit_id AND e.cob_date BETWEEN l.valid_from AND l.valid_to\nWHERE e.limit_id = :limitId\n  AND e.cob_date > business_days_back(:asOf, 90)\nORDER BY e.cob_date;"
};
const SOURCE: Record<string, { object: string; label: string }> = {
  'dataset-1': { object: 'RISK.VAR_DAILY', label: 'Data warehouse' }, 'dataset-2': { object: 'RISK.VAR_DAILY', label: 'Data warehouse' },
  'dataset-3': { object: 'RISK.VAR_COMPONENT_DAILY', label: 'Data warehouse' }, 'dataset-4': { object: 'RISK.VAR_COMPONENT_DAILY', label: 'Data warehouse' },
  'dataset-5': { object: 'RISK.LIMIT_EXPOSURE_DAILY', label: 'Limits service' }, 'dataset-6': { object: 'RISK.LIMIT_EXPOSURE_DAILY', label: 'Limits service' },
};
function meta(id: string, rows: number, batch: number, p: Params) {
  const n = Number(id.split('-')[1]) || 1;
  const hit = (batch + rows) % 3 !== 0;
  const src = SOURCE[id] ?? { object: id.toUpperCase(), label: 'Data warehouse' };
  const cacheKey = 'var:' + id.replace('dataset-', 'd') + ':' + (p.asOf ?? '');
  return {
    rowCount: rows, batchId: batch, queryId: 'q-' + n + '-' + batch.toString(16),
    requestId: 'req_' + (batch * 31 + n * 977).toString(16) + '_' + (p.asOf ?? '').replace(/-/g, ''),
    cache: hit ? ('HIT' as const) : ('MISS' as const), lineage: LINEAGE[id], source: src.label,
    sql: SQL[id],
    plan: {
      sourceObject: src.object,
      accessPath: 'PRUNED ' + (2 + (n % 3)) + ' / ' + (2000 + n * 92).toLocaleString('en-US') + ' micro-partitions',
      rowsScanned: rows * 38,
      serverMs: 18 + ((batch * 7 + n * 13) % 40),
      cache: hit ? 'Redis · TTL 900s · key ' + cacheKey : 'MISS · stored as ' + cacheKey,
    },
  };
}
const money = (field: string, headerName: string, extra: Partial<ColDefContract> = {}) => ({ field, headerName, type: ['money'], ...extra }) as ColDefContract;
function sd(xs: number[]) {
  const d = xs.slice(1).map((x, i) => x - xs[i]);
  const m = d.reduce((a, b) => a + b, 0) / d.length;
  return Math.sqrt(d.reduce((a, b) => a + (b - m) ** 2, 0) / d.length) || 1;
}
const V = GRID_META.values;
/** Column group “Monte Carlo (VAR)” → COB · PCOB · Diff (+ hidden Diff %). Header words come from GRID_META. */
const groupCols = (g: Group, max: number, measures: Record<string, string>): ColDefContract => ({
  groupId: g.key, headerName: `${g.model.long} (${measures[g.measure.id] ?? g.measure.label})`, headerTooltip: `${g.model.long} ${g.measure.label}`,
  children: [
    money(`${g.key}_cob`, V.cob, { cellRenderer: 'smartCell', minWidth: 72, cellRendererParams: { previousField: `${g.key}_pcob`, changeField: `${g.key}_d`, max, color: GROUP_COLOR[g.key] } }),
    money(`${g.key}_pcob`, V.pcob, { minWidth: 64 }),
    money(`${g.key}_d`, V.diff, { type: ['money', 'change'], minWidth: 64 }),
    { field: `${g.key}_dp`, headerName: V.diffPct, type: ['percentChange'], hide: true, minWidth: 72 },
  ],
});
/**
 * Compact cell tooltip for every COB / PCOB / Diff cell of a model × measure group (component: cellInfoTooltip).
 * Services resolve the facts for the request; the UI only lays them out.
 */
function withCellTips(defs: ColDefContract[], p: Params, measures: Record<string, string>, path: string[], footer: { field: string; label?: string }[]): ColDefContract[] {
  const T = GRID_META.tooltip;
  const variant = FILTER_META.variant.options.find(([v]) => v === (p.variant || '1D'))?.[1] ?? p.variant;
  const cmp = p.compare && p.compare !== 'Custom' ? p.compare + ' ' + T.change : T.change;
  return defs.map((def) => {
    if (!('children' in def)) return def;
    const key = def.groupId, me = key.split('_')[1] ?? 'var';
    const params = {
      facts: [{ label: T.type, value: measures[me] ?? me.toUpperCase() }, { label: T.variant, value: variant }, { label: T.attr, value: p.attr || 'Trading' }],
      path,
      values: { title: T.values, items: [{ label: GRID_META.values.cob, field: key + '_cob' }, { label: GRID_META.values.pcob, field: key + '_pcob' }, { label: cmp, field: key + '_d' }] },
      footer,
    };
    return { ...def, children: def.children.map((c) => ('field' in c && /_(cob|pcob|d)$/.test(c.field) ? { ...c, tooltipComponent: 'cellInfoTooltip', tooltipComponentParams: params } : c)) };
  });
}
const sum = (rows: Row[], f: string) => rows.reduce((a, r) => a + ((r[f] as number) || 0), 0);

// dataset-1 · primary grid · Standalone VaR / SVaR per row
function dataset1(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), off = offsetFor(p), pm = primaryModel(p);
  const f = (HORIZON_FACTOR[p.variant || '1D'] ?? 1) * (ATTR_FACTOR[p.attr || 'Trading'] ?? 1);
  const maxBy: Record<string, number> = {};
  const rows: Row[] = rowsInScope(p, false).map(({ d, i }) => {
    const r: Row = { id: d.id, label: d.name, short: d.short, region: d.region, limit: Math.round(d.limit * f),
      business: d.name.replace(/ Desk [A-Z]$/, ''), nodeCode: 'L4S-L6' + String.fromCharCode(65 + i), ntr: (41900 + i * 37) + ' / 1' };
    for (const g of groups) {
      const s = series(i, g.model, g.measure.id as 'var' | 'svar', p, batch), cob = Math.round(s[N - 1]), pcob = Math.round(s[N - 1 - off]);
      Object.assign(r, { [`${g.key}_cob`]: cob, [`${g.key}_pcob`]: pcob, [`${g.key}_d`]: cob - pcob, [`${g.key}_dp`]: pcob ? (cob - pcob) / pcob : 0 });
      maxBy[g.key] = Math.max(maxBy[g.key] ?? 0, cob);
    }
    for (const m of ['var', 'svar'] as const) {
      const s = series(i, pm, m, p, batch);
      r[m + 'Cob'] = Math.round(s[N - 1]); r[m + 'Pcob'] = Math.round(s[N - 1 - off]); r[m + 'D'] = (r[m + 'Cob'] as number) - (r[m + 'Pcob'] as number);
      if (m === 'var') {
        const z = (s[N - 1] - s[N - 1 - off]) / (sd(s.slice(-61)) * Math.sqrt(off));
        if (Math.abs(z) >= 2) r._meta = { row: { badges: [{ text: (z > 0 ? '▲ ' : '▼ ') + Math.abs(z).toFixed(1) + 'σ', tone: z > 0 ? 'negative' : 'positive', tooltip: 'Unusual move vs typical daily change' }] } };
      }
    }
    r.limitUse = (r.varCob as number) / (r.limit as number);
    r.varDp = r.varPcob ? (r.varD as number) / (r.varPcob as number) : 0;
    r.svarDp = r.svarPcob ? (r.svarD as number) / (r.svarPcob as number) : 0;
    const sh = share(i, 0);
    r.topFs = FS.map((code, j) => ({ code, name: FS_NAMES[code] ?? code, value: Math.round((r.varCob as number) * sh[j]) }))
      .sort((a, b) => b.value - a.value).slice(0, 4);
    return r;
  });
  const totalVar = sum(rows, 'varCob') || 1;
  [...rows].sort((a, b) => (b.varCob as number) - (a.varCob as number)).forEach((r, k) => { r.rank = k + 1; r.varShare = (r.varCob as number) / totalVar; });
  const total: Row = { id: 'total', label: 'Total' };
  for (const g of groups) {
    for (const k of ['cob', 'pcob', 'd']) total[`${g.key}_${k}`] = sum(rows, `${g.key}_${k}`);
    total[`${g.key}_dp`] = total[`${g.key}_pcob`] ? (total[`${g.key}_d`] as number) / (total[`${g.key}_pcob`] as number) : 0;
  }
  for (const k of ['varCob', 'varPcob', 'varD', 'svarCob', 'svarPcob', 'svarD', 'limit']) total[k] = sum(rows, k);
  total.limitUse = total.limit ? (total.varCob as number) / (total.limit as number) : 0;
  const columnDefs: ColDefContract[] = [
    {
      field: 'label', headerName: GRID_META.primary.rowHeader, pinned: 'left', width: 230, minWidth: 200, type: ['text'], cellRenderer: 'labelCell', cellRendererParams: { tagField: 'region' }, tooltipField: 'label', // name cell: plain value tooltip (rich card params kept below, component not attached)
      tooltipComponentParams: {
        kicker: PRIMARY_GRID_LABELS.one, tagField: 'region', statusField: 'limitUse', rankField: 'rank', rankOf: rows.length, rankLabel: 'by VaR',
        sections: [{ label: 'VaR COB', field: 'varCob' }, { label: 'VaR vs {compare}', field: 'varD', type: 'change', pctField: 'varDp' }, { label: 'SVaR COB', field: 'svarCob' }, { label: 'SVaR vs {compare}', field: 'svarD', type: 'change', pctField: 'svarDp' }, { label: 'Share of total VaR', field: 'varShare', type: 'percent' }],
        list: { title: 'Top FS contributors · $MM', field: 'topFs' },
        compare: p.compare || 'DoD',
        hint: `to cross-filter · J / K to step ${PRIMARY_GRID_LABELS.many}`,
      },
      rendererRules: [{ when: { row: 'pinned' }, renderer: 'totalCell' }],
    },
    ...withCellTips(groups.map((g) => groupCols(g, maxBy[g.key] || 1, GRID_META.primary.measures)), p, GRID_META.primary.measures, ['business', 'region', 'label'], [{ field: 'nodeCode' }, { field: 'ntr', label: GRID_META.tooltip.ntr }]),
    { field: 'limit', headerName: 'VaR limit', type: ['money'], hide: true },
    { field: 'limitUse', headerName: 'Limit use', hide: true, type: ['percent', 'threshold'], minWidth: 110, cellRendererParams: { warn: 0.8, breach: 1 },
      styleRules: [{ when: { op: 'gte', value: 1 }, tone: 'breach', emphasis: true }] },
  ];
  return {
    datasetId: 'dataset-1', kind: 'grid', version: `b${batch}-1`, asOf: ASOF(p), rowKey: 'id', columnDefs, rowData: rows, pinnedBottomRowData: [total],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'single', statusBar: 'aggregations' }, meta: meta('dataset-1', rows.length, batch, p),
  };
}

// dataset-2 · VaR trend (per group) + primary VaR/SVaR totals for KPI sparklines
function dataset2(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), days = Number(p.days || 90), dates = businessDays(p.asOf || '2026-09-11', days), pm = primaryModel(p);
  const scope = rowsInScope(p, true);
  const agg = (model: Model, m: 'var' | 'svar') => { const acc = new Array(N).fill(0); scope.forEach(({ i }) => series(i, model, m, p, batch).forEach((v, k) => { acc[k] += v; })); return acc.slice(-days); };
  const g = groups.map((x) => agg(x.model, x.measure.id as 'var' | 'svar'));
  const kv = agg(pm, 'var'), ks = agg(pm, 'svar');
  return {
    datasetId: 'dataset-2', kind: 'series', version: `b${batch}-2`, asOf: ASOF(p), rowKey: 'date',
    seriesDefs: groups.map((x) => ({ field: x.key, name: x.label, type: ['money'], palette: { MC_var: 1, Hist_var: 6, MC_svar: 3, Hist_svar: 5 }[x.key] ?? 1, dash: x.model.id === 'Hist' })),
    rowData: dates.map((d, k) => ({ date: d, ...Object.fromEntries(groups.map((x, j) => [x.key, Math.round(g[j][k])])), var: Math.round(kv[k]), svar: Math.round(ks[k]) })),
    meta: meta('dataset-2', days, batch, p),
  };
}

const share = (rowIdx: number, phase: number) => {
  const a = FS_BASE.map((b, j) => b * (1 + 0.45 * Math.sin(j * 1.3 + rowIdx * 0.7 + phase)));
  const t = a.reduce((x, y) => x + y, 0);
  return a.map((x) => x / t);
};

// dataset-3 · Component VaR / SVaR by FS type
function dataset3(p: Params, batch: number): Dataset {
  const groups = groupsFor(p), off = offsetFor(p), scope = rowsInScope(p, true);
  const rows: Row[] = FS.map((code, j) => {
    const r: Row = { id: code, label: code, name: FS_NAMES[code] ?? code, color: FS_COLORS[j % FS_COLORS.length] };
    for (const g of groups) {
      const m = g.measure.id as 'var' | 'svar', ph = m === 'svar' ? 2 : 0;
      let cob = 0, pcob = 0;
      scope.forEach(({ i }) => { const s = series(i, g.model, m, p, batch); cob += s[N - 1] * share(i, ph)[j]; pcob += s[N - 1 - off] * share(i, ph + 0.5)[j]; });
      Object.assign(r, { [`${g.key}_cob`]: Math.round(cob), [`${g.key}_pcob`]: Math.round(pcob), [`${g.key}_d`]: Math.round(cob) - Math.round(pcob), [`${g.key}_dp`]: pcob ? (cob - pcob) / Math.abs(pcob) : 0 });
    }
    return r;
  });
  const k0 = groups[0].key, t1 = sum(rows, `${k0}_cob`) || 1;
  rows.forEach((r) => { r.share = (r[`${k0}_cob`] as number) / t1; r.primaryD = r[`${k0}_d`]; });
  rows.sort((a, b) => (b[`${k0}_cob`] as number) - (a[`${k0}_cob`] as number));
  const total: Row = { id: 'total', label: 'Total' };
  for (const g of groups) for (const k of ['cob', 'pcob', 'd']) total[`${g.key}_${k}`] = sum(rows, `${g.key}_${k}`);
  total.share = 1;
  return {
    datasetId: 'dataset-3', kind: 'grid', version: `b${batch}-3`, asOf: ASOF(p), rowKey: 'id', rowData: rows, pinnedBottomRowData: [total],
    columnDefs: [
      { field: 'label', headerName: GRID_META.component.rowHeader, pinned: 'left', width: 130, minWidth: 110, type: ['text'], cellRenderer: 'swatchCell', cellRendererParams: { colorField: 'color' }, tooltipField: 'name', rendererRules: [{ when: { row: 'pinned' }, renderer: 'totalCell' }] },
      ...withCellTips(groups.map((g) => groupCols(g, Math.max(1, ...rows.map((r) => r[`${g.key}_cob`] as number)), GRID_META.component.measures)), p, GRID_META.component.measures, ['label', 'name'], []),
      { field: 'share', headerName: 'Share of VaR', hide: true, type: ['percent'], minWidth: 130, cellRenderer: 'shareCell', rendererRules: [{ when: { row: 'pinned' }, renderer: 'shareTotalCell' }] },
    ],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'single' },
    meta: meta('dataset-3', rows.length, batch, p),
  };
}

// dataset-4 · Component VaR over time (top 6 FS types + Other)
function dataset4(p: Params, batch: number): Dataset {
  const g = groupsFor(p)[0], m = g.measure.id as 'var' | 'svar', days = Number(p.days || 90), dates = businessDays(p.asOf || '2026-09-11', days);
  const scope = rowsInScope(p, true);
  const top = FS.slice(0, 6);
  const rows = dates.map((d, k) => {
    const idx = N - days + k; const r: Row = { date: d }; let tot = 0;
    scope.forEach(({ i }) => { tot += series(i, g.model, m, p, batch)[idx]; });
    let used = 0;
    top.forEach((code, j) => { const v = tot * FS_BASE[j] * (1 + 0.14 * Math.sin(k / 4.3 + j * 1.7)); r[code] = Math.round(v); used += v; });
    r.Other = Math.round(tot - used);
    return r;
  });
  return {
    datasetId: 'dataset-4', kind: 'series', version: `b${batch}-4`, asOf: ASOF(p), rowKey: 'date', rowData: rows,
    seriesDefs: [...top.map((c, j) => ({ field: c, name: c, type: ['money'], palette: j + 1, stack: 's' })), { field: 'Other', name: 'Other', type: ['money'], palette: 8, stack: 's' }],
    meta: meta('dataset-4', days, batch, p),
  };
}

function limitExposure(l: (typeof LIMITS)[number], p: Params, batch: number) {
  const [, , , rowIdx, kind] = l;
  const idx = rowIdx === null ? PRIMARY_ROWS.map((_, i) => i) : [rowIdx];
  const acc = new Array(N).fill(0);
  idx.forEach((i) => series(i, MODELS[0], kind, { ...p, variant: '1D', attr: 'Trading' }, batch).forEach((v, k) => { acc[k] += v; }));
  return acc;
}

// dataset-5 · VaR / SVaR limits (column names from GRID_META.limits)
function dataset5(p: Params, batch: number): Dataset {
  const C = GRID_META.limits.columns;
  const rows: Row[] = LIMITS.map((l) => {
    const s = limitExposure(l, p, batch), threshold = l[5] * 1e6, exposure = Math.round(s[N - 1]), previous = Math.round(s[N - 2]);
    return { id: l[0], limitId: l[0], limitName: l[1], label: l[1], tierDescription: l[2], unit: '$MM', kind: l[4] === 'var' ? 'VaR' : 'SVaR',
      threshold, exposure, previous, change: exposure - previous, utilization: exposure / threshold, headroom: threshold - exposure };
  }).sort((a, b) => (b.utilization as number) - (a.utilization as number));
  const breaches = rows.filter((r) => (r.utilization as number) >= 1).length, warn = rows.filter((r) => (r.utilization as number) >= 0.8).length;
  const total: Row = { id: 'total', tierDescription: `${warn} at risk · ${breaches} in breach`, label: 'Total', threshold: sum(rows, 'threshold'), exposure: sum(rows, 'exposure'), previous: sum(rows, 'previous'), change: sum(rows, 'change') };
  return {
    datasetId: 'dataset-5', kind: 'grid', version: `b${batch}-5`, asOf: ASOF(p), rowKey: 'id', rowData: rows, pinnedBottomRowData: [total],
    columnDefs: [
      { field: 'tierDescription', headerName: C.tierDescription, pinned: 'left', width: 190, minWidth: 160, type: ['text'], tooltipField: 'tierDescription', rendererRules: [{ when: { row: 'pinned' }, renderer: 'totalCell' }] },
      { field: 'limitId', headerName: C.limitId, type: ['text'], minWidth: 90 },
      { field: 'limitName', headerName: C.limitName, type: ['text'], minWidth: 150, tooltipField: 'limitName' },
      { field: 'unit', headerName: C.unit, type: ['tag'], minWidth: 64 },
      money('threshold', C.threshold, { minWidth: 84 }),
      money('exposure', C.exposure, { minWidth: 84 }),
      { field: 'utilization', headerName: C.utilization, type: ['percent', 'threshold'], minWidth: 140, cellRendererParams: { warn: 0.8, breach: 1 } },
      money('change', C.change1d, { type: ['money', 'change'], minWidth: 84 }),
    ],
    gridOptions: { rowModel: 'clientSide', rowSelection: 'single' }, meta: meta('dataset-5', rows.length, batch, p),
  };
}

// dataset-6 · Exposure vs limit for one limit (default: highest utilisation)
function dataset6(p: Params, batch: number): Dataset {
  const ranked = [...LIMITS].sort((a, b) => { const u = (l: typeof a) => limitExposure(l, p, batch)[N - 1] / (l[5] * 1e6); return u(b) - u(a); });
  const l = LIMITS.find((x) => x[0] === p.limitId) ?? ranked[0];
  const days = Number(p.days || 90), limit = l[5] * 1e6, s = limitExposure(l, p, batch).slice(-days), dates = businessDays(p.asOf || '2026-09-11', days);
  return {
    datasetId: 'dataset-6', kind: 'series', version: `b${batch}-6-${l[0]}`, asOf: ASOF(p), rowKey: 'date',
    seriesDefs: [{ field: 'value', name: `${l[0]} · ${l[1]}`, type: ['money'], palette: 1 }],
    rowData: dates.map((d, k) => ({ date: d, value: Math.round(s[k]), threshold: k < days / 2 ? Math.round(limit * 0.9) : limit })),
    meta: meta('dataset-6', days, batch, { ...p, limitId: l[0] }),
  };
}

const BUILDERS: Record<string, (p: Params, b: number) => Dataset> = {
  'dataset-1': dataset1, 'dataset-2': dataset2, 'dataset-3': dataset3, 'dataset-4': dataset4, 'dataset-5': dataset5, 'dataset-6': dataset6,
};
export const MOCK_DATASET_IDS = Object.keys(BUILDERS);

export function buildDataset(id: string, params: Params, batch: number): Dataset {
  const b = BUILDERS[id];
  if (!b) throw new Error('Unknown dataset ' + id);
  if (cache.size > 4000) cache.clear();
  return b(params, batch);
}
