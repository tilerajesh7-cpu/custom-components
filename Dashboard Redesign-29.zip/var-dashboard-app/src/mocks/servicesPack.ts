// Builds the "services pack": every endpoint the UI calls, with a real request URL and the exact mock response.
// This is what you hand to the services team — the mock IS the contract.
import { buildDashboard, NAVIGATION } from './dashboard';
import { buildDataset } from './datasets';

interface Example { name: string; purpose: string; method: 'GET'; url: string; params: Record<string, string>; response: unknown }

const qs = (p: Record<string, string>) => new URLSearchParams(p).toString();

/** $filter.x → default value; optional $selection?.w dropped (or replaced for drilldown examples). */
function paramsFor(raw: Record<string, string | number>, defaults: Record<string, string>, pick: Record<string, string> = {}) {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(raw)) {
    const s = String(v);
    if (s.startsWith('$filter.')) out[k] = defaults[s.slice(8)] ?? '';
    else if (s.startsWith('$selection')) { if (pick[k]) out[k] = pick[k]; }
    else out[k] = s;
  }
  return out;
}

export function buildServicesPack() {
  const dash = buildDashboard();
  const defaults = Object.fromEntries(dash.filters.map((f) => [f.filterId, f.default]));
  const batch = 4812;
  const examples: Example[] = [
    { name: 'navigation', purpose: 'Sidebar tree. Called once at app start.', method: 'GET', url: '/me/navigation', params: {}, response: NAVIGATION },
    { name: 'dashboard', purpose: 'Dashboard definition: filters, datasets + bindings, widgets, layout, tabs, alerts, hotkeys, views. Called once per dashboard.', method: 'GET', url: `/dashboards/${dash.dashboardId}`, params: {}, response: dash },
    { name: 'latest-batch', purpose: 'Polled every 15 s to detect a new risk batch.', method: 'GET', url: '/batches/latest', params: {}, response: { batchId: batch, publishedAt: new Date().toISOString() } },
  ];
  const used = (id: string) => dash.widgets.filter((w) => 'datasetId' in w && w.datasetId === id).map((w) => `${w.widgetId} (${w.type}: ${w.title})`);
  for (const ref of dash.datasets) {
    const p = paramsFor(ref.params, defaults);
    examples.push({ name: `${ref.datasetId}`, purpose: `${ref.kind === 'grid' ? 'Grid' : 'Series'} dataset — default view. Used by: ${used(ref.datasetId).join(', ')}.`, method: 'GET', url: `/datasets/${ref.datasetId}?${qs(p)}`, params: p, response: buildDataset(ref.datasetId, p, batch) });
    const drill = Object.entries(ref.params).find(([, v]) => String(v).startsWith('$selection'));
    if (drill) {
      const key = drill[0];
      const value = key === 'limitId' ? 'LIM-1870' : 'R01';
      const pd = paramsFor(ref.params, defaults, { [key]: value });
      examples.push({ name: `${ref.datasetId}.drilldown`, purpose: `Same dataset after a click (${key}=${value}, from ${String(drill[1]).replace('$selection?.', '').replace('$selection.', '')}).`, method: 'GET', url: `/datasets/${ref.datasetId}?${qs(pd)}`, params: pd, response: buildDataset(ref.datasetId, pd, batch) });
    }
  }
  const errors = [
    { status: 403, when: 'User not entitled to this dataset', body: { error: 'Forbidden' }, ui: 'Card shows “You don’t have access to this panel”' },
    { status: 404, when: 'Unknown dataset / dashboard id', body: { error: 'Not found' }, ui: 'Card shows error + Retry' },
    { status: 503, when: 'Upstream unavailable', body: { error: 'Service unavailable' }, ui: 'Card shows error + Retry (only that card)' },
    { status: 200, when: 'Valid request, no rows', body: { '…': 'same shape', rowData: [], meta: { rowCount: 0 } }, ui: 'Card shows its empty message' },
  ];
  return {
    title: 'VaR Summary — services pack (generated from the UI mocks)',
    generatedAt: new Date().toISOString(),
    howToRead: [
      'Each example = one HTTP call the UI makes: method, url, params and the exact response body the UI expects.',
      'Grid datasets (kind: "grid") are AG Grid-ready: rowData + columnDefs (allowed subset) + pinnedBottomRowData + gridOptions + meta.',
      'Series datasets (kind: "series") feed Highcharts: rowData keyed by date + seriesDefs.',
      'Money values are in base units (USD). The UI formats them ($MM, %, dates). Services never send colours — only tones.',
      'meta.sql is only for non-production. The UI never sends SQL.',
      '"*.drilldown" examples show the same dataset after a user click (rowId / limitId added).',
    ],
    endpoints: examples.map(({ name, purpose, method, url }) => ({ name, method, url, purpose })),
    examples,
    errors,
  };
}

/** One JSON file per endpoint + index, for teams that prefer separate fixtures. */
export function servicesPackFiles() {
  const pack = buildServicesPack();
  const files: Record<string, string> = { '00-index.json': JSON.stringify({ title: pack.title, generatedAt: pack.generatedAt, howToRead: pack.howToRead, endpoints: pack.endpoints, errors: pack.errors }, null, 2) };
  pack.examples.forEach((e, i) => { files[`${String(i + 1).padStart(2, '0')}-${e.name}.json`] = JSON.stringify(e, null, 2); });
  return { pack, files };
}
