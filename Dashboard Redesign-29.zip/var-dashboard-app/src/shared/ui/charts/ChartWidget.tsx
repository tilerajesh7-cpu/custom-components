import { useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import Highcharts, { type Options } from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import type { ChartWidgetConfig, Row } from '@/contracts';
import { formats, isNum } from '../lib/formats';
import { SegmentedControl } from '../controls';
import type { WidgetProps } from '../widgets/registry';
import { encode } from './encode';
import { presets } from './presets';
import './charts.css';

type AnyChart = Highcharts.Chart & { exportChartLocal?: (o: object) => void; downloadCSV?: () => void };

/** Generic chart widget: preset + encoding over any dataset's rows. Updates in place (no re-create). */
export function ChartWidget({ config, dataset, selection, clientFilters, onEvent, actionRef, density }: WidgetProps<ChartWidgetConfig>) {
  const ref = useRef<HighchartsReact.RefObject>(null);
  const ranges = config.options?.ranges;
  const [range, setRange] = useState<number | undefined>(ranges?.[ranges.length - 1]);
  const listens = config.interactions?.listens ?? [];
  const seriesSel = listens.find((l) => l.field === '$series');
  const highlight = seriesSel ? selection[seriesSel.from] : undefined;

  const rows = useMemo<Row[]>(() => {
    if (!dataset) return [];
    return dataset.rowData.filter((r) =>
      Object.entries(clientFilters).every(([f, v]) => !v || v === 'all' || !(f in r) || String(r[f]) === v) &&
      listens.every((l) => { if (l.field.startsWith('$')) return true; const k = selection[l.from]; return !k?.length || k.includes(String(r[l.field])); }));
  }, [dataset, clientFilters, selection, listens]);

  const pointEmit = config.interactions?.emits?.find((e) => e.on === 'pointClick');
  // Category charts highlight the key selected in the widget they drive (e.g. What moved ↔ primary grid).
  const focusKeys = pointEmit ? selection[pointEmit.target ?? config.widgetId] : undefined;
  const legendEmit = config.interactions?.emits?.find((e) => e.on === 'legendClick');

  const options = useMemo<Options>(() => {
    if (!dataset) return {};
    const base = presets[config.preset] ?? {};
    const { series, xAxis } = encode(dataset, config.encoding, rows, { range: dataset.kind === 'series' ? range : undefined, highlight, focus: focusKeys });
    const height = (config.options?.height ?? 320) + (density === 'spacious' ? 20 : density === 'comfortable' ? 10 : 0);
    return {
      ...base,
      chart: { ...base.chart, height },
      xAxis: { ...(base.xAxis as object), ...(xAxis ?? {}) } as Highcharts.XAxisOptions,
      tooltip: {
        ...base.tooltip,
        xDateFormat: '%a %b %e, %Y',
        headerFormat: '<div style="font-weight:600;margin-bottom:6px;color:#c7d2ea">{point.key}</div>',
        pointFormatter(this: Highcharts.Point) {
          return `<div style="display:flex;gap:10px;justify-content:space-between;min-width:190px"><span><span style="color:${this.color}">●</span> ${this.series.name}</span><b style="font-family:'IBM Plex Mono',monospace">${formats.full(this.y)}</b></div>`;
        },
      },
      exporting: { enabled: false, fallbackToExportServer: false, filename: config.widgetId, sourceWidth: 1200 },
      plotOptions: {
        ...base.plotOptions,
        series: {
          ...(base.plotOptions?.series ?? {}),
          cursor: pointEmit || legendEmit ? 'pointer' : undefined,
          point: pointEmit ? { events: { click(this: Highcharts.Point) {
            const key = (this.options as { custom?: { key?: string } }).custom?.key;
            const target = pointEmit.target ?? config.widgetId;
            if (key) onEvent({ kind: 'selection', widgetId: target, keys: selection[target]?.includes(key) ? [] : [key] });
          } } } : undefined,
          events: legendEmit ? { legendItemClick(this: Highcharts.Series, e: { preventDefault?: () => void }) {
            e?.preventDefault?.();
            const target = legendEmit.target ?? config.widgetId;
            const name = this.name;
            onEvent({ kind: 'selection', widgetId: target, keys: selection[target]?.includes(name) ? [] : [name] });
            return false;
          } } : undefined,
        },
      },
      series,
    } as Options;
  }, [dataset, rows, range, highlight, focusKeys, config, onEvent, selection, pointEmit, legendEmit, density]);

  const chart = () => ref.current?.chart as AnyChart | undefined;
  actionRef.current = {
    'export.png': () => chart()?.exportChartLocal?.({ type: 'image/png', filename: config.widgetId }),
    'export.svg': () => chart()?.exportChartLocal?.({ type: 'image/svg+xml', filename: config.widgetId }),
    'export.csv': () => chart()?.downloadCSV?.(),
  };

  const stats = useMemo(() => {
    if (!config.options?.stats || !dataset || dataset.kind !== 'series') return null;
    const y = Array.isArray(config.encoding.y) ? config.encoding.y[0] : dataset.seriesDefs[0]?.field;
    const refField = config.encoding.reference?.[0]?.field;
    const vals = rows.map((r) => r[y ?? '']).filter(isNum);
    if (!vals.length) return null;
    const last = rows[rows.length - 1];
    const over = refField ? rows.filter((r) => isNum(r[y ?? '']) && isNum(r[refField]) && (r[y ?? ''] as number) > (r[refField] as number)).length : 0;
    const ratio = refField && isNum(last[refField]) ? (last[y ?? ''] as number) / (last[refField] as number) : undefined;
    return { current: vals[vals.length - 1], peak: Math.max(...vals), over, ratio, name: dataset.seriesDefs[0]?.name };
  }, [config, dataset, rows]);

  const [slot, setSlot] = useState<HTMLElement | null>(null);
  useLayoutEffect(() => { setSlot(document.getElementById('w-' + config.widgetId + '-tools')); }, [config.widgetId]);
  const rangeCtl = ranges && ranges.length > 1 ? (
    <div className="cw-range">
      <SegmentedControl tone="light" size="sm" value={String(range)} onChange={(v) => setRange(Number(v))} options={ranges.map((r) => ({ value: String(r), label: `${r}D` }))} />
    </div>
  ) : null;
  return (
    <div className="cw">
      {rangeCtl && (slot ? createPortal(rangeCtl, slot) : <div className="cw-bar">{rangeCtl}</div>)}
      {stats && <div className="cw-bar"><span className="cw-name">{stats.name}</span></div>}
      {stats && (
        <div className="cw-stats">
          <div className="cw-stat"><span>Current</span><b title={formats.full(stats.current)}>{formats.millions(stats.current)}</b>{stats.ratio !== undefined && <em className={stats.ratio >= 1 ? 'tone-negative' : stats.ratio >= 0.8 ? 'tone-warn-fg' : ''}>{formats.percent0(stats.ratio)} of threshold</em>}</div>
          <div className="cw-stat"><span>Peak (90D)</span><b title={formats.full(stats.peak)}>{formats.millions(stats.peak)}</b></div>
          <div className="cw-stat"><span>Days over</span><b className={stats.over ? 'tone-negative' : ''}>{stats.over}</b></div>
        </div>
      )}
      <HighchartsReact ref={ref} highcharts={Highcharts} options={options} updateArgs={[true, true, true]} containerProps={{ className: 'cw-chart' }} />
    </div>
  );
}
