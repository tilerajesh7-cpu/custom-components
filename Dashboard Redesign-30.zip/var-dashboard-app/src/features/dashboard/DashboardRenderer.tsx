import { Fragment, createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import type { Dashboard, WidgetConfig } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { useAppSelector } from '@/app/hooks';
import { cssVars } from '@/shared/ui/controls';
import { WidgetHost } from './WidgetHost';
import { TabBar } from './Sections';
import './dashboard.css';

/** UI visibility flag from the dashboard definition (default: shown). Hidden = not rendered; component + logic stay. */
export const featureOn = (d: Dashboard, key: string) => d.features?.[key] !== false;

/** In-page expand: the expanded card takes the full row width, the other cards in that row wrap below at full width. */
interface ExpandCtx { expanded: string | null; toggle: (widgetId: string) => void; clear: () => void }
const RowExpand = createContext<ExpandCtx>({ expanded: null, toggle: () => {}, clear: () => {} });
export const useRowExpand = (widgetId: string) => { const c = useContext(RowExpand); return { expanded: c.expanded === widgetId, rowExpanded: c.expanded !== null, toggle: () => c.toggle(widgetId), clear: c.clear }; };
function ExpandRow({ ids, children }: { ids: string[]; children: (expanded: string | null) => ReactNode }) {
  const [expanded, setExpanded] = useState<string | null>(null);
  const toggle = useCallback((id: string) => {
    setExpanded((x) => (x === id ? null : id));
    requestAnimationFrame(() => requestAnimationFrame(() => window.dispatchEvent(new Event('resize'))));   // AG Grid / Highcharts re-fit
  }, []);
  const clear = useCallback(() => { setExpanded(null); requestAnimationFrame(() => window.dispatchEvent(new Event('resize'))); }, []);
  const value = useMemo(() => ({ expanded: expanded && ids.includes(expanded) ? expanded : null, toggle, clear }), [expanded, ids, toggle, clear]);
  return <RowExpand.Provider value={value}>{children(value.expanded)}</RowExpand.Provider>;
}

const HIDE_BY_TYPE: Record<string, string> = { summary: 'dailyBrief', kpi: 'kpis' };
const shown = (d: Dashboard, w: WidgetConfig | undefined) => !!w && featureOn(d, HIDE_BY_TYPE[w.type] ?? '__none');

/**
 * Renders the backend flex layout. With tabs on, rows not listed in any tab are always shown; the tab bar sits
 * before the first tabbed row. `before` injects nodes (e.g. alerts) before a row index.
 */
export function DashboardRenderer({ dashboard, datasets, before }: { dashboard: Dashboard; datasets: DatasetResults; before?: Record<number, ReactNode> }) {
  const tabId = useAppSelector((s) => s.ui.tab);
  const byId = useMemo(() => new Map(dashboard.widgets.map((w) => [w.widgetId, w])), [dashboard.widgets]);
  const tabs = featureOn(dashboard, 'tabs') ? dashboard.tabs ?? [] : [];
  const tab = tabs.find((t) => t.tabId === tabId) ?? tabs[0];
  const tabbed = new Set(tabs.flatMap((t) => t.rows));
  const rows = dashboard.layout.rows.map((row, i) => ({
    i,
    items: row.items.map((it) => ({ ...it, stack: it.stack?.filter((id) => shown(dashboard, byId.get(id))) }))
      .filter((it) => (it.stack ? it.stack.length > 0 : shown(dashboard, byId.get(it.widgetId ?? ''))) ),
    visible: !tabbed.has(i) || !tab || tab.rows.includes(i),
  }));
  const firstTabbed = rows.findIndex(({ i, visible, items }) => visible && items.length && tabbed.has(i));
  const host = (id: string) => { const w = byId.get(id); return w ? <WidgetHost key={id} widget={w} dashboard={dashboard} datasets={datasets} /> : null; };
  return (
    <div className="dash">
      {rows.map(({ i, items, visible }, k) => (
        <Fragment key={i}>
          {before?.[i]}
          {k === firstTabbed && <TabBar dashboard={dashboard} />}
          {visible && items.length > 0 && (
            <ExpandRow ids={items.flatMap((it) => it.stack ?? (it.widgetId ? [it.widgetId] : []))}>
              {(expanded) => (
                <div className={'dash-row' + (expanded ? ' is-expanded' : '')}>
                  {items.map((it, j) => {
                    const ids = it.stack ?? (it.widgetId ? [it.widgetId] : []);
                    return (
                      <div key={it.widgetId ?? j} className={'dash-slot' + (expanded && ids.includes(expanded) ? ' is-lead' : '')} style={cssVars({ '--grow': it.grow, '--basis': it.basis + 'px', '--min-w': it.minW ? it.minW + 'px' : '0px' })}>
                        {ids.map(host)}
                      </div>
                    );
                  })}
                </div>
              )}
            </ExpandRow>
          )}
        </Fragment>
      ))}
    </div>
  );
}
