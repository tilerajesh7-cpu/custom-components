import type { ReactNode } from 'react';
import type { Dashboard, Filter } from '@/contracts';
import { SegmentedControl } from '@/shared/ui/controls';
import { Icon } from '@/shared/ui/icons';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { clearAllSelections, clearSelection, setFilter } from './model';
import './filter-bar.css';

const COB = 'asOfDate', PCOB = 'pcobDate', COMPARE = 'compareTo';
const HEADER = new Set([COB, PCOB, COMPARE]);

/** Panels that react to the given selections (for the "→ …" hint). */
function affected(d: Dashboard, from: string[]) {
  return d.widgets.filter((w) => !from.includes(w.widgetId) && w.interactions?.listens?.some((l) => from.includes(l.from))).map((w) => w.title).join(', ') || 'related panels';
}

/** PCOB implied by the compare preset (DoD = previous business day, WoW −7d, MoM −1 month). */
export function impliedPcob(asOf: string, cmp: string, custom?: string) {
  if (cmp === 'Custom' && custom) return custom;
  const d = new Date(asOf + 'T00:00:00Z');
  if (Number.isNaN(d.getTime())) return '';
  if (cmp === 'WoW') d.setUTCDate(d.getUTCDate() - 7);
  else if (cmp === 'MoM') d.setUTCMonth(d.getUTCMonth() - 1);
  else do { d.setUTCDate(d.getUTCDate() - 1); } while (d.getUTCDay() === 0 || d.getUTCDay() === 6);
  return d.toISOString().slice(0, 10);
}

/** Sticky top: title + COB / PCOB + compare + actions · navy filter bar in labelled groups · cross-filter strip. */
export function FilterBar({ dashboard, actions, banner, views, labelFor }: {
  dashboard: Dashboard; actions?: ReactNode; banner?: ReactNode; views?: ReactNode; labelFor: (widgetId: string, key: string) => string;
}) {
  const dispatch = useAppDispatch();
  const values = useAppSelector((s) => s.filters.values);
  const selection = useAppSelector((s) => s.selection.byWidget);
  const chips = Object.entries(selection);
  const byId = (id: string) => dashboard.filters.find((f) => f.filterId === id);
  const cob = byId(COB), pcob = byId(PCOB), compare = byId(COMPARE);
  const bar = dashboard.filters.filter((f) => !HEADER.has(f.filterId) && !f.hidden && f.control !== 'date');
  // Group bar filters into backend-declared sections (unknown / missing section → last section, or one "Filters" section).
  const defs = dashboard.filterSections?.length ? dashboard.filterSections : [{ sectionId: '_all', label: 'Filters', icon: 'filter' }];
  const sections = defs.map((s, i) => ({ ...s, filters: bar.filter((f) => f.section === s.sectionId || (i === defs.length - 1 && !defs.some((d) => d.sectionId === f.section))) })).filter((s) => s.filters.length);
  const v = (f: Filter) => values[f.filterId] ?? f.default;
  const set = (id: string, value: string) => dispatch(setFilter({ id, value }));
  const asOf = cob ? v(cob) : '';
  const cmp = compare ? v(compare) : 'DoD';
  const pcobValue = impliedPcob(asOf, cmp, pcob ? v(pcob) : undefined);

  const control = (f: Filter) => f.control === 'select' ? (
    <span className="fb-select">
      <select value={v(f)} onChange={(e) => set(f.filterId, e.target.value)} aria-label={f.label}>
        {(f.options ?? []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <Icon name="chevronDown" size={13} />
    </span>
  ) : <SegmentedControl value={v(f)} options={f.options ?? []} onChange={(x) => set(f.filterId, x)} />;

  return (
    <div className="fb-sticky">
      <header className="fb-head">
        <div className="fb-titles">
          {dashboard.breadcrumb && <div className="fb-crumb">{dashboard.breadcrumb.map((b) => <span key={b}>{b}</span>)}</div>}
          <h1 className="fb-title">{dashboard.title}</h1>
        </div>
        <div className="fb-right">
          {cob && (
            <label className="fb-date">
              <small>{cob.label}</small>
              <span className="fb-date-box"><input type="date" value={asOf} onChange={(e) => e.target.value && set(COB, e.target.value)} /><Icon name="calendar" size={14} /></span>
            </label>
          )}
          {pcob && (
            <label className="fb-date">
              <small>{pcob.label}</small>
              <span className="fb-date-box">
                <input type="date" value={pcobValue} max={asOf} onChange={(e) => { if (!e.target.value) return; set(PCOB, e.target.value); if (compare) set(COMPARE, 'Custom'); }} />
                <Icon name="calendar" size={14} />
              </span>
            </label>
          )}
          {compare && (
            <div className="hdr-seg">
              <SegmentedControl tone="light" value={cmp} options={compare.options ?? []}
                onChange={(x) => { if (x === 'Custom' && pcob) set(PCOB, pcobValue); set(COMPARE, x); }} />
            </div>
          )}
          <div className="fb-actions">{actions}</div>
        </div>
      </header>
      <div className="fb-panel" role="toolbar" aria-label="Filters">
        {sections.map((s) => (
          <section key={s.sectionId} className="fb-sec" aria-label={s.label}>
            <header className="fb-sec-head">
              <span className="fb-sec-icon"><Icon name={(s.icon ?? 'filter') as never} size={13} /></span>
              <span className="fb-sec-title">{s.label}</span>
              {s.description && <span className="fb-sec-desc">{s.description}</span>}
            </header>
            <div className="fb-sec-body">
              {s.filters.map((f) => (
                <div key={f.filterId} className="fb-field">
                  <span className="fb-field-label">{f.label}</span>
                  {control(f)}
                </div>
              ))}
            </div>
          </section>
        ))}
        {views && <section className="fb-sec fb-sec-views" aria-label="Views"><div className="fb-sec-body">{views}</div></section>}
      </div>
      <div className="fb-cross">
        <span className="fb-cross-label"><Icon name="filter" size={12} />Cross-filters<b>{chips.length}</b></span>
        {chips.length === 0 && <span className="fb-cross-hint">Click a row, bar or legend to filter related panels</span>}
        {chips.map(([wid, keys]) => (
          <span key={wid} className="fb-chip">
            <span className="fb-chip-kind">{dashboard.widgets.find((w) => w.widgetId === wid)?.title ?? wid}</span>
            <b>{keys.map((k) => labelFor(wid, k)).join(', ')}</b>
            <button type="button" aria-label="Remove filter" onClick={() => dispatch(clearSelection(wid))}><Icon name="x" size={11} strokeWidth={2.4} /></button>
          </span>
        ))}
        {chips.length > 0 && <span className="fb-applies">→ {affected(dashboard, chips.map(([w]) => w))}</span>}
        {chips.length > 0 && <button type="button" className="fb-clear" onClick={() => dispatch(clearAllSelections())}>Clear all <kbd className="kbd">Esc</kbd></button>}
      </div>
      {banner}
    </div>
  );
}
