import type { Dashboard } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { formats, isNum } from '@/shared/ui/lib/formats';
import { Icon } from '@/shared/ui/icons';
import { dismissAlert, setSelection, setTab } from './model';
import { scrollToWidget } from '@/features/command-palette/scroll';

/** Tab bar from dashboard.tabs. */
export function TabBar({ dashboard }: { dashboard: Dashboard }) {
  const dispatch = useAppDispatch();
  const current = useAppSelector((s) => s.ui.tab);
  if (!dashboard.tabs?.length) return null;
  const active = dashboard.tabs.find((t) => t.tabId === current) ? current : dashboard.tabs[0].tabId;
  return (
    <div className="tabs" role="tablist" aria-label="Sections">
      {dashboard.tabs.map((t) => (
        <button key={t.tabId} type="button" role="tab" aria-selected={t.tabId === active} className={'tab' + (t.tabId === active ? ' is-on' : '')} onClick={() => dispatch(setTab(t.tabId))}>{t.label}</button>
      ))}
    </div>
  );
}

/**
 * Attention panel: every row at/above `warn` with a plain-language explanation —
 * status, name + id, exposure vs threshold, utilization, amount over / headroom, 1D change.
 * Clicking an item selects the row in the target grid and scrolls to it.
 */
export function AttentionStrip({ dashboard, datasets }: { dashboard: Dashboard; datasets: DatasetResults }) {
  const dispatch = useAppDispatch();
  const dismissed = useAppSelector((s) => s.ui.alertDismissed);
  const selected = useAppSelector((s) => (dashboard.alerts ? s.selection.byWidget[dashboard.alerts.target] : undefined));
  const cfg = dashboard.alerts;
  const ds = cfg ? datasets[cfg.datasetId]?.data : undefined;
  if (!cfg || !ds || dismissed) return null;
  const hits = ds.rowData.filter((r) => isNum(r[cfg.field]) && (r[cfg.field] as number) >= cfg.warn).sort((a, b) => (b[cfg.field] as number) - (a[cfg.field] as number));
  if (!hits.length) return null;
  const noun = cfg.noun ?? 'limit';
  const breach = hits.filter((r) => (r[cfg.field] as number) >= cfg.breach).length;
  const warn = hits.length - breach;
  const num = (r: Record<string, unknown>, f?: string) => (f && isNum(r[f]) ? (r[f] as number) : undefined);
  // One compact row: title + one clickable pill per limit (drilldown). Details live in the hover title.
  return (
    <section className={'att' + (breach ? ' is-breach' : '')} role="status" aria-live="polite">
      <span className={'att-icon' + (breach ? ' is-breach' : '')}><Icon name="alert" size={15} /></span>
      <b className="att-title">{hits.length} {noun}{hits.length === 1 ? '' : 's'} need{hits.length === 1 ? 's' : ''} attention</b>
      <div className="att-list">
        {hits.map((r) => {
          const key = String(r[ds.rowKey]), u = r[cfg.field] as number, on = selected?.includes(key), isBreach = u >= cfg.breach;
          const exp = num(r, cfg.valueField), lim = num(r, cfg.limitField), chg = num(r, cfg.changeField);
          const gap = exp !== undefined && lim !== undefined ? exp - lim : undefined;
          const title = [exp !== undefined && lim !== undefined ? `Exposure ${formats.millions(exp)} of ${formats.millions(lim)} threshold ($MM)` : '', gap !== undefined ? (gap > 0 ? 'over by ' : 'headroom ') + formats.millions(Math.abs(gap)) : '', chg !== undefined ? '1D ' + formats.millionsSigned(chg) : '', on ? 'Click to clear' : 'Click to drill down to this limit'].filter(Boolean).join(' · ');
          return (
            <button key={key} type="button" aria-pressed={!!on} title={title} className={'att-item ' + (isBreach ? 'is-breach' : 'is-warn') + (on ? ' is-on' : '')}
              onClick={() => { dispatch(setSelection({ widgetId: cfg.target, keys: on ? [] : [key] })); if (!on) scrollToWidget(cfg.target); }}>
              <em className={'att-tag ' + (isBreach ? 'is-breach' : 'is-warn')}>{isBreach ? 'Breach' : 'Warning'}</em>
              <b className="att-name">{String(r[cfg.labelField] ?? key)}</b>
              {cfg.idField && <span className="att-id">{String(r[cfg.idField] ?? '')}</span>}
              <b className="att-pct">{formats.percent1(u)}</b>
              <span className="att-go" aria-hidden="true"><Icon name="chevronRight" size={13} /></span>
            </button>
          );
        })}
      </div>
      <button type="button" className="att-close" onClick={() => dispatch(dismissAlert())} title="Hide until next load"><Icon name="x" size={14} /></button>
    </section>
  );
}
