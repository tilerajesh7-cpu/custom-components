import { Profiler, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { UseQueryResult } from '@tanstack/react-query';
import type { ChartWidgetConfig, Dashboard, Dataset, WidgetConfig, WidgetEvent, WidgetStatus } from '@/contracts';
import type { DatasetResults } from '@/api/queries';
import { ApiError } from '@/api/client';
import { useRowExpand } from './DashboardRenderer';
import { useAppDispatch, useAppSelector } from '@/app/hooks';
import { ExportMenu, WidgetFrame, getWidgetComponent, widgetActions, type WidgetActions } from '@/shared/ui/widgets';
import { IconButton, SegmentedControl } from '@/shared/ui/controls';
import { devBus } from '@/features/dev-tools/bus';
import { clearSelection, openInspector, resetGridPref, setGridPref, setSelection } from './model';
import { labelFor } from './labels';

function statusOf(q: UseQueryResult<Dataset> | undefined): WidgetStatus {
  if (!q) return 'loading';
  if (q.isError) return (q.error as ApiError).status === 403 ? 'forbidden' : 'error';
  if (q.isPending) return 'loading';
  if (q.isFetching) return 'refreshing';
  return q.data && q.data.rowData.length === 0 ? 'empty' : 'ready';
}

/** Connects one widget to the store, its dataset and the frame. The widget itself stays pure. */
export function WidgetHost({ widget, dashboard, datasets }: { widget: WidgetConfig; dashboard: Dashboard; datasets: DatasetResults }) {
  const dispatch = useAppDispatch();
  const selection = useAppSelector((s) => s.selection.byWidget);
  const filters = useAppSelector((s) => s.filters.values);
  const density = useAppSelector((s) => s.preferences.density);
  const prefs = useAppSelector((s) => s.preferences.grid[widget.widgetId]);
  const devOpen = useAppSelector((s) => s.ui.devOpen);
  const actionRef = useRef<WidgetActions>({});
  const movedRef = useRef<WidgetActions>({});
  const on = (k: string) => dashboard.features?.[k] !== false;
  // Grid | What moved (per grid) and expand-to-viewport (every card). Local UI state only.
  const [view, setView] = useState<'grid' | 'moved'>('grid');
  const { expanded, rowExpanded, toggle: toggleExpand, clear: clearExpand } = useRowExpand(widget.widgetId);
  useEffect(() => { requestAnimationFrame(() => window.dispatchEvent(new Event('resize'))); }, [view]);
  useEffect(() => {
    if (!expanded) return;
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); clearExpand(); } };
    document.addEventListener('keydown', k, true);
    return () => document.removeEventListener('keydown', k, true);
  }, [expanded, clearExpand]);
  useEffect(() => { widgetActions.set(widget.widgetId, actionRef); return () => { widgetActions.delete(widget.widgetId); }; }, [widget.widgetId]);

  const datasetId = 'datasetId' in widget ? widget.datasetId : undefined;
  const q = datasetId ? datasets[datasetId] : undefined;
  const summaryIds = widget.type === 'summary' ? [...new Set(widget.items.map((i) => i.datasetId))] : [];
  const status: WidgetStatus = widget.type === 'summary'
    ? summaryIds.some((id) => statusOf(datasets[id]) === 'loading') ? 'loading' : summaryIds.some((id) => statusOf(datasets[id]) === 'refreshing') ? 'refreshing' : 'ready'
    : statusOf(q);
  const Component = getWidgetComponent(widget.type);
  const ChartComponent = getWidgetComponent('chart');
  const wm = widget.type === 'grid' && on('whatMovedToggle') ? widget.presentation?.whatMoved : undefined;
  const showMoved = !!wm && view === 'moved';
  // Expanded row: every card in it is full width; grids get more height, charts keep a comfortable height.
  const tall = rowExpanded ? (widget.type === 'grid' ? Math.max(420, window.innerHeight - 320) : 460) : undefined;
  const movedConfig = useMemo<ChartWidgetConfig | undefined>(() => (wm && widget.type === 'grid' ? {
    widgetId: widget.widgetId + '-moved', type: 'chart', title: wm.label ?? 'What moved', preset: 'bar.diverging', datasetId: widget.datasetId,
    interactions: { emits: [{ on: 'pointClick', target: widget.widgetId }] }, actions: ['export.png', 'export.svg', 'export.csv'],
    encoding: { x: wm.labelField, y: [wm.field], sort: 'abs.desc', limit: wm.limit ?? 10 },
    options: { height: tall ?? Math.max(260, (widget.presentation?.height ?? 420) - 40) },
  } : undefined), [wm, widget, tall]);
  const config = widget.type === 'chart' && tall ? { ...widget, options: { ...widget.options, height: tall } } : widget;

  const versions = Object.values(datasets).map((d) => d.data?.version ?? '').join('|');
  const related = useMemo(() => Object.fromEntries(Object.entries(datasets).map(([k, v]) => [k, v.data])), [versions]); // eslint-disable-line react-hooks/exhaustive-deps
  const clientFilters = useMemo(() => Object.fromEntries(
    dashboard.filters.filter((f) => f.scope === 'client' && f.field).map((f) => [f.field!, filters[f.filterId] ?? 'all'])), [dashboard.filters, filters]);

  const onEvent = useCallback((e: WidgetEvent) => {
    if (e.kind === 'selection') dispatch(setSelection({ widgetId: e.widgetId, keys: e.keys }));
    else if (e.key === 'columns') dispatch(setGridPref({ widgetId: e.widgetId, patch: { columns: e.value as Record<string, boolean> } }));
    else if (e.key === 'cellMode') dispatch(setGridPref({ widgetId: e.widgetId, patch: { cellMode: e.value as 'smart' | 'table' } }));
    else if (e.key === 'reset') dispatch(resetGridPref(e.widgetId));
  }, [dispatch]);

  const listens = (widget.interactions?.listens ?? []).filter((l) => l.from !== widget.widgetId);
  const filteredBy = listens.filter((l) => selection[l.from]?.length).map((l) => selection[l.from].map((k) => labelFor(dashboard, datasets, l.from, k)).join(', '));
  const subtitle = widget.subtitle?.replace(/\{filter\.(\w+)\}/g, (_, id: string) => filters[id] ?? '');

  const body = (
    <WidgetFrame
      id={'w-' + widget.widgetId}
      title={widget.type === 'kpi' ? undefined : widget.title}
      subtitle={widget.type === 'kpi' ? undefined : subtitle}
      status={status}
      emptyText={widget.states?.empty}
      filteredBy={on('filteredByChip') ? [...new Set(filteredBy)] : undefined}
      onClearFilter={() => listens.forEach((l) => dispatch(clearSelection(l.from)))}
      onRetry={() => void q?.refetch()}
      actions={widget.type === 'kpi' ? undefined : (
        <>
          {wm && (
            <span className="wf-view" title="Switch between the grid and its largest changes">
              <SegmentedControl tone="light" size="sm" value={view} onChange={(v) => setView(v as 'grid' | 'moved')}
                options={[{ value: 'grid', label: 'Grid' }, { value: 'moved', label: 'What moved' }]} />
            </span>
          )}
          {devOpen && datasetId && <IconButton icon="database" title="Query inspector" className="wf-db" onClick={() => dispatch(openInspector(widget.widgetId))} />}
          {showMoved && movedConfig?.actions ? <ExportMenu actions={movedConfig.actions} actionRef={movedRef} />
            : widget.actions?.length ? <ExportMenu actions={widget.actions} actionRef={actionRef} /> : null}
          {on('expand') && <IconButton icon={expanded ? 'collapseH' : 'expandH'} title={expanded ? 'Back to side by side (Esc)' : 'Expand to full width'} onClick={toggleExpand} />}
        </>
      )}
    >
      {showMoved && ChartComponent && movedConfig ? (
        <ChartComponent config={movedConfig} dataset={q?.data} related={related} status={status} selection={selection} clientFilters={clientFilters}
          density={density} prefs={undefined} actionRef={movedRef} onEvent={onEvent} />
      ) : Component ? (
        <Component config={widget.type === 'kpi' ? { ...widget, subtitle } : config} dataset={q?.data} related={related} status={status} selection={selection} clientFilters={clientFilters}
          density={density} prefs={prefs} actionRef={actionRef} onEvent={onEvent} />
      ) : <div className="wf-state">Unknown widget type “{widget.type}”</div>}
    </WidgetFrame>
  );

  const framed = body;
  return devBus.enabled ? <Profiler id={widget.widgetId} onRender={(id, _p, ms) => devBus.render(id, ms)}>{framed}</Profiler> : framed;
}
