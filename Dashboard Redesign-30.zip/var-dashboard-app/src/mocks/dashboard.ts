import { FILTER_META as F, GRID_META, PRIMARY_GRID_LABELS as L } from './seed';
// Mock dashboard definition + navigation — same shape services will return.
import type { Dashboard, NavItem } from '@/contracts';

type Opts = (string | [string, string])[];
const opts = (o: Opts) => o.map((x) => (Array.isArray(x) ? { value: x[0], label: x[1] } : { value: x, label: x }));
const seg = (filterId: keyof typeof F, def: string, extra: { hidden?: boolean; section?: string; hint?: string } = {}) => ({
  filterId, label: F[filterId].label, control: 'segmented' as const, default: def, scope: 'server' as const, options: opts((F[filterId] as { options: Opts }).options), ...extra,
});
const select = (filterId: keyof typeof F, def: string, extra: { section?: string; hint?: string } = {}) => ({ ...seg(filterId, def, extra), control: 'select' as const });

const EXPORT_GRID = ['export.excel', 'export.csv', 'export.copy', 'export.json'];
const EXPORT_CHART = ['export.png', 'export.svg', 'export.csv'];

export function buildDashboard(): Dashboard {
  const P = {
    asOf: '$filter.asOfDate', compare: '$filter.compareTo', pcob: '$filter.pcobDate', region: '$filter.region', variant: '$filter.variant',
    model: '$filter.model', attr: '$filter.attr', measure: '$filter.measure',
  };
  const selectedRow = '$selection?.widget-3';
  const G = GRID_META;
  return {
    schemaVersion: '1.0', dashboardId: 'dashboard-1', version: 2, title: 'VaR Summary', breadcrumb: ['Daily Risk', 'Equities'],
    // Filter bar order = array order. Labels / options are data (FILTER_META) — another dashboard sends its own.
    filters: [
      { filterId: 'asOfDate', label: F.asOfDate.label, control: 'date', default: '2026-09-11', scope: 'server' },
      { filterId: 'pcobDate', label: F.pcobDate.label, control: 'date', default: '2026-09-10', scope: 'server' },
      seg('compareTo', 'DoD'),
      select('region', 'All', { section: 'scope' }),
      seg('variant', '1D', { section: 'measure' }),
      seg('model', 'Both', { section: 'measure' }),
      seg('attr', 'Trading', { section: 'attribution' }),
      seg('days', '30', { section: 'chart' }),
      seg('measure', 'Both', { hidden: true }),
    ],
    // Filter bar sections (labels are data). Filters without a section fall into the last one.
    filterSections: [
      { sectionId: 'scope', label: 'Scope', icon: 'globe', description: 'Which rows' },
      { sectionId: 'measure', label: 'Risk measure', icon: 'layers', description: 'Horizon & model' },
      { sectionId: 'attribution', label: 'Attribution', icon: 'tag', description: 'Portfolio view' },
      { sectionId: 'chart', label: 'Trend chart', icon: 'chart', description: 'History shown' },
    ],
    datasets: [
      { datasetId: 'dataset-1', kind: 'grid', params: P },
      { datasetId: 'dataset-2', kind: 'series', params: { ...P, days: '$filter.days', rowId: selectedRow } },
      { datasetId: 'dataset-3', kind: 'grid', params: { ...P, rowId: selectedRow } },
      { datasetId: 'dataset-4', kind: 'series', params: { ...P, days: '$filter.days', rowId: selectedRow } },
      { datasetId: 'dataset-5', kind: 'grid', params: { asOf: '$filter.asOfDate' } },
      { datasetId: 'dataset-7', kind: 'grid', params: P },
      { datasetId: 'dataset-8', kind: 'series', params: { ...P, days: '$filter.days', rowId: '$selection?.widget-11' } },
      { datasetId: 'dataset-6', kind: 'series', params: { asOf: '$filter.asOfDate', days: '$filter.days', limitId: '$selection?.widget-8' } },
    ],
    widgets: [
      // Hidden on screen via features (kpis / dailyBrief = false) — definitions and components kept.
      { widgetId: 'kpi-var', type: 'kpi', title: 'Total VaR', subtitle: 'vs previous COB · $MM', datasetId: 'dataset-1', row: 'pinnedBottom', value: 'varCob', compare: 'varPcob', tone: 'higherIsWorse', spark: 'dataset-2:var' },
      { widgetId: 'kpi-svar', type: 'kpi', title: 'Total SVaR', subtitle: 'vs previous COB · $MM', datasetId: 'dataset-1', row: 'pinnedBottom', value: 'svarCob', compare: 'svarPcob', tone: 'higherIsWorse', spark: 'dataset-2:svar' },
      { widgetId: 'kpi-limit', type: 'kpi', title: 'VaR limit used', subtitle: `all ${L.many} in scope`, datasetId: 'dataset-1', row: 'pinnedBottom', value: 'limitUse', format: 'percent', bar: true },
      { widgetId: 'kpi-risk', type: 'kpi', title: `${L.one} limits at risk`, datasetId: 'dataset-1', row: 'first', value: 'limitUse', mode: 'countAtRisk', format: 'count' },
      { widgetId: 'kpi-mover', type: 'kpi', title: 'Largest VaR mover', datasetId: 'dataset-1', row: 'first', value: 'varD', mode: 'maxAbs', labelField: 'short', format: 'moneySigned' },
      { widgetId: 'widget-10', type: 'summary', title: 'Daily brief', subtitle: 'what moved today · click an item to focus it', items: [
        { label: 'Largest VaR increase', rule: 'max', datasetId: 'dataset-1', field: 'varD', labelField: 'label', target: 'widget-3', format: 'moneySigned' },
        { label: 'Largest VaR decrease', rule: 'min', datasetId: 'dataset-1', field: 'varD', labelField: 'label', target: 'widget-3', format: 'moneySigned' },
        { label: 'Highest limit utilisation', rule: 'max', datasetId: 'dataset-5', field: 'utilization', labelField: 'limitName', target: 'widget-8', format: 'percent' },
        { label: 'Unusual moves (≥ 2σ)', rule: 'countBadges', datasetId: 'dataset-1', field: 'short', format: 'count' },
      ] },
      { widgetId: 'widget-3', type: 'grid', title: G.primary.title, subtitle: '{filter.variant} · {filter.attr} · click a row to filter', datasetId: 'dataset-1',
        interactions: { emits: [{ on: 'rowClick' }] }, actions: EXPORT_GRID,
        presentation: { height: 520, cellMode: 'table', searchNoun: L.many, features: { search: false, columnsPanel: false },
          whatMoved: { field: 'varD', labelField: 'short', limit: 10, label: 'Largest VaR changes vs PCOB' } } },
      { widgetId: 'widget-4', type: 'chart', title: G.charts.primary, subtitle: '$MM · business days · MC solid, Hist dashed', preset: 'line', datasetId: 'dataset-2',
        interactions: { listens: [{ from: 'widget-3', field: '$param' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { height: 470 } },
      // Standalone "What moved" chart kept (not in layout) — the same view now lives in every grid's header toggle.
      { widgetId: 'widget-5', type: 'chart', title: 'What moved', subtitle: 'largest VaR changes vs {filter.compareTo} · click to focus', preset: 'bar.diverging', datasetId: 'dataset-1',
        interactions: { emits: [{ on: 'pointClick', target: 'widget-3' }] }, actions: EXPORT_CHART,
        encoding: { x: 'short', y: ['varD'], sort: 'abs.desc', limit: 7 }, options: { height: 230 } },
      { widgetId: 'widget-11', type: 'grid', title: G.componentByRow.title, subtitle: '{filter.variant} · {filter.attr} · click a row to filter', datasetId: 'dataset-7',
        interactions: { emits: [{ on: 'rowClick' }] }, actions: EXPORT_GRID,
        presentation: { height: 520, cellMode: 'table', searchNoun: L.many, features: { search: false, columnsPanel: false },
          whatMoved: { field: 'primaryD', labelField: 'short', limit: 10, label: 'Largest component VaR changes vs PCOB' } } },
      { widgetId: 'widget-12', type: 'chart', title: G.charts.componentByRow, subtitle: '$MM · business days · MC solid, Hist dashed', preset: 'line', datasetId: 'dataset-8',
        interactions: { listens: [{ from: 'widget-11', field: '$param' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { height: 470 } },
      { widgetId: 'widget-6', type: 'grid', title: G.component.title, subtitle: '{filter.variant} · {filter.attr} · click a row to filter', datasetId: 'dataset-3',
        interactions: { emits: [{ on: 'rowClick', target: 'widget-7' }], listens: [{ from: 'widget-3', field: '$param' }] }, actions: EXPORT_GRID,
        presentation: { height: 440, cellMode: 'table', searchNoun: 'FS types', features: { search: false, columnsPanel: false },
          whatMoved: { field: 'primaryD', labelField: 'label', limit: 10, label: 'Largest component VaR changes' } } },
      { widgetId: 'widget-7', type: 'chart', title: G.charts.component, subtitle: 'daily · stacked by FS type · click the legend to filter', preset: 'column.stacked', datasetId: 'dataset-4',
        interactions: { emits: [{ on: 'legendClick' }], listens: [{ from: 'widget-3', field: '$param' }, { from: 'widget-7', field: '$series' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: { fromSeriesDefs: true } }, options: { height: 420 } },
      { widgetId: 'widget-8', type: 'grid', title: G.limits.title, subtitle: 'sorted by utilization · click a row to chart', datasetId: 'dataset-5',
        interactions: { emits: [{ on: 'rowClick' }] }, actions: EXPORT_GRID,
        presentation: { height: 440, searchNoun: 'limits', features: { search: false, columnsPanel: false },
          whatMoved: { field: 'change', labelField: 'limitName', limit: 10, label: 'Largest 1D exposure changes' } } },
      { widgetId: 'widget-9', type: 'chart', title: G.exposure.title, subtitle: 'business days · highest utilization until you pick a limit', preset: 'column.reference', datasetId: 'dataset-6',
        interactions: { listens: [{ from: 'widget-8', field: '$param' }] }, actions: EXPORT_CHART,
        encoding: { x: 'date', y: ['value'], reference: [{ field: 'threshold', label: 'Limit' }, { field: 'threshold', scale: 0.8, style: 'dashed', label: '80% of limit' }], zones: { ratioOf: 'threshold', steps: [[0.8, 'warn'], [1, 'breach']] } },
        options: { height: 330, stats: true } },
    ],
    // Rows: 0 brief · 1 KPIs (hidden) · 2–5 grid + chart side by side. Expand = that card takes the full row, its partner drops below (also full width).
    layout: { type: 'flex', gap: 16, rows: [
      { items: [{ widgetId: 'widget-10', basis: 600, grow: 1 }] },
      { items: [
        { widgetId: 'kpi-var', basis: 200, grow: 1 }, { widgetId: 'kpi-svar', basis: 200, grow: 1 }, { widgetId: 'kpi-limit', basis: 200, grow: 1 },
        { widgetId: 'kpi-risk', basis: 200, grow: 1 }, { widgetId: 'kpi-mover', basis: 200, grow: 1 },
      ] },
      { items: [{ widgetId: 'widget-3', basis: 640, grow: 7, minW: 460 }, { widgetId: 'widget-4', basis: 380, grow: 5, minW: 320 }] },
      { items: [{ widgetId: 'widget-11', basis: 640, grow: 7, minW: 460 }, { widgetId: 'widget-12', basis: 380, grow: 5, minW: 320 }] },
      { items: [{ widgetId: 'widget-6', basis: 640, grow: 7, minW: 460 }, { widgetId: 'widget-7', basis: 380, grow: 5, minW: 320 }] },
      { items: [{ widgetId: 'widget-8', basis: 640, grow: 7, minW: 460 }, { widgetId: 'widget-9', basis: 380, grow: 5, minW: 320 }] },
    ] },
    views: [
      { viewId: 'v-morning', name: 'Morning check', filters: { compareTo: 'DoD', variant: '1D', model: 'Both', attr: 'Trading', region: 'All', days: '30' } },
      { viewId: 'v-weekly', name: 'Weekly review', filters: { compareTo: 'WoW', variant: '1D', model: 'MC', attr: 'Trading', region: 'All', days: '60' } },
      { viewId: 'v-reg', name: 'Regulatory', filters: { compareTo: 'MoM', variant: '10D', model: 'Hist', attr: 'Basel 3 Regulatory', region: 'All', days: '90' } },
    ],
    tabs: [
      { tabId: 'overview', label: 'Overview', rows: [2, 3, 4, 5] },
      { tabId: 'grid-1', label: L.tab, rows: [2, 3] },
      { tabId: 'fs', label: 'FS Type', rows: [4] },
      { tabId: 'limits', label: 'Limits', rows: [5] },
    ],
    alerts: { datasetId: 'dataset-5', field: 'utilization', labelField: 'limitName', idField: 'limitId', valueField: 'exposure', limitField: 'threshold', changeField: 'change', noun: 'VaR limit', warn: 0.8, breach: 1, target: 'widget-8' },
    hotkeys: { cycle: { c: 'compareTo', m: 'model' }, walk: 'widget-3', export: 'widget-3' },
    // UI visibility — false hides it on screen; the component and its logic stay in the app.
    features: { dailyBrief: false, kpis: false, livePolling: false, tabs: false, filteredByChip: false, whatMovedToggle: true, expand: true },
  };
}

export const NAVIGATION: NavItem[] = [
  { id: 'nav-daily', section: 'Risk management', label: 'Daily Risk', icon: 'layers' },
  { id: 'nav-eq', section: 'Risk management', label: 'Equities', icon: 'trendUp', parent: 'nav-daily' },
  { id: 'nav-var', section: 'Risk management', label: 'VaR Summary', icon: 'dashboard', parent: 'nav-eq', route: '/dashboards/dashboard-1', badge: { text: 'Mock 1', tone: 'mock' } },
  { id: 'nav-var2', section: 'Risk management', label: 'VaR Summary', icon: 'dashboard', parent: 'nav-eq', disabled: true, badge: { text: 'Mock 2', tone: 'mock' } },
  { id: 'nav-fs', section: 'Risk management', label: 'FS Summary', icon: 'pie', parent: 'nav-eq', disabled: true, badge: { text: 'Soon', tone: 'soon' } },
  { id: 'nav-admin', section: 'Administration', label: 'Admin', icon: 'sliders', disabled: true },
];

export const PORTAL = { name: 'Risk Portal', userId: 'USER-001' };
