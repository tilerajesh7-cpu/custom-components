// Seeded mock world for this dashboard. Row names / labels below are DATA (what services would send) — the UI code never depends on them.
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** [name, region, VaR COB, VaR PCOB, SVaR COB, SVaR PCOB, VaR limit] in $MM */
/** Display labels of the primary grid in THIS app (data, not code). Another app sends its own. */
export const PRIMARY_GRID_LABELS = { one: 'Desk', many: 'desks', tab: 'Desks', column: 'Volcker Desk Name' };

/** Display metadata for THIS dashboard (what services send as text). Code never depends on these words. */
export const GRID_META = {
  primary:   { title: 'Standalone VaR/SVaR ($MM)', rowHeader: 'Volcker Desk Name', measures: { var: 'VAR', svar: 'SVAR' } },
  componentByRow: { title: 'Component VaR/SVaR ($MM)', rowHeader: 'Volcker Desk Name', measures: { var: 'CVAR', svar: 'CSVAR' } },
  component: { title: 'Component VaR/SVaR by FS Type ($MM)', rowHeader: 'Fs Type Code', measures: { var: 'CVAR', svar: 'CSVAR' } },
  limits: {
    title: 'VaR/SVaR Limits',
    columns: { tierDescription: 'Tier Description', limitId: 'Limit Id', limitName: 'Limit Name', unit: 'Unit', threshold: 'Threshold', exposure: 'Exposure', utilization: 'Utilization %', change1d: '1D Change' },
  },
  values: { cob: 'COB', pcob: 'PCOB', diff: 'Diff', diffPct: 'Diff %' },
  tooltip: { type: 'VaR Type', variant: 'VaR Variant', attr: 'VaR Attribute', values: 'VaR Exposure | Data', change: 'Chg', ntr: 'NTR' },
  exposure: { title: 'Exposure' },
  charts: { primary: 'Standalone VaR/SVaR Trend ($MM)', componentByRow: 'Component VaR/SVaR Trend ($MM)', component: 'Component VaR/SVaR by FS Type Trend ($MM)' },
};

/** Filter labels and options for THIS dashboard (sent by services in the dashboard definition). */
export const FILTER_META = {
  asOfDate:  { label: 'COB' },
  pcobDate:  { label: 'PCOB' },
  compareTo: { label: 'Compare', options: [['Custom', 'Custom'], ['DoD', 'DoD'], ['WoW', 'WoW'], ['MoM', 'MoM']] as [string, string][] },
  region:    { label: 'Region By Desk', options: [['All', 'ALL'], ['NA', 'NA'], ['EMEA', 'EMEA'], ['APAC', 'APAC'], ['Latam', 'LATAM'], ['Global', 'GLOBAL']] as [string, string][] },
  variant:   { label: 'Variant', options: [['1D', '1DAY'], ['10D', '10DAY']] as [string, string][] },
  attr:      { label: 'Attribute', options: [['Trading', 'Trading'], ['Economic', 'Economic'], ['Volcker', 'Volcker'], ['Basel 3 Regulatory', 'Basel 3 Regulatory'], ['Trading & Credit Portfolio', 'Trading & Credit Portfolio']] as [string, string][] },
  model:     { label: 'Display', options: [['Both', 'Both'], ['MC', 'MC VaR'], ['Hist', 'Hist VaR']] as [string, string][] },
  days:      { label: 'Days in Trend Chart', options: [['30', '30 Days'], ['60', '60 Days'], ['90', '90 Days']] as [string, string][] },
  measure:   { label: 'Measure', options: [['VaR', 'VaR'], ['SVaR', 'SVaR'], ['Both', 'Both']] as [string, string][] },
};

const PRIMARY_ROWS_SEED: [string, string, number, number, number, number, number][] = [
  ['Derivatives Desk A', 'NA', 52.40, 49.10, 68.10, 66.40, 62],
  ['Derivatives Desk B', 'NA', 29.85, 27.60, 41.32, 39.87, 40],
  ['Financing Desk A', 'EMEA', 24.73, 18.53, 29.00, 26.60, 35],
  ['Derivatives Desk C', 'EMEA', 11.40, 5.05, 28.25, 11.20, 10],
  ['Financing Desk B', 'Global', 6.90, 7.92, 9.39, 9.33, 12],
  ['Derivatives Desk D', 'NA', 6.18, 8.03, 6.95, 10.37, 12],
  ['Financing Desk C', 'Global', 6.07, 5.81, 4.31, 4.29, 9],
  ['Derivatives Desk E', 'EMEA', 3.87, 3.96, 3.49, 3.59, 6],
  ['Financing Desk D', 'APAC', 3.41, 11.85, 3.10, 14.11, 15],
  ['Derivatives Desk F', 'APAC', 2.59, 2.62, 3.42, 3.28, 5],
  ['Financing Desk E', 'Latam', 1.02, 1.01, 1.17, 1.00, 3],
  ['Derivatives Desk G', 'Latam', 0.60, 0.62, 0.84, 0.96, 2],
  ['Financing Desk F', 'Global', 0.42, 0.44, 2.19, 2.38, 2],
  ['Derivatives Desk H', 'Global', 0.09, 1.46, 0.17, 2.39, 3],
  ['Financing Desk G', 'Global', 0.03, 0.03, 0.01, 0.01, 1],
  ['Financing Desk H', 'Global', 0.01, 0.01, 0.01, 0.01, 1],
];
export const short = (n: string) => n.replace('Derivatives Desk', 'Deriv').replace('Financing Desk', 'Fin');

export const PRIMARY_ROWS = PRIMARY_ROWS_SEED.map(([name, region, vc, vp, sc, sp, limit], i) => ({
  id: 'R' + String(i + 1).padStart(2, '0'), name, short: short(name), region,
  cob: { var: vc * 1e6, svar: sc * 1e6 }, pcob: { var: vp * 1e6, svar: sp * 1e6 }, limit: limit * 1e6,
}));

export const MODELS = [{ id: 'MC', label: 'MC', long: 'Monte Carlo', factor: 1 }, { id: 'Hist', label: 'Hist', long: 'Historical', factor: 0.91 }];
export const MEASURES = [{ id: 'var', label: 'VaR' }, { id: 'svar', label: 'SVaR' }];

export const FS = ['EQDV', 'EQDL', 'IRVG', 'BCSY', 'ISDL', 'IDIO', 'BCID', 'CMDL', 'DTID', 'ECVG', 'FXVG', 'IRDL', 'CMVG', 'FXRR', 'FXST', 'FXDL'];
export const FS_NAMES: Record<string, string> = {
  EQDV: 'Equity vega', EQDL: 'Equity delta', IRVG: 'Interest-rate vega', BCSY: 'Basis · credit sys', ISDL: 'Inflation delta', IDIO: 'Idiosyncratic',
  BCID: 'Basis · credit idio', CMDL: 'Commodity delta', DTID: 'Default idio', ECVG: 'Equity corr vega', FXVG: 'FX vega', IRDL: 'Interest-rate delta',
  CMVG: 'Commodity vega', FXRR: 'FX risk reversal', FXST: 'FX spot', FXDL: 'FX delta',
};
export const FS_BASE = [0.40, 0.19, 0.08, 0.07, 0.06, 0.05, 0.04, 0.03, 0.025, 0.02, 0.015, 0.012, 0.006, 0.004, 0.002, -0.012];

/** [id, name, owner, primary row index | null (all rows), kind, limit $MM] */
export const LIMITS: [string, string, string, number | null, 'var' | 'svar', number][] = [
  ['LIM-1870', 'Deriv - NAM VaR', 'Business Unit - Americas', 0, 'var', 62],
  ['LIM-1355', 'Fin - EMEA VaR', 'Business Unit - Europe', 3, 'var', 10],
  ['LIM-1875', 'Fin - NAM VaR', 'Business Unit - Americas', 1, 'var', 40],
  ['LIM-9663', 'SVaR - Global', 'Division', null, 'svar', 250],
  ['LIM-1360', 'Deriv - EMEA VaR', 'Business Unit - Europe', 2, 'var', 35],
  ['LIM-2050', 'Cash - APAC VaR', 'Business Unit - Asia', 9, 'var', 5],
  ['LIM-6032', 'Structured - VaR', 'Business Unit - Global', 4, 'var', 27],
  ['LIM-8345', 'Convertibles - Stressed VaR', 'Business Unit - Global', 6, 'svar', 20],
  ['LIM-1873', 'Cash - NAM VaR', 'Business Unit - Americas', 5, 'var', 35],
  ['LIM-2045', 'Deriv - Stressed VaR', 'Business Unit - Asia', 8, 'svar', 18],
  ['LIM-1878', 'Fin - LATAM VaR', 'Business Unit - Americas', 10, 'var', 8],
  ['LIM-1357', 'Cash - SVaR', 'Business Unit - Europe', 7, 'svar', 32],
  ['LIM-1872', 'Fin - LATAM Stress', 'Business Unit - Americas', 10, 'svar', 14],
  ['LIM-1206', 'Cash - NAM Stress', 'Business Unit - Americas', 5, 'svar', 90],
  ['LIM-1877', 'Deriv - LATAM VaR', 'Business Unit - Americas', 11, 'var', 10],
];

export function businessDays(asOf: string, n: number): string[] {
  const out: string[] = [];
  let d = new Date(asOf + 'T00:00:00Z');
  while (out.length < n) {
    const w = d.getUTCDay();
    if (w && w < 6) out.unshift(d.toISOString().slice(0, 10));
    d = new Date(d.getTime() - 864e5);
  }
  return out;
}

/** Seeded walk of n points: ends at `end`, point n-2 equals `prev` (the DoD PCOB). */
export function history(seed: number, end: number, prev: number, n = 250): number[] {
  const r = rng(seed);
  const raw: number[] = [1];
  for (let i = 1; i < n; i++) raw.push(raw[i - 1] * (1 + (r() - 0.5) * 0.05 + 0.012 * Math.sin(i / 9 + seed)));
  const scale = prev / raw[n - 2];
  const out = raw.map((x) => x * scale);
  out[n - 1] = end;
  return out;
}

export const COMPARE_OFFSET: Record<string, number> = { DoD: 1, WoW: 5, MoM: 21 };
export const HORIZON_FACTOR: Record<string, number> = { '1D': 1, '10D': Math.sqrt(10) };
export const ATTR_FACTOR: Record<string, number> = { Trading: 1, Economic: 1.07, Volcker: 0.94, 'Basel 3 Regulatory': 1.12, 'Trading & Credit Portfolio': 1.18 };
