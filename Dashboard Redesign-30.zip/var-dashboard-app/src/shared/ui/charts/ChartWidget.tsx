import { useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import Highcharts, { type Options } from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import type { ChartWidgetConfig, Row } from '@/contracts';
import { formats, isNum } from '../lib/formats';
import { SegmentedControl } from '../controls';
import type { WidgetProps } from '../widgets/registry';
import { encode } from './encode';
import { presets } from './presets';
import './charts.css';

const esc = (s: unknown) => String(s ?? '').replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch] as string));
const mm = (v: number | null | undefined) => (v == null ? '—' : (v < 0 ? '(' + (Math.abs(v) / 1e6).toFixed(2) + ')' : (v / 1e6).toFixed(2)));
const signed = (v: number) => (v > 0 ? '+' : v < 0 ? '−' : '') + (Math.abs(v) / 1e6).toFixed(2);
const dateLabel = (x: unknown) => (typeof x === 'number' ? new Date(x).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' }) : esc(x));
type TipCtx = { x?: unknown; key?: unknown; points?: Highcharts.Point[]; point?: Highcharts.Point; y?: number | null; series?: Highcharts.Series };

/** One dark tooltip for every chart: header (date or category), a row per series in $MM (exact on the right), totals / utilisation where relevant. */
function chartTooltip(preset: string, title: string): Highcharts.TooltipOptions {
  return {
    useHTML: true, outside: true, hideDelay: 80, padding: 0, backgroundColor: 'transparent', borderWidth: 0, shadow: false,
    formatter(this: unknown) {
      const t = this as TipCtx;
      const pts = (t.points && t.points.length ? t.points : t.point ? [t.point] : []).filter((p) => p && p.y != null);
      if (!pts.length) return false;
      const head = preset === 'bar.diverging' || preset === 'column' ? esc(pts[0].category ?? t.key) : dateLabel(pts[0].x ?? t.x);
      const row = (p: Highcharts.Point, extra = '') =>
        `<div class="ht-row"><svg class="ht-sw" viewBox="0 0 8 8" aria-hidden="true"><rect width="8" height="8" rx="2.5" fill="${esc(p.color)}"></rect></svg><span class="ht-name">${esc(p.series.name)}</span><b class="ht-val${extra}">${preset === 'bar.diverging' ? signed(p.y as number) : mm(p.y)}</b></div>`;
      let body = pts.map((p) => row(p, preset === 'bar.diverging' ? ((p.y as number) > 0 ? ' is-up' : ' is-down') : '')).join('');
      if (preset === 'column.stacked' && pts.length > 1) body += `<div class="ht-row ht-total"><span class="ht-name">Total</span><b class="ht-val">${mm(pts.reduce((a, p) => a + (p.y as number), 0))}</b></div>`;
      if (preset === 'column.reference') {
        const val = pts.find((p) => p.series.type === 'column'), lim = pts.find((p) => /limit/i.test(p.series.name) && !/80/.test(p.series.name));
        if (val && lim && lim.y) { const u = (val.y as number) / (lim.y as number); body += `<div class="ht-row ht-total"><span class="ht-name">Utilization</span><b class="ht-val ${u >= 1 ? 'is-up' : u >= 0.8 ? 'is-warn' : ''}">${(u * 100).toFixed(1)}%</b></div>`; }
      }
      const exact = pts.length === 1 ? `<div class="ht-foot">Exact ${esc(formats.full(pts[0].y))}</div>` : '<div class="ht-foot">$MM · negatives in ( )</div>';
      return `<div class="ht"><div class="ht-kicker">${esc(title)}</div><div class="ht-head">${head}</div><div class="ht-body">${body}</div>${exact}</div>`;
    },
  };
}

type AnyChart = Highcharts.Chart & { exportChartLocal?: (o: object) => void; downloadCSV?: () => void };

/** Generic chart widget: preset + encoding over any dataset's rows. Updates in place (no re-create). */
export function ChartWidget({ config, dataset, selection, clientFilters, onEvent, actionRef, density }: WidgetProps<ChartWidgetConfig>) {
  const ref = useRef<HighchartsReact.RefObject>(null);
  const ranges = config.options?.ranges;
  const [range, setRange] = useState<number | undefined>(ranges?.[ranges.length - 1]);
  const listens = config.interactions?.listens ?? [];
  const seriesSel = listens.find((l) => l.field === '$series');
  const highlight = seriesSel ? selection[seriesSel.from] : undefined;

  const rows = useMemo<Row[]>(() => {
    if (!dataset) return [];
    return dataset.rowData.filter((r) =>
      Object.entries(clientFilters).every(([f, v]) => !v || v === 'all' || !(f in r) || String(r[f]) === v) &&
      listens.every((l) => { if (l.field.startsWith('$')) return true; const k = selection[l.from]; return !k?.length || k.includes(String(r[l.field])); }));
  }, [dataset, clientFilters, selection, listens]);

  const pointEmit = config.interactions?.emits?.find((e) => e.on === 'pointClick');
  // Category charts highlight the key selected in the widget they drive (e.g. What moved ↔ primary grid).
  const focusKeys = pointEmit ? selection[pointEmit.target ?? config.widgetId] : undefined;
  const legendEmit = config.interactions?.emits?.find((e) => e.on === 'legendClick');

  const options = useMemo<Options>(() => {
    if (!dataset) return {};
    const base = presets[config.preset] ?? {};
    const { series, xAxis } = encode(dataset, config.encoding, rows, { range: dataset.kind === 'series' ? range : undefined, highlight, focus: focusKeys });
    const height = (config.options?.height ?? 320) + (density === 'spacious' ? 20 : density === 'comfortable' ? 10 : 0);
    return {
      ...base,
      xAxis: { ...(base.xAxis as object), ...(xAxis ?? {}) } as Highcharts.XAxisOptions,
      tooltip: { ...base.tooltip, ...chartTooltip(config.preset, config.title) },
      chart: { ...base.chart, height },
      exporting: { enabled: false, fallbackToExportServer: false, filename: config.widgetId, sourceWidth: 1200 },
      plotOptions: {
        ...base.plotOptions,
        series: {
          ...(base.plotOptions?.series ?? {}),
          cursor: pointEmit || legendEmit ? 'pointer' : undefined,
          point: pointEmit ? { events: { click(this: Highcharts.Point) {
            const key = (this.options as { custom?: { key?: string } }).custom?.key;
            const target = pointEmit.target ?? config.widgetId;
            if (key) onEvent({ kind: 'selection', widgetId: target, keys: selection[target]?.includes(key) ? [] : [key] });
          } } } : undefined,
          events: legendEmit ? { legendItemClick(this: Highcharts.Series, e: { preventDefault?: () => void }) {
            e?.preventDefault?.();
            const target = legendEmit.target ?? config.widgetId;
            const name = this.name;
            onEvent({ kind: 'selection', widgetId: target, keys: selection[target]?.includes(name) ? [] : [name] });
            return false;
          } } : undefined,
        },
      },
      series,
    } as Options;
  }, [dataset, rows, range, highlight, focusKeys, config, onEvent, selection, pointEmit, legendEmit, density]);

  const chart = () => ref.current?.chart as AnyChart | undefined;
  actionRef.current = {
    'export.png': () => chart()?.exportChartLocal?.({ type: 'image/png', filename: config.widgetId }),
    'export.svg': () => chart()?.exportChartLocal?.({ type: 'image/svg+xml', filename: config.widgetId }),
    'export.csv': () => chart()?.downloadCSV?.(),
  };

  const stats = useMemo(() => {
    if (!config.options?.stats || !dataset || dataset.kind !== 'series') return null;
    const y = Array.isArray(config.encoding.y) ? config.encoding.y[0] : dataset.seriesDefs[0]?.field;
    const refField = config.encoding.reference?.[0]?.field;
    const vals = rows.map((r) => r[y ?? '']).filter(isNum);
    if (!vals.length) return null;
    const last = rows[rows.length - 1];
    const over = refField ? rows.filter((r) => isNum(r[y ?? '']) && isNum(r[refField]) && (r[y ?? ''] as number) > (r[refField] as number)).length : 0;
    const ratio = refField && isNum(last[refField]) ? (last[y ?? ''] as number) / (last[refField] as number) : undefined;
    return { current: vals[vals.length - 1], peak: Math.max(...vals), over, ratio, name: dataset.seriesDefs[0]?.name };
  }, [config, dataset, rows]);

  const [slot, setSlot] = useState<HTMLElement | null>(null);
  useLayoutEffect(() => { setSlot(document.getElementById('w-' + config.widgetId + '-tools')); }, [config.widgetId]);
  const rangeCtl = ranges && ranges.length > 1 ? (
    <div className="cw-range">
      <SegmentedControl tone="light" size="sm" value={String(range)} onChange={(v) => setRange(Number(v))} options={ranges.map((r) => ({ value: String(r), label: `${r}D` }))} />
    </div>
  ) : null;
  return (
    <div className="cw">
      {rangeCtl && (slot ? createPortal(rangeCtl, slot) : <div className="cw-bar">{rangeCtl}</div>)}
      {stats && <div className="cw-bar"><span className="cw-name">{stats.name}</span></div>}
      {stats && (
        <div className="cw-stats">
          <div className="cw-stat"><span>Current</span><b title={formats.full(stats.current)}>{formats.millions(stats.current)}</b>{stats.ratio !== undefined && <em className={stats.ratio >= 1 ? 'tone-negative' : stats.ratio >= 0.8 ? 'tone-warn-fg' : ''}>{formats.percent0(stats.ratio)} of threshold</em>}</div>
          <div className="cw-stat"><span>Peak (90D)</span><b title={formats.full(stats.peak)}>{formats.millions(stats.peak)}</b></div>
          <div className="cw-stat"><span>Days over</span><b className={stats.over ? 'tone-negative' : ''}>{stats.over}</b></div>
        </div>
      )}
      <HighchartsReact ref={ref} highcharts={Highcharts} options={options} updateArgs={[true, true, true]} containerProps={{ className: 'cw-chart' }} />
    </div>
  );
}
