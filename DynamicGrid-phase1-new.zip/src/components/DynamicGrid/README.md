# DynamicGrid — Phase 1

Backend-driven, reusable AG Grid wrapper. The service payload decides columns,
values, visual treatment, tooltips and clickability. The app supplies only the
payload, native AG Grid options, and callbacks.

## Install

```bash
npm i ag-grid-react ag-grid-community
# Enterprise (Phase 2: SSRM, pivot, master-detail)
# npm i ag-grid-enterprise
```

```tsx
import { DynamicGrid } from '@/components/DynamicGrid';

<DynamicGrid
  gridData={payload}                 // GridConfig or the raw cells[] shape
  gridOptions={{ rowHeight: 36 }}    // native AG Grid passthrough
  onCellClicked={handleCellClicked}
  onRowSelected={handleRowSelected}
/>
```

## Structure

```
DynamicGrid/
├── DynamicGrid.tsx              main wrapper
├── types/                       GridConfig, ColumnDef, CellOverride, display schema
├── adapters/rawGridAdapter.ts   ONLY file that knows the cells[] wire format
├── mappers/
│   ├── columnMapper.ts          ColumnDef -> ColDef (precedence lives here)
│   ├── cellOverrideMapper.ts    rowId::field lookup map
│   ├── gridOptionsMapper.ts     metadata -> gridOptions
│   └── display/
│       ├── displayRegistry.ts   type -> handler  (the extension point)
│       └── handlers/            plain, numeric, status, heatmap, utilization, icon
├── hooks/                       normalisation, overrides, config, api, events
├── components/                  IconRegistry, DynamicCellRenderer, CustomTooltip
├── registry/componentRegistry   AG Grid component map
├── styles/dynamicGrid.css       CSS variables + cell classes
├── __mocks__/                   flat mock + raw cells[] mock
└── examples/PortfolioDashboard  parent integration
```

## How a cell gets its look

```
cellOverride.style  ->  cellOverride.display  ->  column.display  ->  default
```

Resolved identically in `cellStyle`, `valueFormatter` and `cellClass`, all inside
`columnMapper.ts`. Handlers are built once per column; per-cell work is a `Map.get`
plus a comparison or a colour lerp.

## Adding a new visual type

1. Add the type to `CellDisplayType` and its config interface in `types/display.types.ts`.
2. Create `mappers/display/handlers/<name>Handler.ts` implementing `DisplayHandler`.
3. Register it in `displayRegistry.ts`.

No other file changes — not `columnMapper`, not `DynamicGrid`.

## Performance notes

- Renderers are attached only where DOM is unavoidable: icons, utilization bars,
  opt-in status pills, and columns that have a per-cell icon override. Everything
  else (numeric, heatmap, renderer-free status, plain) stays on native
  `valueFormatter` + `cellStyle` with no React node per cell.
- Heatmap `min`/`max` always come from the column config. Row data is never scanned,
  so cost is O(1) per cell and the behaviour is already correct under SSRM.
- Overrides are sparse and response-scoped. The map is rebuilt per payload, never
  merged, so stale flags are impossible and Phase 2 can feed per-block overrides in
  unchanged.
- Normalisation and mapping are memoised on `metadata.version`. Only the normalised
  payload is held in state — the raw payload is not retained.
- `getRowId` gives rows stable identity, which is the prerequisite for
  `applyTransaction` updates on live ticks.

## Phase 2 hooks already in place

- `gridOptionsMapper` reads `rowModelType: 'serverSide'`, warns, and falls back to
  clientSide. One `TODO(phase-2)` marks the switch.
- `ColumnDef.phase2` flags are parsed and forced off in `columnMapper`.
- `componentRegistry` reserves a slot for the master-detail renderer.
- `useGridApi` holds the api ref — the attachment point for an SSRM datasource.

## Phase 3 hooks already in place

- All colours resolve through CSS variables scoped to `.dg-root`, so a dashboard
  theme can restyle every grid without touching handler code.
- `useGridApi` is structured to be keyed by `widgetId` when grids become widgets.
- `destroy()` runs on unmount, which matters once widgets mount and unmount as
  users drag them around a dashboard.
