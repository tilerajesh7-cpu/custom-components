import React from 'react';

/**
 * Inline outline icon set, drawn to match the current Tabler/Lucide/Phosphor
 * visual language: 1.75px stroke, rounded caps/joins, 16px grid, no fills except
 * where a solid mark reads better at small size (star).
 *
 * Authored inline rather than pulled from a package so the grid has zero icon-
 * library dependency and every icon shares one exact stroke weight — mixing
 * icon sets at different default weights is the most common way a grid ends up
 * looking inconsistent.
 */
export type IconKey =
  | 'icon-check-circle'
  | 'icon-alert-triangle'
  | 'icon-clock'
  | 'icon-star'
  | 'icon-arrow-up'
  | 'icon-arrow-down'
  | 'icon-minus'
  | 'icon-trend-up'
  | 'icon-trend-down'
  | 'icon-flag'
  | 'icon-shield-check'
  | 'icon-chart-up';

const base = {
  width: 15,
  height: 15,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.75,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
  'aria-hidden': true,
  focusable: false,
};

export const ICON_REGISTRY: Record<string, React.ReactElement> = {
  'icon-check-circle': (
    <svg {...base}>
      <path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z" />
      <path d="m8.5 12.5 2.3 2.3L15.5 10" />
    </svg>
  ),
  'icon-alert-triangle': (
    <svg {...base}>
      <path d="M12 3.5 2.5 20h19L12 3.5Z" />
      <path d="M12 10v4" />
      <path d="M12 17.2v.1" />
    </svg>
  ),
  'icon-clock': (
    <svg {...base}>
      <path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z" />
      <path d="M12 7.5V12l3 2" />
    </svg>
  ),
  'icon-star': (
    <svg {...base} fill="currentColor" stroke="none">
      <path d="M12 2.5 15 9l7 .9-5.1 4.8 1.3 6.9L12 18.1 5.8 21.6l1.3-6.9L2 9.9 9 9l3-6.5Z" />
    </svg>
  ),
  'icon-arrow-up': (
    <svg {...base}>
      <path d="M12 19V5" />
      <path d="m6 11 6-6 6 6" />
    </svg>
  ),
  'icon-arrow-down': (
    <svg {...base}>
      <path d="M12 5v14" />
      <path d="m18 13-6 6-6-6" />
    </svg>
  ),
  'icon-minus': (
    <svg {...base}>
      <path d="M5 12h14" />
    </svg>
  ),
  /* Jagged trend arrow — the zigzag-into-arrowhead shape from typical fintech
     dashboards, distinct from a plain diagonal arrow. */
  'icon-trend-up': (
    <svg {...base}>
      <polyline points="3 17 9 11 13 15 21 6" />
      <polyline points="14 6 21 6 21 13" />
    </svg>
  ),
  'icon-trend-down': (
    <svg {...base}>
      <polyline points="3 7 9 13 13 9 21 18" />
      <polyline points="21 11 21 18 14 18" />
    </svg>
  ),
  'icon-flag': (
    <svg {...base}>
      <path d="M5 21V4" />
      <path d="M5 4h13l-3 4 3 4H5" />
    </svg>
  ),
  'icon-shield-check': (
    <svg {...base}>
      <path d="M12 3.5 5 6.5v5c0 4.6 3 7.8 7 9 4-1.2 7-4.4 7-9v-5L12 3.5Z" />
      <path d="m9 12 2 2 4-4.2" />
    </svg>
  ),
  'icon-chart-up': (
    <svg {...base}>
      <path d="M4 18 9 11.5l3.5 3L20 6" />
      <path d="M4 21h16" />
    </svg>
  ),
};

export function getIcon(key?: string): React.ReactElement | null {
  if (!key) return null;
  return ICON_REGISTRY[key] ?? null;
}
