import React, { memo } from 'react';
import type { ITooltipParams } from 'ag-grid-community';
import type { RowRecord } from '../../types/gridConfig.types';

/** Nested payloads may arrive as an object or a JSON string. Parse defensively. */
function toRecord(value: unknown): Record<string, unknown> | null {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  if (typeof value === 'string') {
    try {
      const parsed: unknown = JSON.parse(value);
      return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null;
    } catch {
      return null;
    }
  }
  return null;
}

const LABELS: Record<string, string> = {
  var95: 'VaR (95%)',
  beta: 'Beta',
  sector: 'Sector',
};

/**
 * Used only where a column declares `tooltip.type === 'complex'`.
 * Simple text tooltips stay on AG Grid's native tooltipValueGetter.
 */
function CustomTooltipBase(params: ITooltipParams<RowRecord>) {
  const record = toRecord(params.value);

  if (!record) {
    return <div className="dg-tooltip">{String(params.value ?? '')}</div>;
  }

  return (
    <div className="dg-tooltip">
      {Object.entries(record).map(([key, val]) => (
        <div className="dg-tooltip__row" key={key}>
          <span className="dg-tooltip__key">{LABELS[key] ?? key}</span>
          <span className="dg-tooltip__value">{String(val)}</span>
        </div>
      ))}
    </div>
  );
}

export const CustomTooltip = memo(CustomTooltipBase);
