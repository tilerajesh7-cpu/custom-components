import type { HeatmapConfig } from '../../../types/display.types';
import { clamp, lerpColor, resolveColor } from '../../../utils/colorUtils';
import type { DisplayHandler } from '../types';

/**
 * Continuous colour scale. min/max ALWAYS come from the backend column config —
 * row data is never scanned, so this is O(1) per cell and correct under SSRM.
 */
export const heatmapHandler: DisplayHandler = {
  type: 'heatmap',

  getCellStyle(value, ctx) {
    const cfg = ctx.display.config as HeatmapConfig | undefined;
    if (!cfg) return undefined;
    if (typeof value !== 'number' || !Number.isFinite(value)) return undefined;

    const mid = cfg.mid ?? (cfg.min < 0 && cfg.max > 0 ? 0 : (cfg.min + cfg.max) / 2);
    const shouldClamp = cfg.clamp !== false;
    const v = shouldClamp ? clamp(value, cfg.min, cfg.max) : value;

    let color: string;
    if (v >= mid) {
      const span = cfg.max - mid;
      const t = span === 0 ? 1 : (v - mid) / span;
      color = lerpColor(cfg.midColor, cfg.highColor, t);
    } else {
      const span = mid - cfg.min;
      const t = span === 0 ? 1 : (mid - v) / span;
      color = lerpColor(cfg.midColor, cfg.lowColor, t);
    }

    return cfg.applyTo === 'text'
      ? { color }
      : { backgroundColor: color, color: resolveColor('neutral') as string };
  },

  getDisplayText: (value, ctx) => ctx.format(value),
};
