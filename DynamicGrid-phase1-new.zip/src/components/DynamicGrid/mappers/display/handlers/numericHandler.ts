import type { NumericConfig } from '../../../types/display.types';
import { resolveColor, resolveSoftBg } from '../../../utils/colorUtils';
import type { DisplayHandler } from '../types';

const asNumber = (v: unknown): number | null =>
  typeof v === 'number' && Number.isFinite(v) ? v : null;

const ARROW_UP = '↗';
const ARROW_DOWN = '↘';

/**
 * Sign-aware numbers: colour by sign, optional trend indicator, optional
 * accounting parentheses, and an OPT-IN pill background reserved for values
 * that cross `pillWhenAbs`. Below that threshold the cell stays plain coloured
 * text — a grid where every cell is tinted reads as noise; a grid where only
 * the outliers are tinted reads as signal.
 *
 * `trendIndicator: 'text'` stays on the pure cellStyle/formatter path (no
 * renderer). `trendIndicator: 'icon'` opts into a renderer only for that
 * column, since the jagged trend-arrow SVG is real markup, not a character.
 */
export const numericHandler: DisplayHandler = {
  type: 'numeric',

  getCellStyle(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const n = asNumber(value);
    if (n === null) return undefined;

    const usesColor = cfg.negativeStyle !== 'parentheses';
    const sign = n > 0 ? 'positiveColor' : n < 0 ? 'negativeColor' : 'zeroColor';
    const color = usesColor ? resolveColor(cfg[sign]) : undefined;

    const bold =
      (cfg.bold === 'positive' && n > 0) || (cfg.bold === 'negative' && n < 0)
        ? '600'
        : undefined;

    const style: Record<string, string> = {};

    const isPill = cfg.pillWhenAbs !== undefined && Math.abs(n) >= cfg.pillWhenAbs;
    if (isPill) {
      const bgToken = n > 0 ? cfg.positiveColor : n < 0 ? cfg.negativeColor : cfg.zeroColor;
      const bg = resolveSoftBg(bgToken);
      if (bg) style.backgroundColor = bg;
    }

    if (color) style.color = color;
    if (bold) style.fontWeight = bold;
    return Object.keys(style).length ? style : undefined;
  },

  getCellClass(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const n = asNumber(value);
    if (n === null || cfg.pillWhenAbs === undefined) return undefined;
    return Math.abs(n) >= cfg.pillWhenAbs ? 'dg-numeric-pill' : undefined;
  },

  getDisplayText(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const n = asNumber(value);
    if (n === null) return ctx.format(value);

    const showParens = cfg.negativeStyle === 'parentheses' || cfg.negativeStyle === 'both';
    // The icon variant draws its own indicator in the renderer — no text glyph here.
    const arrow =
      cfg.trendIndicator === 'text' ? (n > 0 ? `${ARROW_UP} ` : n < 0 ? `${ARROW_DOWN} ` : '') : '';

    if (n < 0 && showParens) return `${arrow}(${ctx.format(Math.abs(n))})`;
    if (n > 0 && cfg.showSign) return `${arrow}+${ctx.format(n)}`;
    return `${arrow}${ctx.format(n)}`;
  },

  needsRenderer(ctx) {
    return (ctx.display.config as NumericConfig | undefined)?.trendIndicator === 'icon';
  },
};
