import type { GridOptions } from 'ag-grid-community';
import type { GridMetadata } from '../types/gridConfig.types';

/**
 * Grid-level options derived from backend metadata.
 * Phase 2 switches are read but deliberately forced off here — one place to flip.
 */
export function mapGridOptions(metadata: GridMetadata): GridOptions {
  const serverSideRequested = metadata.rowModelType === 'serverSide';

  if (serverSideRequested && process.env.NODE_ENV !== 'production') {
    // eslint-disable-next-line no-console
    console.warn(
      '[DynamicGrid] serverSide row model requested but not implemented until Phase 2. Falling back to clientSide.',
    );
  }

  return {
    // TODO(phase-2): rowModelType: serverSideRequested ? 'serverSide' : 'clientSide'
    rowModelType: 'clientSide',

    pagination: metadata.pagination.enabled,
    paginationPageSize: metadata.pagination.pageSize,
    // TODO(phase-2): server-side pagination uses cacheBlockSize + a datasource.

    animateRows: false, // off by default: costs frames on large financial grids
    suppressCellFocus: false,
    tooltipShowDelay: 300,
    rowBuffer: 10,

    // Phase 2 — pivot / row grouping.
    pivotMode: false,
    // TODO(phase-2): enable when metadata.features.pivotEnabled is honoured.

    // Phase 2 — master/detail.
    masterDetail: false,
    // TODO(phase-2): wire detailCellRenderer from componentRegistry.
  };
}
