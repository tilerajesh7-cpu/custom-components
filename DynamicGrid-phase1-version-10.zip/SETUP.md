# DynamicGrid — drop-in setup

## 1. Copy

Copy `src/components/DynamicGrid/` into your app's `src/components/`.
`src/services/portfolioService.ts` and `src/pages/PortfolioPage.tsx` are reference
files — adapt them, don't copy them over anything you already have.

## 2. Install

```bash
npm i ag-grid-react ag-grid-community
# Phase 2 only: npm i ag-grid-enterprise
```

## 3. App root — once, not per grid

**Do NOT import ag-grid.css or ag-theme-quartz.css.** On AG Grid 33+ (you are on
36.1.0) those are the legacy CSS-theming path. This component uses the JS
Theming API (`theme/dynamicGridTheme.ts`); importing the CSS files alongside it
causes the two systems to fight, which is what makes header background and
border overrides silently not apply.

```tsx
// src/main.tsx
// (no AG Grid CSS imports — the theme object handles it)

// Enterprise licence, if used — once at startup, never per widget:
// import { LicenseManager } from 'ag-grid-enterprise';
// LicenseManager.setLicenseKey(import.meta.env.VITE_AG_GRID_LICENSE);
```

Wrap the app once if you want the global density toggle:

```tsx
import { DensityProvider } from '@/components/DynamicGrid';

<DensityProvider initialDensity="comfortable">
  <App />
</DensityProvider>
```

## 4. Path alias

Files import via `@/components/DynamicGrid`. Add the alias:

```jsonc
// tsconfig.json
{ "compilerOptions": { "baseUrl": "src", "paths": { "@/*": ["*"] } } }
```

```ts
// vite.config.ts
resolve: { alias: { '@': path.resolve(__dirname, 'src') } }
```

If you don't use aliases, relative imports work — only the two reference files
(`services/`, `pages/`) use `@/`; the component's internals are all relative.

## 5. Use it

```tsx
import { DynamicGrid } from '@/components/DynamicGrid';

<DynamicGrid
  gridData={payload}
  gridOptions={{ rowHeight: 52 }}
  onCellClicked={handleCellClicked}
/>
```

`gridData` accepts either the flat `GridConfig` shape or the legacy positional
`cells[]` wire format — the adapter inside the component normalises both.

Columns may be flat or nested under a group header:

```ts
columns: [
  { field: 'symbol', headerName: 'Symbol', type: 'text' },
  {
    headerName: 'P&L',
    groupId: 'pnl-group',
    children: [
      { field: 'pnl', headerName: 'Amount', type: 'number', display: { ... } },
      { field: 'pnlPercent', headerName: '%', type: 'number', display: { ... } },
    ],
  },
]
```

## 6. Keep the boundary

Add this so nothing reaches past the barrel:

```jsonc
// .eslintrc
"no-restricted-imports": ["error", {
  "patterns": ["**/DynamicGrid/*", "!**/DynamicGrid/index"]
}]
```

## 7. Exclude dev-only files from the production build

```jsonc
// tsconfig.build.json
{ "exclude": ["src/**/__mocks__/**", "src/**/examples/**"] }
```

`largeDataset.mock.ts` generates 5k rows — there is no reason for it in a prod bundle.
