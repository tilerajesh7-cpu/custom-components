import React, { useCallback, useEffect, useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { GetRowIdParams, GridOptions } from 'ag-grid-community';

import { validateGridConfig } from './adapters/validateGridConfig';
import { GridErrorBoundary } from './components/errors/GridErrorBoundary';
import { GridEmptyState, GridErrorState } from './components/errors/GridStates';
import { GridSkeleton, useMinimumVisible } from './components/feedback/Skeletons';
import { SoftSpinner } from './components/feedback/SoftSpinner';
import { useDensity, type Density } from './context/DensityContext';
import { useCellOverrides } from './hooks/useCellOverrides';
import { useGridApi } from './hooks/useGridApi';
import { useGridConfig } from './hooks/useGridConfig';
import { useDrillDown } from './hooks/useDrillDown';
import { useGridEvents } from './hooks/useGridEvents';
import { useNormalizedGridData } from './hooks/useNormalizedGridData';
import { gridComponents } from './registry/componentRegistry';
import { buildDynamicGridTheme } from './theme/dynamicGridTheme';
import type {
  CellClickPayload,
  GridConfig,
  RowRecord,
  RowSelectPayload,
} from './types/gridConfig.types';
import type { DrillDownPayload } from './types/drilldown.types';
import type { GridErrorPayload } from './types/errors.types';
import type { RawGridData } from './types/rawGridData.types';
import { flattenColumns } from './utils/columnTree';

import './styles/dynamicGrid.css';

export interface DynamicGridProps {
  /** Service payload — either the raw `cells[]` shape or the normalised one. */
  gridData: GridConfig | RawGridData;
  /** Native AG Grid passthrough. Anything AG Grid already exposes belongs here. */
  gridOptions?: Partial<GridOptions<RowRecord>>;
  onCellClicked?: (payload: CellClickPayload) => void;
  onRowSelected?: (payload: RowSelectPayload) => void;
  loading?: boolean;
  className?: string;
  /** Overrides the app-wide DensityProvider for this one grid instance only. */
  density?: Density;
  /** Fired on validation failure and render crashes. Wire to Sentry/Datadog. */
  onGridError?: (error: GridErrorPayload) => void;
  /** Called by the Retry button in the error state. */
  onRetry?: () => void;
  /** Message shown when the payload is valid but has zero rows. */
  emptyMessage?: string;
  /**
   * Fired when a clickable cell is activated. The component handles selection
   * visuals, abort and request sequencing; the app decides what to load.
   */
  onDrillDown?: (payload: DrillDownPayload) => void;
  /** Controlled selection. Omit to let the grid own it. */
  selectedRowId?: string;
  /** Row field used to label the active-context chip (e.g. 'symbol'). */
  selectionLabelField?: string;
  /**
   * Notified whenever selection changes, so the parent can render the
   * ActiveContextChip above its detail panels and clear it from there.
   */
  onSelectionChange?: (selection: { rowId: string; label: string } | null) => void;
  /**
   * Dim non-selected rows instead of only elevating the active one.
   * Off by default: dimming removes peer comparison exactly when the user
   * needs it, and makes still-clickable rows look disabled.
   */
  dimUnselected?: boolean;
  /** Borderless banding instead of row hairlines. */
  borderless?: boolean;
  /** Fixed height today; Phase 3 makes this fill the dashboard widget frame. */
  height?: number | string;
}

function DynamicGridBase({
  gridData,
  gridOptions,
  onCellClicked,
  onRowSelected,
  loading = false,
  className,
  height = 520,
  density,
  onGridError,
  onRetry,
  emptyMessage,
  onDrillDown,
  selectedRowId,
  selectionLabelField,
  dimUnselected = false,
  borderless = true,
  onSelectionChange,
}: DynamicGridProps) {
  const { density: globalDensity } = useDensity();
  const resolvedDensity = density ?? globalDensity;

  // Built once per density value (there are only two) — never rebuilt per
  // render, since AG Grid treats a new theme object as a full re-theme.
  const config = useNormalizedGridData(gridData);

  // Theme is rebuilt only when density or the backend's layout block changes —
  // AG Grid treats a new theme object as a full re-theme, so this must not be
  // recreated per render.
  const layout = config.metadata?.layout;
  const theme = useMemo(
    () => buildDynamicGridTheme(resolvedDensity, layout),
    [resolvedDensity, layout],
  );

  // Trust boundary. Runs once per payload (memoised on the normalised config),
  // not per render. Structural errors stop the render entirely rather than
  // letting malformed data reach a handler and mis-paint a number.
  const validation = useMemo(() => validateGridConfig(config), [config]);

  useEffect(() => {
    if (!validation.ok) {
      onGridError?.({
        type: 'validation',
        message: `Grid config rejected: ${validation.errors.length} error(s)`,
        context: { errors: validation.errors },
      });
    }
    if (validation.warnings.length && process.env.NODE_ENV !== 'production') {
      // eslint-disable-next-line no-console
      console.warn('[DynamicGrid] config warnings', validation.warnings);
    }
  }, [validation, onGridError]);

  const overrideState = useCellOverrides(config.cellOverrides);
  const { columnDefs, defaultColDef, baseGridOptions } = useGridConfig(config, overrideState);
  const { apiRef, onGridReady, destroy } = useGridApi();

  // useGridEvents resolves clickability/actionType by field, so it only ever
  // needs the flat leaf columns — group nodes carry no click behaviour of
  // their own and would just be dead weight in that lookup.
  const leafColumns = useMemo(() => flattenColumns(config.columns), [config.columns]);

  const drill = useDrillDown({ onDrillDown, labelField: selectionLabelField, selectedRowId });

  const { handleCellClicked, handleSelectionChanged } = useGridEvents({
    columns: leafColumns,
    overrides: overrideState.overrides,
    // Every qualifying click both notifies the app AND drives selection +
    // the drill-down lifecycle. Selection is applied synchronously here, so it
    // never waits on whatever the app decides to fetch.
    onCellClicked: (payload) => {
      drill.trigger(payload);
      onCellClicked?.(payload);
    },
    onRowSelected,
  });

  // Stable row identity: lets AG Grid reuse rows across refreshes instead of
  // rebuilding them, and is the prerequisite for transactional updates later.
  const getRowId = useCallback((params: GetRowIdParams<RowRecord>) => params.data.id, []);

  const activeRowId = drill.selection?.rowId;

  /*
   * rowClassRules, not getRowClass.
   *
   * getRowClass is evaluated when a row is CREATED and not re-run when the
   * component re-renders, so the previously selected row kept its class and
   * two rows appeared active at once. rowClassRules is re-evaluated by AG Grid
   * whenever the row refreshes, which is what makes selection actually move.
   */
  const rowClassRules = useMemo(
    () => ({
      'dg-row-active': (params: { data?: RowRecord }) =>
        Boolean(params.data && activeRowId && params.data.id === activeRowId),
    }),
    [activeRowId],
  );

  // Per-cell icon overrides are resolved by the renderer through this lookup.
  const getOverrideIcon = useCallback(
    (rowId: string, field: string) => overrideState.overrides.get(`${rowId}::${field}`)?.icon,
    [overrideState.overrides],
  );

  const context = useMemo(() => ({ getOverrideIcon }), [getOverrideIcon]);

  // App-supplied options win over anything derived from metadata.
  const mergedOptions = useMemo<GridOptions<RowRecord>>(
    () => ({ ...baseGridOptions, ...gridOptions }),
    [baseGridOptions, gridOptions],
  );

  useEffect(() => {
    onSelectionChange?.(drill.selection ?? null);
  }, [drill.selection, onSelectionChange]);

  // rowClassRules only re-runs when rows refresh; selection changes nothing in
  // the row DATA, so nothing would trigger that on its own.
  useEffect(() => {
    apiRef.current?.refreshCells({ force: true });
    apiRef.current?.redrawRows();
  }, [activeRowId, apiRef]);

  useEffect(() => destroy, [destroy]);

  /*
   * MUST live above the early return below. It was previously declared after
   * it, which makes it a conditional hook — React then calls a different
   * number of hooks depending on whether validation passed, and the state it
   * owns never settles. That is why the skeleton never appeared.
   *
   * Rendered by US rather than through AG Grid's loadingOverlayComponent: that
   * API changed in v36 and silently no-ops in some configurations.
   */
  const showSkeleton = useMinimumVisible(loading, 400);

  /*
   * Loading is a BRANCH, not an overlay.
   *
   * Two earlier attempts failed: AG Grid's loadingOverlayComponent no-ops in
   * v36, and an absolutely-positioned cover competes with the grid's own
   * chrome. Returning before AgGridReact mounts removes the contest entirely —
   * there is nothing to paint over.
   *
   * Skeleton when the shape is known (a grid is coming); spinner only for an
   * indeterminate wait with no structure to preview.
   */
  if (showSkeleton) {
    return (
      <div
        className={`dg-root ${className ?? ''}`.trim()}
        style={{ height, width: '100%' }}
        data-density={resolvedDensity}
      >
        {config.columns.length ? (
          <GridSkeleton rows={8} columns={Math.min(leafColumns.length || 5, 6)} />
        ) : (
          <div className="dg-state">
            <SoftSpinner label="Loading" />
          </div>
        )}
      </div>
    );
  }

  if (!validation.ok) {
    return (
      <div className={`dg-root ${className ?? ''}`.trim()} style={{ height, width: '100%' }}>
        <GridErrorState
          details={validation.errors.map((e) => `${e.path}: ${e.message}`)}
          onRetry={onRetry}
        />
      </div>
    );
  }

  const isEmpty = !loading && config.rows.length === 0;

  return (
    <div
      className={[
        'dg-root',
        borderless ? 'dg-borderless' : '',
        dimUnselected && activeRowId ? 'dg-dim-unselected' : '',
        className ?? '',
      ]
        .filter(Boolean)
        .join(' ')}
      style={{ height, width: '100%' }}
      data-grid-id={config.metadata.gridId}
      data-density={resolvedDensity}
    >
      <AgGridReact<RowRecord>
        {...mergedOptions}
        theme={theme}
        rowData={config.rows}
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        components={gridComponents}
        context={context}
        getRowId={getRowId}
        rowClassRules={rowClassRules}
        onGridReady={onGridReady}
        onCellClicked={handleCellClicked}
        onSelectionChanged={handleSelectionChanged}
        tooltipInteraction
        suppressColumnVirtualisation={false}
        ref={undefined}
      />
      {isEmpty ? <GridEmptyState message={emptyMessage} /> : null}
      {/* apiRef is available to future phases (state persistence, SSRM datasource). */}
      <span hidden aria-hidden data-has-api={apiRef.current ? 'true' : 'false'} />
    </div>
  );
}

/**
 * memo() matters here: dashboards re-render parents often, and remapping columns
 * for an unchanged payload is the most expensive avoidable work in this component.
 */
const MemoisedGrid = React.memo(DynamicGridBase);

/**
 * The exported component is wrapped in an error boundary BY DEFAULT, so a
 * consuming app can't accidentally ship without one. A render crash is
 * contained to the grid's own box instead of unmounting the page around it.
 */
export function DynamicGrid(props: DynamicGridProps) {
  return (
    <GridErrorBoundary onGridError={props.onGridError} onRetry={props.onRetry}>
      <MemoisedGrid {...props} />
    </GridErrorBoundary>
  );
}
