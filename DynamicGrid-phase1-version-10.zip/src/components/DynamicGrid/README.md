# DynamicGrid — Phase 1

Backend-driven, reusable AG Grid wrapper. The service payload decides columns,
values, visual treatment, tooltips and clickability. The app supplies only the
payload, native AG Grid options, and callbacks.

## Install

```bash
npm i ag-grid-react ag-grid-community   # v36.1.0
# Enterprise (Phase 2: SSRM, pivot, master-detail)
# npm i ag-grid-enterprise
```

**Do NOT import `ag-grid.css` or `ag-theme-quartz.css`.** On v33+ those are the
legacy CSS-theming path. This component uses the JS Theming API
(`theme/dynamicGridTheme.ts`); importing the CSS files alongside it makes the
two systems fight, which silently breaks header background and border overrides.

No webfonts either — one system font stack, so type can't fall back
inconsistently per element.

```tsx
import { DynamicGrid } from '@/components/DynamicGrid';

<DynamicGrid
  gridData={payload}                 // GridConfig or the raw cells[] shape
  gridOptions={{ rowHeight: 36 }}    // native AG Grid passthrough
  onCellClicked={handleCellClicked}
  onRowSelected={handleRowSelected}
/>
```

## Structure

```
DynamicGrid/
├── DynamicGrid.tsx              main wrapper
├── types/                       GridConfig, ColumnDef, CellOverride, display schema
├── adapters/rawGridAdapter.ts   ONLY file that knows the cells[] wire format
├── mappers/
│   ├── columnMapper.ts          ColumnDef -> ColDef (precedence lives here)
│   ├── cellOverrideMapper.ts    rowId::field lookup map
│   ├── gridOptionsMapper.ts     metadata -> gridOptions
│   └── display/
│       ├── displayRegistry.ts   type -> handler  (the extension point)
│       └── handlers/            plain, numeric, status, heatmap, utilization, icon
├── hooks/                       normalisation, overrides, config, api, events
├── components/                  IconRegistry, DynamicCellRenderer, CustomTooltip
├── registry/componentRegistry   AG Grid component map
├── styles/dynamicGrid.css       CSS variables + cell classes
├── __mocks__/                   flat mock + raw cells[] mock
└── examples/PortfolioDashboard  parent integration
```

## How a cell gets its look

```
cellOverride.style  ->  cellOverride.display  ->  column.display  ->  default
```

Resolved identically in `cellStyle`, `valueFormatter` and `cellClass`, all inside
`columnMapper.ts`. Handlers are built once per column; per-cell work is a `Map.get`
plus a comparison or a colour lerp.

## Adding a new visual type

1. Add the type to `CellDisplayType` and its config interface in `types/display.types.ts`.
2. Create `mappers/display/handlers/<name>Handler.ts` implementing `DisplayHandler`.
3. Register it in `displayRegistry.ts`.

No other file changes — not `columnMapper`, not `DynamicGrid`.

## Performance notes

- Renderers are attached only where DOM is unavoidable: icons, utilization bars,
  opt-in status pills, and columns that have a per-cell icon override. Everything
  else (numeric, heatmap, renderer-free status, plain) stays on native
  `valueFormatter` + `cellStyle` with no React node per cell.
- Heatmap `min`/`max` always come from the column config. Row data is never scanned,
  so cost is O(1) per cell and the behaviour is already correct under SSRM.
- Overrides are sparse and response-scoped. The map is rebuilt per payload, never
  merged, so stale flags are impossible and Phase 2 can feed per-block overrides in
  unchanged.
- Normalisation and mapping are memoised on `metadata.version`. Only the normalised
  payload is held in state — the raw payload is not retained.
- `getRowId` gives rows stable identity, which is the prerequisite for
  `applyTransaction` updates on live ticks.

## Phase 2 hooks already in place

- `gridOptionsMapper` reads `rowModelType: 'serverSide'`, warns, and falls back to
  clientSide. One `TODO(phase-2)` marks the switch.
- `ColumnDef.phase2` flags are parsed and forced off in `columnMapper`.
- `componentRegistry` reserves a slot for the master-detail renderer.
- `useGridApi` holds the api ref — the attachment point for an SSRM datasource.

## Who owns which prop

| Comes from the service (`metadata.layout`) | Comes from the app (`props` / `gridOptions`) |
|---|---|
| `rowHeight`, `headerHeight`, `groupHeaderHeight` | `height`, `width` (container size) |
| `pagination.enabled`, `pagination.pageSize` | resize behaviour, theme/density if dashboard-wide |
| column widths, pinning, sort/filter defaults | anything about *where* the grid sits, not what it shows |

Rule of thumb: if it describes the data's shape, the backend owns it — a dense
20-column exposure grid and a 5-column summary reasonably want different row
heights, and product should be able to change that without a frontend deploy.
If it describes the frame around the data, the app owns it — height/width are
never backend-driven, since the same grid config has to work full-page today
and as a resizable dashboard widget in Phase 3 without the service knowing
which. When both set the same AG Grid key, app-provided `gridOptions` always
wins (see `DynamicGrid.tsx`'s `mergedOptions`).

## Phase 3 hooks already in place

- All colours resolve through CSS variables scoped to `.dg-root`, so a dashboard
  theme can restyle every grid without touching handler code.
- `useGridApi` is structured to be keyed by `widgetId` when grids become widgets.
- `destroy()` runs on unmount, which matters once widgets mount and unmount as
  users drag them around a dashboard.

## Display types

| Type | Renders | Renderer? |
|---|---|---|
| `plain` | text via format DSL | no |
| `numeric` | sign colour, brackets, trend icon, severity pill, underline bar | only for icon/pill/bar |
| `status` | tone-driven badge | opt-in |
| `heatmap` | density fill from backend min/max | no |
| `utilization` | track + fill | only with `showBar` |
| `icon` / `iconWithText` | tone or key lookup | yes |
| `rank` | position badge from row index | yes |
| `commentary` | freeform narrative pill | yes |

Renderers are attached per column ONLY when a handler says DOM is unavoidable.
Everything else stays on native `cellStyle` / `valueFormatter`.

## Key contracts

- **Backend sends meaning, UI owns appearance.** Tones (`positive`, `negative`)
  over hex; hex still accepted via `ColorValue` as an escape hatch.
- **Bounds are never scanned.** `heatmap.min/max` and `underlineBar.max` come
  from config — a client-side column scan breaks under SSRM.
- **Overrides are sparse and response-scoped**, rebuilt per payload, never merged.
- **Pre-formatted values**: `valueMode: PRE_FORMATTED` + `displayField` renders
  the backend string verbatim; the raw value still drives sort/colour maths.
- **App `gridOptions` always win** over anything derived from `metadata`.

## Selection & drill-down

`onDrillDown` receives an `AbortSignal` and a `requestId`. Both are needed:
abort cancels in-flight work, the id catches a response that resolved just
before the abort landed. See `examples/DrillDownDashboard.tsx`.

Selection uses elevation, not dimming — dimming peers removes comparison
context exactly when it's needed and makes clickable rows look disabled.
`dimUnselected` is available but off by default.

## Known gaps

- Tests are written for Vitest — `npm i -D vitest` before running.
- Not compiled against a real AG Grid install in this environment; a v36 param
  rename would surface at build time, not in review.
- `emphasis: 'primary'` is 21px. One primary column per grid, or they compete.
