import type { GridConfig } from '../types/gridConfig.types';
import { gridServiceResponseMock } from './gridServiceResponse.mock';

/**
 * Demo-tunable latency.
 *
 * A uniform 400ms everywhere makes skeletons flash so briefly they read as a
 * glitch. Varied, realistic delays let the panels resolve progressively, which
 * is what the loading design is actually for.
 *
 * Override at runtime for a demo: `?dgLatency=2` doubles every delay so the
 * loading states are clearly visible while presenting; `?dgLatency=0` removes
 * them for the "look how fast it feels" moment.
 */
function latencyMultiplier(): number {
  if (typeof window === 'undefined') return 1;
  const raw = new URLSearchParams(window.location.search).get('dgLatency');
  const n = raw === null ? NaN : Number(raw);
  return Number.isFinite(n) && n >= 0 ? n : 1;
}

function delay<T>(value: T, ms: number, signal?: AbortSignal): Promise<T> {
  const wait = ms * latencyMultiplier();
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException('Aborted', 'AbortError'));
      return;
    }
    const t = setTimeout(() => resolve(value), wait);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(t);
        reject(new DOMException('Aborted', 'AbortError'));
      },
      { once: true },
    );
  });
}

export interface DrillDownChartPoint {
  label: string;
  value: number;
}

/** Detail grid for a selected row. ~700ms — resolves before the chart. */
export function fetchDrillDownGrid(rowId: string, signal?: AbortSignal): Promise<GridConfig> {
  const detail: GridConfig = {
    ...gridServiceResponseMock,
    metadata: {
      ...gridServiceResponseMock.metadata,
      gridId: `${rowId}-detail`,
      version: `${rowId}-detail-v1`,
    },
    // Deterministic subset so the demo is repeatable rather than random.
    rows: gridServiceResponseMock.rows.filter((_, i) => i % 2 === 0),
    cellOverrides: [],
  };
  return delay(detail, 700, signal);
}

/** Chart series for a selected row. ~1200ms — deliberately slower than the grid,
 *  so the demo shows panels resolving independently rather than all at once. */
export function fetchDrillDownChart(rowId: string, signal?: AbortSignal): Promise<DrillDownChartPoint[]> {
  const seed = rowId.length;
  const points: DrillDownChartPoint[] = Array.from({ length: 12 }, (_, i) => ({
    label: `M${i + 1}`,
    value: Math.round(Math.sin((i + seed) / 2) * 40 + 60),
  }));
  return delay(points, 1200, signal);
}
