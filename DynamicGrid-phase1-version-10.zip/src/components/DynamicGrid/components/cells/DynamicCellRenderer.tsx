import React, { memo } from 'react';
import type { ICellRendererParams } from 'ag-grid-community';
import type {
  CommentaryConfig,
  RankConfig,
  ColumnDisplay,
  IconConfig,
  NumericConfig,
  StatusConfig,
  UtilizationConfig,
} from '../../types/display.types';
import type { RowRecord } from '../../types/gridConfig.types';
import { clamp, resolveColor, resolveSoftBg } from '../../utils/colorUtils';
import { iconKeyFor } from '../../mappers/display/handlers/iconHandler';
import { numericVisual } from '../../mappers/display/handlers/numericHandler';
import { rankTone } from '../../mappers/display/handlers/rankHandler';
import { thresholdFor } from '../../mappers/display/handlers/utilizationHandler';
import { getIcon } from '../icons/IconRegistry';
import { TONE_COLORS, iconForTone } from '../icons/toneRegistry';

interface Params extends ICellRendererParams<RowRecord> {
  display: ColumnDisplay;
  columnField: string;
}

/** Injected once by DynamicGrid via the grid `context`, not per cell. */
interface GridContext {
  getOverrideIcon?: (rowId: string, field: string) => string | undefined;
}

/**
 * The only cell renderer in Phase 1. It is attached to a column ONLY when the
 * display handler reports that DOM structure is unavoidable — icons, utilization
 * bars, and opt-in status pills. Everything else renders through native
 * valueFormatter + cellStyle with no React node per cell.
 *
 * memo() keeps AG Grid's cell refresh from re-rendering unchanged cells.
 */
function DynamicCellRendererBase(params: Params) {
  const { display, columnField, value, valueFormatted, data } = params;
  const text = valueFormatted ?? (value === null || value === undefined ? '' : String(value));
  const ctx = params.context as GridContext | undefined;
  const overrideIcon = data ? ctx?.getOverrideIcon?.(data.id, columnField) : undefined;

  if (display.type === 'rank') {
    // rowIndex, not the cell value — the badge must follow the row's CURRENT
    // position so it stays right after the user sorts.
    const position = (params.node?.rowIndex ?? 0) + 1;
    const tone = rankTone(position, display.config as RankConfig | undefined);
    return (
      <span
        className="dg-rank"
        style={{ backgroundColor: resolveSoftBg(tone), color: resolveColor(tone) }}
      >
        {position}
      </span>
    );
  }

  if (display.type === 'commentary') {
    const cfg = display.config as CommentaryConfig | undefined;
    const tone = (cfg?.toneField && data ? (data[cfg.toneField] as string) : undefined) ?? 'neutral';
    const iconKey = cfg?.iconField && data ? (data[cfg.iconField] as string) : undefined;
    if (!text) return null;
    return (
      <span
        className="dg-commentary"
        style={{ backgroundColor: resolveSoftBg(tone), color: resolveColor(tone) }}
      >
        {getIcon(iconKey)}
        <span>{text}</span>
      </span>
    );
  }

  if (display.type === 'numeric') {
    const cfg = (display.config ?? {}) as NumericConfig;
    const visual = numericVisual(value, cfg);

    // The arrow carries its OWN tone, deliberately not inheriting the cell's
    // text colour — on a tinted pill an inherited colour goes muddy. Three
    // states, not two: a flat dash for zero reads faster than an absent arrow,
    // which is ambiguous with "not loaded yet".
    const TREND_ICON = { up: 'icon-trend-up', down: 'icon-trend-down', flat: 'icon-minus' } as const;
    const TREND_TONE = { up: 'positive', down: 'negative', flat: 'muted' } as const;

    // Thin magnitude bar under the value. Width is a share of the backend's
    // declared max — never a client-side column scan, which breaks under SSRM.
    const ub = cfg.underlineBar;
    const ubMax = typeof ub?.max === 'number' ? ub.max : undefined;
    const n = typeof value === 'number' && Number.isFinite(value) ? value : null;
    const underline =
      ub && ubMax && n !== null
        ? {
            width: `${Math.min(100, Math.max(0, (Math.abs(n) / ubMax) * 100))}%`,
            backgroundColor: resolveColor(ub.tone ?? 'info'),
          }
        : undefined;

    const showTrend = cfg.trendIndicator === 'icon' && visual.direction !== null;
    const dir = visual.direction ?? 'flat';

    return (
      <span
        className={visual.isPill ? 'dg-num dg-num--pill' : 'dg-num'}
        style={{
          ...(visual.background ? { backgroundColor: visual.background } : {}),
          ...(visual.color ? { color: visual.color } : {}),
          ...(visual.bold ? { fontWeight: visual.bold } : {}),
        }}
      >
        {underline ? <span className="dg-num__underline" style={underline} /> : null}
        {showTrend ? (
          <span className="dg-num__trend" style={{ color: resolveColor(TREND_TONE[dir]) }}>
            {getIcon(TREND_ICON[dir])}
          </span>
        ) : null}
        <span className="dg-num__value">{text}</span>
      </span>
    );
  }

  if (display.type === 'icon' || display.type === 'iconWithText') {
    const cfg = display.config as IconConfig | undefined;
    const key = overrideIcon ?? iconKeyFor(value, cfg);
    const icon = getIcon(key);
    const showValue = display.type === 'iconWithText' || cfg?.showValue === true;
    const iconRight = cfg?.position === 'right';

    // When the icon IS the whole cell content, it must carry an accessible
    // name — otherwise a screen reader announces an empty cell. When there is
    // visible text alongside it, the text is the name and the icon is decorative.
    return (
      <span
        className="dg-icon-cell"
        title={text}
        {...(showValue ? {} : { role: 'img', 'aria-label': text || 'no value' })}
      >
        {!iconRight && icon}
        {showValue && <span className="dg-icon-cell__label">{text}</span>}
        {iconRight && icon}
      </span>
    );
  }

  if (display.type === 'utilization') {
    const cfg = display.config as UtilizationConfig | undefined;
    const numeric = typeof value === 'number' && Number.isFinite(value) ? value : null;
    if (!cfg || numeric === null) return <span>{text}</span>;

    const band = thresholdFor(numeric, cfg);
    const span = cfg.max - cfg.min || 1;
    const pct = clamp(((numeric - cfg.min) / span) * 100, 0, 100);

    return (
      <span className="dg-util-cell">
        <span className="dg-util-cell__track">
          <span
            className="dg-util-cell__bar"
            style={{ width: `${pct}%`, backgroundColor: resolveColor(band?.bgColor) }}
          />
        </span>
        <span className="dg-util-cell__label" style={{ color: resolveColor(band?.textColor) }}>
          {text}
        </span>
      </span>
    );
  }

  if (display.type === 'status') {
    const cfg = display.config as StatusConfig | undefined;
    const entry = cfg && typeof value === 'string' ? cfg.map[value] : undefined;
    const toneColors = entry?.tone ? TONE_COLORS[entry.tone] : undefined;
    const icon = getIcon(overrideIcon ?? iconForTone(entry?.tone, entry?.icon));

    return (
      <span
        className="dg-status-pill"
        style={{
          backgroundColor: resolveSoftBg(entry?.bgColor ?? toneColors?.bg ?? cfg?.fallback?.bgColor),
          color: resolveColor(entry?.textColor ?? toneColors?.text ?? cfg?.fallback?.textColor),
        }}
      >
        {icon}
        <span>{entry?.label ?? text}</span>
      </span>
    );
  }

  // Reached when a column only needs a renderer because of a per-cell icon override.
  const icon = getIcon(overrideIcon);
  return (
    <span className="dg-icon-cell">
      {icon}
      <span className="dg-icon-cell__label">{text}</span>
    </span>
  );
}

export const DynamicCellRenderer = memo(DynamicCellRendererBase);
