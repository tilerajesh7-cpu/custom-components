import React from 'react';

/**
 * Tells the user what the dependent panels below are showing.
 *
 * This does more to prevent "wait, what am I looking at?" than any amount of
 * row styling — especially once the source row is scrolled out of view, which
 * happens immediately on a long grid.
 */
export function ActiveContextChip({
  label,
  onClear,
}: {
  label: string;
  onClear?: () => void;
}) {
  return (
    <div className="dg-context-chip" role="status" aria-live="polite">
      <span className="dg-context-chip__dot" aria-hidden />
      <span className="dg-context-chip__label">{label}</span>
      {onClear ? (
        <button
          type="button"
          className="dg-context-chip__clear"
          onClick={onClear}
          aria-label={`Clear selection: ${label}`}
        >
          ×
        </button>
      ) : null}
    </div>
  );
}
