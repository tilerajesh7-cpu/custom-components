import React, { useEffect, useRef, useState } from 'react';

/**
 * Holds a skeleton visible for a minimum duration.
 *
 * Counterintuitive but important: a skeleton that appears and vanishes in 80ms
 * reads as a flicker or a bug. Holding it briefly feels MORE stable than being
 * maximally fast — perceived smoothness beats raw speed here.
 */
export function useMinimumVisible(active: boolean, minimumMs = 400): boolean {
  const [visible, setVisible] = useState(active);
  const shownAt = useRef<number | null>(null);

  useEffect(() => {
    if (active) {
      shownAt.current = Date.now();
      setVisible(true);
      return;
    }
    if (shownAt.current === null) {
      setVisible(false);
      return;
    }
    const elapsed = Date.now() - shownAt.current;
    const remaining = Math.max(0, minimumMs - elapsed);
    const t = setTimeout(() => {
      setVisible(false);
      shownAt.current = null;
    }, remaining);
    return () => clearTimeout(t);
  }, [active, minimumMs]);

  return visible;
}

/**
 * Matches the real row structure and count, so nothing reflows when data
 * lands. A generic spinner cannot communicate "a table is coming"; this can.
 */
export function GridSkeleton({ rows = 6, columns = 5 }: { rows?: number; columns?: number }) {
  return (
    <div className="dg-skeleton" aria-hidden>
      <div className="dg-skeleton__header">
        {Array.from({ length: columns }).map((_, i) => (
          <span key={i} className="dg-skeleton__bar dg-skeleton__bar--header" />
        ))}
      </div>
      {Array.from({ length: rows }).map((_, r) => (
        <div className="dg-skeleton__row" key={r}>
          {Array.from({ length: columns }).map((_, c) => (
            <span
              key={c}
              className="dg-skeleton__bar"
              /* Varied widths read as real content; identical bars read as a loader. */
              style={{ width: `${55 + ((r + c) % 4) * 12}%` }}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

/** Axes plus a shimmer plot area — communicates "a chart is coming". */
export function ChartSkeleton({ height = 220 }: { height?: number }) {
  return (
    <div className="dg-chart-skeleton" style={{ height }} aria-hidden>
      <div className="dg-chart-skeleton__yaxis">
        {Array.from({ length: 4 }).map((_, i) => (
          <span key={i} className="dg-skeleton__bar dg-skeleton__bar--tick" />
        ))}
      </div>
      <div className="dg-chart-skeleton__plot" />
      <div className="dg-chart-skeleton__xaxis">
        {Array.from({ length: 6 }).map((_, i) => (
          <span key={i} className="dg-skeleton__bar dg-skeleton__bar--tick" />
        ))}
      </div>
    </div>
  );
}
