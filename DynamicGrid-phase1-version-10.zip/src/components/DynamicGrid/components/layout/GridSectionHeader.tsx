import React from 'react';

export interface SegmentOption {
  id: string;
  label: string;
}

export interface GridSectionHeaderProps {
  title: string;
  subtitle?: string;
  /** Optional segmented filter, e.g. All Types / Funded Loans / My Clients. */
  segments?: SegmentOption[];
  activeSegment?: string;
  onSegmentChange?: (id: string) => void;
  /** Right-aligned slot — a badge, a count, an action. */
  trailing?: React.ReactNode;
  children: React.ReactNode;
}

/**
 * Card framing for a grid: accent rule, title/subtitle, optional segmented
 * filter.
 *
 * Deliberately WRAPS DynamicGrid rather than living inside it. The grid is a
 * dashboard widget (Phase 3) and must stay container-agnostic — a title bar
 * baked into the component would be dead weight in every embedded usage, and
 * the segmented filter is app state, not grid state.
 */
export function GridSectionHeader({
  title,
  subtitle,
  segments,
  activeSegment,
  onSegmentChange,
  trailing,
  children,
}: GridSectionHeaderProps) {
  return (
    <section className="dg-section">
      <div className="dg-section__accent" aria-hidden />
      <header className="dg-section__head">
        <div className="dg-section__titles">
          <h3 className="dg-section__title">{title}</h3>
          {subtitle ? <p className="dg-section__subtitle">{subtitle}</p> : null}
        </div>
        {trailing ? <div className="dg-section__trailing">{trailing}</div> : null}
      </header>

      {segments?.length ? (
        <div className="dg-segments" role="tablist" aria-label={`${title} filters`}>
          {segments.map((seg) => {
            const active = seg.id === activeSegment;
            return (
              <button
                key={seg.id}
                type="button"
                role="tab"
                aria-selected={active}
                className={active ? 'dg-segment dg-segment--active' : 'dg-segment'}
                onClick={() => onSegmentChange?.(seg.id)}
              >
                {seg.label}
              </button>
            );
          })}
        </div>
      ) : null}

      <div className="dg-section__body">{children}</div>
    </section>
  );
}
