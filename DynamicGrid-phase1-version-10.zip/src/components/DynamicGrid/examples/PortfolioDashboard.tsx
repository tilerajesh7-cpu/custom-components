import React, { useCallback, useMemo } from 'react';
import { DynamicGrid } from '../DynamicGrid';
import { useMockGridData } from '../hooks/useMockGridData';
import { gridServiceResponseMock } from '../__mocks__/gridServiceResponse.mock';
import type { CellClickPayload } from '../types/gridConfig.types';

/**
 * Minimal integration showing the loading state working.
 *
 * The only thing that makes the skeleton appear is `loading` being true for a
 * real interval — useMockGridData supplies that gap, since importing the mock
 * object directly is synchronous and leaves no window for it.
 *
 * Try ?dgLatency=3 to hold the skeleton long enough to look at properly.
 */
export function PortfolioDashboard() {
  const { gridData, loading } = useMockGridData(gridServiceResponseMock, 1500);

  const gridOptions = useMemo(
    () => ({ rowSelection: 'single' as const }),
    [],
  );

  const handleCellClicked = useCallback((payload: CellClickPayload) => {
    switch (payload.actionType) {
      case 'OPEN_COMPLIANCE_REVIEW':
      case 'OPEN_RISK_DRILLDOWN':
      case 'OPEN_INSTRUMENT':
      default:
        break;
    }
  }, []);

  return (
    <DynamicGrid
      gridData={gridData}
      gridOptions={gridOptions}
      loading={loading}
      onCellClicked={handleCellClicked}
      height={520}
    />
  );
}
