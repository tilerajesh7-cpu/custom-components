import { useCallback, useEffect, useRef, useState } from 'react';
import type { DrillDownPayload, SelectionState } from '../types/drilldown.types';
import type { CellClickPayload } from '../types/gridConfig.types';

interface Args {
  onDrillDown?: (payload: DrillDownPayload) => void;
  /** Field whose value labels the active-context chip. Defaults to the clicked field. */
  labelField?: string;
  /** Controlled mode — when provided, the parent owns selection. */
  selectedRowId?: string;
}

/**
 * Owns selection state, request sequencing and abort for drill-down.
 *
 * The stale-response problem this solves: click row A, then quickly row B.
 * A's fetch may resolve AFTER B's, painting A's detail under B's header. A
 * loading boolean does not prevent that — you need both an abort (to cancel
 * in-flight work) and a request-id check (for responses that already resolved
 * before the abort landed).
 */
export function useDrillDown({ onDrillDown, labelField, selectedRowId }: Args) {
  const [internalSelection, setInternalSelection] = useState<SelectionState | null>(null);
  const controllerRef = useRef<AbortController | null>(null);
  const requestIdRef = useRef(0);

  const selection = selectedRowId
    ? internalSelection?.rowId === selectedRowId
      ? internalSelection
      : { rowId: selectedRowId, label: selectedRowId }
    : internalSelection;

  const abortInFlight = useCallback(() => {
    controllerRef.current?.abort();
    controllerRef.current = null;
  }, []);

  const trigger = useCallback(
    (click: CellClickPayload) => {
      // 1. Selection is INSTANT — never gated on the network. The click must
      //    feel acknowledged before any request is even created.
      const label = String(
        (labelField ? click.rowData[labelField] : undefined) ?? click.value ?? click.rowId,
      );
      setInternalSelection({ rowId: click.rowId, label });

      if (!onDrillDown) return;

      // 2. Cancel whatever the previous selection started.
      abortInFlight();
      const controller = new AbortController();
      controllerRef.current = controller;
      requestIdRef.current += 1;

      onDrillDown({
        ...click,
        signal: controller.signal,
        requestId: requestIdRef.current,
      });
    },
    [onDrillDown, labelField, abortInFlight],
  );

  const clear = useCallback(() => {
    abortInFlight();
    setInternalSelection(null);
  }, [abortInFlight]);

  // Abort on unmount so a dashboard widget being dragged away doesn't leave
  // a request running against a component that no longer exists.
  useEffect(() => abortInFlight, [abortInFlight]);

  return { selection, trigger, clear, latestRequestId: requestIdRef };
}
