import { useEffect, useRef, useState } from 'react';
import type { GridConfig } from '../types/gridConfig.types';
import type { RawGridData } from '../types/rawGridData.types';

/**
 * Demo-only: turns a synchronous mock into an async one so the loading states
 * are actually reachable.
 *
 * Importing a mock object directly means `loading` is never true and the
 * skeleton has no window to appear in — which is the usual reason it seems
 * "not to work". This hook supplies the missing async gap.
 *
 * Latency can be dialled at runtime without a rebuild:
 *   ?dgLatency=2   double every delay (good for presenting)
 *   ?dgLatency=0   no delay at all (the "look how fast" moment)
 *
 * DELETE this hook when the real service is wired — it exists to simulate a
 * network, not to be part of the component's behaviour.
 */
export function useMockGridData<T extends GridConfig | RawGridData>(
  data: T,
  delayMs = 1500,
): { gridData: T; loading: boolean } {
  const [loading, setLoading] = useState(true);
  const dataRef = useRef(data);
  dataRef.current = data;

  useEffect(() => {
    const raw =
      typeof window === 'undefined'
        ? null
        : new URLSearchParams(window.location.search).get('dgLatency');
    const parsed = raw === null ? NaN : Number(raw);
    const multiplier = Number.isFinite(parsed) && parsed >= 0 ? parsed : 1;
    const wait = delayMs * multiplier;

    if (wait === 0) {
      setLoading(false);
      return;
    }

    setLoading(true);
    const t = setTimeout(() => setLoading(false), wait);
    return () => clearTimeout(t);
  }, [delayMs]);

  return { gridData: dataRef.current, loading };
}
