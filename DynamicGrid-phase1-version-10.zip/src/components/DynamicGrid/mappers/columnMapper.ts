import type { ColDef, ColGroupDef, CellClassParams, CellStyle, ValueFormatterParams } from 'ag-grid-community';
import type { ColumnDisplay } from '../types/display.types';
import { TooltipType, ValueMode } from '../types/enums';
import type { ColumnDef, RowRecord } from '../types/gridConfig.types';
import { isColumnGroup, type ColumnNode } from '../utils/columnTree';
import { createFormatter } from '../utils/formatters';
import { getHandler } from './display/displayRegistry';
import type { HandlerContext } from './display/types';
import { overrideKey, type OverrideMap } from './cellOverrideMapper';

const DEFAULT_DISPLAY: ColumnDisplay = { type: 'plain' };

function defaultFilterFor(type: ColumnDef['type']): string | boolean {
  switch (type) {
    case 'number':
      return 'agNumberColumnFilter';
    case 'date':
      return 'agDateColumnFilter';
    default:
      return 'agTextColumnFilter';
  }
}

/** Merges a cell-level display patch onto the column display. Cheap, only on overridden cells. */
function mergeDisplay(base: ColumnDisplay, patch?: Partial<ColumnDisplay>): ColumnDisplay {
  if (!patch) return base;
  return {
    type: patch.type ?? base.type,
    format: patch.format ?? base.format,
    config: patch.config ?? base.config,
  };
}

export interface ColumnMapperDeps {
  overrides: OverrideMap;
  /** Fields that have at least one icon override — those columns need a renderer. */
  iconOverrideFields: ReadonlySet<string>;
  /** BCP-47 locale from metadata. Only affects ValueMode.RAW columns. */
  locale?: string;
}

/**
 * Backend column tree -> AG Grid (ColDef | ColGroupDef) tree.
 *
 * A column group is a header-only wrapper — grouping never changes how a leaf
 * column's cells look, sort, filter, or override. This walks the tree and
 * recurses into groups; `mapLeafColumn` does all the real per-column work and
 * only ever sees leaves, so nothing about the display/override precedence
 * chain needed to change to support nesting.
 *
 * Precedence, applied identically everywhere regardless of nesting depth:
 *   cellOverride.style  ->  cellOverride.display  ->  column.display  ->  default
 */
export function mapColumns(
  nodes: ColumnNode[],
  deps: ColumnMapperDeps,
): (ColDef<RowRecord> | ColGroupDef<RowRecord>)[] {
  return nodes.map((node): ColDef<RowRecord> | ColGroupDef<RowRecord> => {
    if (isColumnGroup(node)) {
      return {
        headerName: node.headerName,
        ...(node.groupId ? { groupId: node.groupId } : {}),
        marryChildren: node.marryChildren ?? true,
        children: mapColumns(node.children, deps),
      };
    }
    return mapLeafColumn(node, deps);
  });
}

/**
 * Everything the display handler can express as cellStyle / cellClass / valueFormatter
 * stays on AG Grid's native fast path. A renderer is attached only when the handler
 * says DOM is unavoidable (icons, bars, opt-in pills).
 */
function mapLeafColumn(column: ColumnDef, deps: ColumnMapperDeps): ColDef<RowRecord> {
  const { overrides, iconOverrideFields, locale } = deps;

  const display = column.display ?? DEFAULT_DISPLAY;
  const handler = getHandler(display.type);

  // Built ONCE per column, closed over by the per-cell callbacks below.
  const ctx: HandlerContext = { display, format: createFormatter(display.format, locale) };

  const rendererNeeded =
    Boolean(handler.needsRenderer?.(ctx)) || iconOverrideFields.has(column.field);

  const lookup = (data: RowRecord | undefined) =>
    data ? overrides.get(overrideKey(data.id, column.field)) : undefined;

  const colDef: ColDef<RowRecord> = {
    field: column.field,
    headerName: column.headerName,
    sortable: column.sortable ?? true,
    // Right-aligns the header label so it sits over its numbers.
    headerClass: column.type === 'number' ? 'dg-header-numeric' : undefined,
    filter: column.filter === false ? false : (column.filter ?? defaultFilterFor(column.type)),
    resizable: true,
    hide: column.hide,
    ...(column.width ? { width: column.width } : {}),
    ...(column.flex ? { flex: column.flex } : {}),
    ...(column.pinned ? { pinned: column.pinned } : {}),

    valueFormatter: (params: ValueFormatterParams<RowRecord>) => {
      // PRE_FORMATTED short-circuits everything below: no createFormatter call,
      // no handler.getDisplayText — the backend's string is the text, full stop.
      // A per-cell display override can still change COLOUR/ICON (handled in
      // cellStyle/renderer below), but it cannot re-format text the backend
      // already computed — that would silently disagree with what the backend
      // intended to show.
      if (column.valueMode === ValueMode.PRE_FORMATTED) {
        const raw = params.data?.[column.displayField ?? `${column.field}Display`];
        return raw !== undefined && raw !== null ? String(raw) : '';
      }

      const override = lookup(params.data);
      if (override?.display) {
        const merged = mergeDisplay(display, override.display);
        const mergedHandler = getHandler(merged.type);
        const mergedCtx: HandlerContext = {
          display: merged,
          format: merged.format === display.format ? ctx.format : createFormatter(merged.format, locale),
        };
        return mergedHandler.getDisplayText?.(params.value, mergedCtx) ?? mergedCtx.format(params.value);
      }
      return handler.getDisplayText?.(params.value, ctx) ?? ctx.format(params.value);
    },

    cellStyle: (params: CellClassParams<RowRecord>): CellStyle | undefined => {
      const override = lookup(params.data);

      if (override?.style) {
        const s: Record<string, string> = {};
        if (override.style.bgColor) s.backgroundColor = override.style.bgColor;
        if (override.style.textColor) s.color = override.style.textColor;
        if (override.style.fontWeight) s.fontWeight = override.style.fontWeight;
        return s as CellStyle;
      }

      if (override?.display) {
        const merged = mergeDisplay(display, override.display);
        const mergedCtx: HandlerContext = { display: merged, format: ctx.format };
        return getHandler(merged.type).getCellStyle?.(params.value, mergedCtx, override) as CellStyle;
      }

      return handler.getCellStyle?.(params.value, ctx) as CellStyle;
    },

    cellClass: (params: CellClassParams<RowRecord>) => {
      const classes: string[] = [];
      const fromHandler = handler.getCellClass?.(params.value, ctx);
      if (typeof fromHandler === 'string') classes.push(fromHandler);
      else if (Array.isArray(fromHandler)) classes.push(...fromHandler);

      if (column.type === 'number') classes.push('dg-cell-numeric');

      // Type hierarchy — one primary metric per row reads far faster than a
      // wall of identically-sized numbers. Backend declares which one matters.
      if (column.emphasis === 'primary') classes.push('dg-cell-primary');
      else if (column.emphasis === 'secondary') classes.push('dg-cell-secondary');

      const override = lookup(params.data);
      const clickable = override?.clickable ?? column.clickable ?? false;
      if (clickable) classes.push('dg-cell-clickable');

      return classes.length ? classes : undefined;
    },

    ...(rendererNeeded
      ? {
          cellRenderer: 'dgCellRenderer',
          cellRendererParams: { display, columnField: column.field },
        }
      : {}),

    ...buildTooltip(column, lookup),

    enableRowGroup: false,
    enablePivot: false,
    enableValue: false,
  };

  return colDef;
}

type Lookup = (
  data: RowRecord | undefined,
) => { tooltip?: { type: 'simple' | 'complex'; value?: string; data?: Record<string, unknown> } } | undefined;

function buildTooltip(column: ColumnDef, lookup: Lookup): Partial<ColDef<RowRecord>> {
  const columnTooltip = column.tooltip;
  const complexPossible = columnTooltip?.type === TooltipType.COMPLEX;

  return {
    tooltipValueGetter: (params) => {
      const override = lookup(params.data as RowRecord | undefined);
      if (override?.tooltip) return override.tooltip.value ?? params.value;
      if (!columnTooltip) return undefined;

      // VALUE tooltip: the cell shows a pre-formatted string, but on hover we
      // show the actual raw number underneath it, unrounded, no styling.
      // `tooltip.field` here is the RAW field (e.g. 'pnl'), not the display one.
      if (columnTooltip.type === TooltipType.VALUE) {
        const rawField = columnTooltip.field ?? column.field;
        const raw = params.data ? (params.data as RowRecord)[rawField] : undefined;
        return raw !== undefined && raw !== null ? String(raw) : undefined;
      }

      if (columnTooltip.field && params.data) {
        return (params.data as RowRecord)[columnTooltip.field] as string;
      }
      return params.value as string;
    },
    ...(complexPossible ? { tooltipComponent: 'dgCustomTooltip' } : {}),
  };
}
