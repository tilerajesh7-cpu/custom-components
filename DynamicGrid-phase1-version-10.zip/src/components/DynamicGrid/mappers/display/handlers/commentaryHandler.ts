import type { DisplayHandler } from '../types';

/**
 * Freeform narrative pill. Unlike `status`, the text is composed per row by the
 * backend, so there is no value->entry map to drive colour — the tone travels
 * in a sibling field named by `toneField`.
 */
export const commentaryHandler: DisplayHandler = {
  type: 'commentary',
  getDisplayText: (value, ctx) => ctx.format(value),
  needsRenderer: () => true,
};
