import type { NumericConfig } from '../../../types/display.types';
import { NegativeStyle } from '../../../types/enums';
import { resolveColor, resolveSoftBg } from '../../../utils/colorUtils';
import type { DisplayHandler } from '../types';

const asNumber = (v: unknown): number | null =>
  typeof v === 'number' && Number.isFinite(v) ? v : null;

/**
 * Back-compat: the earlier enum used 'color' | 'parentheses' | 'both'. The old
 * 'parentheses' value silently disabled colour, which produced grey negatives
 * in a financial grid — almost certainly never the intent. Old values still
 * resolve, but the DEFAULT is now brackets + colour.
 */
function resolveNegativeStyle(raw: string | undefined): {
  brackets: boolean;
  colour: boolean;
} {
  switch (raw) {
    case NegativeStyle.COLOUR_ONLY:
    case 'color':
      return { brackets: false, colour: true };
    case NegativeStyle.BRACKETS_ONLY:
      return { brackets: true, colour: false };
    case NegativeStyle.BRACKETS_COLOURED:
    case 'both':
    case 'parentheses': // legacy: treated as brackets + colour, not brackets alone
    case undefined:
    default:
      return { brackets: true, colour: true };
  }
}

export interface NumericVisual {
  color?: string;
  background?: string;
  bold?: string;
  isPill: boolean;
  /** Direction of the trend glyph, independent of the number's own colour. */
  direction: 'up' | 'down' | 'flat' | null;
}

/**
 * Single source of truth for how a numeric value looks. Both the cell style and
 * the renderer read this, so the pill background, the text colour and the arrow
 * can never disagree about the same value.
 */
export function numericVisual(value: unknown, cfg: NumericConfig): NumericVisual {
  const n = asNumber(value);
  if (n === null) return { isPill: false, direction: null };

  const { colour } = resolveNegativeStyle(cfg.negativeStyle);
  const key = n > 0 ? 'positiveColor' : n < 0 ? 'negativeColor' : 'zeroColor';

  // Negative numbers are coloured unless the column explicitly opted out.
  // Positives/zero always follow their configured token.
  const applyColour = n < 0 ? colour : true;
  const color = applyColour ? resolveColor(cfg[key]) : undefined;

  const bold =
    (cfg.bold === 'positive' && n > 0) || (cfg.bold === 'negative' && n < 0) ? '600' : undefined;

  const isPill = cfg.pillWhenAbs !== undefined && Math.abs(n) >= cfg.pillWhenAbs;
  const background = isPill ? resolveSoftBg(cfg[key]) : undefined;

  return {
    color,
    background,
    bold,
    isPill,
    direction: n > 0 ? 'up' : n < 0 ? 'down' : 'flat',
  };
}

export const numericHandler: DisplayHandler = {
  type: 'numeric',

  getCellStyle(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const v = numericVisual(value, cfg);

    // When the renderer draws a pill it owns the background AND the text colour
    // inside it — the cell must stay transparent or the pill sits on a slab.
    if (v.isPill) return undefined;

    const style: Record<string, string> = {};
    if (v.color) style.color = v.color;
    if (v.bold) style.fontWeight = v.bold;
    return Object.keys(style).length ? style : undefined;
  },

  getDisplayText(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const n = asNumber(value);
    if (n === null) return ctx.format(value);

    const { brackets } = resolveNegativeStyle(cfg.negativeStyle);

    if (n < 0 && brackets) return `(${ctx.format(Math.abs(n))})`;
    if (n > 0 && cfg.showSign) return `+${ctx.format(n)}`;
    return ctx.format(n);
  },

  needsRenderer(ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    return cfg.trendIndicator === 'icon' || cfg.pillWhenAbs !== undefined;
  },
};
