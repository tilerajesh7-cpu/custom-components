import type { RankConfig } from '../../../types/display.types';
import type { ColorToken } from '../../../types/enums';
import type { DisplayHandler } from '../types';

const DEFAULT_TIERS: ColorToken[] = ['warning', 'muted', 'critical'];

/**
 * Position badge. The tone comes from WHERE the row sits, not from the cell's
 * value — so it stays correct after the user sorts, which a value-driven map
 * could never do.
 */
export function rankTone(position: number, cfg?: RankConfig): ColorToken {
  const tiers = cfg?.tiers ?? DEFAULT_TIERS;
  return tiers[position - 1] ?? cfg?.restTone ?? 'neutral';
}

export const rankHandler: DisplayHandler = {
  type: 'rank',
  getDisplayText: (value, ctx) => ctx.format(value),
  needsRenderer: () => true,
};
