import { themeQuartz } from 'ag-grid-community';

/**
 * AG Grid 36 Theming API — a JS Theme object, not a CSS class.
 *
 * v33+ deprecated CSS-file theming (`className="ag-theme-quartz"` +
 * `--ag-*` CSS variables). That path still renders SOMETHING, but overrides
 * via CSS variables are unreliable under the new engine — which is why
 * header background and border-colour overrides were silently not applying
 * earlier in this build. `.withParams()` is the supported way to customise
 * a theme now, and it fully replaces the ag-grid.css / ag-theme-quartz.css
 * imports — do not import those files alongside this.
 *
 * Every value here is our --dg-* token, just expressed as JS instead of CSS,
 * so the design intent hasn't changed — only the mechanism AG Grid actually
 * reads it through.
 */

export interface DensityTokens {
  spacing: number;
  rowHeight: number;
  headerHeight: number;
  fontSize: number;
}

/**
 * Two presets. `spacing` is AG Grid's own density primitive — it scales
 * internal padding consistently, which is why compact/comfortable use it
 * rather than us hand-tuning padding for every part of the grid separately.
 */
export const DENSITY_PRESETS: Record<'compact' | 'comfortable', DensityTokens> = {
  compact: { spacing: 6, rowHeight: 34, headerHeight: 34, fontSize: 12 },
  comfortable: { spacing: 9, rowHeight: 46, headerHeight: 42, fontSize: 13 },
};

const HAIRLINE = '#e4e6e9';

const BASE_PARAMS = {
  // The outer frame is drawn by .dg-root in CSS, so the wrapper must not draw
  // a second one — that produced a square inner border inside our rounded
  // container.
  wrapperBorder: false,
  /*
   * MUST be a plain string. It was previously an object literal
   * ({ googleFont: undefined, fontFamily: ... }), which is not a shape the
   * theming API accepts. An invalid param invalidates the whole params object,
   * so AG Grid silently fell back to Quartz defaults — which is why the font
   * AND the border settings below both appeared to do nothing. One bug, two
   * symptoms.
   */
  fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif',

  backgroundColor: '#ffffff',
  oddRowBackgroundColor: '#ffffff',
  headerBackgroundColor: '#f4f5f7',
  rowHoverColor: '#f7f8f9',
  selectedRowBackgroundColor: '#eef4ff',

  borderColor: HAIRLINE,
  headerRowBorder: { width: 1, color: HAIRLINE },
  // No inner row lines — rows separate by alternating tint instead. The only
  // line in the grid is under the header.
  rowBorder: false,
  // The two params that actually remove internal vertical rules — this is
  // the native fix for "internal borders still there", not a CSS override
  // fighting the grid's own separators.
  columnBorder: false,
  headerColumnBorder: false,

  headerFontWeight: 600,
  headerTextColor: '#1f2329',
  textColor: '#1f2329',

  cellHorizontalPadding: 14,
} as const;

/**
 * Builds the theme for one density. Called once per density value (there are
 * only two), memoised by the caller — never rebuilt per render.
 */
export interface LayoutOverrides {
  rowHeight?: number;
  headerHeight?: number;
  groupHeaderHeight?: number;
}

/**
 * Builds the theme for one density, with optional per-grid overrides from
 * `metadata.layout`.
 *
 * Precedence: backend layout > density preset. A backend value is more
 * specific — it knows THIS grid has pill/bar columns needing taller rows —
 * so it wins over the app-wide density default. Density still controls
 * everything the backend did not explicitly set (spacing, font size).
 */
export function buildDynamicGridTheme(
  density: 'compact' | 'comfortable',
  layout?: LayoutOverrides,
) {
  const d = DENSITY_PRESETS[density];
  return themeQuartz.withParams({
    ...BASE_PARAMS,
    spacing: d.spacing,
    fontSize: d.fontSize,
    rowHeight: layout?.rowHeight ?? d.rowHeight,
    headerHeight: layout?.headerHeight ?? d.headerHeight,
    ...(layout?.groupHeaderHeight ? { headerGroupHeight: layout.groupHeaderHeight } : {}),
  });
}
