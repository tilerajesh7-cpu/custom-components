import type { ColorToken, IconTone } from './enums';
/**
 * Cell visual representation schema.
 *
 * A column declares ONE `display` block describing how its cells should look.
 * Each display type is handled by exactly one handler in `mappers/display/handlers`.
 * Adding a new visual type later = add one handler + register it. Nothing else changes.
 */

/** Semantic colour tokens resolve to CSS variables so dashboard theming works later. */
export type ColorToken =
  | 'positive'
  | 'negative'
  | 'neutral'
  | 'warning'
  | 'critical'
  | 'info'
  | 'muted';

/** Either a semantic token (preferred) or a raw hex escape hatch from the backend. */
export type ColorValue = ColorToken | string;

export type CellDisplayType =
  | 'plain'
  | 'numeric'
  | 'status'
  | 'heatmap'
  | 'utilization'
  | 'icon'
  | 'iconWithText';

/** Format DSL, e.g. "currency:USD:2" | "percent:1" | "number:0" | "text". */
export type FormatString = string;

export interface NumericConfig {
  positiveColor?: ColorValue;
  negativeColor?: ColorValue;
  zeroColor?: ColorValue;
  /** Render "+1,200" for positive values. */
  showSign?: boolean;
  /** 'parentheses' renders -1200 as (1,200) — accounting convention. */
  negativeStyle?: 'color' | 'parentheses' | 'both';
  bold?: 'positive' | 'negative' | 'none';
  /**
   * Prefixes a trend indicator matching the value's sign. 'text' uses a plain
   * ↗/↘ glyph via the formatter (no renderer). 'icon' uses the jagged
   * trending-up/trending-down SVG from IconRegistry instead — visually closer
   * to typical fintech dashboards, but requires a renderer since it's real
   * markup, not a character. Omit for no indicator.
   */
  trendIndicator?: 'text' | 'icon';
  /**
   * Thin magnitude bar drawn UNDER the value text — not a full-width track.
   * The number stays the anchor; the bar is a quiet secondary cue.
   *
   * `max` must be supplied by the backend, exactly as heatmap requires: a
   * client-side column scan breaks under SSRM (Phase 2) where the UI never
   * holds all rows. 'columnMax' is available for client-side row models only
   * and is deliberately not the default.
   */
  underlineBar?: { max: number | 'columnMax'; tone?: ColorToken };
  /**
   * Reserves the pill background for values that actually need attention.
   * Only |value| >= this threshold gets a tinted pill; everything below it
   * stays plain coloured text. Omit to never show a pill for this column.
   */
  pillWhenAbs?: number;
}

export interface StatusEntry {
  label?: string;
  /**
   * Semantic tone drives BOTH the colour pair and the icon. The backend says
   * "this state is bad"; the UI decides that means a red alert-circle. This is
   * what keeps every 'positive' status across every grid looking identical
   * without each backend team having to pick the same icon key.
   */
  tone: IconTone;
  /** Escape hatch — overrides the tone's default glyph for this state only. */
  icon?: string;
  /** Escape hatch — overrides the tone's default colours. */
  bgColor?: ColorValue;
  textColor?: ColorValue;
}

export interface StatusConfig {
  map: Record<string, StatusEntry>;
  fallback?: Pick<StatusEntry, 'bgColor' | 'textColor'>;
  /**
   * false (default) = renderer-free. The cell itself is tinted — fastest path.
   * true = use a renderer so the pill hugs the text. Costs a React node per cell.
   */
  useRenderer?: boolean;
}

export interface HeatmapConfig {
  /** REQUIRED from the backend. Never derived by scanning row data. */
  min: number;
  max: number;

  /**
   * 'density' (the default) — the service sends min/max and a semantic tone
   * plus min/max, and the UI derives the tint strength per cell. This is how a
   * VaR/exposure grid normally works: a single hue per column, stronger fill as
   * the value approaches max. Text flips to white once the fill is dark enough
   * to need it.
   *
   * 'scale' — three-stop interpolation (low → mid → high) for signed values
   * like P&L where the sign, not the magnitude, picks the hue.
   */
  mode?: 'density' | 'scale';

  /**
   * density mode: a SEMANTIC tone, not a hex. The backend says what the metric
   * means ('info' for a neutral risk measure, 'negative' for a breach metric);
   * the UI owns which hue that is and every alpha step derived from it.
   * Defaults to 'info' (blue) when omitted.
   */
  tone?: ColorToken;
  /** density mode: tint strength at `min` and at `max`. Defaults 0.06 → 0.92. */
  minAlpha?: number;
  maxAlpha?: number;
  /** density mode: alpha past which the label switches to white. Default 0.55. */
  invertTextAbove?: number;

  /** scale mode only. */
  mid?: number;
  lowColor?: ColorValue;
  midColor?: ColorValue;
  highColor?: ColorValue;

  applyTo?: 'background' | 'text';
  /** Values outside [min, max] clamp to the end colour. Default true. */
  clamp?: boolean;
}

export interface UtilizationThreshold {
  upTo: number;
  bgColor: ColorValue;
  textColor?: ColorValue;
}

export interface UtilizationConfig {
  min: number;
  max: number;
  thresholds: UtilizationThreshold[];
  /** Inline proportional bar behind the value. Requires a renderer. */
  showBar?: boolean;
}

export interface RankConfig {
  /**
   * Tone per position, index 0 = rank 1. Positions beyond the list fall back
   * to `restTone`. Backend sends nothing here — rank is derived from row order
   * at render time, so it stays correct after a client-side sort.
   */
  tiers?: ColorToken[];
  restTone?: ColorToken;
}

export interface CommentaryConfig {
  /**
   * Field holding the per-row tone ('positive' | 'negative' | ...). Freeform
   * text means the tone cannot be looked up from the value, so the backend
   * names a sibling field that carries it.
   */
  toneField?: string;
  /** Field holding an optional icon key for the pill. */
  iconField?: string;
}

export interface IconConfig {
  /** Cell value -> icon key registered in IconRegistry. */
  map: Record<string, string>;
  position?: 'left' | 'right';
  /** iconWithText always shows the value; `icon` uses this flag. */
  showValue?: boolean;
}

export type DisplayConfig =
  | RankConfig
  | CommentaryConfig
  | NumericConfig
  | StatusConfig
  | HeatmapConfig
  | UtilizationConfig
  | IconConfig
  | undefined;

export interface ColumnDisplay {
  type: CellDisplayType;
  format?: FormatString;
  config?: DisplayConfig;
}
