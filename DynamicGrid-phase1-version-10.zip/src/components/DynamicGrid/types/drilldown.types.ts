import type { RowRecord } from './gridConfig.types';

/**
 * Drill-down contract.
 *
 * The component owns selection visuals and the abort lifecycle; the app owns
 * what a drill-down MEANS — consistent with how `actionType` already works.
 * The grid never knows that clicking a desk loads a chart.
 */
export interface DrillDownPayload {
  rowId: string;
  field: string;
  value: unknown;
  rowData: RowRecord;
  actionType?: string;
  /**
   * Aborted automatically when the user selects a different row. Pass this
   * straight to fetch() — it is the component's half of the stale-response
   * guard, and the reason a slow response for row A cannot land under row B.
   */
  signal: AbortSignal;
  /**
   * Monotonic per-grid. Belt and braces alongside `signal`: abort handles
   * in-flight fetches, this catches a response that already resolved before
   * the abort fired. Compare against the latest before applying state.
   */
  requestId: number;
}

export interface SelectionState {
  rowId: string;
  /** Human-readable label for the active-context chip. */
  label: string;
}
