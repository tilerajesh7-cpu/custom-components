import type { ColumnDisplay } from './display.types';
import type { Phase2ColumnFlags, Phase2Features } from './phase2.types';
import type { ColumnNode } from '../utils/columnTree';
import type { TooltipType as TooltipTypeValue, ValueMode as ValueModeValue } from './enums';

export type { ColumnGroupDef, ColumnNode } from '../utils/columnTree';

/** A normalised row: flat field -> value. `id` is mandatory and stable. */
export interface RowRecord {
  id: string;
  [field: string]: unknown;
}

export interface TooltipConfig {
  type: TooltipTypeValue;
  /**
   * Alternative field to read the tooltip text/data from. For `TooltipType.VALUE`
   * on a pre-formatted column, this is where the RAW numeric field lives —
   * e.g. `pnl` for a cell whose display text comes from `pnlDisplay`.
   */
  field?: string;
}

export interface ColumnDef {
  field: string;
  headerName: string;
  type: 'text' | 'number' | 'date' | 'icon';
  sortable?: boolean;
  filter?: string | false;
  width?: number;
  flex?: number;
  pinned?: 'left' | 'right';
  hide?: boolean;
  /** How this column's cells look. Omitted => plain text. */
  display?: ColumnDisplay;
  tooltip?: TooltipConfig;
  /**
   * Which metric in a row carries the visual weight. PRIMARY renders larger and
   * heavier, SECONDARY smaller and muted. Backend-declared because only the
   * service knows which number this particular grid exists to show — a P&L grid
   * and a margin grid emphasise different columns from the same row shape.
   * Omitted = normal weight.
   */
  emphasis?: 'primary' | 'secondary';
  /** Whole-column click affordance. Cell overrides can narrow or widen this. */
  clickable?: boolean;
  actionType?: string;

  /**
   * Who formats the cell's display text. Defaults to `ValueMode.RAW`
   * (UI formats `row[field]` via `display.format`).
   *
   * `ValueMode.PRE_FORMATTED` — the backend already computed the string
   * (currency conversion, locale rules, whatever business logic it owns) and
   * sends it in `displayField`. The UI renders that string VERBATIM — no
   * createFormatter call happens for this column's text. `row[field]` still
   * carries the raw number for sort/filter/colour math (heatmap, numeric
   * sign colouring, pill threshold) — only the TEXT comes pre-made.
   */
  valueMode?: ValueModeValue;
  /**
   * Required when `valueMode` is PRE_FORMATTED. The row field holding the
   * ready-to-render string, e.g. `field: 'pnl'` + `displayField: 'pnlDisplay'`.
   */
  displayField?: string;

  /** Parsed but inert until Phase 2. */
  phase2?: Phase2ColumnFlags;
}

/** Direct style escape hatch for a single cell. */
export interface CellStyleOverride {
  bgColor?: string;
  textColor?: string;
  fontWeight?: string;
}

/**
 * Sparse, response-scoped. Only cells that deviate from their column's rules appear here.
 * Never accumulated across fetches — see useCellOverrides.
 */
export interface CellOverride {
  rowId: string;
  field: string;
  /** Swap the display type or patch its config for this cell only. */
  display?: Partial<ColumnDisplay>;
  style?: CellStyleOverride;
  icon?: string;
  tooltip?: { type: 'simple' | 'complex'; value?: string; data?: Record<string, unknown> };
  clickable?: boolean;
  actionType?: string;
}

/** Bump when a breaking change lands in the payload contract. */
export const SUPPORTED_SCHEMA_VERSION = 1;

export interface GridMetadata {
  gridId: string;
  /**
   * Payload contract version. Omitted is treated as the current version for
   * back-compat, but every new producer should send it explicitly.
   *
   * This exists because of a real break in this component's history: a field
   * rename (`showTrendArrow` -> `trendIndicator`) silently stopped working for
   * anyone still sending the old name, with no error anywhere. With a version
   * on the payload, the adapter can reject or migrate instead of silently
   * dropping fields.
   */
  schemaVersion?: number;
  /**
   * BCP-47 locale for number/currency formatting in ValueMode.RAW columns.
   * Ignored by PRE_FORMATTED columns — those already arrive localised.
   * Defaults to 'en-US'.
   */
  locale?: string;
  /** Memoisation key. Mapping only re-runs when this changes. */
  version: string;
  rowModelType: 'clientSide' | 'serverSide';
  pagination: {
    enabled: boolean;
    pageSize: number;
    mode: 'client' | 'server';
    totalRows?: number;
  };
  features: Phase2Features;
  /**
   * Data-shape layout — things that vary by WHAT this grid shows, not by
   * WHERE it's placed. A dense 20-column exposure grid wants short rows; a
   * 5-column summary wants taller ones. This is why these are backend-driven.
   *
   * Deliberately excludes container size (height/width): those describe the
   * frame the grid sits in, not the data, and stay an app/props concern so
   * the same grid config works full-page today and as a resizable dashboard
   * widget in Phase 3 without the backend needing to know which.
   *
   * App-provided `gridOptions` always win over this when both set the same
   * key — see gridOptionsMapper.
   */
  layout?: {
    rowHeight?: number;
    headerHeight?: number;
    groupHeaderHeight?: number;
    domLayout?: 'normal' | 'autoHeight';
  };
}

/** The normalised model. Everything downstream of the adapter speaks only this. */
export interface GridConfig {
  metadata: GridMetadata;
  /** Flat columns and column groups may be mixed at the top level. */
  columns: ColumnNode[];
  rows: RowRecord[];
  cellOverrides?: CellOverride[];
}

/** Payload handed to the parent on a cell click. `actionType` is passed through untouched. */
export interface CellClickPayload {
  rowId: string;
  field: string;
  value: unknown;
  rowData: RowRecord;
  actionType?: string;
}

export interface RowSelectPayload {
  rowIds: string[];
  rows: RowRecord[];
}
