import React, { useCallback, useEffect, useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { GetRowIdParams, GridOptions } from 'ag-grid-community';

import { useCellOverrides } from './hooks/useCellOverrides';
import { useGridApi } from './hooks/useGridApi';
import { useGridConfig } from './hooks/useGridConfig';
import { useGridEvents } from './hooks/useGridEvents';
import { useNormalizedGridData } from './hooks/useNormalizedGridData';
import { gridComponents } from './registry/componentRegistry';
import type {
  CellClickPayload,
  GridConfig,
  RowRecord,
  RowSelectPayload,
} from './types/gridConfig.types';
import type { RawGridData } from './types/rawGridData.types';
import { flattenColumns } from './utils/columnTree';

import './styles/dynamicGrid.css';

export interface DynamicGridProps {
  /** Service payload — either the raw `cells[]` shape or the normalised one. */
  gridData: GridConfig | RawGridData;
  /** Native AG Grid passthrough. Anything AG Grid already exposes belongs here. */
  gridOptions?: Partial<GridOptions<RowRecord>>;
  onCellClicked?: (payload: CellClickPayload) => void;
  onRowSelected?: (payload: RowSelectPayload) => void;
  loading?: boolean;
  className?: string;
  /** Fixed height today; Phase 3 makes this fill the dashboard widget frame. */
  height?: number | string;
}

function DynamicGridBase({
  gridData,
  gridOptions,
  onCellClicked,
  onRowSelected,
  loading = false,
  className,
  height = 520,
}: DynamicGridProps) {
  const config = useNormalizedGridData(gridData);
  const overrideState = useCellOverrides(config.cellOverrides);
  const { columnDefs, defaultColDef, baseGridOptions } = useGridConfig(config, overrideState);
  const { apiRef, onGridReady, destroy } = useGridApi();

  // useGridEvents resolves clickability/actionType by field, so it only ever
  // needs the flat leaf columns — group nodes carry no click behaviour of
  // their own and would just be dead weight in that lookup.
  const leafColumns = useMemo(() => flattenColumns(config.columns), [config.columns]);

  const { handleCellClicked, handleSelectionChanged } = useGridEvents({
    columns: leafColumns,
    overrides: overrideState.overrides,
    onCellClicked,
    onRowSelected,
  });

  // Stable row identity: lets AG Grid reuse rows across refreshes instead of
  // rebuilding them, and is the prerequisite for transactional updates later.
  const getRowId = useCallback((params: GetRowIdParams<RowRecord>) => params.data.id, []);

  // Per-cell icon overrides are resolved by the renderer through this lookup.
  const getOverrideIcon = useCallback(
    (rowId: string, field: string) => overrideState.overrides.get(`${rowId}::${field}`)?.icon,
    [overrideState.overrides],
  );

  const context = useMemo(() => ({ getOverrideIcon }), [getOverrideIcon]);

  // App-supplied options win over anything derived from metadata.
  const mergedOptions = useMemo<GridOptions<RowRecord>>(
    () => ({ ...baseGridOptions, ...gridOptions }),
    [baseGridOptions, gridOptions],
  );

  useEffect(() => destroy, [destroy]);

  return (
    <div
      className={`dg-root ag-theme-quartz ${className ?? ''}`.trim()}
      style={{ height, width: '100%' }}
      data-grid-id={config.metadata.gridId}
    >
      <AgGridReact<RowRecord>
        {...mergedOptions}
        rowData={config.rows}
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        components={gridComponents}
        context={context}
        getRowId={getRowId}
        onGridReady={onGridReady}
        onCellClicked={handleCellClicked}
        onSelectionChanged={handleSelectionChanged}
        loading={loading}
        loadingOverlayComponent="dgLoadingOverlay"
        tooltipInteraction
        suppressColumnVirtualisation={false}
        ref={undefined}
      />
      {/* apiRef is available to future phases (state persistence, SSRM datasource). */}
      <span hidden aria-hidden data-has-api={apiRef.current ? 'true' : 'false'} />
    </div>
  );
}

/**
 * memo() matters here: dashboards re-render parents often, and remapping columns
 * for an unchanged payload is the most expensive avoidable work in this component.
 */
export const DynamicGrid = React.memo(DynamicGridBase);
