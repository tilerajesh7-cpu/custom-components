import type { GridConfig } from '../types/gridConfig.types';

/**
 * Normalised (recommended) service shape: flat rows + sparse overrides.
 * Exercises every display type and every branch of the precedence chain.
 */
export const gridServiceResponseMock: GridConfig = {
  metadata: {
    gridId: 'portfolio-positions',
    version: '2026-09-15T10:00:00Z',
    rowModelType: 'clientSide',
    pagination: { enabled: true, pageSize: 25, mode: 'client' },
    features: {
      export: true,
      columnPanel: true,
      pivotEnabled: false,
      masterDetailEnabled: false,
    },
    // Data-shape layout — this grid asks for a slightly taller row than default
    // because several columns carry pills/bars. Container height/width are NOT
    // here; those come from the app via <DynamicGrid height={...} />.
    layout: {
      rowHeight: 44,
      headerHeight: 40,
      groupHeaderHeight: 28,
    },
  },

  columns: [
    {
      field: 'symbol',
      headerName: 'Symbol',
      type: 'text',
      width: 120,
      pinned: 'left',
      clickable: true,
      actionType: 'OPEN_INSTRUMENT',
    },
    { field: 'assetClass', headerName: 'Asset class', type: 'text', filter: 'agSetColumnFilter' },
    {
      field: 'quantity',
      headerName: 'Qty',
      type: 'number',
      display: { type: 'plain', format: 'number:0' },
    },
    {
      // Nested column group — mirrors AG Grid's native ColGroupDef. Grouping is
      // purely a header-level concept: avgPrice/ltp behave exactly as they
      // would ungrouped (same sort, filter, format, overrides).
      headerName: 'Price',
      groupId: 'price',
      children: [
        {
          field: 'avgPrice',
          headerName: 'Avg price',
          type: 'number',
          display: { type: 'plain', format: 'currency:USD:2' },
        },
        {
          field: 'ltp',
          headerName: 'Last price',
          type: 'number',
          display: { type: 'plain', format: 'currency:USD:2' },
        },
      ],
    },
    {
      headerName: 'P&L',
      groupId: 'pnl-group',
      children: [
        {
          field: 'pnl',
          headerName: 'Amount',
          type: 'number',
          width: 150,
          display: {
            type: 'numeric',
            format: 'currency:USD:0',
            config: {
              positiveColor: 'positive',
              negativeColor: 'negative',
              zeroColor: 'muted',
              showSign: true,
              trendIndicator: 'icon',
              // Only P&L beyond ±$7.5k gets a tinted pill — smaller moves stay plain text.
              pillWhenAbs: 7500,
            },
          },
        },
        {
          field: 'pnlPercent',
          headerName: '%',
          type: 'number',
          width: 110,
          display: {
            type: 'numeric',
            format: 'percent:1',
            config: {
              positiveColor: 'positive',
              negativeColor: 'negative',
              zeroColor: 'muted',
              trendIndicator: 'icon',
              negativeStyle: 'parentheses',
            },
          },
        },
      ],
    },
    {
      // Density heatmap — the service sends ONE colour plus min/max and nothing
      // else; the UI derives each cell's tint strength per row.
      // Sample values only: 28.40 sits near max so the label inverts to white,
      // 0.00 gets the faintest tint, and the rest spread across the middle.
      field: 'varCob',
      headerName: 'VaR COB',
      type: 'number',
      width: 120,
      display: {
        type: 'heatmap',
        format: 'number:2',
        config: {
          mode: 'density',
          baseColor: '#1f4e9c',
          min: 0,
          max: 30,
        },
      },
    },
    {
      field: 'marginUtilization',
      headerName: 'Margin used',
      type: 'number',
      width: 150,
      display: {
        type: 'utilization',
        format: 'percent:0',
        config: {
          min: 0,
          max: 100,
          showBar: true,
          thresholds: [
            { upTo: 60, bgColor: '#4ade80', textColor: 'positive' },
            { upTo: 85, bgColor: '#fbbf24', textColor: 'warning' },
            { upTo: 100, bgColor: '#f87171', textColor: 'negative' },
          ],
        },
      },
    },
    {
      field: 'status',
      headerName: 'Status',
      type: 'text',
      width: 130,
      display: {
        type: 'status',
        config: {
          useRenderer: true,
          map: {
            active: { label: 'Active', bgColor: '#e6f4ec', textColor: 'positive', icon: 'icon-check-circle' },
            flagged: { label: 'Flagged', bgColor: '#fbeae9', textColor: 'negative', icon: 'icon-alert-circle' },
            pending: { label: 'Pending', bgColor: '#fdf0d5', textColor: 'warning', icon: 'icon-clock' },
          },
          fallback: { bgColor: '#f3f4f6', textColor: 'muted' },
        },
      },
    },
    {
      field: 'trend',
      headerName: 'Trend',
      type: 'text',
      width: 90,
      display: {
        type: 'icon',
        config: {
          map: { up: 'icon-arrow-up', down: 'icon-arrow-down' },
          showValue: false,
        },
      },
    },
    {
      field: 'exposureNote',
      headerName: 'Notes',
      type: 'text',
      flex: 1,
      tooltip: { type: 'simple' },
    },
    {
      // Cell shows a short human-readable summary; the nested object behind it
      // is surfaced on hover by CustomTooltip. Sending a flat summary string
      // alongside the nested payload avoids the grid ever having to stringify
      // an object into a cell.
      field: 'riskSummary',
      headerName: 'Risk',
      type: 'text',
      width: 150,
      tooltip: { type: 'complex', field: 'riskBreakdown' },
      display: { type: 'plain', format: 'text' },
    },
    {
      field: 'region',
      headerName: 'Region',
      type: 'text',
      width: 100,
      phase2: { enableRowGroup: true, enablePivot: true },
    },
  ],

  rows: [
    {
      id: 'POS-1001',
      symbol: 'AAPL',
      varCob: 28.40,
      assetClass: 'Equity',
      quantity: 500,
      avgPrice: 172.3,
      ltp: 191.1,
      pnl: 9400,
      pnlPercent: 10.9,
      marginUtilization: 42,
      status: 'active',
      trend: 'up',
      exposureNote: 'Within limit, reviewed 09/12',
      riskSummary: 'Tech · β 1.12',
      riskBreakdown: { var95: 4200, beta: 1.12, sector: 'Tech' },
      region: 'NA',
    },
    {
      id: 'POS-1002',
      symbol: 'TSLA',
      varCob: 15.25,
      assetClass: 'Equity',
      quantity: 200,
      avgPrice: 250,
      ltp: 210.5,
      pnl: -7900,
      pnlPercent: -15.8,
      marginUtilization: 91,
      status: 'flagged',
      trend: 'down',
      exposureNote: 'Exceeds sector concentration limit',
      riskSummary: 'Auto · β 1.90',
      riskBreakdown: { var95: 6100, beta: 1.9, sector: 'Auto' },
      region: 'NA',
    },
    {
      // Zero-value row: exercises the neutral branch of the numeric handler.
      id: 'POS-1003',
      symbol: 'INFY',
      varCob: 0.00,
      assetClass: 'Equity',
      quantity: 1000,
      avgPrice: 18.2,
      ltp: 18.2,
      pnl: 0,
      pnlPercent: 0,
      marginUtilization: 12,
      status: 'pending',
      trend: 'up',
      exposureNote: 'Trade settlement in progress',
      riskSummary: 'IT Services · β 0.80',
      riskBreakdown: { var95: 1500, beta: 0.8, sector: 'IT Services' },
      region: 'APAC',
    },
    {
      // P&L above the declared heatmap max: exercises clamping.
      id: 'POS-1004',
      symbol: 'HDFCBANK',
      varCob: 7.10,
      assetClass: 'Equity',
      quantity: 800,
      avgPrice: 1650,
      ltp: 1720.5,
      pnl: 56400,
      pnlPercent: 4.3,
      marginUtilization: 68,
      status: 'active',
      trend: 'up',
      exposureNote: 'Core holding',
      riskSummary: 'Financials · β 1.05',
      riskBreakdown: { var95: 8200, beta: 1.05, sector: 'Financials' },
      region: 'APAC',
    },
    {
      id: 'POS-1005',
      symbol: 'VOD',
      varCob: 2.35,
      assetClass: 'Equity',
      quantity: 3000,
      avgPrice: 9.8,
      ltp: 8.1,
      pnl: -5100,
      pnlPercent: -17.3,
      marginUtilization: 77,
      status: 'flagged',
      trend: 'down',
      exposureNote: 'Currency exposure under review',
      riskSummary: 'Telecom · β 1.30',
      riskBreakdown: { var95: 3900, beta: 1.3, sector: 'Telecom' },
      region: 'EU',
    },
  ],

  // Sparse: three cells out of sixty-five.
  cellOverrides: [
    {
      // tooltip-only override — no icon swap, so the status column keeps one
      // consistent icon family across every row
      rowId: 'POS-1001',
      field: 'status',
      tooltip: { type: 'simple', value: 'Top performer this quarter' },
    },
    {
      // highest-precedence path: explicit style beats the heatmap entirely
      rowId: 'POS-1002',
      field: 'pnl',
      style: { bgColor: '#fef3c7', textColor: '#92400e', fontWeight: '600' },
      clickable: true,
      actionType: 'OPEN_COMPLIANCE_REVIEW',
      tooltip: { type: 'simple', value: 'Manually flagged for compliance review' },
    },
    {
      // clickable without any style change — the two are independent
      rowId: 'POS-1005',
      field: 'status',
      clickable: true,
      actionType: 'OPEN_RISK_DRILLDOWN',
    },
  ],
};

/** Simulated service call. */
export function fetchGridConfig(delayMs = 400): Promise<GridConfig> {
  return new Promise((resolve) => {
    setTimeout(() => resolve(gridServiceResponseMock), delayMs);
  });
}
