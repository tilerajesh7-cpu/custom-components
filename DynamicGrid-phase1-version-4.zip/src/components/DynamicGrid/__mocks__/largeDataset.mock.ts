import type { CellOverride, GridConfig, RowRecord } from '../types/gridConfig.types';
import { gridServiceResponseMock } from './gridServiceResponse.mock';

const SYMBOLS = ['AAPL', 'TSLA', 'INFY', 'HDFCBANK', 'VOD', 'MSFT', 'NVDA', 'RELIANCE', 'BP', 'TCS'];
const ASSET_CLASSES = ['Equity', 'Bond', 'Derivative', 'FX'];
const REGIONS = ['NA', 'EU', 'APAC', 'LATAM'];
const STATUSES = ['active', 'flagged', 'pending'];

/** Deterministic PRNG so profiling runs are comparable across reloads. */
function seeded(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

/**
 * Generated fixture for scroll/virtualisation profiling.
 *
 * Overrides stay sparse on purpose — roughly 0.3% of rows — which is what a real
 * compliance/exception feed looks like. If you need to stress the override path
 * specifically, raise `overrideRate`; payload size should still barely move.
 */
export function generateLargeGridConfig(rowCount = 5000, overrideRate = 0.003): GridConfig {
  const rand = seeded(42);
  const rows: RowRecord[] = new Array(rowCount);
  const cellOverrides: CellOverride[] = [];

  for (let i = 0; i < rowCount; i += 1) {
    const id = `POS-${(10000 + i).toString()}`;
    const avgPrice = Math.round((10 + rand() * 1900) * 100) / 100;
    const drift = (rand() - 0.48) * 0.4;
    const ltp = Math.round(avgPrice * (1 + drift) * 100) / 100;
    const quantity = Math.round(50 + rand() * 4000);
    const pnl = Math.round((ltp - avgPrice) * quantity);
    const pnlPercent = Math.round(drift * 1000) / 10;
    const status = STATUSES[Math.floor(rand() * STATUSES.length)];

    rows[i] = {
      id,
      symbol: SYMBOLS[Math.floor(rand() * SYMBOLS.length)],
      assetClass: ASSET_CLASSES[Math.floor(rand() * ASSET_CLASSES.length)],
      quantity,
      avgPrice,
      ltp,
      pnl,
      pnlPercent,
      marginUtilization: Math.round(rand() * 100),
      status,
      trend: drift >= 0 ? 'up' : 'down',
      exposureNote: status === 'flagged' ? 'Breach pending review' : 'Within limit',
      riskBreakdown: {
        var95: Math.round(rand() * 9000),
        beta: Math.round(rand() * 250) / 100,
        sector: ASSET_CLASSES[Math.floor(rand() * ASSET_CLASSES.length)],
      },
      region: REGIONS[Math.floor(rand() * REGIONS.length)],
    };

    if (rand() < overrideRate) {
      cellOverrides.push({
        rowId: id,
        field: 'pnl',
        style: { bgColor: '#fef3c7', textColor: '#92400e', fontWeight: '600' },
        clickable: true,
        actionType: 'OPEN_COMPLIANCE_REVIEW',
        tooltip: { type: 'simple', value: 'Manually flagged for compliance review' },
      });
    }
  }

  return {
    metadata: {
      ...gridServiceResponseMock.metadata,
      gridId: 'portfolio-positions-large',
      version: `generated-${rowCount}`,
      pagination: { enabled: false, pageSize: 100, mode: 'client' },
    },
    // Heatmap bounds come from metadata, not from scanning these rows.
    columns: gridServiceResponseMock.columns,
    rows,
    cellOverrides,
  };
}

export function fetchLargeGridConfig(rowCount = 5000, delayMs = 200): Promise<GridConfig> {
  return new Promise((resolve) => {
    setTimeout(() => resolve(generateLargeGridConfig(rowCount)), delayMs);
  });
}
