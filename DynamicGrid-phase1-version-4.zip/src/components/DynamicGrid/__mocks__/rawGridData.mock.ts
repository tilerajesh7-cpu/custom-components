import type { RawGridData } from '../types/rawGridData.types';
import { gridServiceResponseMock } from './gridServiceResponse.mock';

/**
 * The legacy wire format the current service returns: positional `cells[]`
 * with metadata inlined per cell. Feeding this to <DynamicGrid> produces the
 * same grid as the flat mock — the adapter is the only difference.
 */
export const rawGridDataMock: RawGridData = {
  metadata: { ...gridServiceResponseMock.metadata, gridId: 'portfolio-positions-raw' },
  columns: gridServiceResponseMock.columns,
  rows: [
    {
      id: 'POS-1001',
      cells: [
        { value: 'AAPL', isClickable: true, actionType: 'OPEN_INSTRUMENT' },
        { value: 'Equity' },
        { value: 500 },
        { value: 172.3 },
        { value: 191.1 },
        { value: 9400 },
        { value: 10.9 },
        { value: 42 },
        { value: 'active', icon: 'icon-star', description: 'Top performer this quarter' },
        { value: 'up' },
        { value: 'Within limit, reviewed 09/12' },
        { value: JSON.stringify({ var95: 4200, beta: 1.12, sector: 'Tech' }) },
        { value: 'NA' },
      ],
    },
    {
      id: 'POS-1002',
      cells: [
        { value: 'TSLA', isClickable: true, actionType: 'OPEN_INSTRUMENT' },
        { value: 'Equity' },
        { value: 200 },
        { value: 250 },
        { value: 210.5 },
        {
          value: -7900,
          isClickable: true,
          actionType: 'OPEN_COMPLIANCE_REVIEW',
          description: 'Manually flagged for compliance review',
          style: { bgColor: '#fef3c7', textColor: '#92400e', fontWeight: '600' },
        },
        { value: -15.8 },
        { value: 91 },
        { value: 'flagged' },
        { value: 'down' },
        { value: 'Exceeds sector concentration limit' },
        { value: JSON.stringify({ var95: 6100, beta: 1.9, sector: 'Auto' }) },
        { value: 'NA' },
      ],
    },
    {
      id: 'POS-1003',
      cells: [
        { value: 'INFY', isClickable: true, actionType: 'OPEN_INSTRUMENT' },
        { value: 'Equity' },
        { value: 1000 },
        { value: 18.2 },
        { value: 18.2 },
        { value: 0 },
        { value: 0 },
        { value: 12 },
        { value: 'pending' },
        { value: 'up' },
        { value: 'Trade settlement in progress' },
        { value: JSON.stringify({ var95: 1500, beta: 0.8, sector: 'IT Services' }) },
        { value: 'APAC' },
      ],
    },
  ],
};

export function fetchRawGridData(delayMs = 400): Promise<RawGridData> {
  return new Promise((resolve) => {
    setTimeout(() => resolve(rawGridDataMock), delayMs);
  });
}
