import type { CellOverride, GridConfig, RowRecord } from '../types/gridConfig.types';
import type { RawGridData } from '../types/rawGridData.types';
import { flattenColumns } from '../utils/columnTree';

/**
 * The ONLY file that knows about the positional `cells[]` wire format.
 *
 * It does two things in a single pass per row:
 *   1. cells[i].value -> flatRow[field], where field comes from the FLATTENED
 *      leaf columns (a column group is a header-only wrapper — it contributes
 *      no cell of its own, so grouped and ungrouped columns share one flat
 *      index sequence left-to-right).
 *   2. any cell metadata that deviates from the column default -> sparse cellOverrides[]
 *
 * Everything downstream sees flat rows and a sparse override list, so swapping the
 * backend format later means editing this file and nothing else.
 */
export function adaptRawGridData(raw: RawGridData): GridConfig {
  // Built once, not per row.
  const leafColumns = flattenColumns(raw.columns);
  const fieldByIndex = leafColumns.map((c) => c.field);
  const columnDefaults = new Map(
    leafColumns.map((c) => [c.field, { clickable: c.clickable === true }]),
  );

  const rows: RowRecord[] = new Array(raw.rows.length);
  const cellOverrides: CellOverride[] = [];

  for (let r = 0; r < raw.rows.length; r += 1) {
    const rawRow = raw.rows[r];
    const flat: RowRecord = { id: rawRow.id };

    const count = Math.min(rawRow.cells.length, fieldByIndex.length);
    for (let c = 0; c < count; c += 1) {
      const field = fieldByIndex[c];
      const cell = rawRow.cells[c];
      flat[field] = cell.value;

      const columnDefault = columnDefaults.get(field);
      const clickableDiffers =
        cell.isClickable !== undefined && cell.isClickable !== columnDefault?.clickable;

      const hasOverride =
        clickableDiffers ||
        cell.description !== undefined ||
        cell.icon !== undefined ||
        cell.style !== undefined ||
        cell.actionType !== undefined;

      // Sparse by construction: default cells contribute nothing.
      if (hasOverride) {
        cellOverrides.push({
          rowId: rawRow.id,
          field,
          ...(clickableDiffers ? { clickable: cell.isClickable } : {}),
          ...(cell.actionType ? { actionType: cell.actionType } : {}),
          ...(cell.icon ? { icon: cell.icon } : {}),
          ...(cell.style ? { style: cell.style } : {}),
          ...(cell.description ? { tooltip: { type: 'simple' as const, value: cell.description } } : {}),
        });
      }
    }

    rows[r] = flat;
  }

  return {
    metadata: raw.metadata,
    columns: raw.columns,
    rows,
    cellOverrides,
  };
}

/** Narrow a payload that may already be in the normalised shape. */
export function isRawGridData(data: GridConfig | RawGridData): data is RawGridData {
  const first = (data as RawGridData).rows?.[0];
  return Boolean(first && Array.isArray((first as { cells?: unknown }).cells));
}
