import React, { memo } from 'react';
import type { ICellRendererParams } from 'ag-grid-community';
import type {
  ColumnDisplay,
  IconConfig,
  NumericConfig,
  StatusConfig,
  UtilizationConfig,
} from '../../types/display.types';
import type { RowRecord } from '../../types/gridConfig.types';
import { clamp, resolveColor } from '../../utils/colorUtils';
import { iconKeyFor } from '../../mappers/display/handlers/iconHandler';
import { numericVisual } from '../../mappers/display/handlers/numericHandler';
import { thresholdFor } from '../../mappers/display/handlers/utilizationHandler';
import { getIcon } from '../icons/IconRegistry';

interface Params extends ICellRendererParams<RowRecord> {
  display: ColumnDisplay;
  columnField: string;
}

/** Injected once by DynamicGrid via the grid `context`, not per cell. */
interface GridContext {
  getOverrideIcon?: (rowId: string, field: string) => string | undefined;
}

/**
 * The only cell renderer in Phase 1. It is attached to a column ONLY when the
 * display handler reports that DOM structure is unavoidable — icons, utilization
 * bars, and opt-in status pills. Everything else renders through native
 * valueFormatter + cellStyle with no React node per cell.
 *
 * memo() keeps AG Grid's cell refresh from re-rendering unchanged cells.
 */
function DynamicCellRendererBase(params: Params) {
  const { display, columnField, value, valueFormatted, data } = params;
  const text = valueFormatted ?? (value === null || value === undefined ? '' : String(value));
  const ctx = params.context as GridContext | undefined;
  const overrideIcon = data ? ctx?.getOverrideIcon?.(data.id, columnField) : undefined;

  if (display.type === 'numeric') {
    const cfg = (display.config ?? {}) as NumericConfig;
    const n = typeof value === 'number' && Number.isFinite(value) ? value : null;
    const visual = numericVisual(value, cfg);

    const iconKey =
      cfg.trendIndicator === 'icon' && n !== null && n !== 0
        ? n > 0
          ? 'icon-trend-up'
          : 'icon-trend-down'
        : undefined;

    // The pill lives on this span, not on the cell, so it hugs the number and
    // can never collide with the rows above or below.
    return (
      <span
        className={visual.isPill ? 'dg-num dg-num--pill' : 'dg-num'}
        style={{
          ...(visual.background ? { backgroundColor: visual.background } : {}),
          ...(visual.color ? { color: visual.color } : {}),
          ...(visual.bold ? { fontWeight: visual.bold } : {}),
        }}
      >
        {getIcon(iconKey)}
        <span className="dg-num__value">{text}</span>
      </span>
    );
  }

  if (display.type === 'icon' || display.type === 'iconWithText') {
    const cfg = display.config as IconConfig | undefined;
    const key = overrideIcon ?? iconKeyFor(value, cfg);
    const icon = getIcon(key);
    const showValue = display.type === 'iconWithText' || cfg?.showValue === true;
    const iconRight = cfg?.position === 'right';

    return (
      <span className="dg-icon-cell" title={text}>
        {!iconRight && icon}
        {showValue && <span className="dg-icon-cell__label">{text}</span>}
        {iconRight && icon}
      </span>
    );
  }

  if (display.type === 'utilization') {
    const cfg = display.config as UtilizationConfig | undefined;
    const numeric = typeof value === 'number' && Number.isFinite(value) ? value : null;
    if (!cfg || numeric === null) return <span>{text}</span>;

    const band = thresholdFor(numeric, cfg);
    const span = cfg.max - cfg.min || 1;
    const pct = clamp(((numeric - cfg.min) / span) * 100, 0, 100);

    return (
      <span className="dg-util-cell">
        <span className="dg-util-cell__track">
          <span
            className="dg-util-cell__bar"
            style={{ width: `${pct}%`, backgroundColor: resolveColor(band?.bgColor) }}
          />
        </span>
        <span className="dg-util-cell__label" style={{ color: resolveColor(band?.textColor) }}>
          {text}
        </span>
      </span>
    );
  }

  if (display.type === 'status') {
    const cfg = display.config as StatusConfig | undefined;
    const entry = cfg && typeof value === 'string' ? cfg.map[value] : undefined;
    const icon = getIcon(overrideIcon ?? entry?.icon);

    return (
      <span
        className="dg-status-pill"
        style={{
          backgroundColor: resolveColor(entry?.bgColor ?? cfg?.fallback?.bgColor),
          color: resolveColor(entry?.textColor ?? cfg?.fallback?.textColor),
        }}
      >
        {icon}
        <span>{entry?.label ?? text}</span>
      </span>
    );
  }

  // Reached when a column only needs a renderer because of a per-cell icon override.
  const icon = getIcon(overrideIcon);
  return (
    <span className="dg-icon-cell">
      {icon}
      <span className="dg-icon-cell__label">{text}</span>
    </span>
  );
}

export const DynamicCellRenderer = memo(DynamicCellRendererBase);
