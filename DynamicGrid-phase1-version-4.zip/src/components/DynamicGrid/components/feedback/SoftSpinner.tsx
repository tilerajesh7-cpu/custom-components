import React from 'react';

export interface SoftSpinnerProps {
  label?: string;
  size?: number;
}

/**
 * Soft, blurred concentric-ring spinner — deliberately not a hard-edged single
 * ring. Two rings rotate at different speeds with a soft glow behind them, which
 * reads as "working" without the mechanical, sharp feel of a native browser
 * spinner. Pure CSS animation, no JS ticking, respects reduced-motion.
 */
export function SoftSpinner({ label = 'Loading', size = 40 }: SoftSpinnerProps) {
  return (
    <div className="dg-spinner" role="status" aria-live="polite" style={{ width: size, height: size }}>
      <span className="dg-spinner__glow" />
      <span className="dg-spinner__ring dg-spinner__ring--outer" />
      <span className="dg-spinner__ring dg-spinner__ring--inner" />
      <span className="dg-spinner__label">{label}</span>
    </div>
  );
}

/** Registered as AG Grid's loadingOverlayComponent — see componentRegistry.ts. */
export function GridLoadingOverlay() {
  return (
    <div className="dg-loading-overlay">
      <SoftSpinner label="Loading positions" size={44} />
    </div>
  );
}
