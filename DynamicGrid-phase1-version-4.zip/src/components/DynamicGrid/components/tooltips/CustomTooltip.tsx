import React, { memo } from 'react';
import type { ITooltipParams } from 'ag-grid-community';
import type { RowRecord } from '../../types/gridConfig.types';

/** Nested payloads may arrive as an object or a JSON string. Parse defensively. */
function toRecord(value: unknown): Record<string, unknown> | null {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  if (typeof value === 'string') {
    try {
      const parsed: unknown = JSON.parse(value);
      return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null;
    } catch {
      return null;
    }
  }
  return null;
}

/** camelCase / snake_case -> "Sentence case", so backend keys stay readable. */
function humanise(key: string): string {
  const spaced = key
    .replace(/[_-]+/g, ' ')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .trim();
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

const LABELS: Record<string, string> = {
  var95: 'VaR (95%)',
  beta: 'Beta',
  sector: 'Sector',
};

const isNumeric = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

/**
 * Used only where a column declares `tooltip.type === 'complex'`.
 * Simple text tooltips stay on AG Grid's native tooltipValueGetter.
 */
function CustomTooltipBase(params: ITooltipParams<RowRecord>) {
  const record = toRecord(params.value);
  const title = params.colDef && 'headerName' in params.colDef ? params.colDef.headerName : undefined;

  if (!record) {
    return (
      <div className="dg-tooltip dg-tooltip--plain">
        <span>{String(params.value ?? '')}</span>
      </div>
    );
  }

  return (
    <div className="dg-tooltip">
      {title ? <div className="dg-tooltip__title">{title}</div> : null}
      <div className="dg-tooltip__body">
        {Object.entries(record).map(([key, val]) => (
          <div className="dg-tooltip__row" key={key}>
            <span className="dg-tooltip__key">{LABELS[key] ?? humanise(key)}</span>
            <span className={isNumeric(val) ? 'dg-tooltip__value dg-tooltip__value--num' : 'dg-tooltip__value'}>
              {isNumeric(val) ? val.toLocaleString() : String(val)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export const CustomTooltip = memo(CustomTooltipBase);
