import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { DynamicGrid } from '../DynamicGrid';
import { fetchGridConfig } from '../__mocks__/gridServiceResponse.mock';
import type { CellClickPayload, GridConfig, RowSelectPayload } from '../types/gridConfig.types';

/**
 * Parent integration example.
 *
 * The app passes three things: the service payload, native AG Grid options, and
 * callbacks. It does not pass column config, styling, or feature flags — those
 * all live in the payload.
 */
export function PortfolioDashboard() {
  const [gridData, setGridData] = useState<GridConfig | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    fetchGridConfig().then((data) => {
      if (cancelled) return;
      setGridData(data);
      setLoading(false);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  // Stable identity — a new object here would remount grid options every render.
  const gridOptions = useMemo(
    () => ({
      rowSelection: 'multiple' as const,
      rowHeight: 36,
      headerHeight: 38,
      paginationPageSizeSelector: [25, 50, 100],
    }),
    [],
  );

  const handleCellClicked = useCallback((payload: CellClickPayload) => {
    // The grid forwards actionType untouched; the app decides what it means.
    switch (payload.actionType) {
      case 'OPEN_COMPLIANCE_REVIEW':
        // openComplianceModal(payload.rowId);
        break;
      case 'OPEN_RISK_DRILLDOWN':
        // openRiskDrawer(payload.rowId);
        break;
      case 'OPEN_INSTRUMENT':
        // navigate(`/instrument/${payload.value}`);
        break;
      default:
        break;
    }
  }, []);

  const handleRowSelected = useCallback((payload: RowSelectPayload) => {
    // setSelection(payload.rowIds);
    void payload;
  }, []);

  if (!gridData) {
    return <div style={{ padding: 16 }}>Loading positions…</div>;
  }

  return (
    <DynamicGrid
      gridData={gridData}
      gridOptions={gridOptions}
      onCellClicked={handleCellClicked}
      onRowSelected={handleRowSelected}
      loading={loading}
      height={560}
    />
  );
}
