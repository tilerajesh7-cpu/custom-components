import { useMemo } from 'react';
import { buildOverrideMap, type OverrideMap } from '../mappers/cellOverrideMapper';
import type { CellOverride } from '../types/gridConfig.types';

export interface CellOverrideState {
  overrides: OverrideMap;
  /** Columns that need a renderer purely because some cell overrides its icon. */
  iconOverrideFields: ReadonlySet<string>;
}

/**
 * Response-scoped by design: the map is rebuilt from the current payload and never
 * merged with a previous one. That makes stale flags impossible and lets Phase 2
 * feed per-block SSRM overrides through unchanged.
 */
export function useCellOverrides(overrides?: CellOverride[]): CellOverrideState {
  return useMemo(() => {
    const map = buildOverrideMap(overrides);
    const iconFields = new Set<string>();
    if (overrides) {
      for (const o of overrides) {
        if (o.icon) iconFields.add(o.field);
      }
    }
    return { overrides: map, iconOverrideFields: iconFields };
  }, [overrides]);
}
