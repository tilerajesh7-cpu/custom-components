import { useCallback, useRef } from 'react';
import type { GridApi, GridReadyEvent } from 'ag-grid-community';
import type { RowRecord } from '../types/gridConfig.types';

/**
 * Holds the grid api in a ref so nothing re-renders when it becomes available.
 *
 * Phase 3 note: this is the attachment point for per-widget identity. When the
 * grid becomes a dashboard widget, the ref is keyed by widgetId so several grids
 * can coexist with independent state.
 */
export function useGridApi() {
  const apiRef = useRef<GridApi<RowRecord> | null>(null);

  const onGridReady = useCallback((event: GridReadyEvent<RowRecord>) => {
    apiRef.current = event.api;
  }, []);

  const destroy = useCallback(() => {
    // Explicit teardown matters once widgets mount/unmount dynamically (Phase 3).
    apiRef.current?.destroy?.();
    apiRef.current = null;
  }, []);

  return { apiRef, onGridReady, destroy };
}
