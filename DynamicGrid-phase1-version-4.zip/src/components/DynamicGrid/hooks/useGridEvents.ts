import { useCallback } from 'react';
import type { CellClickedEvent, SelectionChangedEvent } from 'ag-grid-community';
import { overrideKey, type OverrideMap } from '../mappers/cellOverrideMapper';
import type {
  CellClickPayload,
  ColumnDef,
  RowRecord,
  RowSelectPayload,
} from '../types/gridConfig.types';

interface Args {
  columns: ColumnDef[];
  overrides: OverrideMap;
  onCellClicked?: (payload: CellClickPayload) => void;
  onRowSelected?: (payload: RowSelectPayload) => void;
}

/**
 * One grid-level click handler for the whole grid — not one per cell.
 * It resolves clickability at click time (override first, then column default) and
 * forwards `actionType` to the parent untouched: the grid never interprets it.
 */
export function useGridEvents({ columns, overrides, onCellClicked, onRowSelected }: Args) {
  const handleCellClicked = useCallback(
    (event: CellClickedEvent<RowRecord>) => {
      if (!onCellClicked || !event.data) return;

      const field = event.colDef.field;
      if (!field) return;

      const column = columns.find((c) => c.field === field);
      const override = overrides.get(overrideKey(event.data.id, field));

      const clickable = override?.clickable ?? column?.clickable ?? false;
      if (!clickable) return;

      onCellClicked({
        rowId: event.data.id,
        field,
        value: event.value,
        rowData: event.data,
        actionType: override?.actionType ?? column?.actionType,
      });
    },
    [columns, overrides, onCellClicked],
  );

  const handleSelectionChanged = useCallback(
    (event: SelectionChangedEvent<RowRecord>) => {
      if (!onRowSelected) return;
      const rows = event.api.getSelectedRows();
      onRowSelected({ rowIds: rows.map((r) => r.id), rows });
    },
    [onRowSelected],
  );

  return { handleCellClicked, handleSelectionChanged };
}
