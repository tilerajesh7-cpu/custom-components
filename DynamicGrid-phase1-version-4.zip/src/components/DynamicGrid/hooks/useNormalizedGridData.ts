import { useMemo } from 'react';
import { adaptRawGridData, isRawGridData } from '../adapters/rawGridAdapter';
import type { GridConfig } from '../types/gridConfig.types';
import type { RawGridData } from '../types/rawGridData.types';

/**
 * Normalises whichever payload shape arrives into the internal GridConfig.
 *
 * Memoised on metadata.version so a new object identity from the service layer on
 * every render does not re-run the O(rows x cols) transform. Only the normalised
 * result is kept — the raw payload is not retained.
 */
export function useNormalizedGridData(data: GridConfig | RawGridData): GridConfig {
  const version = data.metadata?.version;

  return useMemo(() => {
    return isRawGridData(data) ? adaptRawGridData(data) : (data as GridConfig);
    // `version` is the real cache key; `data` is included so a payload without a
    // version still behaves correctly (falls back to reference identity).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [version, data]);
}
