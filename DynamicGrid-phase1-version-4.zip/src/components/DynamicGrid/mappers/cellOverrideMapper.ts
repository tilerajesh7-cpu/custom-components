import type { CellOverride } from '../types/gridConfig.types';

export type OverrideMap = ReadonlyMap<string, CellOverride>;

/** Join key. Kept in one place so rows and overrides can never drift apart. */
export const overrideKey = (rowId: string, field: string): string => `${rowId}::${field}`;

/**
 * Builds the rowId::field lookup. Cost is O(overrides), not O(rows) — which is why
 * overrides stay sparse. The map is rebuilt from scratch on every payload and is
 * never merged with a previous one, so SSRM block responses (Phase 2) can feed
 * this function directly with no change.
 */
export function buildOverrideMap(overrides?: CellOverride[]): OverrideMap {
  const map = new Map<string, CellOverride>();
  if (!overrides?.length) return map;
  for (const o of overrides) {
    map.set(overrideKey(o.rowId, o.field), o);
  }
  return map;
}
