import type { CellDisplayType } from '../../types/display.types';
import { heatmapHandler } from './handlers/heatmapHandler';
import { iconHandler, iconWithTextHandler } from './handlers/iconHandler';
import { numericHandler } from './handlers/numericHandler';
import { plainHandler } from './handlers/plainHandler';
import { statusHandler } from './handlers/statusHandler';
import { utilizationHandler } from './handlers/utilizationHandler';
import type { DisplayHandler } from './types';

/**
 * The extension point. A new visual type = one handler file + one line here.
 * No other file in the codebase changes.
 */
export const displayRegistry: Record<CellDisplayType, DisplayHandler> = {
  plain: plainHandler,
  numeric: numericHandler,
  status: statusHandler,
  heatmap: heatmapHandler,
  utilization: utilizationHandler,
  icon: iconHandler,
  iconWithText: iconWithTextHandler,
};

export function getHandler(type?: CellDisplayType): DisplayHandler {
  return (type && displayRegistry[type]) || plainHandler;
}
