import type { HeatmapConfig } from '../../../types/display.types';
import { clamp, densityFill, lerpColor, resolveColor } from '../../../utils/colorUtils';
import type { DisplayHandler } from '../types';

/**
 * Two modes, one handler.
 *
 * DENSITY (default when `baseColor` is set) — the service sends a single hue
 * plus min/max, and the UI derives how strong the tint should be for each cell.
 * Nothing about the colour ramp travels over the wire; the backend only says
 * "this column is blue, and it runs 0 to 30".
 *
 * SCALE — three-stop low/mid/high interpolation, for signed values where the
 * sign picks the hue rather than the magnitude picking the strength.
 *
 * Either way min/max come from the column config, never from scanning rows, so
 * this is O(1) per cell and stays correct under SSRM.
 */
export const heatmapHandler: DisplayHandler = {
  type: 'heatmap',

  getCellStyle(value, ctx) {
    const cfg = ctx.display.config as HeatmapConfig | undefined;
    if (!cfg) return undefined;
    if (typeof value !== 'number' || !Number.isFinite(value)) return undefined;

    const shouldClamp = cfg.clamp !== false;
    const mode = cfg.mode ?? (cfg.baseColor ? 'density' : 'scale');

    if (mode === 'density') {
      const { backgroundColor, invertText } = densityFill(
        value,
        cfg.min,
        cfg.max,
        cfg.baseColor,
        cfg.minAlpha,
        cfg.maxAlpha,
        cfg.invertTextAbove,
        shouldClamp,
      );

      if (cfg.applyTo === 'text') return { color: backgroundColor };

      return {
        backgroundColor,
        // Only forced once the fill is dark enough that the default text would
        // fail contrast — below that the cell keeps the grid's normal ink.
        ...(invertText ? { color: '#ffffff' } : {}),
      };
    }

    const mid = cfg.mid ?? (cfg.min < 0 && cfg.max > 0 ? 0 : (cfg.min + cfg.max) / 2);
    const v = shouldClamp ? clamp(value, cfg.min, cfg.max) : value;
    const midC = (cfg.midColor as string) ?? '#ffffff';

    let color: string;
    if (v >= mid) {
      const span = cfg.max - mid;
      color = lerpColor(midC, (cfg.highColor as string) ?? midC, span === 0 ? 1 : (v - mid) / span);
    } else {
      const span = mid - cfg.min;
      color = lerpColor(midC, (cfg.lowColor as string) ?? midC, span === 0 ? 1 : (mid - v) / span);
    }

    return cfg.applyTo === 'text'
      ? { color }
      : { backgroundColor: color, color: resolveColor('neutral') as string };
  },

  getDisplayText: (value, ctx) => ctx.format(value),
};
