import type { IconConfig } from '../../../types/display.types';
import type { DisplayHandler } from '../types';

export function iconKeyFor(value: unknown, cfg?: IconConfig): string | undefined {
  if (!cfg || typeof value !== 'string') return undefined;
  return cfg.map[value];
}

/** Icon only (optionally with the raw value). Needs DOM, so a renderer is used. */
export const iconHandler: DisplayHandler = {
  type: 'icon',
  getDisplayText: (value, ctx) => ctx.format(value),
  needsRenderer: () => true,
};

/** Icon + label, always both. */
export const iconWithTextHandler: DisplayHandler = {
  type: 'iconWithText',
  getDisplayText: (value, ctx) => ctx.format(value),
  needsRenderer: () => true,
};
