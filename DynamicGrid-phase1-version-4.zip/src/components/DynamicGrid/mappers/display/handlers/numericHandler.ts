import type { NumericConfig } from '../../../types/display.types';
import { resolveColor, resolveSoftBg } from '../../../utils/colorUtils';
import type { DisplayHandler } from '../types';

const asNumber = (v: unknown): number | null =>
  typeof v === 'number' && Number.isFinite(v) ? v : null;

export interface NumericVisual {
  color?: string;
  background?: string;
  bold?: string;
  isPill: boolean;
}

/**
 * Single source of truth for how a numeric value looks. Both the cell style and
 * the renderer read this, so the pill background and the text colour can never
 * disagree about the same value.
 */
export function numericVisual(value: unknown, cfg: NumericConfig): NumericVisual {
  const n = asNumber(value);
  if (n === null) return { isPill: false };

  const usesColor = cfg.negativeStyle !== 'parentheses';
  const key = n > 0 ? 'positiveColor' : n < 0 ? 'negativeColor' : 'zeroColor';
  const color = usesColor ? resolveColor(cfg[key]) : undefined;

  const bold =
    (cfg.bold === 'positive' && n > 0) || (cfg.bold === 'negative' && n < 0) ? '600' : undefined;

  const isPill = cfg.pillWhenAbs !== undefined && Math.abs(n) >= cfg.pillWhenAbs;
  const background = isPill ? resolveSoftBg(cfg[key]) : undefined;

  return { color, background, bold, isPill };
}

/**
 * Sign-aware numbers.
 *
 * A renderer is used when the column needs a trend icon or a pill, because both
 * need an inner element: the pill has to hug the number, and painting it on the
 * cell itself makes a full-width block that collides with the row above and
 * below. Plain coloured numbers stay on the native cellStyle path with no
 * renderer at all.
 */
export const numericHandler: DisplayHandler = {
  type: 'numeric',

  getCellStyle(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const v = numericVisual(value, cfg);

    // When the renderer draws a pill it owns the background AND the text colour
    // inside it — the cell must stay transparent or the pill sits on a slab.
    if (v.isPill) return undefined;

    const style: Record<string, string> = {};
    if (v.color) style.color = v.color;
    if (v.bold) style.fontWeight = v.bold;
    return Object.keys(style).length ? style : undefined;
  },

  getDisplayText(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const n = asNumber(value);
    if (n === null) return ctx.format(value);

    const showParens = cfg.negativeStyle === 'parentheses' || cfg.negativeStyle === 'both';
    if (n < 0 && showParens) return `(${ctx.format(Math.abs(n))})`;
    if (n > 0 && cfg.showSign) return `+${ctx.format(n)}`;
    return ctx.format(n);
  },

  needsRenderer(ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    return cfg.trendIndicator === 'icon' || cfg.pillWhenAbs !== undefined;
  },
};
