import type { UtilizationConfig } from '../../../types/display.types';
import { resolveColor } from '../../../utils/colorUtils';
import type { DisplayHandler } from '../types';

export function thresholdFor(value: number, cfg: UtilizationConfig) {
  // Thresholds are evaluated in order; first match wins. Backend sends them ascending.
  for (const t of cfg.thresholds) {
    if (value <= t.upTo) return t;
  }
  return cfg.thresholds[cfg.thresholds.length - 1];
}

/**
 * Percentage-style values with banded colouring. Flat bands = no renderer.
 * `showBar: true` adds a proportional fill, which does need DOM.
 */
export const utilizationHandler: DisplayHandler = {
  type: 'utilization',

  getCellStyle(value, ctx) {
    const cfg = ctx.display.config as UtilizationConfig | undefined;
    if (!cfg || cfg.showBar) return undefined; // bar variant styles itself
    if (typeof value !== 'number' || !Number.isFinite(value)) return undefined;

    const band = thresholdFor(value, cfg);
    if (!band) return undefined;

    const style: Record<string, string> = { backgroundColor: resolveColor(band.bgColor) as string };
    const fg = resolveColor(band.textColor);
    if (fg) style.color = fg;
    return style;
  },

  getDisplayText: (value, ctx) => ctx.format(value),

  needsRenderer(ctx) {
    return Boolean((ctx.display.config as UtilizationConfig | undefined)?.showBar);
  },
};
