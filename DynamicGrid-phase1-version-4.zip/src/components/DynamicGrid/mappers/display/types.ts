import type { CellDisplayType, ColumnDisplay } from '../../types/display.types';
import type { CellOverride } from '../../types/gridConfig.types';
import type { ValueFormatterFn } from '../../utils/formatters';

/** Plain style object handed back to AG Grid's cellStyle. */
export type CellStyleResult = Record<string, string> | undefined;

export interface HandlerContext {
  display: ColumnDisplay;
  /** Built once per column. */
  format: ValueFormatterFn;
}

/**
 * One handler per display type. Each returns NATIVE AG Grid outputs.
 * A handler only declares `needsRenderer` when DOM structure is unavoidable.
 */
export interface DisplayHandler {
  readonly type: CellDisplayType;

  /** Continuous / data-dependent colour. Return undefined for "no style". */
  getCellStyle?(value: unknown, ctx: HandlerContext, override?: CellOverride): CellStyleResult;

  /** Finite palettes belong here — CSS classes beat inline styles. */
  getCellClass?(value: unknown, ctx: HandlerContext): string | string[] | undefined;

  /** Wraps/replaces the column format (e.g. status labels, accounting negatives). */
  getDisplayText?(value: unknown, ctx: HandlerContext): string;

  /** True only when the cell needs real DOM (icons, bars, pills). */
  needsRenderer?(ctx: HandlerContext): boolean;
}
