# Font files go here

This folder is intentionally empty in the delivered package — font binaries
aren't something to generate, and shipping someone else's font file without
checking your org's license terms isn't something to do silently.

Drop these five files here (exact names, referenced by `dynamicGrid.css`):

```
Inter-Regular.woff2
Inter-Medium.woff2
Inter-SemiBold.woff2
JetBrainsMono-Regular.woff2
JetBrainsMono-Medium.woff2
```

Sources (both open-license, safe to vendor into an internal repo):
- Inter — https://github.com/rsms/inter (SIL Open Font License)
- JetBrains Mono — https://github.com/JetBrains/JetBrainsMono (SIL Open Font License)

If your org already has an approved internal font CDN or asset pipeline,
point the `url()` paths in `dynamicGrid.css` at that instead of this folder.

Until files exist here, the grid renders fine using the system fallback
fonts already defined in `--dg-font-sans` / `--dg-font-mono` — nothing
breaks, nothing waits on a missing file.
