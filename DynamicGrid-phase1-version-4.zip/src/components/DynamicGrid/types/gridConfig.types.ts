import type { ColumnDisplay } from './display.types';
import type { Phase2ColumnFlags, Phase2Features } from './phase2.types';
import type { ColumnNode } from '../utils/columnTree';

export type { ColumnGroupDef, ColumnNode } from '../utils/columnTree';

/** A normalised row: flat field -> value. `id` is mandatory and stable. */
export interface RowRecord {
  id: string;
  [field: string]: unknown;
}

export interface TooltipConfig {
  type: 'simple' | 'complex';
  /** Optional alternative field to read the tooltip text from. */
  field?: string;
}

export interface ColumnDef {
  field: string;
  headerName: string;
  type: 'text' | 'number' | 'date' | 'icon';
  sortable?: boolean;
  filter?: string | false;
  width?: number;
  flex?: number;
  pinned?: 'left' | 'right';
  hide?: boolean;
  /** How this column's cells look. Omitted => plain text. */
  display?: ColumnDisplay;
  tooltip?: TooltipConfig;
  /** Whole-column click affordance. Cell overrides can narrow or widen this. */
  clickable?: boolean;
  actionType?: string;
  /** Parsed but inert until Phase 2. */
  phase2?: Phase2ColumnFlags;
}

/** Direct style escape hatch for a single cell. */
export interface CellStyleOverride {
  bgColor?: string;
  textColor?: string;
  fontWeight?: string;
}

/**
 * Sparse, response-scoped. Only cells that deviate from their column's rules appear here.
 * Never accumulated across fetches — see useCellOverrides.
 */
export interface CellOverride {
  rowId: string;
  field: string;
  /** Swap the display type or patch its config for this cell only. */
  display?: Partial<ColumnDisplay>;
  style?: CellStyleOverride;
  icon?: string;
  tooltip?: { type: 'simple' | 'complex'; value?: string; data?: Record<string, unknown> };
  clickable?: boolean;
  actionType?: string;
}

export interface GridMetadata {
  gridId: string;
  /** Memoisation key. Mapping only re-runs when this changes. */
  version: string;
  rowModelType: 'clientSide' | 'serverSide';
  pagination: {
    enabled: boolean;
    pageSize: number;
    mode: 'client' | 'server';
    totalRows?: number;
  };
  features: Phase2Features;
  /**
   * Data-shape layout — things that vary by WHAT this grid shows, not by
   * WHERE it's placed. A dense 20-column exposure grid wants short rows; a
   * 5-column summary wants taller ones. This is why these are backend-driven.
   *
   * Deliberately excludes container size (height/width): those describe the
   * frame the grid sits in, not the data, and stay an app/props concern so
   * the same grid config works full-page today and as a resizable dashboard
   * widget in Phase 3 without the backend needing to know which.
   *
   * App-provided `gridOptions` always win over this when both set the same
   * key — see gridOptionsMapper.
   */
  layout?: {
    rowHeight?: number;
    headerHeight?: number;
    groupHeaderHeight?: number;
    domLayout?: 'normal' | 'autoHeight';
  };
}

/** The normalised model. Everything downstream of the adapter speaks only this. */
export interface GridConfig {
  metadata: GridMetadata;
  /** Flat columns and column groups may be mixed at the top level. */
  columns: ColumnNode[];
  rows: RowRecord[];
  cellOverrides?: CellOverride[];
}

/** Payload handed to the parent on a cell click. `actionType` is passed through untouched. */
export interface CellClickPayload {
  rowId: string;
  field: string;
  value: unknown;
  rowData: RowRecord;
  actionType?: string;
}

export interface RowSelectPayload {
  rowIds: string[];
  rows: RowRecord[];
}
