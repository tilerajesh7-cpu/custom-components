/**
 * Phase 2 surface area. These fields travel in the payload today and are parsed,
 * but every flag is forced off until the corresponding feature is implemented.
 */

export interface Phase2ColumnFlags {
  enableRowGroup?: boolean;
  enablePivot?: boolean;
  enableValue?: boolean;
  aggFunc?: string;
}

export interface Phase2Features {
  export: boolean;
  columnPanel: boolean;
  /** Phase 2 — pivot panel. */
  pivotEnabled: boolean;
  /** Phase 2 — expandable rows. */
  masterDetailEnabled: boolean;
}

/** Phase 2 — SSRM datasource contract. Declared now so the shape is agreed. */
export interface ServerSideBlockRequest {
  startRow: number;
  endRow: number;
  sortModel: unknown[];
  filterModel: Record<string, unknown>;
}
