import type { ColumnNode } from '../utils/columnTree';
import type { GridMetadata } from './gridConfig.types';

/**
 * The wire format the current service returns: positional `cells[]` aligned by
 * index to the FLATTENED leaf columns (grouping is a header-only concept — it
 * never changes how many data cells a row carries or their order).
 *
 * rawGridAdapter.ts is the ONLY file allowed to know about this shape.
 */
export interface RawCell {
  value: unknown;
  isClickable?: boolean;
  actionType?: string;
  /** Free-text tooltip. */
  description?: string;
  icon?: string;
  style?: { bgColor?: string; textColor?: string; fontWeight?: string };
}

export interface RawRow {
  id: string;
  cells: RawCell[];
}

export interface RawGridData {
  metadata: GridMetadata;
  columns: ColumnNode[];
  rows: RawRow[];
}
