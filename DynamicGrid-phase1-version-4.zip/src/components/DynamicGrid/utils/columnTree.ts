import type { ColumnDef } from '../types/gridConfig.types';

/**
 * A group of columns under one shared header — AG Grid's ColGroupDef, expressed
 * in the backend's vocabulary. `children` may itself contain further groups,
 * though in practice fintech grids rarely nest more than one level deep.
 */
export interface ColumnGroupDef {
  headerName: string;
  groupId?: string;
  /** Mirrors AG Grid's marryChildren — keeps the group's columns adjacent when reordered. */
  marryChildren?: boolean;
  children: ColumnNode[];
}

export type ColumnNode = ColumnDef | ColumnGroupDef;

export function isColumnGroup(node: ColumnNode): node is ColumnGroupDef {
  return Object.prototype.hasOwnProperty.call(node, 'children');
}

/**
 * Flattens a possibly-nested column tree into its leaf ColumnDefs, in the same
 * left-to-right order they'd render. Used anywhere that needs to reason about
 * actual data columns without caring about grouping — the raw cells[] adapter
 * (index alignment) and anywhere counting/validating real fields.
 */
export function flattenColumns(nodes: ColumnNode[]): ColumnDef[] {
  const out: ColumnDef[] = [];
  for (const node of nodes) {
    if (isColumnGroup(node)) {
      out.push(...flattenColumns(node.children));
    } else {
      out.push(node);
    }
  }
  return out;
}
