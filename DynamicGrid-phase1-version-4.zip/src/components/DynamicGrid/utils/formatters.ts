/**
 * Format DSL parser.
 *
 * Supported:
 *   "currency:USD:2"  -> $1,234.56
 *   "percent:1"       -> 12.3%
 *   "number:0"        -> 1,235
 *   "#,##0" / "#,##0.00" (legacy backend patterns) -> number with N decimals
 *   "text" / undefined -> String(value)
 *
 * Intl formatters are created ONCE per column at map time, never per cell.
 */

export type ValueFormatterFn = (value: unknown) => string;

const isNumber = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

function legacyPatternDecimals(pattern: string): number | null {
  if (!pattern.includes('#') && !pattern.includes('0')) return null;
  const dot = pattern.indexOf('.');
  return dot === -1 ? 0 : pattern.length - dot - 1;
}

export function createFormatter(format?: string, locale = 'en-US'): ValueFormatterFn {
  if (!format || format === 'text') {
    return (value) => (value === null || value === undefined ? '' : String(value));
  }

  const [kind, a, b] = format.split(':');

  if (kind === 'currency') {
    const currency = a || 'USD';
    const decimals = Number(b ?? 2);
    const nf = new Intl.NumberFormat(locale, {
      style: 'currency',
      currency,
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
    return (value) => (isNumber(value) ? nf.format(value) : '');
  }

  if (kind === 'percent') {
    const decimals = Number(a ?? 1);
    const nf = new Intl.NumberFormat(locale, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
    // Backend sends 12.3 meaning 12.3% — not 0.123. Do not re-scale.
    return (value) => (isNumber(value) ? `${nf.format(value)}%` : '');
  }

  if (kind === 'number') {
    const decimals = Number(a ?? 0);
    const nf = new Intl.NumberFormat(locale, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    });
    return (value) => (isNumber(value) ? nf.format(value) : '');
  }

  const legacy = legacyPatternDecimals(format);
  if (legacy !== null) {
    const nf = new Intl.NumberFormat(locale, {
      minimumFractionDigits: legacy,
      maximumFractionDigits: legacy,
    });
    return (value) => (isNumber(value) ? nf.format(value) : '');
  }

  return (value) => (value === null || value === undefined ? '' : String(value));
}

/** Strips the sign so numeric display rules can re-apply it (+ / parentheses). */
export function formatAbsolute(fn: ValueFormatterFn, value: number): string {
  return fn(Math.abs(value));
}
