import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { DynamicGrid } from '@/components/DynamicGrid';
import type { CellClickPayload, GridConfig, RawGridData } from '@/components/DynamicGrid';
import { getPortfolioGrid } from '@/services/portfolioService';

export default function PortfolioPage() {
  const [gridData, setGridData] = useState<GridConfig | RawGridData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const controller = new AbortController();

    getPortfolioGrid(controller.signal)
      .then(setGridData)
      .catch((err: unknown) => {
        if (controller.signal.aborted) return;
        setError(err instanceof Error ? err.message : 'Could not load positions');
      });

    return () => controller.abort();
  }, []);

  const gridOptions = useMemo(
    () => ({ rowSelection: 'multiple' as const, rowHeight: 52, headerHeight: 46 }),
    [],
  );

  const handleCellClicked = useCallback((payload: CellClickPayload) => {
    // actionType arrives untouched from the payload — the app decides what it means.
    switch (payload.actionType) {
      case 'OPEN_COMPLIANCE_REVIEW':
        break;
      case 'OPEN_RISK_DRILLDOWN':
        break;
      case 'OPEN_INSTRUMENT':
        break;
      default:
        break;
    }
  }, []);

  if (error) return <div style={{ padding: 16 }}>{error}</div>;
  if (!gridData) return <div style={{ padding: 16 }}>Loading positions…</div>;

  return <DynamicGrid gridData={gridData} gridOptions={gridOptions} onCellClicked={handleCellClicked} height={560} />;
}
