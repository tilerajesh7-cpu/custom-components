import type { GridConfig, RawGridData } from '@/components/DynamicGrid';
import { fetchGridConfig } from '@/components/DynamicGrid/__mocks__';

/**
 * App-owned service layer. The grid never fetches — it receives.
 * Swap the mock call for the real endpoint; the return type is the contract.
 */
export async function getPortfolioGrid(signal?: AbortSignal): Promise<GridConfig | RawGridData> {
  if (import.meta.env?.DEV) {
    return fetchGridConfig();
  }

  const response = await fetch('/api/portfolio/positions', { signal });
  if (!response.ok) {
    throw new Error(`Portfolio grid request failed: ${response.status}`);
  }
  return (await response.json()) as GridConfig | RawGridData;
}
