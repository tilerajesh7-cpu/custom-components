import React, { useCallback, useEffect, useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import type { GetRowIdParams, GridOptions } from 'ag-grid-community';

import { validateGridConfig } from './adapters/validateGridConfig';
import { GridErrorBoundary } from './components/errors/GridErrorBoundary';
import { GridEmptyState, GridErrorState } from './components/errors/GridStates';
import { useDensity, type Density } from './context/DensityContext';
import { useCellOverrides } from './hooks/useCellOverrides';
import { useGridApi } from './hooks/useGridApi';
import { useGridConfig } from './hooks/useGridConfig';
import { useGridEvents } from './hooks/useGridEvents';
import { useNormalizedGridData } from './hooks/useNormalizedGridData';
import { gridComponents } from './registry/componentRegistry';
import { buildDynamicGridTheme } from './theme/dynamicGridTheme';
import type {
  CellClickPayload,
  GridConfig,
  RowRecord,
  RowSelectPayload,
} from './types/gridConfig.types';
import type { GridErrorPayload } from './types/errors.types';
import type { RawGridData } from './types/rawGridData.types';
import { flattenColumns } from './utils/columnTree';

import './styles/dynamicGrid.css';

export interface DynamicGridProps {
  /** Service payload — either the raw `cells[]` shape or the normalised one. */
  gridData: GridConfig | RawGridData;
  /** Native AG Grid passthrough. Anything AG Grid already exposes belongs here. */
  gridOptions?: Partial<GridOptions<RowRecord>>;
  onCellClicked?: (payload: CellClickPayload) => void;
  onRowSelected?: (payload: RowSelectPayload) => void;
  loading?: boolean;
  className?: string;
  /** Overrides the app-wide DensityProvider for this one grid instance only. */
  density?: Density;
  /** Fired on validation failure and render crashes. Wire to Sentry/Datadog. */
  onGridError?: (error: GridErrorPayload) => void;
  /** Called by the Retry button in the error state. */
  onRetry?: () => void;
  /** Message shown when the payload is valid but has zero rows. */
  emptyMessage?: string;
  /** Fixed height today; Phase 3 makes this fill the dashboard widget frame. */
  height?: number | string;
}

function DynamicGridBase({
  gridData,
  gridOptions,
  onCellClicked,
  onRowSelected,
  loading = false,
  className,
  height = 520,
  density,
  onGridError,
  onRetry,
  emptyMessage,
}: DynamicGridProps) {
  const { density: globalDensity } = useDensity();
  const resolvedDensity = density ?? globalDensity;

  // Built once per density value (there are only two) — never rebuilt per
  // render, since AG Grid treats a new theme object as a full re-theme.
  const config = useNormalizedGridData(gridData);

  // Theme is rebuilt only when density or the backend's layout block changes —
  // AG Grid treats a new theme object as a full re-theme, so this must not be
  // recreated per render.
  const layout = config.metadata?.layout;
  const theme = useMemo(
    () => buildDynamicGridTheme(resolvedDensity, layout),
    [resolvedDensity, layout],
  );

  // Trust boundary. Runs once per payload (memoised on the normalised config),
  // not per render. Structural errors stop the render entirely rather than
  // letting malformed data reach a handler and mis-paint a number.
  const validation = useMemo(() => validateGridConfig(config), [config]);

  useEffect(() => {
    if (!validation.ok) {
      onGridError?.({
        type: 'validation',
        message: `Grid config rejected: ${validation.errors.length} error(s)`,
        context: { errors: validation.errors },
      });
    }
    if (validation.warnings.length && process.env.NODE_ENV !== 'production') {
      // eslint-disable-next-line no-console
      console.warn('[DynamicGrid] config warnings', validation.warnings);
    }
  }, [validation, onGridError]);

  const overrideState = useCellOverrides(config.cellOverrides);
  const { columnDefs, defaultColDef, baseGridOptions } = useGridConfig(config, overrideState);
  const { apiRef, onGridReady, destroy } = useGridApi();

  // useGridEvents resolves clickability/actionType by field, so it only ever
  // needs the flat leaf columns — group nodes carry no click behaviour of
  // their own and would just be dead weight in that lookup.
  const leafColumns = useMemo(() => flattenColumns(config.columns), [config.columns]);

  const { handleCellClicked, handleSelectionChanged } = useGridEvents({
    columns: leafColumns,
    overrides: overrideState.overrides,
    onCellClicked,
    onRowSelected,
  });

  // Stable row identity: lets AG Grid reuse rows across refreshes instead of
  // rebuilding them, and is the prerequisite for transactional updates later.
  const getRowId = useCallback((params: GetRowIdParams<RowRecord>) => params.data.id, []);

  // Per-cell icon overrides are resolved by the renderer through this lookup.
  const getOverrideIcon = useCallback(
    (rowId: string, field: string) => overrideState.overrides.get(`${rowId}::${field}`)?.icon,
    [overrideState.overrides],
  );

  const context = useMemo(() => ({ getOverrideIcon }), [getOverrideIcon]);

  // App-supplied options win over anything derived from metadata.
  const mergedOptions = useMemo<GridOptions<RowRecord>>(
    () => ({ ...baseGridOptions, ...gridOptions }),
    [baseGridOptions, gridOptions],
  );

  useEffect(() => destroy, [destroy]);

  if (!validation.ok) {
    return (
      <div className={`dg-root ${className ?? ''}`.trim()} style={{ height, width: '100%' }}>
        <GridErrorState
          details={validation.errors.map((e) => `${e.path}: ${e.message}`)}
          onRetry={onRetry}
        />
      </div>
    );
  }

  const isEmpty = !loading && config.rows.length === 0;

  return (
    <div
      className={`dg-root ${className ?? ''}`.trim()}
      style={{ height, width: '100%' }}
      data-grid-id={config.metadata.gridId}
      data-density={resolvedDensity}
    >
      <AgGridReact<RowRecord>
        {...mergedOptions}
        theme={theme}
        rowData={config.rows}
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        components={gridComponents}
        context={context}
        getRowId={getRowId}
        onGridReady={onGridReady}
        onCellClicked={handleCellClicked}
        onSelectionChanged={handleSelectionChanged}
        loading={loading}
        loadingOverlayComponent="dgLoadingOverlay"
        tooltipInteraction
        suppressColumnVirtualisation={false}
        ref={undefined}
      />
      {isEmpty ? <GridEmptyState message={emptyMessage} /> : null}
      {/* apiRef is available to future phases (state persistence, SSRM datasource). */}
      <span hidden aria-hidden data-has-api={apiRef.current ? 'true' : 'false'} />
    </div>
  );
}

/**
 * memo() matters here: dashboards re-render parents often, and remapping columns
 * for an unchanged payload is the most expensive avoidable work in this component.
 */
const MemoisedGrid = React.memo(DynamicGridBase);

/**
 * The exported component is wrapped in an error boundary BY DEFAULT, so a
 * consuming app can't accidentally ship without one. A render crash is
 * contained to the grid's own box instead of unmounting the page around it.
 */
export function DynamicGrid(props: DynamicGridProps) {
  return (
    <GridErrorBoundary onGridError={props.onGridError} onRetry={props.onRetry}>
      <MemoisedGrid {...props} />
    </GridErrorBoundary>
  );
}
