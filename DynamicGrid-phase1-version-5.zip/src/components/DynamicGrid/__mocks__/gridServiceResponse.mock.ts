import type { GridConfig } from '../types/gridConfig.types';
import { CellDisplayType, IconTone, TooltipType, ValueMode } from '../types/enums';

/**
 * Normalised (recommended) service shape: flat rows + sparse overrides.
 * Exercises every display type and every branch of the precedence chain.
 */
export const gridServiceResponseMock: GridConfig = {
  metadata: {
    gridId: 'portfolio-positions',
    schemaVersion: 1,
    version: '2026-09-15T10:00:00Z',
    locale: 'en-US',
    rowModelType: 'clientSide',
    pagination: { enabled: true, pageSize: 25, mode: 'client' },
    features: {
      export: true,
      columnPanel: true,
      pivotEnabled: false,
      masterDetailEnabled: false,
    },
    // Data-shape layout — this grid asks for a slightly taller row than default
    // because several columns carry pills/bars. Container height/width are NOT
    // here; those come from the app via <DynamicGrid height={...} />.
    layout: {
      rowHeight: 44,
      headerHeight: 40,
      groupHeaderHeight: 28,
    },
  },

  columns: [
    {
      field: 'symbol',
      headerName: 'Symbol',
      type: 'text',
      width: 120,
      pinned: 'left',
      clickable: true,
      actionType: 'OPEN_INSTRUMENT',
    },
    { field: 'assetClass', headerName: 'Asset class', type: 'text', filter: 'agSetColumnFilter' },
    {
      field: 'quantity',
      headerName: 'Qty',
      type: 'number',
      display: { type: CellDisplayType.PLAIN, format: 'number:0' },
    },
    {
      // Nested column group — mirrors AG Grid's native ColGroupDef. Grouping is
      // purely a header-level concept: avgPrice/ltp behave exactly as they
      // would ungrouped (same sort, filter, format, overrides).
      headerName: 'Price',
      groupId: 'price',
      children: [
        {
          // PRE_FORMATTED: the backend already owns currency/locale conversion
          // for prices (desk-local currency, region-specific separators), so
          // it sends the final string directly — the UI does not format this.
          field: 'avgPrice',
          headerName: 'Avg price',
          type: 'number',
          valueMode: ValueMode.PRE_FORMATTED,
          displayField: 'avgPriceDisplay',
          tooltip: { type: TooltipType.VALUE, field: 'avgPrice' },
        },
        {
          field: 'ltp',
          headerName: 'Last price',
          type: 'number',
          valueMode: ValueMode.PRE_FORMATTED,
          displayField: 'ltpDisplay',
          tooltip: { type: TooltipType.VALUE, field: 'ltp' },
        },
      ],
    },
    {
      headerName: 'P&L',
      groupId: 'pnl-group',
      children: [
        {
          // PRE_FORMATTED for TEXT only — pnl still carries the raw number so
          // the numeric handler can still colour/pill/trend-icon it. Only the
          // string that appears in the cell comes from the backend now.
          field: 'pnl',
          headerName: 'Amount',
          type: 'number',
          width: 150,
          valueMode: ValueMode.PRE_FORMATTED,
          displayField: 'pnlDisplay',
          tooltip: { type: TooltipType.VALUE, field: 'pnl' },
          display: {
            type: CellDisplayType.NUMERIC,
            config: {
              positiveColor: 'positive',
              negativeColor: 'negative',
              zeroColor: 'muted',
              showSign: true,
              trendIndicator: 'icon',
              // Only P&L beyond ±$7.5k gets a tinted pill — smaller moves stay plain text.
              pillWhenAbs: 7500,
            },
          },
        },
        {
          field: 'pnlPercent',
          headerName: '%',
          type: 'number',
          width: 110,
          display: {
            type: CellDisplayType.NUMERIC,
            format: 'percent:1',
            config: {
              positiveColor: 'positive',
              negativeColor: 'negative',
              zeroColor: 'muted',
              trendIndicator: 'icon',
              negativeStyle: 'parentheses',
            },
          },
        },
      ],
    },
    {
      // Density heatmap — the service sends ONE colour plus min/max and nothing
      // else; the UI derives each cell's tint strength per row.
      // Sample values only: 28.40 sits near max so the label inverts to white,
      // 0.00 gets the faintest tint, and the rest spread across the middle.
      field: 'varCob',
      headerName: 'VaR COB',
      type: 'number',
      width: 120,
      display: {
        type: CellDisplayType.HEATMAP,
        format: 'number:2',
        config: {
          mode: 'density',
          // Semantic tone only — the UI owns the hue and every alpha step.
          tone: 'info',
          min: 0,
          max: 30,
        },
      },
    },
    {
      field: 'marginUtilization',
      headerName: 'Margin used',
      type: 'number',
      width: 150,
      display: {
        type: CellDisplayType.UTILIZATION,
        format: 'percent:0',
        config: {
          min: 0,
          max: 100,
          showBar: true,
          thresholds: [
            { upTo: 60, bgColor: 'positive', textColor: 'positive' },
            { upTo: 85, bgColor: 'warning', textColor: 'warning' },
            { upTo: 100, bgColor: 'negative', textColor: 'negative' },
          ],
        },
      },
    },
    {
      field: 'status',
      headerName: 'Status',
      type: 'text',
      width: 130,
      display: {
        type: CellDisplayType.STATUS,
        config: {
          useRenderer: true,
          map: {
            // tone drives colour AND glyph — no icon keys, no hex.
            active: { label: 'Active', tone: IconTone.POSITIVE },
            flagged: { label: 'Flagged', tone: IconTone.NEGATIVE },
            pending: { label: 'Pending', tone: IconTone.WARNING },
          },
          fallback: { bgColor: 'muted', textColor: 'muted' },
        },
      },
    },
    {
      field: 'trend',
      headerName: 'Trend',
      type: 'text',
      width: 90,
      display: {
        type: CellDisplayType.ICON,
        config: {
          map: { up: 'icon-trend-up', down: 'icon-trend-down' },
          showValue: false,
        },
      },
    },
    {
      field: 'exposureNote',
      headerName: 'Notes',
      type: 'text',
      flex: 1,
      tooltip: { type: TooltipType.SIMPLE },
    },
    {
      // Cell shows a short human-readable summary; the nested object behind it
      // is surfaced on hover by CustomTooltip. Sending a flat summary string
      // alongside the nested payload avoids the grid ever having to stringify
      // an object into a cell.
      field: 'riskSummary',
      headerName: 'Risk',
      type: 'text',
      width: 150,
      tooltip: { type: TooltipType.COMPLEX, field: 'riskBreakdown' },
      display: { type: CellDisplayType.PLAIN, format: 'text' },
    },
    {
      field: 'region',
      headerName: 'Region',
      type: 'text',
      width: 100,
      phase2: { enableRowGroup: true, enablePivot: true },
    },
  ],

  rows: [
    {
      id: 'POS-1001',
      symbol: 'AAPL',
      varCob: 28.40,
      assetClass: 'Equity',
      quantity: 500,
      avgPrice: 172.3,
      avgPriceDisplay: '$172.30',
      ltp: 191.1,
      ltpDisplay: '$191.10',
      pnl: 9400,
      pnlDisplay: '+$9,400',
      pnlPercent: 10.9,
      marginUtilization: 42,
      status: 'active',
      trend: 'up',
      exposureNote: 'Within limit, reviewed 09/12',
      riskSummary: 'Tech · β 1.12',
      riskBreakdown: { var95: 4200, beta: 1.12, sector: 'Tech' },
      region: 'NA',
    },
    {
      id: 'POS-1002',
      symbol: 'TSLA',
      varCob: 15.25,
      assetClass: 'Equity',
      quantity: 200,
      avgPrice: 250,
      avgPriceDisplay: '$250.00',
      ltp: 210.5,
      ltpDisplay: '$210.50',
      pnl: -7900,
      pnlDisplay: '-$7,900',
      pnlPercent: -15.8,
      marginUtilization: 91,
      status: 'flagged',
      trend: 'down',
      exposureNote: 'Exceeds sector concentration limit',
      riskSummary: 'Auto · β 1.90',
      riskBreakdown: { var95: 6100, beta: 1.9, sector: 'Auto' },
      region: 'NA',
    },
    {
      // Zero-value row: exercises the neutral branch of the numeric handler.
      id: 'POS-1003',
      symbol: 'INFY',
      varCob: 0.00,
      assetClass: 'Equity',
      quantity: 1000,
      avgPrice: 18.2,
      avgPriceDisplay: '$18.20',
      ltp: 18.2,
      ltpDisplay: '$18.20',
      pnl: 0,
      pnlDisplay: '$0',
      pnlPercent: 0,
      marginUtilization: 12,
      status: 'pending',
      trend: 'up',
      exposureNote: 'Trade settlement in progress',
      riskSummary: 'IT Services · β 0.80',
      riskBreakdown: { var95: 1500, beta: 0.8, sector: 'IT Services' },
      region: 'APAC',
    },
    {
      // P&L above the declared heatmap max: exercises clamping.
      id: 'POS-1004',
      symbol: 'HDFCBANK',
      varCob: 7.10,
      assetClass: 'Equity',
      quantity: 800,
      avgPrice: 1650,
      avgPriceDisplay: '$1,650.00',
      ltp: 1720.5,
      ltpDisplay: '$1,720.50',
      pnl: 56400,
      pnlDisplay: '+$56,400',
      pnlPercent: 4.3,
      marginUtilization: 68,
      status: 'active',
      trend: 'up',
      exposureNote: 'Core holding',
      riskSummary: 'Financials · β 1.05',
      riskBreakdown: { var95: 8200, beta: 1.05, sector: 'Financials' },
      region: 'APAC',
    },
    {
      id: 'POS-1005',
      symbol: 'VOD',
      varCob: 2.35,
      assetClass: 'Equity',
      quantity: 3000,
      avgPrice: 9.8,
      avgPriceDisplay: '$9.80',
      ltp: 8.1,
      ltpDisplay: '$8.10',
      pnl: -5100,
      pnlDisplay: '-$5,100',
      pnlPercent: -17.3,
      marginUtilization: 77,
      status: 'flagged',
      trend: 'down',
      exposureNote: 'Currency exposure under review',
      riskSummary: 'Telecom · β 1.30',
      riskBreakdown: { var95: 3900, beta: 1.3, sector: 'Telecom' },
      region: 'EU',
    },
  ],

  // Sparse: three cells out of sixty-five.
  cellOverrides: [
    {
      // tooltip-only override — no icon swap, so the status column keeps one
      // consistent icon family across every row
      rowId: 'POS-1001',
      field: 'status',
      tooltip: { type: TooltipType.SIMPLE, value: 'Top performer this quarter' },
    },
    {
      // highest-precedence path: explicit style beats the heatmap entirely
      rowId: 'POS-1002',
      field: 'pnl',
      // Tokens, not hex — an override may change WHICH tone applies, never
      // introduce a colour outside the palette.
      style: { bgColor: 'warning', textColor: 'warning', fontWeight: '600' },
      clickable: true,
      actionType: 'OPEN_COMPLIANCE_REVIEW',
      tooltip: { type: TooltipType.SIMPLE, value: 'Manually flagged for compliance review' },
    },
    {
      // clickable without any style change — the two are independent
      rowId: 'POS-1005',
      field: 'status',
      clickable: true,
      actionType: 'OPEN_RISK_DRILLDOWN',
    },
  ],
};

/** Simulated service call. */
export function fetchGridConfig(delayMs = 400): Promise<GridConfig> {
  return new Promise((resolve) => {
    setTimeout(() => resolve(gridServiceResponseMock), delayMs);
  });
}
