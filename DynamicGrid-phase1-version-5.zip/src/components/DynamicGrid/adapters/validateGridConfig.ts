import type { GridConfig } from '../types/gridConfig.types';
import type { ColumnNode } from '../utils/columnTree';
import { isColumnGroup } from '../utils/columnTree';
import { CellDisplayType, ValueMode } from '../types/enums';
import { SUPPORTED_SCHEMA_VERSION } from '../types/gridConfig.types';

/**
 * Runtime validation at the trust boundary.
 *
 * TypeScript types vanish at runtime, so a backend that sends `min` as a string
 * or misspells a display type would otherwise fail deep inside a handler —
 * mid-render, with a useless stack trace, possibly after painting a wrong
 * number on screen. For a grid a trader reads, that is the worst failure mode
 * available. This catches it at the door instead.
 *
 * Deliberately hand-written rather than zod: no new dependency, and the checks
 * are shallow enough that a schema library would be more indirection than
 * value. If the schema grows much past this, swap in zod behind the same
 * function signature.
 *
 * Philosophy: reject STRUCTURE errors (things that would crash or mis-render),
 * warn on SUSPICIOUS ones (things that silently do nothing), ignore unknown
 * extra fields entirely so the backend can add fields without a UI release.
 */

export interface ValidationIssue {
  path: string;
  message: string;
  severity: 'error' | 'warning';
}

export type ValidationResult =
  | { ok: true; data: GridConfig; warnings: ValidationIssue[] }
  | { ok: false; errors: ValidationIssue[]; warnings: ValidationIssue[] };

const DISPLAY_TYPES = new Set<string>(Object.values(CellDisplayType));

const isObj = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v);

function validateColumn(node: ColumnNode, path: string, errors: ValidationIssue[], warnings: ValidationIssue[]): void {
  if (isColumnGroup(node)) {
    if (!node.headerName) {
      errors.push({ path: `${path}.headerName`, message: 'column group requires headerName', severity: 'error' });
    }
    if (!Array.isArray(node.children) || node.children.length === 0) {
      errors.push({ path: `${path}.children`, message: 'column group requires a non-empty children array', severity: 'error' });
      return;
    }
    node.children.forEach((child, i) => validateColumn(child, `${path}.children[${i}]`, errors, warnings));
    return;
  }

  if (!node.field) {
    errors.push({ path: `${path}.field`, message: 'column requires a field', severity: 'error' });
  }

  const display = node.display;
  if (display) {
    if (!DISPLAY_TYPES.has(display.type)) {
      errors.push({
        path: `${path}.display.type`,
        message: `unknown display type "${display.type}" — expected one of ${[...DISPLAY_TYPES].join(', ')}`,
        severity: 'error',
      });
    }

    // Heatmap without usable bounds silently renders every cell identically.
    if (display.type === CellDisplayType.HEATMAP) {
      const cfg = display.config as { min?: unknown; max?: unknown } | undefined;
      if (typeof cfg?.min !== 'number' || typeof cfg?.max !== 'number') {
        errors.push({
          path: `${path}.display.config`,
          message: 'heatmap requires numeric min and max (the UI never scans rows to derive them)',
          severity: 'error',
        });
      } else if (cfg.min === cfg.max) {
        warnings.push({
          path: `${path}.display.config`,
          message: 'heatmap min equals max — every cell will render at the same intensity',
          severity: 'warning',
        });
      }
    }
  }

  if (node.valueMode === ValueMode.PRE_FORMATTED) {
    if (!node.displayField) {
      errors.push({
        path: `${path}.displayField`,
        message: 'valueMode PRE_FORMATTED requires displayField naming the pre-formatted row field',
        severity: 'error',
      });
    }
    // These only affect TEXT, which the backend now owns — they silently do nothing.
    const cfg = node.display?.config as Record<string, unknown> | undefined;
    if (cfg && ('showSign' in cfg || 'negativeStyle' in cfg)) {
      warnings.push({
        path: `${path}.display.config`,
        message: 'showSign/negativeStyle have no effect on a PRE_FORMATTED column — the backend string is rendered verbatim',
        severity: 'warning',
      });
    }
  }
}

export function validateGridConfig(raw: unknown): ValidationResult {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];

  if (!isObj(raw)) {
    return { ok: false, errors: [{ path: '', message: 'payload is not an object', severity: 'error' }], warnings };
  }

  if (!isObj(raw.metadata)) {
    errors.push({ path: 'metadata', message: 'metadata is required', severity: 'error' });
  } else {
    if (typeof raw.metadata.gridId !== 'string') {
      errors.push({ path: 'metadata.gridId', message: 'gridId must be a string', severity: 'error' });
    }

    // Version gate. A payload from a NEWER contract than this build understands
    // is rejected outright rather than partially applied — half-applying a
    // contract we don't know is how fields get silently dropped.
    const version = raw.metadata.schemaVersion;
    if (typeof version === 'number' && version > SUPPORTED_SCHEMA_VERSION) {
      errors.push({
        path: 'metadata.schemaVersion',
        message: `payload schemaVersion ${version} is newer than this build supports (${SUPPORTED_SCHEMA_VERSION}) — upgrade the UI`,
        severity: 'error',
      });
    }
    if (version === undefined) {
      warnings.push({
        path: 'metadata.schemaVersion',
        message: 'payload has no schemaVersion — assuming current; producers should send it explicitly',
        severity: 'warning',
      });
    }
  }

  if (!Array.isArray(raw.columns)) {
    errors.push({ path: 'columns', message: 'columns must be an array', severity: 'error' });
  } else {
    (raw.columns as ColumnNode[]).forEach((c, i) => validateColumn(c, `columns[${i}]`, errors, warnings));
  }

  if (!Array.isArray(raw.rows)) {
    errors.push({ path: 'rows', message: 'rows must be an array', severity: 'error' });
  } else {
    // getRowId depends on this — a missing id breaks row identity silently.
    const missing = (raw.rows as unknown[]).findIndex((r) => !isObj(r) || typeof r.id !== 'string');
    if (missing !== -1) {
      errors.push({ path: `rows[${missing}].id`, message: 'every row requires a string id', severity: 'error' });
    }
  }

  if (raw.cellOverrides !== undefined && !Array.isArray(raw.cellOverrides)) {
    errors.push({ path: 'cellOverrides', message: 'cellOverrides must be an array when present', severity: 'error' });
  }

  if (errors.length) return { ok: false, errors, warnings };
  return { ok: true, data: raw as unknown as GridConfig, warnings };
}
