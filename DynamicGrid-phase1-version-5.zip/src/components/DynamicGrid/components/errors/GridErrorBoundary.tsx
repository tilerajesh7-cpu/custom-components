import React from 'react';
import { GridErrorState } from './GridStates';
import type { GridErrorPayload } from '../../types/errors.types';

interface Props {
  children: React.ReactNode;
  onGridError?: (error: GridErrorPayload) => void;
  onRetry?: () => void;
  fallback?: React.ReactNode;
}

interface State {
  hasError: boolean;
  message?: string;
}

/**
 * Must be a class — React has no hook equivalent for error boundaries.
 *
 * Without this, a throw anywhere inside the grid (a formatter hitting an
 * unexpected shape, a renderer on bad config) unmounts the WHOLE React tree
 * above it, not just the grid. On a trading dashboard that means one bad
 * column config blanks the entire page. This contains the blast radius to the
 * grid's own box.
 */
export class GridErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo): void {
    this.props.onGridError?.({
      type: 'render',
      message: error.message,
      context: { componentStack: info.componentStack },
    });
  }

  private handleRetry = (): void => {
    this.setState({ hasError: false, message: undefined });
    this.props.onRetry?.();
  };

  render(): React.ReactNode {
    if (!this.state.hasError) return this.props.children;
    if (this.props.fallback) return this.props.fallback;
    return (
      <GridErrorState
        details={this.state.message ? [this.state.message] : undefined}
        onRetry={this.handleRetry}
      />
    );
  }
}
