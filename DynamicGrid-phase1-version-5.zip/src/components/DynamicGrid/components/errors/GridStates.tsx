import React from 'react';
import { getIcon } from '../icons/IconRegistry';

/** Shown when the payload is valid but contains no rows. */
export function GridEmptyState({ message = 'No rows to display' }: { message?: string }) {
  return (
    <div className="dg-state" role="status">
      <span className="dg-state__icon dg-state__icon--muted">{getIcon('icon-dot-circle')}</span>
      <p className="dg-state__title">{message}</p>
    </div>
  );
}

export interface GridErrorStateProps {
  title?: string;
  /** Field-level detail from validation, or an error message. Dev builds only. */
  details?: string[];
  onRetry?: () => void;
}

/**
 * Shown by the error boundary and by validation failure. Deliberately shows a
 * plain message in production and the failing field paths in dev — a trader
 * needs "this didn't load, retry"; an engineer needs "columns[3].display.type".
 */
export function GridErrorState({ title = "This view couldn't load", details, onRetry }: GridErrorStateProps) {
  const isDev = process.env.NODE_ENV !== 'production';
  return (
    <div className="dg-state" role="alert">
      <span className="dg-state__icon dg-state__icon--error">{getIcon('icon-alert-circle')}</span>
      <p className="dg-state__title">{title}</p>
      {isDev && details?.length ? (
        <ul className="dg-state__details">
          {details.slice(0, 5).map((d) => (
            <li key={d}>{d}</li>
          ))}
          {details.length > 5 ? <li>{`+${details.length - 5} more`}</li> : null}
        </ul>
      ) : null}
      {onRetry ? (
        <button type="button" className="dg-state__action" onClick={onRetry}>
          Retry
        </button>
      ) : null}
    </div>
  );
}
