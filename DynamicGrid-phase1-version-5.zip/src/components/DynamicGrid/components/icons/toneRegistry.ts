import type { IconTone } from '../../types/enums';

/**
 * tone -> default glyph. The backend never names an icon; it names a meaning.
 *
 * This is the same indirection ColorToken already provides for colour: one
 * place to change if the icon set is ever swapped, and every 'positive' status
 * in every grid in the app stays visually identical for free.
 */
export const TONE_ICON: Record<IconTone, string> = {
  positive: 'icon-check-circle',
  negative: 'icon-alert-circle',
  warning: 'icon-clock',
  info: 'icon-dot-circle',
  neutral: 'icon-minus',
};

/** tone -> (soft background, text colour) token pair. */
export const TONE_COLORS: Record<IconTone, { bg: string; text: string }> = {
  positive: { bg: 'positive', text: 'positive' },
  negative: { bg: 'negative', text: 'negative' },
  warning: { bg: 'warning', text: 'warning' },
  info: { bg: 'info', text: 'info' },
  neutral: { bg: 'muted', text: 'muted' },
};

export function iconForTone(tone: IconTone | undefined, explicitIcon?: string): string | undefined {
  if (explicitIcon) return explicitIcon;
  return tone ? TONE_ICON[tone] : undefined;
}
