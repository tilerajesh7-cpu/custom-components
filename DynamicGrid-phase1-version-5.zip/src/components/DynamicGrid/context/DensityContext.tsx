import React, { createContext, useContext, useMemo, useState } from 'react';

export type Density = 'compact' | 'comfortable';

interface DensityContextValue {
  density: Density;
  setDensity: (d: Density) => void;
}

const DensityContext = createContext<DensityContextValue | null>(null);

/**
 * App-level toggle. Wrap once near the root; every <DynamicGrid> underneath
 * re-reads this and switches its AG Grid theme instantly — no prop drilling,
 * no per-grid wiring. A grid can still override with its own `density` prop
 * for the rare case one grid needs to differ from the global setting.
 */
export function DensityProvider({
  children,
  initialDensity = 'comfortable',
}: {
  children: React.ReactNode;
  initialDensity?: Density;
}) {
  const [density, setDensity] = useState<Density>(initialDensity);
  const value = useMemo(() => ({ density, setDensity }), [density]);
  return <DensityContext.Provider value={value}>{children}</DensityContext.Provider>;
}

/** Falls back to 'comfortable' when no provider is mounted, so a lone grid still works. */
export function useDensity(): DensityContextValue {
  const ctx = useContext(DensityContext);
  return ctx ?? { density: 'comfortable', setDensity: () => {} };
}
