import { useMemo } from 'react';
import type { ColDef, ColGroupDef, GridOptions } from 'ag-grid-community';
import { mapColumns } from '../mappers/columnMapper';
import { mapGridOptions } from '../mappers/gridOptionsMapper';
import type { GridConfig, RowRecord } from '../types/gridConfig.types';
import type { CellOverrideState } from './useCellOverrides';

export interface MappedGridConfig {
  columnDefs: (ColDef<RowRecord> | ColGroupDef<RowRecord>)[];
  defaultColDef: ColDef<RowRecord>;
  baseGridOptions: GridOptions<RowRecord>;
}

const DEFAULT_COL_DEF: ColDef<RowRecord> = {
  sortable: true,
  resizable: true,
  filter: true,
  minWidth: 90,
  // Keeps sort/filter menus off the header until hovered — less DOM per column.
  suppressHeaderMenuButton: false,
};

/**
 * Single memoised derivation of everything AG Grid needs.
 * Re-runs only when the payload version, column list, or override map changes —
 * not on unrelated parent re-renders.
 */
export function useGridConfig(
  config: GridConfig,
  overrideState: CellOverrideState,
): MappedGridConfig {
  const { columns, metadata } = config;
  const { overrides, iconOverrideFields } = overrideState;

  const locale = metadata.locale;

  const columnDefs = useMemo(
    () => mapColumns(columns, { overrides, iconOverrideFields, locale }),
    [columns, overrides, iconOverrideFields, locale],
  );

  const baseGridOptions = useMemo(() => mapGridOptions(metadata), [metadata]);

  return { columnDefs, defaultColDef: DEFAULT_COL_DEF, baseGridOptions };
}
