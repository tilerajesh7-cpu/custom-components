import { describe, expect, it } from 'vitest';
import type { ColDef } from 'ag-grid-community';
import { mapColumns } from '../columnMapper';
import { buildOverrideMap } from '../cellOverrideMapper';
import { CellDisplayType, ValueMode } from '../../types/enums';
import type { ColumnDef, RowRecord } from '../../types/gridConfig.types';

const row = (over: Partial<RowRecord> = {}): RowRecord => ({ id: 'R1', pnl: 1000, ...over });

function styleOf(colDef: ColDef<RowRecord>, data: RowRecord, value: unknown) {
  const fn = colDef.cellStyle as (p: unknown) => Record<string, string> | undefined;
  return fn({ data, value, colDef });
}

function textOf(colDef: ColDef<RowRecord>, data: RowRecord, value: unknown) {
  const fn = colDef.valueFormatter as (p: unknown) => string;
  return fn({ data, value, colDef });
}

const numericColumn: ColumnDef = {
  field: 'pnl',
  headerName: 'P&L',
  type: 'number',
  display: {
    type: CellDisplayType.NUMERIC,
    format: 'number:0',
    config: { positiveColor: 'positive', negativeColor: 'negative', zeroColor: 'muted' },
  },
};

const deps = (overrides = buildOverrideMap([]), icons = new Set<string>()) => ({
  overrides,
  iconOverrideFields: icons,
});

/**
 * The precedence chain is the single most load-bearing piece of logic in the
 * component — every display feature depends on it resolving in this exact order.
 */
describe('cell style precedence', () => {
  it('1. override.style beats everything else', () => {
    const overrides = buildOverrideMap([
      { rowId: 'R1', field: 'pnl', style: { bgColor: '#123456', textColor: '#abcdef' } },
    ]);
    const [col] = mapColumns([numericColumn], deps(overrides)) as ColDef<RowRecord>[];
    const style = styleOf(col, row(), 1000);
    expect(style?.backgroundColor).toBe('#123456');
    expect(style?.color).toBe('#abcdef');
  });

  it('2. override.display beats column.display when no style override', () => {
    const overrides = buildOverrideMap([
      {
        rowId: 'R1',
        field: 'pnl',
        display: { type: CellDisplayType.NUMERIC, config: { positiveColor: 'warning' } },
      },
    ]);
    const [col] = mapColumns([numericColumn], deps(overrides)) as ColDef<RowRecord>[];
    const style = styleOf(col, row(), 1000);
    expect(style?.color).toContain('warning');
  });

  it('3. column.display applies when no override exists for that cell', () => {
    const [col] = mapColumns([numericColumn], deps()) as ColDef<RowRecord>[];
    const style = styleOf(col, row(), 1000);
    expect(style?.color).toContain('positive');
  });

  it('4. an override on a DIFFERENT cell does not leak into this one', () => {
    const overrides = buildOverrideMap([
      { rowId: 'R2', field: 'pnl', style: { bgColor: '#123456' } },
    ]);
    const [col] = mapColumns([numericColumn], deps(overrides)) as ColDef<RowRecord>[];
    const style = styleOf(col, row(), 1000);
    expect(style?.backgroundColor).toBeUndefined();
  });

  it('5. plain default applies when the column declares no display block', () => {
    const [col] = mapColumns(
      [{ field: 'symbol', headerName: 'Symbol', type: 'text' }],
      deps(),
    ) as ColDef<RowRecord>[];
    expect(styleOf(col, row(), 'AAPL')).toBeUndefined();
  });
});

describe('valueMode', () => {
  it('PRE_FORMATTED renders displayField verbatim and skips the formatter', () => {
    const col: ColumnDef = {
      ...numericColumn,
      valueMode: ValueMode.PRE_FORMATTED,
      displayField: 'pnlDisplay',
      display: { type: CellDisplayType.NUMERIC, format: 'currency:USD:2', config: {} },
    };
    const [mapped] = mapColumns([col], deps()) as ColDef<RowRecord>[];
    // format would give "$1,000.00"; the backend string must win untouched.
    expect(textOf(mapped, row({ pnlDisplay: '1.0K USD' }), 1000)).toBe('1.0K USD');
  });

  it('PRE_FORMATTED with a missing display field renders empty, not "undefined"', () => {
    const col: ColumnDef = { ...numericColumn, valueMode: ValueMode.PRE_FORMATTED, displayField: 'missing' };
    const [mapped] = mapColumns([col], deps()) as ColDef<RowRecord>[];
    expect(textOf(mapped, row(), 1000)).toBe('');
  });

  it('RAW (default) formats via the display format string', () => {
    const [mapped] = mapColumns([numericColumn], deps()) as ColDef<RowRecord>[];
    expect(textOf(mapped, row(), 1000)).toBe('1,000');
  });
});

describe('column groups', () => {
  it('maps a group to children without applying leaf logic to the group node', () => {
    const mapped = mapColumns(
      [{ headerName: 'P&L', groupId: 'g', children: [numericColumn] }],
      deps(),
    );
    const group = mapped[0] as { headerName: string; children: unknown[] };
    expect(group.headerName).toBe('P&L');
    expect(group.children).toHaveLength(1);
    expect((group.children[0] as ColDef).field).toBe('pnl');
  });
});
