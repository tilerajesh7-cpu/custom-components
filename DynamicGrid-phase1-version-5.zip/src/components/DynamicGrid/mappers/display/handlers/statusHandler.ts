import type { StatusConfig } from '../../../types/display.types';
import { resolveColor, resolveSoftBg } from '../../../utils/colorUtils';
import { TONE_COLORS } from '../../../components/icons/toneRegistry';
import type { DisplayHandler } from '../types';

const entryFor = (value: unknown, cfg: StatusConfig) =>
  typeof value === 'string' ? cfg.map[value] : undefined;

/**
 * Status badges. Renderer-free by default: the cell itself is tinted and rounded
 * via CSS, which keeps thousands of status cells off the React path.
 * Set `useRenderer: true` when the pill must hug the text instead.
 */
export const statusHandler: DisplayHandler = {
  type: 'status',

  getCellStyle(value, ctx) {
    const cfg = ctx.display.config as StatusConfig | undefined;
    if (!cfg) return undefined;
    if (cfg.useRenderer) return undefined; // the renderer paints it instead

    const entry = entryFor(value, cfg);
    // tone supplies the defaults; explicit bgColor/textColor override it.
    const toneColors = entry?.tone ? TONE_COLORS[entry.tone] : undefined;
    const bg = resolveSoftBg(entry?.bgColor ?? toneColors?.bg ?? cfg.fallback?.bgColor);
    const fg = resolveColor(entry?.textColor ?? toneColors?.text ?? cfg.fallback?.textColor);
    if (!bg && !fg) return undefined;

    const style: Record<string, string> = {};
    if (bg) style.backgroundColor = bg;
    if (fg) style.color = fg;
    return style;
  },

  getCellClass(_value, ctx) {
    const cfg = ctx.display.config as StatusConfig | undefined;
    return cfg?.useRenderer ? undefined : 'dg-status-cell';
  },

  getDisplayText(value, ctx) {
    const cfg = ctx.display.config as StatusConfig | undefined;
    const entry = cfg ? entryFor(value, cfg) : undefined;
    return entry?.label ?? ctx.format(value);
  },

  needsRenderer(ctx) {
    return Boolean((ctx.display.config as StatusConfig | undefined)?.useRenderer);
  },
};
