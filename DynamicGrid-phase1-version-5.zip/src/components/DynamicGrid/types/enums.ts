/**
 * Central enums. Plain `as const` objects, not native TS `enum` — those don't
 * tree-shake and complicate consumption from plain JS backends/tests. Every
 * mapper/handler should reference these instead of string literals, so a typo
 * becomes a compile error instead of a silently-ignored config.
 */

export const ValueMode = {
  /** UI formats the raw number via `format` (createFormatter). Default. */
  RAW: 'raw',
  /**
   * Backend sends the display string directly — UI renders it verbatim, zero
   * formatting logic on our side. The raw numeric value still travels
   * alongside it (a separate field) for sort/filter/colour math.
   */
  PRE_FORMATTED: 'preFormatted',
} as const;
export type ValueMode = (typeof ValueMode)[keyof typeof ValueMode];

export const TooltipType = {
  SIMPLE: 'simple',
  COMPLEX: 'complex',
  /** Hovering a pre-formatted cell shows the actual unrounded raw value. */
  VALUE: 'value',
} as const;
export type TooltipType = (typeof TooltipType)[keyof typeof TooltipType];

export const CellDisplayType = {
  PLAIN: 'plain',
  NUMERIC: 'numeric',
  STATUS: 'status',
  HEATMAP: 'heatmap',
  UTILIZATION: 'utilization',
  ICON: 'icon',
  ICON_WITH_TEXT: 'iconWithText',
} as const;
export type CellDisplayType = (typeof CellDisplayType)[keyof typeof CellDisplayType];

export const ColorToken = {
  POSITIVE: 'positive',
  NEGATIVE: 'negative',
  NEUTRAL: 'neutral',
  WARNING: 'warning',
  CRITICAL: 'critical',
  INFO: 'info',
  MUTED: 'muted',
} as const;
export type ColorToken = (typeof ColorToken)[keyof typeof ColorToken];

/** Backend sends a tone, never an icon key — UI's registry decides the glyph. */
export const IconTone = {
  POSITIVE: 'positive',
  NEGATIVE: 'negative',
  WARNING: 'warning',
  INFO: 'info',
  NEUTRAL: 'neutral',
} as const;
export type IconTone = (typeof IconTone)[keyof typeof IconTone];

export const NegativeStyle = {
  COLOR: 'color',
  PARENTHESES: 'parentheses',
  BOTH: 'both',
} as const;
export type NegativeStyle = (typeof NegativeStyle)[keyof typeof NegativeStyle];

export const TrendIndicator = {
  TEXT: 'text',
  ICON: 'icon',
} as const;
export type TrendIndicator = (typeof TrendIndicator)[keyof typeof TrendIndicator];

export const HeatmapMode = {
  DENSITY: 'density',
  SCALE: 'scale',
} as const;
export type HeatmapMode = (typeof HeatmapMode)[keyof typeof HeatmapMode];

export const Density = {
  COMPACT: 'compact',
  COMFORTABLE: 'comfortable',
} as const;
export type Density = (typeof Density)[keyof typeof Density];
