/** Observability payload. Tool-agnostic — the app wires this to its own logger. */
export interface GridErrorPayload {
  type: 'validation' | 'render' | 'formatter';
  message: string;
  context?: Record<string, unknown>;
}
