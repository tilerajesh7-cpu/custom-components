import { describe, expect, it } from 'vitest';
import { clamp, densityFill, lerpColor } from '../colorUtils';

const alphaOf = (rgba: string): number => Number(rgba.match(/[\d.]+\)$/)?.[0].replace(')', ''));

describe('densityFill', () => {
  it('uses minAlpha at exactly min and maxAlpha at exactly max', () => {
    expect(alphaOf(densityFill(0, 0, 30, '#1f4e9c').backgroundColor)).toBeCloseTo(0.06, 2);
    expect(alphaOf(densityFill(30, 0, 30, '#1f4e9c').backgroundColor)).toBeCloseTo(0.92, 2);
  });

  it('clamps values beyond the declared range by default', () => {
    const over = densityFill(500, 0, 30, '#1f4e9c');
    expect(alphaOf(over.backgroundColor)).toBeCloseTo(0.92, 2);
    const under = densityFill(-500, 0, 30, '#1f4e9c');
    expect(alphaOf(under.backgroundColor)).toBeCloseTo(0.06, 2);
  });

  it('inverts the label only once the fill is dark enough to need it', () => {
    expect(densityFill(0, 0, 30, '#1f4e9c').invertText).toBe(false);
    expect(densityFill(30, 0, 30, '#1f4e9c').invertText).toBe(true);
  });

  it('does not divide by zero when min equals max', () => {
    const r = densityFill(5, 10, 10, '#1f4e9c');
    expect(Number.isFinite(alphaOf(r.backgroundColor))).toBe(true);
  });
});

describe('lerpColor', () => {
  it('returns the endpoints at t=0 and t=1', () => {
    expect(lerpColor('#000000', '#ffffff', 0)).toBe('rgb(0, 0, 0)');
    expect(lerpColor('#000000', '#ffffff', 1)).toBe('rgb(255, 255, 255)');
  });

  it('clamps t outside [0,1] rather than extrapolating past the endpoint', () => {
    expect(lerpColor('#000000', '#ffffff', 5)).toBe('rgb(255, 255, 255)');
  });

  it('falls back to the target when a colour is not interpolable hex', () => {
    expect(lerpColor('var(--x)', '#ffffff', 0.5)).toBe('#ffffff');
  });
});

describe('clamp', () => {
  it('is inclusive at both bounds', () => {
    expect(clamp(0, 0, 10)).toBe(0);
    expect(clamp(10, 0, 10)).toBe(10);
  });
});
