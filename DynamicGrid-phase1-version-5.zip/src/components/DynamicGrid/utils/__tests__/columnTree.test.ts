import { describe, expect, it } from 'vitest';
import { flattenColumns, isColumnGroup } from '../columnTree';
import type { ColumnDef } from '../../types/gridConfig.types';

const col = (field: string): ColumnDef => ({ field, headerName: field, type: 'text' });

describe('flattenColumns', () => {
  it('returns leaves in left-to-right render order', () => {
    const out = flattenColumns([
      col('a'),
      { headerName: 'G', children: [col('b'), col('c')] },
      col('d'),
    ]);
    // Order matters: the raw cells[] adapter aligns by this index sequence.
    expect(out.map((c) => c.field)).toEqual(['a', 'b', 'c', 'd']);
  });

  it('flattens groups nested inside groups', () => {
    const out = flattenColumns([
      { headerName: 'Outer', children: [{ headerName: 'Inner', children: [col('x')] }, col('y')] },
    ]);
    expect(out.map((c) => c.field)).toEqual(['x', 'y']);
  });

  it('handles an empty children array without throwing', () => {
    expect(flattenColumns([{ headerName: 'Empty', children: [] }])).toEqual([]);
  });
});

describe('isColumnGroup', () => {
  it('discriminates on the presence of children, not on headerName', () => {
    expect(isColumnGroup({ headerName: 'G', children: [] })).toBe(true);
    expect(isColumnGroup(col('a'))).toBe(false);
  });
});
