import React, { useCallback, useMemo, useRef, useState } from 'react';
import { DynamicGrid } from '../DynamicGrid';
import { ActiveContextChip } from '../components/feedback/ActiveContextChip';
import { ChartSkeleton, GridSkeleton, useMinimumVisible } from '../components/feedback/Skeletons';
import { gridServiceResponseMock } from '../__mocks__/gridServiceResponse.mock';
import {
  fetchDrillDownChart,
  fetchDrillDownGrid,
  type DrillDownChartPoint,
} from '../__mocks__/drillDownService.mock';
import type { DrillDownPayload } from '../types/drilldown.types';
import type { GridConfig } from '../types/gridConfig.types';

/**
 * Reference implementation of the drill-down flow.
 *
 * The three rules this demonstrates, in order of how likely each is to be got
 * wrong:
 *
 * 1. STALE RESPONSES. Click row A then quickly row B and A's response may
 *    resolve after B's. Both guards are used here: the AbortSignal the grid
 *    supplies, AND a requestId check before applying state — abort cancels
 *    in-flight work, the id catches a response that already resolved before
 *    the abort landed. A loading boolean alone does not prevent this.
 *
 * 2. INDEPENDENT PANELS. The chart is slower than the grid on purpose. Each
 *    panel owns its own loading flag, so a slow chart never holds up a fast
 *    grid.
 *
 * 3. INSTANT SELECTION. The grid applies the active-row treatment
 *    synchronously — nothing here is awaited before the click is acknowledged.
 */
export function DrillDownDashboard() {
  const [selection, setSelection] = useState<{ rowId: string; label: string } | null>(null);

  const [detail, setDetail] = useState<GridConfig | null>(null);
  const [chart, setChart] = useState<DrillDownChartPoint[] | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [chartLoading, setChartLoading] = useState(false);

  // Latest request wins. Anything older is discarded on arrival.
  const latestRequest = useRef(0);

  const handleDrillDown = useCallback(async (payload: DrillDownPayload) => {
    latestRequest.current = payload.requestId;
    setDetail(null);
    setChart(null);
    setDetailLoading(true);
    setChartLoading(true);

    const isStale = () => payload.requestId !== latestRequest.current;

    // Fired together, resolved independently — not awaited in sequence.
    fetchDrillDownGrid(payload.rowId, payload.signal)
      .then((data) => {
        if (isStale()) return;
        setDetail(data);
        setDetailLoading(false);
      })
      .catch((err: unknown) => {
        if ((err as Error)?.name === 'AbortError' || isStale()) return;
        setDetailLoading(false);
      });

    fetchDrillDownChart(payload.rowId, payload.signal)
      .then((data) => {
        if (isStale()) return;
        setChart(data);
        setChartLoading(false);
      })
      .catch((err: unknown) => {
        if ((err as Error)?.name === 'AbortError' || isStale()) return;
        setChartLoading(false);
      });
  }, []);

  const handleClear = useCallback(() => {
    latestRequest.current += 1; // invalidates anything in flight
    setSelection(null);
    setDetail(null);
    setChart(null);
    setDetailLoading(false);
    setChartLoading(false);
  }, []);

  // Minimum visible time — a skeleton that flashes for 80ms reads as a bug.
  const showDetailSkeleton = useMinimumVisible(detailLoading, 400);
  const showChartSkeleton = useMinimumVisible(chartLoading, 400);

  const gridOptions = useMemo(() => ({ rowSelection: 'single' as const }), []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <DynamicGrid
        gridData={gridServiceResponseMock}
        gridOptions={gridOptions}
        height={420}
        selectionLabelField="symbol"
        onSelectionChange={setSelection}
        onDrillDown={handleDrillDown}
      />

      {selection ? (
        <>
          <ActiveContextChip label={selection.label} onClear={handleClear} />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <section aria-label="Detail positions">
              {showDetailSkeleton || !detail ? (
                <GridSkeleton rows={4} columns={5} />
              ) : (
                <DynamicGrid gridData={detail} height={260} borderless />
              )}
            </section>

            <section aria-label="Trend chart">
              {showChartSkeleton || !chart ? (
                <ChartSkeleton height={260} />
              ) : (
                <MiniChart points={chart} />
              )}
            </section>
          </div>
        </>
      ) : null}
    </div>
  );
}

/** Minimal inline chart — a real app would use its own charting component. */
function MiniChart({ points }: { points: DrillDownChartPoint[] }) {
  const max = Math.max(...points.map((p) => p.value), 1);
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 260, padding: 12 }}>
      {points.map((p) => (
        <div
          key={p.label}
          title={`${p.label}: ${p.value}`}
          style={{
            flex: 1,
            height: `${(p.value / max) * 100}%`,
            background: 'var(--dg-color-info, #1f4e9c)',
            opacity: 0.75,
            borderRadius: '4px 4px 0 0',
          }}
        />
      ))}
    </div>
  );
}
