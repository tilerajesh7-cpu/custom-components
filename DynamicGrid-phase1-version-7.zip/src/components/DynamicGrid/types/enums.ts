/**
 * Central enums. Plain `as const` objects, not native TS `enum` — those don't
 * tree-shake and complicate consumption from plain JS backends/tests. Every
 * mapper/handler should reference these instead of string literals, so a typo
 * becomes a compile error instead of a silently-ignored config.
 */

export const ValueMode = {
  /** UI formats the raw number via `format` (createFormatter). Default. */
  RAW: 'raw',
  /**
   * Backend sends the display string directly — UI renders it verbatim, zero
   * formatting logic on our side. The raw numeric value still travels
   * alongside it (a separate field) for sort/filter/colour math.
   */
  PRE_FORMATTED: 'preFormatted',
} as const;
export type ValueMode = (typeof ValueMode)[keyof typeof ValueMode];

export const TooltipType = {
  SIMPLE: 'simple',
  COMPLEX: 'complex',
  /** Hovering a pre-formatted cell shows the actual unrounded raw value. */
  VALUE: 'value',
} as const;
export type TooltipType = (typeof TooltipType)[keyof typeof TooltipType];

export const CellDisplayType = {
  PLAIN: 'plain',
  NUMERIC: 'numeric',
  STATUS: 'status',
  HEATMAP: 'heatmap',
  UTILIZATION: 'utilization',
  ICON: 'icon',
  ICON_WITH_TEXT: 'iconWithText',
} as const;
export type CellDisplayType = (typeof CellDisplayType)[keyof typeof CellDisplayType];

export const ColorToken = {
  POSITIVE: 'positive',
  NEGATIVE: 'negative',
  NEUTRAL: 'neutral',
  WARNING: 'warning',
  CRITICAL: 'critical',
  INFO: 'info',
  MUTED: 'muted',
} as const;
export type ColorToken = (typeof ColorToken)[keyof typeof ColorToken];

/** Backend sends a tone, never an icon key — UI's registry decides the glyph. */
export const IconTone = {
  POSITIVE: 'positive',
  NEGATIVE: 'negative',
  WARNING: 'warning',
  INFO: 'info',
  NEUTRAL: 'neutral',
} as const;
export type IconTone = (typeof IconTone)[keyof typeof IconTone];

/**
 * How a negative number is rendered.
 *
 * BRACKETS_COLOURED is the DEFAULT when a numeric column omits this — it is the
 * financial convention, and "brackets but no colour" (the old `parentheses`
 * value) was almost never what anyone actually wanted. Old string values are
 * still accepted by the handler for back-compat.
 */
export const NegativeStyle = {
  /** -1,200 in red, no brackets. */
  COLOUR_ONLY: 'colourOnly',
  /** (1,200) in default ink — rare; use only for deliberately quiet columns. */
  BRACKETS_ONLY: 'bracketsOnly',
  /** (1,200) in red. The default. */
  BRACKETS_COLOURED: 'bracketsColoured',
} as const;
export type NegativeStyle = (typeof NegativeStyle)[keyof typeof NegativeStyle];

/** Which metric in a row carries the visual weight. Drives type scale. */
export const Emphasis = {
  PRIMARY: 'primary',
  SECONDARY: 'secondary',
} as const;
export type Emphasis = (typeof Emphasis)[keyof typeof Emphasis];

export const TrendIndicator = {
  TEXT: 'text',
  ICON: 'icon',
} as const;
export type TrendIndicator = (typeof TrendIndicator)[keyof typeof TrendIndicator];

export const HeatmapMode = {
  DENSITY: 'density',
  SCALE: 'scale',
} as const;
export type HeatmapMode = (typeof HeatmapMode)[keyof typeof HeatmapMode];

export const Density = {
  COMPACT: 'compact',
  COMFORTABLE: 'comfortable',
} as const;
export type Density = (typeof Density)[keyof typeof Density];
