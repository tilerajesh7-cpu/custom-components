export { DynamicGrid } from './DynamicGrid';
export type { DynamicGridProps } from './DynamicGrid';

// ./types already re-exports enums and errors.types — do not also export them
// here, or every enum becomes an ambiguous duplicate export.
export * from './types';

export { DensityProvider, useDensity } from './context/DensityContext';
export type { Density } from './context/DensityContext';

export { GridErrorBoundary } from './components/errors/GridErrorBoundary';
export { ActiveContextChip } from './components/feedback/ActiveContextChip';
export { GridSectionHeader } from './components/layout/GridSectionHeader';
export type { GridSectionHeaderProps, SegmentOption } from './components/layout/GridSectionHeader';
export { GridSkeleton, ChartSkeleton, useMinimumVisible } from './components/feedback/Skeletons';
export { useDrillDown } from './hooks/useDrillDown';
export type { DrillDownPayload, SelectionState } from './types/drilldown.types';
export { GridEmptyState, GridErrorState } from './components/errors/GridStates';

export { adaptRawGridData, isRawGridData } from './adapters/rawGridAdapter';
export { validateGridConfig } from './adapters/validateGridConfig';
export type { ValidationIssue, ValidationResult } from './adapters/validateGridConfig';

export { displayRegistry, getHandler } from './mappers/display/displayRegistry';
export type { DisplayHandler } from './mappers/display/types';
export { flattenColumns, isColumnGroup } from './utils/columnTree';
export { TONE_ICON, TONE_COLORS, iconForTone } from './components/icons/toneRegistry';
export { buildDynamicGridTheme, DENSITY_PRESETS } from './theme/dynamicGridTheme';
