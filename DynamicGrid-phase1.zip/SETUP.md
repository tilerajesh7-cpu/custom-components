# DynamicGrid — drop-in setup

## 1. Copy

Copy `src/components/DynamicGrid/` into your app's `src/components/`.
`src/services/portfolioService.ts` and `src/pages/PortfolioPage.tsx` are reference
files — adapt them, don't copy them over anything you already have.

## 2. Install

```bash
npm i ag-grid-react ag-grid-community
# Phase 2 only: npm i ag-grid-enterprise
```

## 3. App root — once, not per grid

```tsx
// src/main.tsx
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';

// Phase 2, when Enterprise lands:
// import { LicenseManager } from 'ag-grid-enterprise';
// LicenseManager.setLicenseKey(import.meta.env.VITE_AG_GRID_LICENSE);
```

## 4. Path alias

Files import via `@/components/DynamicGrid`. Add the alias:

```jsonc
// tsconfig.json
{ "compilerOptions": { "baseUrl": "src", "paths": { "@/*": ["*"] } } }
```

```ts
// vite.config.ts
resolve: { alias: { '@': path.resolve(__dirname, 'src') } }
```

If you don't use aliases, relative imports work — only the two reference files
(`services/`, `pages/`) use `@/`; the component's internals are all relative.

## 5. Use it

```tsx
import { DynamicGrid } from '@/components/DynamicGrid';

<DynamicGrid
  gridData={payload}
  gridOptions={{ rowHeight: 36 }}
  onCellClicked={handleCellClicked}
/>
```

## 6. Keep the boundary

Add this so nothing reaches past the barrel:

```jsonc
// .eslintrc
"no-restricted-imports": ["error", {
  "patterns": ["**/DynamicGrid/*", "!**/DynamicGrid/index"]
}]
```

## 7. Exclude dev-only files from the production build

```jsonc
// tsconfig.build.json
{ "exclude": ["src/**/__mocks__/**", "src/**/examples/**"] }
```

`largeDataset.mock.ts` generates 5k rows — there is no reason for it in a prod bundle.
