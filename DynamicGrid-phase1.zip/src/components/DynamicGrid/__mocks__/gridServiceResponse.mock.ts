import type { GridConfig } from '../types/gridConfig.types';

/**
 * Normalised (recommended) service shape: flat rows + sparse overrides.
 * Exercises every display type and every branch of the precedence chain.
 */
export const gridServiceResponseMock: GridConfig = {
  metadata: {
    gridId: 'portfolio-positions',
    version: '2026-09-15T10:00:00Z',
    rowModelType: 'clientSide',
    pagination: { enabled: true, pageSize: 25, mode: 'client' },
    features: {
      export: true,
      columnPanel: true,
      pivotEnabled: false,
      masterDetailEnabled: false,
    },
  },

  columns: [
    {
      field: 'symbol',
      headerName: 'Symbol',
      type: 'text',
      width: 120,
      pinned: 'left',
      clickable: true,
      actionType: 'OPEN_INSTRUMENT',
    },
    { field: 'assetClass', headerName: 'Asset class', type: 'text', filter: 'agSetColumnFilter' },
    {
      field: 'quantity',
      headerName: 'Qty',
      type: 'number',
      display: { type: 'plain', format: 'number:0' },
    },
    {
      field: 'avgPrice',
      headerName: 'Avg price',
      type: 'number',
      display: { type: 'plain', format: 'currency:USD:2' },
    },
    {
      field: 'ltp',
      headerName: 'Last price',
      type: 'number',
      display: { type: 'plain', format: 'currency:USD:2' },
    },
    {
      field: 'pnl',
      headerName: 'P&L',
      type: 'number',
      width: 140,
      display: {
        type: 'heatmap',
        format: 'currency:USD:0',
        config: {
          min: -50000,
          max: 50000,
          mid: 0,
          lowColor: '#f87171',
          midColor: '#ffffff',
          highColor: '#4ade80',
          applyTo: 'background',
          clamp: true,
        },
      },
    },
    {
      field: 'pnlPercent',
      headerName: 'P&L %',
      type: 'number',
      width: 110,
      display: {
        type: 'numeric',
        format: 'percent:1',
        config: {
          positiveColor: 'positive',
          negativeColor: 'negative',
          zeroColor: 'muted',
          showSign: true,
          negativeStyle: 'both',
          bold: 'negative',
        },
      },
    },
    {
      field: 'marginUtilization',
      headerName: 'Margin used',
      type: 'number',
      width: 150,
      display: {
        type: 'utilization',
        format: 'percent:0',
        config: {
          min: 0,
          max: 100,
          showBar: true,
          thresholds: [
            { upTo: 60, bgColor: '#4ade80', textColor: 'positive' },
            { upTo: 85, bgColor: '#fbbf24', textColor: 'warning' },
            { upTo: 100, bgColor: '#f87171', textColor: 'negative' },
          ],
        },
      },
    },
    {
      field: 'status',
      headerName: 'Status',
      type: 'text',
      width: 130,
      display: {
        type: 'status',
        config: {
          useRenderer: true,
          map: {
            active: { label: 'Active', bgColor: '#dcfce7', textColor: 'positive', icon: 'icon-check-circle' },
            flagged: { label: 'Flagged', bgColor: '#fee2e2', textColor: 'negative', icon: 'icon-alert-triangle' },
            pending: { label: 'Pending', bgColor: '#fef3c7', textColor: 'warning', icon: 'icon-clock' },
          },
          fallback: { bgColor: '#f3f4f6', textColor: 'muted' },
        },
      },
    },
    {
      field: 'trend',
      headerName: 'Trend',
      type: 'text',
      width: 90,
      display: {
        type: 'icon',
        config: {
          map: { up: 'icon-arrow-up', down: 'icon-arrow-down' },
          showValue: false,
        },
      },
    },
    {
      field: 'exposureNote',
      headerName: 'Notes',
      type: 'text',
      flex: 1,
      tooltip: { type: 'simple' },
    },
    {
      field: 'riskBreakdown',
      headerName: 'Risk',
      type: 'text',
      width: 110,
      tooltip: { type: 'complex' },
      display: { type: 'plain', format: 'text' },
    },
    {
      field: 'region',
      headerName: 'Region',
      type: 'text',
      width: 100,
      phase2: { enableRowGroup: true, enablePivot: true },
    },
  ],

  rows: [
    {
      id: 'POS-1001',
      symbol: 'AAPL',
      assetClass: 'Equity',
      quantity: 500,
      avgPrice: 172.3,
      ltp: 191.1,
      pnl: 9400,
      pnlPercent: 10.9,
      marginUtilization: 42,
      status: 'active',
      trend: 'up',
      exposureNote: 'Within limit, reviewed 09/12',
      riskBreakdown: { var95: 4200, beta: 1.12, sector: 'Tech' },
      region: 'NA',
    },
    {
      id: 'POS-1002',
      symbol: 'TSLA',
      assetClass: 'Equity',
      quantity: 200,
      avgPrice: 250,
      ltp: 210.5,
      pnl: -7900,
      pnlPercent: -15.8,
      marginUtilization: 91,
      status: 'flagged',
      trend: 'down',
      exposureNote: 'Exceeds sector concentration limit',
      riskBreakdown: { var95: 6100, beta: 1.9, sector: 'Auto' },
      region: 'NA',
    },
    {
      // Zero-value row: exercises the neutral branch of the numeric handler.
      id: 'POS-1003',
      symbol: 'INFY',
      assetClass: 'Equity',
      quantity: 1000,
      avgPrice: 18.2,
      ltp: 18.2,
      pnl: 0,
      pnlPercent: 0,
      marginUtilization: 12,
      status: 'pending',
      trend: 'up',
      exposureNote: 'Trade settlement in progress',
      riskBreakdown: { var95: 1500, beta: 0.8, sector: 'IT Services' },
      region: 'APAC',
    },
    {
      // P&L above the declared heatmap max: exercises clamping.
      id: 'POS-1004',
      symbol: 'HDFCBANK',
      assetClass: 'Equity',
      quantity: 800,
      avgPrice: 1650,
      ltp: 1720.5,
      pnl: 56400,
      pnlPercent: 4.3,
      marginUtilization: 68,
      status: 'active',
      trend: 'up',
      exposureNote: 'Core holding',
      riskBreakdown: { var95: 8200, beta: 1.05, sector: 'Financials' },
      region: 'APAC',
    },
    {
      id: 'POS-1005',
      symbol: 'VOD',
      assetClass: 'Equity',
      quantity: 3000,
      avgPrice: 9.8,
      ltp: 8.1,
      pnl: -5100,
      pnlPercent: -17.3,
      marginUtilization: 77,
      status: 'flagged',
      trend: 'down',
      exposureNote: 'Currency exposure under review',
      riskBreakdown: { var95: 3900, beta: 1.3, sector: 'Telecom' },
      region: 'EU',
    },
  ],

  // Sparse: three cells out of sixty-five.
  cellOverrides: [
    {
      // icon override on a status column + a tooltip the column does not define
      rowId: 'POS-1001',
      field: 'status',
      icon: 'icon-star',
      tooltip: { type: 'simple', value: 'Top performer this quarter' },
    },
    {
      // highest-precedence path: explicit style beats the heatmap entirely
      rowId: 'POS-1002',
      field: 'pnl',
      style: { bgColor: '#fef3c7', textColor: '#92400e', fontWeight: '600' },
      clickable: true,
      actionType: 'OPEN_COMPLIANCE_REVIEW',
      tooltip: { type: 'simple', value: 'Manually flagged for compliance review' },
    },
    {
      // clickable without any style change — the two are independent
      rowId: 'POS-1005',
      field: 'status',
      clickable: true,
      actionType: 'OPEN_RISK_DRILLDOWN',
    },
  ],
};

/** Simulated service call. */
export function fetchGridConfig(delayMs = 400): Promise<GridConfig> {
  return new Promise((resolve) => {
    setTimeout(() => resolve(gridServiceResponseMock), delayMs);
  });
}
