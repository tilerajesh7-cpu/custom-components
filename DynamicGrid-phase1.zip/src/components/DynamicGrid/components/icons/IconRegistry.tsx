import React from 'react';

/**
 * Inline SVG registry. Backend sends a key string; the grid never receives markup.
 * Icons are plain functions returning SVG so they cost nothing beyond the element.
 */
export type IconKey =
  | 'icon-check-circle'
  | 'icon-alert-triangle'
  | 'icon-clock'
  | 'icon-star'
  | 'icon-arrow-up'
  | 'icon-arrow-down';

const base = {
  width: 14,
  height: 14,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 2,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
  'aria-hidden': true,
  focusable: false,
};

export const ICON_REGISTRY: Record<string, React.ReactElement> = {
  'icon-check-circle': (
    <svg {...base}>
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  ),
  'icon-alert-triangle': (
    <svg {...base}>
      <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  ),
  'icon-clock': (
    <svg {...base}>
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  ),
  'icon-star': (
    <svg {...base} fill="currentColor">
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  ),
  'icon-arrow-up': (
    <svg {...base}>
      <line x1="12" y1="19" x2="12" y2="5" />
      <polyline points="5 12 12 5 19 12" />
    </svg>
  ),
  'icon-arrow-down': (
    <svg {...base}>
      <line x1="12" y1="5" x2="12" y2="19" />
      <polyline points="19 12 12 19 5 12" />
    </svg>
  ),
};

export function getIcon(key?: string): React.ReactElement | null {
  if (!key) return null;
  return ICON_REGISTRY[key] ?? null;
}
