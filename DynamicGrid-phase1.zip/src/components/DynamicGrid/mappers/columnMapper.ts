import type { ColDef, CellClassParams, CellStyle, ValueFormatterParams } from 'ag-grid-community';
import type { ColumnDisplay } from '../types/display.types';
import type { ColumnDef, RowRecord } from '../types/gridConfig.types';
import { createFormatter } from '../utils/formatters';
import { getHandler } from './display/displayRegistry';
import type { HandlerContext } from './display/types';
import { overrideKey, type OverrideMap } from './cellOverrideMapper';

const DEFAULT_DISPLAY: ColumnDisplay = { type: 'plain' };

function defaultFilterFor(type: ColumnDef['type']): string | boolean {
  switch (type) {
    case 'number':
      return 'agNumberColumnFilter';
    case 'date':
      return 'agDateColumnFilter';
    default:
      return 'agTextColumnFilter';
  }
}

/** Merges a cell-level display patch onto the column display. Cheap, only on overridden cells. */
function mergeDisplay(base: ColumnDisplay, patch?: Partial<ColumnDisplay>): ColumnDisplay {
  if (!patch) return base;
  return {
    type: patch.type ?? base.type,
    format: patch.format ?? base.format,
    config: patch.config ?? base.config,
  };
}

export interface ColumnMapperDeps {
  overrides: OverrideMap;
  /** Fields that have at least one icon override — those columns need a renderer. */
  iconOverrideFields: ReadonlySet<string>;
}

/**
 * Backend ColumnDef -> AG Grid ColDef.
 *
 * Everything the display handler can express as cellStyle / cellClass / valueFormatter
 * stays on AG Grid's native fast path. A renderer is attached only when the handler
 * says DOM is unavoidable (icons, bars, opt-in pills).
 *
 * Precedence, applied identically everywhere:
 *   cellOverride.style  ->  cellOverride.display  ->  column.display  ->  default
 */
export function mapColumns(columns: ColumnDef[], deps: ColumnMapperDeps): ColDef<RowRecord>[] {
  const { overrides, iconOverrideFields } = deps;

  return columns.map((column) => {
    const display = column.display ?? DEFAULT_DISPLAY;
    const handler = getHandler(display.type);

    // Built ONCE per column, closed over by the per-cell callbacks below.
    const ctx: HandlerContext = { display, format: createFormatter(display.format) };

    const rendererNeeded =
      Boolean(handler.needsRenderer?.(ctx)) || iconOverrideFields.has(column.field);

    const lookup = (data: RowRecord | undefined) =>
      data ? overrides.get(overrideKey(data.id, column.field)) : undefined;

    const colDef: ColDef<RowRecord> = {
      field: column.field,
      headerName: column.headerName,
      sortable: column.sortable ?? true,
      filter: column.filter === false ? false : (column.filter ?? defaultFilterFor(column.type)),
      resizable: true,
      hide: column.hide,
      ...(column.width ? { width: column.width } : {}),
      ...(column.flex ? { flex: column.flex } : {}),
      ...(column.pinned ? { pinned: column.pinned } : {}),

      // --- text ------------------------------------------------------------
      valueFormatter: (params: ValueFormatterParams<RowRecord>) => {
        const override = lookup(params.data);
        if (override?.display) {
          const merged = mergeDisplay(display, override.display);
          const mergedHandler = getHandler(merged.type);
          const mergedCtx: HandlerContext = {
            display: merged,
            format: merged.format === display.format ? ctx.format : createFormatter(merged.format),
          };
          return mergedHandler.getDisplayText?.(params.value, mergedCtx) ?? mergedCtx.format(params.value);
        }
        return handler.getDisplayText?.(params.value, ctx) ?? ctx.format(params.value);
      },

      // --- colour ----------------------------------------------------------
      cellStyle: (params: CellClassParams<RowRecord>): CellStyle | undefined => {
        const override = lookup(params.data);

        // 1. explicit per-cell style wins outright
        if (override?.style) {
          const s: Record<string, string> = {};
          if (override.style.bgColor) s.backgroundColor = override.style.bgColor;
          if (override.style.textColor) s.color = override.style.textColor;
          if (override.style.fontWeight) s.fontWeight = override.style.fontWeight;
          return s as CellStyle;
        }

        // 2. per-cell display patch
        if (override?.display) {
          const merged = mergeDisplay(display, override.display);
          const mergedCtx: HandlerContext = { display: merged, format: ctx.format };
          return getHandler(merged.type).getCellStyle?.(params.value, mergedCtx, override) as CellStyle;
        }

        // 3. column rule
        return handler.getCellStyle?.(params.value, ctx) as CellStyle;
      },

      cellClass: (params: CellClassParams<RowRecord>) => {
        const classes: string[] = [];
        const fromHandler = handler.getCellClass?.(params.value, ctx);
        if (typeof fromHandler === 'string') classes.push(fromHandler);
        else if (Array.isArray(fromHandler)) classes.push(...fromHandler);

        const override = lookup(params.data);
        const clickable = override?.clickable ?? column.clickable ?? false;
        if (clickable) classes.push('dg-cell-clickable');

        return classes.length ? classes : undefined;
      },

      // --- renderer (last resort) -------------------------------------------
      ...(rendererNeeded
        ? {
            cellRenderer: 'dgCellRenderer',
            cellRendererParams: { display, columnField: column.field },
          }
        : {}),

      // --- tooltips ---------------------------------------------------------
      ...buildTooltip(column, lookup),

      // --- Phase 2 (parsed, inert) ------------------------------------------
      enableRowGroup: false, // TODO(phase-2): column.phase2?.enableRowGroup
      enablePivot: false, // TODO(phase-2): column.phase2?.enablePivot
      enableValue: false, // TODO(phase-2): column.phase2?.enableValue
    };

    return colDef;
  });
}

type Lookup = (data: RowRecord | undefined) => { tooltip?: { type: 'simple' | 'complex'; value?: string; data?: Record<string, unknown> } } | undefined;

function buildTooltip(column: ColumnDef, lookup: Lookup): Partial<ColDef<RowRecord>> {
  const columnTooltip = column.tooltip;
  const complexPossible = columnTooltip?.type === 'complex';

  return {
    tooltipValueGetter: (params) => {
      const override = lookup(params.data as RowRecord | undefined);
      if (override?.tooltip) return override.tooltip.value ?? params.value;
      if (!columnTooltip) return undefined;
      if (columnTooltip.field && params.data) {
        return (params.data as RowRecord)[columnTooltip.field] as string;
      }
      return params.value as string;
    },
    // A custom tooltip component is attached only where nested data is expected.
    ...(complexPossible ? { tooltipComponent: 'dgCustomTooltip' } : {}),
  };
}
