import type { NumericConfig } from '../../../types/display.types';
import { resolveColor } from '../../../utils/colorUtils';
import type { DisplayHandler } from '../types';

const asNumber = (v: unknown): number | null =>
  typeof v === 'number' && Number.isFinite(v) ? v : null;

/**
 * Sign-aware numbers: colour by sign, optional "+" prefix, optional accounting
 * parentheses for negatives. Pure cellStyle + formatter, no renderer.
 */
export const numericHandler: DisplayHandler = {
  type: 'numeric',

  getCellStyle(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const n = asNumber(value);
    if (n === null) return undefined;

    const usesColor = cfg.negativeStyle !== 'parentheses';
    const color = !usesColor
      ? undefined
      : n > 0
        ? resolveColor(cfg.positiveColor)
        : n < 0
          ? resolveColor(cfg.negativeColor)
          : resolveColor(cfg.zeroColor);

    const bold =
      (cfg.bold === 'positive' && n > 0) || (cfg.bold === 'negative' && n < 0)
        ? '600'
        : undefined;

    if (!color && !bold) return undefined;
    const style: Record<string, string> = {};
    if (color) style.color = color;
    if (bold) style.fontWeight = bold;
    return style;
  },

  getDisplayText(value, ctx) {
    const cfg = (ctx.display.config ?? {}) as NumericConfig;
    const n = asNumber(value);
    if (n === null) return ctx.format(value);

    const showParens = cfg.negativeStyle === 'parentheses' || cfg.negativeStyle === 'both';

    if (n < 0 && showParens) return `(${ctx.format(Math.abs(n))})`;
    if (n > 0 && cfg.showSign) return `+${ctx.format(n)}`;
    return ctx.format(n);
  },
};
