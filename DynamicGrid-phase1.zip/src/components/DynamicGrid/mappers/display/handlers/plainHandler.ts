import type { DisplayHandler } from '../types';

/** Default. No styling, formatter only. Cheapest possible path. */
export const plainHandler: DisplayHandler = {
  type: 'plain',
  getDisplayText: (value, ctx) => ctx.format(value),
};
