import { DynamicCellRenderer } from '../components/cells/DynamicCellRenderer';
import { CustomTooltip } from '../components/tooltips/CustomTooltip';

/**
 * AG Grid component registry. Kept intentionally small — a component lands here
 * only when native config cannot express the cell.
 */
export const gridComponents = {
  dgCellRenderer: DynamicCellRenderer,
  dgCustomTooltip: CustomTooltip,
  // TODO(phase-2): dgMasterDetailRenderer — expandable row detail grid.
} as const;

export type GridComponentKey = keyof typeof gridComponents;
