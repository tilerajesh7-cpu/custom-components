/**
 * Cell visual representation schema.
 *
 * A column declares ONE `display` block describing how its cells should look.
 * Each display type is handled by exactly one handler in `mappers/display/handlers`.
 * Adding a new visual type later = add one handler + register it. Nothing else changes.
 */

/** Semantic colour tokens resolve to CSS variables so dashboard theming works later. */
export type ColorToken =
  | 'positive'
  | 'negative'
  | 'neutral'
  | 'warning'
  | 'critical'
  | 'info'
  | 'muted';

/** Either a semantic token (preferred) or a raw hex escape hatch from the backend. */
export type ColorValue = ColorToken | string;

export type CellDisplayType =
  | 'plain'
  | 'numeric'
  | 'status'
  | 'heatmap'
  | 'utilization'
  | 'icon'
  | 'iconWithText';

/** Format DSL, e.g. "currency:USD:2" | "percent:1" | "number:0" | "text". */
export type FormatString = string;

export interface NumericConfig {
  positiveColor?: ColorValue;
  negativeColor?: ColorValue;
  zeroColor?: ColorValue;
  /** Render "+1,200" for positive values. */
  showSign?: boolean;
  /** 'parentheses' renders -1200 as (1,200) — accounting convention. */
  negativeStyle?: 'color' | 'parentheses' | 'both';
  bold?: 'positive' | 'negative' | 'none';
}

export interface StatusEntry {
  label?: string;
  bgColor: ColorValue;
  textColor: ColorValue;
  icon?: string;
}

export interface StatusConfig {
  map: Record<string, StatusEntry>;
  fallback?: Pick<StatusEntry, 'bgColor' | 'textColor'>;
  /**
   * false (default) = renderer-free. The cell itself is tinted — fastest path.
   * true = use a renderer so the pill hugs the text. Costs a React node per cell.
   */
  useRenderer?: boolean;
}

export interface HeatmapConfig {
  /** REQUIRED from the backend. Never derived by scanning row data. */
  min: number;
  max: number;
  /** Defaults to 0 when min < 0 < max, else the midpoint. */
  mid?: number;
  lowColor: ColorValue;
  midColor: ColorValue;
  highColor: ColorValue;
  applyTo?: 'background' | 'text';
  /** Values outside [min, max] clamp to the end colour. Default true. */
  clamp?: boolean;
}

export interface UtilizationThreshold {
  upTo: number;
  bgColor: ColorValue;
  textColor?: ColorValue;
}

export interface UtilizationConfig {
  min: number;
  max: number;
  thresholds: UtilizationThreshold[];
  /** Inline proportional bar behind the value. Requires a renderer. */
  showBar?: boolean;
}

export interface IconConfig {
  /** Cell value -> icon key registered in IconRegistry. */
  map: Record<string, string>;
  position?: 'left' | 'right';
  /** iconWithText always shows the value; `icon` uses this flag. */
  showValue?: boolean;
}

export type DisplayConfig =
  | NumericConfig
  | StatusConfig
  | HeatmapConfig
  | UtilizationConfig
  | IconConfig
  | undefined;

export interface ColumnDisplay {
  type: CellDisplayType;
  format?: FormatString;
  config?: DisplayConfig;
}
