import type { ColumnDef, GridMetadata } from './gridConfig.types';

/**
 * The wire format the current service returns: positional `cells[]` aligned by
 * index to `columns[]`, with metadata inlined per cell.
 *
 * rawGridAdapter.ts is the ONLY file allowed to know about this shape.
 */
export interface RawCell {
  value: unknown;
  isClickable?: boolean;
  actionType?: string;
  /** Free-text tooltip. */
  description?: string;
  icon?: string;
  style?: { bgColor?: string; textColor?: string; fontWeight?: string };
}

export interface RawRow {
  id: string;
  cells: RawCell[];
}

export interface RawGridData {
  metadata: GridMetadata;
  columns: ColumnDef[];
  rows: RawRow[];
}
