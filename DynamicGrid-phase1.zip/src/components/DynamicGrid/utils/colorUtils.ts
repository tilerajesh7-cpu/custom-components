import type { ColorValue } from '../types/display.types';

/**
 * Semantic tokens map to CSS variables so a dashboard theme (Phase 3) can restyle
 * every grid at once. A raw hex from the backend is used as-is.
 */
const TOKEN_VARS: Record<string, string> = {
  positive: 'var(--dg-color-positive, #166534)',
  negative: 'var(--dg-color-negative, #991b1b)',
  neutral: 'var(--dg-color-neutral, #374151)',
  warning: 'var(--dg-color-warning, #92400e)',
  critical: 'var(--dg-color-critical, #7f1d1d)',
  info: 'var(--dg-color-info, #1e40af)',
  muted: 'var(--dg-color-muted, #6b7280)',
};

export function resolveColor(color?: ColorValue): string | undefined {
  if (!color) return undefined;
  return TOKEN_VARS[color] ?? color;
}

/** Hex -> [r,g,b]. Returns null for anything that is not a 3/6-digit hex. */
function hexToRgb(hex: string): [number, number, number] | null {
  const clean = hex.trim().replace('#', '');
  if (clean.length === 3) {
    const r = parseInt(clean[0] + clean[0], 16);
    const g = parseInt(clean[1] + clean[1], 16);
    const b = parseInt(clean[2] + clean[2], 16);
    return Number.isNaN(r + g + b) ? null : [r, g, b];
  }
  if (clean.length === 6) {
    const r = parseInt(clean.slice(0, 2), 16);
    const g = parseInt(clean.slice(2, 4), 16);
    const b = parseInt(clean.slice(4, 6), 16);
    return Number.isNaN(r + g + b) ? null : [r, g, b];
  }
  return null;
}

/**
 * Linear interpolation between two hex colours. `t` is clamped to [0, 1].
 * Deliberately dependency-free and allocation-light — this runs per visible cell.
 */
export function lerpColor(from: string, to: string, t: number): string {
  const a = hexToRgb(from);
  const b = hexToRgb(to);
  if (!a || !b) return to; // tokens/named colours can't be interpolated — fall back
  const k = t < 0 ? 0 : t > 1 ? 1 : t;
  const r = Math.round(a[0] + (b[0] - a[0]) * k);
  const g = Math.round(a[1] + (b[1] - a[1]) * k);
  const bl = Math.round(a[2] + (b[2] - a[2]) * k);
  return `rgb(${r}, ${g}, ${bl})`;
}

export function clamp(value: number, min: number, max: number): number {
  return value < min ? min : value > max ? max : value;
}
