# GSST — Total column only (Grid Response v2)

- `gsst-total.config.json` → GET /grids/gsst/config?params (structure, totals, metadata)
- `gsst-total.data.json` → GET /grids/gsst/data?params → { rowData } (desk rows only, raw values)
- `gsst-total.merged.json` → mergeGrid = {...config, rowData}

Rules
- Heatmap off: gridMetaData.heatmap = null.
- Only Total columns: columnMetadata[*_total].type = "bar", bar.style = "magnitude" (bar from left, length = |value|, tone by sign).
- bar.scaleByRowType = true → desk rows and total rows use separate scales (Global doesn't flatten desk bars).
- Global = pinnedTopRows (GRAND_TOTAL); AMER/EMEA/APAC/X-regions = pinnedBottomRows (SUB_TOTAL).
- Values in $MM; tooltip shows actual value via valueUnit.multiplier.
- Proposed (not yet in v2 contract): bar block, groupToggle. Confirm with services.
